function e(e,t,i,r){var A,s=arguments.length,o=s<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)o=Reflect.decorate(e,t,i,r);else for(var n=e.length-1;n>=0;n--)(A=e[n])&&(o=(s<3?A(o):s>3?A(t,i,o):A(t,i))||o);return s>3&&o&&Object.defineProperty(t,i,o),o}"function"==typeof SuppressedError&&SuppressedError;
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
let t=class extends Event{constructor(e,t,i,r){super("context-request",{bubbles:!0,composed:!0}),this.context=e,this.contextTarget=t,this.callback=i,this.subscribe=r??!1}};
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
let i=class{constructor(e,t,i,r){if(this.subscribe=!1,this.provided=!1,this.value=void 0,this.t=(e,t)=>{this.unsubscribe&&(this.unsubscribe!==t&&(this.provided=!1,this.unsubscribe()),this.subscribe||this.unsubscribe()),this.value=e,this.host.requestUpdate(),this.provided&&!this.subscribe||(this.provided=!0,this.callback&&this.callback(e,t)),this.unsubscribe=t},this.host=e,void 0!==t.context){const e=t;this.context=e.context,this.callback=e.callback,this.subscribe=e.subscribe??!1}else this.context=t,this.callback=i,this.subscribe=r??!1;this.host.addController(this)}hostConnected(){this.dispatchRequest()}hostDisconnected(){this.unsubscribe&&(this.unsubscribe(),this.unsubscribe=void 0)}dispatchRequest(){this.host.dispatchEvent(new t(this.context,this.host,this.t,this.subscribe))}},r=class{get value(){return this.o}set value(e){this.setValue(e)}setValue(e,t=!1){const i=t||!Object.is(e,this.o);this.o=e,i&&this.updateObservers()}constructor(e){this.subscriptions=new Map,this.updateObservers=()=>{for(const[e,{disposer:t}]of this.subscriptions)e(this.o,t)},void 0!==e&&(this.value=e)}addCallback(e,t,i){if(!i)return void e(this.value);this.subscriptions.has(e)||this.subscriptions.set(e,{disposer:()=>{this.subscriptions.delete(e)},consumerHost:t});const{disposer:r}=this.subscriptions.get(e);e(this.value,r)}clearCallbacks(){this.subscriptions.clear()}},A=class extends Event{constructor(e,t){super("context-provider",{bubbles:!0,composed:!0}),this.context=e,this.contextTarget=t}},s=class extends r{constructor(e,i,r){super(void 0!==i.context?i.initialValue:r),this.onContextRequest=e=>{if(e.context!==this.context)return;const t=e.contextTarget??e.composedPath()[0];t!==this.host&&(e.stopPropagation(),this.addCallback(e.callback,t,e.subscribe))},this.onProviderRequest=e=>{if(e.context!==this.context)return;if((e.contextTarget??e.composedPath()[0])===this.host)return;const i=new Set;for(const[e,{consumerHost:r}]of this.subscriptions)i.has(e)||(i.add(e),r.dispatchEvent(new t(this.context,r,e,!0)));e.stopPropagation()},this.host=e,void 0!==i.context?this.context=i.context:this.context=i,this.attachListeners(),this.host.addController?.(this)}attachListeners(){this.host.addEventListener("context-request",this.onContextRequest),this.host.addEventListener("context-provider",this.onProviderRequest)}hostConnected(){this.host.dispatchEvent(new A(this.context,this.host))}};
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
function o({context:e}){return(t,i)=>{const r=new WeakMap;if("object"==typeof i)return{get(){return t.get.call(this)},set(e){return r.get(this).setValue(e),t.set.call(this,e)},init(t){return r.set(this,new s(this,{context:e,initialValue:t})),t}};{t.constructor.addInitializer(t=>{r.set(t,new s(t,{context:e}))});const A=Object.getOwnPropertyDescriptor(t,i);let o;if(void 0===A){const e=new WeakMap;o={get(){return e.get(this)},set(t){r.get(this).setValue(t),e.set(this,t)},configurable:!0,enumerable:!0}}else{const e=A.set;o={...A,set(t){r.get(this).setValue(t),e?.call(this,t)}}}return void Object.defineProperty(t,i,o)}}}
/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function n({context:e,subscribe:t}){return(r,A)=>{"object"==typeof A?A.addInitializer(function(){new i(this,{context:e,callback:e=>{r.set.call(this,e)},subscribe:t})}):r.constructor.addInitializer(r=>{new i(r,{context:e,callback:e=>{r[A]=e},subscribe:t})})}}
/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const a=globalThis,c=a.ShadowRoot&&(void 0===a.ShadyCSS||a.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,l=Symbol(),d=new WeakMap;let u=class{constructor(e,t,i){if(this._$cssResult$=!0,i!==l)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=e,this.t=t}get styleSheet(){let e=this.o;const t=this.t;if(c&&void 0===e){const i=void 0!==t&&1===t.length;i&&(e=d.get(t)),void 0===e&&((this.o=e=new CSSStyleSheet).replaceSync(this.cssText),i&&d.set(t,e))}return e}toString(){return this.cssText}};const h=e=>new u("string"==typeof e?e:e+"",void 0,l),g=(e,...t)=>{const i=1===e.length?e[0]:t.reduce((t,i,r)=>t+(e=>{if(!0===e._$cssResult$)return e.cssText;if("number"==typeof e)return e;throw Error("Value passed to 'css' function must be a 'css' function result: "+e+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(i)+e[r+1],e[0]);return new u(i,e,l)},p=c?e=>e:e=>e instanceof CSSStyleSheet?(e=>{let t="";for(const i of e.cssRules)t+=i.cssText;return h(t)})(e):e,{is:v,defineProperty:m,getOwnPropertyDescriptor:w,getOwnPropertyNames:f,getOwnPropertySymbols:E,getPrototypeOf:C}=Object,B=globalThis,b=B.trustedTypes,I=b?b.emptyScript:"",y=B.reactiveElementPolyfillSupport,Q=(e,t)=>e,D={toAttribute(e,t){switch(t){case Boolean:e=e?I:null;break;case Object:case Array:e=null==e?e:JSON.stringify(e)}return e},fromAttribute(e,t){let i=e;switch(t){case Boolean:i=null!==e;break;case Number:i=null===e?null:Number(e);break;case Object:case Array:try{i=JSON.parse(e)}catch(e){i=null}}return i}},R=(e,t)=>!v(e,t),k={attribute:!0,type:String,converter:D,reflect:!1,useDefault:!1,hasChanged:R};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */Symbol.metadata??=Symbol("metadata"),B.litPropertyMetadata??=new WeakMap;let x=class extends HTMLElement{static addInitializer(e){this._$Ei(),(this.l??=[]).push(e)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(e,t=k){if(t.state&&(t.attribute=!1),this._$Ei(),this.prototype.hasOwnProperty(e)&&((t=Object.create(t)).wrapped=!0),this.elementProperties.set(e,t),!t.noAccessor){const i=Symbol(),r=this.getPropertyDescriptor(e,i,t);void 0!==r&&m(this.prototype,e,r)}}static getPropertyDescriptor(e,t,i){const{get:r,set:A}=w(this.prototype,e)??{get(){return this[t]},set(e){this[t]=e}};return{get:r,set(t){const s=r?.call(this);A?.call(this,t),this.requestUpdate(e,s,i)},configurable:!0,enumerable:!0}}static getPropertyOptions(e){return this.elementProperties.get(e)??k}static _$Ei(){if(this.hasOwnProperty(Q("elementProperties")))return;const e=C(this);e.finalize(),void 0!==e.l&&(this.l=[...e.l]),this.elementProperties=new Map(e.elementProperties)}static finalize(){if(this.hasOwnProperty(Q("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(Q("properties"))){const e=this.properties,t=[...f(e),...E(e)];for(const i of t)this.createProperty(i,e[i])}const e=this[Symbol.metadata];if(null!==e){const t=litPropertyMetadata.get(e);if(void 0!==t)for(const[e,i]of t)this.elementProperties.set(e,i)}this._$Eh=new Map;for(const[e,t]of this.elementProperties){const i=this._$Eu(e,t);void 0!==i&&this._$Eh.set(i,e)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(e){const t=[];if(Array.isArray(e)){const i=new Set(e.flat(1/0).reverse());for(const e of i)t.unshift(p(e))}else void 0!==e&&t.push(p(e));return t}static _$Eu(e,t){const i=t.attribute;return!1===i?void 0:"string"==typeof i?i:"string"==typeof e?e.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise(e=>this.enableUpdating=e),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach(e=>e(this))}addController(e){(this._$EO??=new Set).add(e),void 0!==this.renderRoot&&this.isConnected&&e.hostConnected?.()}removeController(e){this._$EO?.delete(e)}_$E_(){const e=new Map,t=this.constructor.elementProperties;for(const i of t.keys())this.hasOwnProperty(i)&&(e.set(i,this[i]),delete this[i]);e.size>0&&(this._$Ep=e)}createRenderRoot(){const e=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return((e,t)=>{if(c)e.adoptedStyleSheets=t.map(e=>e instanceof CSSStyleSheet?e:e.styleSheet);else for(const i of t){const t=document.createElement("style"),r=a.litNonce;void 0!==r&&t.setAttribute("nonce",r),t.textContent=i.cssText,e.appendChild(t)}})(e,this.constructor.elementStyles),e}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$EO?.forEach(e=>e.hostConnected?.())}enableUpdating(e){}disconnectedCallback(){this._$EO?.forEach(e=>e.hostDisconnected?.())}attributeChangedCallback(e,t,i){this._$AK(e,i)}_$ET(e,t){const i=this.constructor.elementProperties.get(e),r=this.constructor._$Eu(e,i);if(void 0!==r&&!0===i.reflect){const A=(void 0!==i.converter?.toAttribute?i.converter:D).toAttribute(t,i.type);this._$Em=e,null==A?this.removeAttribute(r):this.setAttribute(r,A),this._$Em=null}}_$AK(e,t){const i=this.constructor,r=i._$Eh.get(e);if(void 0!==r&&this._$Em!==r){const e=i.getPropertyOptions(r),A="function"==typeof e.converter?{fromAttribute:e.converter}:void 0!==e.converter?.fromAttribute?e.converter:D;this._$Em=r;const s=A.fromAttribute(t,e.type);this[r]=s??this._$Ej?.get(r)??s,this._$Em=null}}requestUpdate(e,t,i){if(void 0!==e){const r=this.constructor,A=this[e];if(i??=r.getPropertyOptions(e),!((i.hasChanged??R)(A,t)||i.useDefault&&i.reflect&&A===this._$Ej?.get(e)&&!this.hasAttribute(r._$Eu(e,i))))return;this.C(e,t,i)}!1===this.isUpdatePending&&(this._$ES=this._$EP())}C(e,t,{useDefault:i,reflect:r,wrapped:A},s){i&&!(this._$Ej??=new Map).has(e)&&(this._$Ej.set(e,s??t??this[e]),!0!==A||void 0!==s)||(this._$AL.has(e)||(this.hasUpdated||i||(t=void 0),this._$AL.set(e,t)),!0===r&&this._$Em!==e&&(this._$Eq??=new Set).add(e))}async _$EP(){this.isUpdatePending=!0;try{await this._$ES}catch(e){Promise.reject(e)}const e=this.scheduleUpdate();return null!=e&&await e,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??=this.createRenderRoot(),this._$Ep){for(const[e,t]of this._$Ep)this[e]=t;this._$Ep=void 0}const e=this.constructor.elementProperties;if(e.size>0)for(const[t,i]of e){const{wrapped:e}=i,r=this[t];!0!==e||this._$AL.has(t)||void 0===r||this.C(t,void 0,i,r)}}let e=!1;const t=this._$AL;try{e=this.shouldUpdate(t),e?(this.willUpdate(t),this._$EO?.forEach(e=>e.hostUpdate?.()),this.update(t)):this._$EM()}catch(t){throw e=!1,this._$EM(),t}e&&this._$AE(t)}willUpdate(e){}_$AE(e){this._$EO?.forEach(e=>e.hostUpdated?.()),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(e)),this.updated(e)}_$EM(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(e){return!0}update(e){this._$Eq&&=this._$Eq.forEach(e=>this._$ET(e,this[e])),this._$EM()}updated(e){}firstUpdated(e){}};x.elementStyles=[],x.shadowRootOptions={mode:"open"},x[Q("elementProperties")]=new Map,x[Q("finalized")]=new Map,y?.({ReactiveElement:x}),(B.reactiveElementVersions??=[]).push("2.1.1");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const P=globalThis,M=P.trustedTypes,H=M?M.createPolicy("lit-html",{createHTML:e=>e}):void 0,S="$lit$",O=`lit$${Math.random().toFixed(9).slice(2)}$`,q="?"+O,L=`<${q}>`,U=document,T=()=>U.createComment(""),J=e=>null===e||"object"!=typeof e&&"function"!=typeof e,V=Array.isArray,F="[ \t\n\f\r]",z=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,Y=/-->/g,X=/>/g,j=RegExp(`>|${F}(?:([^\\s"'>=/]+)(${F}*=${F}*(?:[^ \t\n\f\r"'\`<>=]|("|')|))|$)`,"g"),K=/'/g,G=/"/g,N=/^(?:script|style|textarea|title)$/i,W=(e=>(t,...i)=>({_$litType$:e,strings:t,values:i}))(1),Z=Symbol.for("lit-noChange"),_=Symbol.for("lit-nothing"),$=new WeakMap,ee=U.createTreeWalker(U,129);function te(e,t){if(!V(e)||!e.hasOwnProperty("raw"))throw Error("invalid template strings array");return void 0!==H?H.createHTML(t):t}const ie=(e,t)=>{const i=e.length-1,r=[];let A,s=2===t?"<svg>":3===t?"<math>":"",o=z;for(let t=0;t<i;t++){const i=e[t];let n,a,c=-1,l=0;for(;l<i.length&&(o.lastIndex=l,a=o.exec(i),null!==a);)l=o.lastIndex,o===z?"!--"===a[1]?o=Y:void 0!==a[1]?o=X:void 0!==a[2]?(N.test(a[2])&&(A=RegExp("</"+a[2],"g")),o=j):void 0!==a[3]&&(o=j):o===j?">"===a[0]?(o=A??z,c=-1):void 0===a[1]?c=-2:(c=o.lastIndex-a[2].length,n=a[1],o=void 0===a[3]?j:'"'===a[3]?G:K):o===G||o===K?o=j:o===Y||o===X?o=z:(o=j,A=void 0);const d=o===j&&e[t+1].startsWith("/>")?" ":"";s+=o===z?i+L:c>=0?(r.push(n),i.slice(0,c)+S+i.slice(c)+O+d):i+O+(-2===c?t:d)}return[te(e,s+(e[i]||"<?>")+(2===t?"</svg>":3===t?"</math>":"")),r]};class re{constructor({strings:e,_$litType$:t},i){let r;this.parts=[];let A=0,s=0;const o=e.length-1,n=this.parts,[a,c]=ie(e,t);if(this.el=re.createElement(a,i),ee.currentNode=this.el.content,2===t||3===t){const e=this.el.content.firstChild;e.replaceWith(...e.childNodes)}for(;null!==(r=ee.nextNode())&&n.length<o;){if(1===r.nodeType){if(r.hasAttributes())for(const e of r.getAttributeNames())if(e.endsWith(S)){const t=c[s++],i=r.getAttribute(e).split(O),o=/([.?@])?(.*)/.exec(t);n.push({type:1,index:A,name:o[2],strings:i,ctor:"."===o[1]?ae:"?"===o[1]?ce:"@"===o[1]?le:ne}),r.removeAttribute(e)}else e.startsWith(O)&&(n.push({type:6,index:A}),r.removeAttribute(e));if(N.test(r.tagName)){const e=r.textContent.split(O),t=e.length-1;if(t>0){r.textContent=M?M.emptyScript:"";for(let i=0;i<t;i++)r.append(e[i],T()),ee.nextNode(),n.push({type:2,index:++A});r.append(e[t],T())}}}else if(8===r.nodeType)if(r.data===q)n.push({type:2,index:A});else{let e=-1;for(;-1!==(e=r.data.indexOf(O,e+1));)n.push({type:7,index:A}),e+=O.length-1}A++}}static createElement(e,t){const i=U.createElement("template");return i.innerHTML=e,i}}function Ae(e,t,i=e,r){if(t===Z)return t;let A=void 0!==r?i._$Co?.[r]:i._$Cl;const s=J(t)?void 0:t._$litDirective$;return A?.constructor!==s&&(A?._$AO?.(!1),void 0===s?A=void 0:(A=new s(e),A._$AT(e,i,r)),void 0!==r?(i._$Co??=[])[r]=A:i._$Cl=A),void 0!==A&&(t=Ae(e,A._$AS(e,t.values),A,r)),t}class se{constructor(e,t){this._$AV=[],this._$AN=void 0,this._$AD=e,this._$AM=t}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(e){const{el:{content:t},parts:i}=this._$AD,r=(e?.creationScope??U).importNode(t,!0);ee.currentNode=r;let A=ee.nextNode(),s=0,o=0,n=i[0];for(;void 0!==n;){if(s===n.index){let t;2===n.type?t=new oe(A,A.nextSibling,this,e):1===n.type?t=new n.ctor(A,n.name,n.strings,this,e):6===n.type&&(t=new de(A,this,e)),this._$AV.push(t),n=i[++o]}s!==n?.index&&(A=ee.nextNode(),s++)}return ee.currentNode=U,r}p(e){let t=0;for(const i of this._$AV)void 0!==i&&(void 0!==i.strings?(i._$AI(e,i,t),t+=i.strings.length-2):i._$AI(e[t])),t++}}class oe{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(e,t,i,r){this.type=2,this._$AH=_,this._$AN=void 0,this._$AA=e,this._$AB=t,this._$AM=i,this.options=r,this._$Cv=r?.isConnected??!0}get parentNode(){let e=this._$AA.parentNode;const t=this._$AM;return void 0!==t&&11===e?.nodeType&&(e=t.parentNode),e}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(e,t=this){e=Ae(this,e,t),J(e)?e===_||null==e||""===e?(this._$AH!==_&&this._$AR(),this._$AH=_):e!==this._$AH&&e!==Z&&this._(e):void 0!==e._$litType$?this.$(e):void 0!==e.nodeType?this.T(e):(e=>V(e)||"function"==typeof e?.[Symbol.iterator])(e)?this.k(e):this._(e)}O(e){return this._$AA.parentNode.insertBefore(e,this._$AB)}T(e){this._$AH!==e&&(this._$AR(),this._$AH=this.O(e))}_(e){this._$AH!==_&&J(this._$AH)?this._$AA.nextSibling.data=e:this.T(U.createTextNode(e)),this._$AH=e}$(e){const{values:t,_$litType$:i}=e,r="number"==typeof i?this._$AC(e):(void 0===i.el&&(i.el=re.createElement(te(i.h,i.h[0]),this.options)),i);if(this._$AH?._$AD===r)this._$AH.p(t);else{const e=new se(r,this),i=e.u(this.options);e.p(t),this.T(i),this._$AH=e}}_$AC(e){let t=$.get(e.strings);return void 0===t&&$.set(e.strings,t=new re(e)),t}k(e){V(this._$AH)||(this._$AH=[],this._$AR());const t=this._$AH;let i,r=0;for(const A of e)r===t.length?t.push(i=new oe(this.O(T()),this.O(T()),this,this.options)):i=t[r],i._$AI(A),r++;r<t.length&&(this._$AR(i&&i._$AB.nextSibling,r),t.length=r)}_$AR(e=this._$AA.nextSibling,t){for(this._$AP?.(!1,!0,t);e!==this._$AB;){const t=e.nextSibling;e.remove(),e=t}}setConnected(e){void 0===this._$AM&&(this._$Cv=e,this._$AP?.(e))}}class ne{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(e,t,i,r,A){this.type=1,this._$AH=_,this._$AN=void 0,this.element=e,this.name=t,this._$AM=r,this.options=A,i.length>2||""!==i[0]||""!==i[1]?(this._$AH=Array(i.length-1).fill(new String),this.strings=i):this._$AH=_}_$AI(e,t=this,i,r){const A=this.strings;let s=!1;if(void 0===A)e=Ae(this,e,t,0),s=!J(e)||e!==this._$AH&&e!==Z,s&&(this._$AH=e);else{const r=e;let o,n;for(e=A[0],o=0;o<A.length-1;o++)n=Ae(this,r[i+o],t,o),n===Z&&(n=this._$AH[o]),s||=!J(n)||n!==this._$AH[o],n===_?e=_:e!==_&&(e+=(n??"")+A[o+1]),this._$AH[o]=n}s&&!r&&this.j(e)}j(e){e===_?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,e??"")}}class ae extends ne{constructor(){super(...arguments),this.type=3}j(e){this.element[this.name]=e===_?void 0:e}}class ce extends ne{constructor(){super(...arguments),this.type=4}j(e){this.element.toggleAttribute(this.name,!!e&&e!==_)}}class le extends ne{constructor(e,t,i,r,A){super(e,t,i,r,A),this.type=5}_$AI(e,t=this){if((e=Ae(this,e,t,0)??_)===Z)return;const i=this._$AH,r=e===_&&i!==_||e.capture!==i.capture||e.once!==i.once||e.passive!==i.passive,A=e!==_&&(i===_||r);r&&this.element.removeEventListener(this.name,this,i),A&&this.element.addEventListener(this.name,this,e),this._$AH=e}handleEvent(e){"function"==typeof this._$AH?this._$AH.call(this.options?.host??this.element,e):this._$AH.handleEvent(e)}}class de{constructor(e,t,i){this.element=e,this.type=6,this._$AN=void 0,this._$AM=t,this.options=i}get _$AU(){return this._$AM._$AU}_$AI(e){Ae(this,e)}}const ue={I:oe},he=P.litHtmlPolyfillSupport;he?.(re,oe),(P.litHtmlVersions??=[]).push("3.3.1");const ge=(e,t,i)=>{const r=i?.renderBefore??t;let A=r._$litPart$;if(void 0===A){const e=i?.renderBefore??null;r._$litPart$=A=new oe(t.insertBefore(T(),e),e,void 0,i??{})}return A._$AI(e),A
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */},pe=globalThis;let ve=class extends x{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){const e=super.createRenderRoot();return this.renderOptions.renderBefore??=e.firstChild,e}update(e){const t=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(e),this._$Do=ge(t,this.renderRoot,this.renderOptions)}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0)}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1)}render(){return Z}};ve._$litElement$=!0,ve.finalized=!0,pe.litElementHydrateSupport?.({LitElement:ve});const me=pe.litElementPolyfillSupport;me?.({LitElement:ve}),(pe.litElementVersions??=[]).push("4.2.1");
/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const we=Symbol.for(""),fe=e=>{if(e?.r===we)return e?._$litStatic$},Ee=(e,...t)=>({_$litStatic$:t.reduce((t,i,r)=>t+(e=>{if(void 0!==e._$litStatic$)return e._$litStatic$;throw Error(`Value passed to 'literal' function must be a 'literal' result: ${e}. Use 'unsafeStatic' to pass non-literal values, but\n            take care to ensure page security.`)})(i)+e[r+1],e[0]),r:we}),Ce=new Map,Be=(e=>(t,...i)=>{const r=i.length;let A,s;const o=[],n=[];let a,c=0,l=!1;for(;c<r;){for(a=t[c];c<r&&void 0!==(s=i[c],A=fe(s));)a+=A+t[++c],l=!0;c!==r&&n.push(s),o.push(a),c++}if(c===r&&o.push(t[r]),l){const e=o.join("$$lit$$");void 0===(t=Ce.get(e))&&(o.raw=o,Ce.set(e,t=o)),i=n}return e(t,...i)})(W),be=e=>(t,i)=>{void 0!==i?i.addInitializer(()=>{customElements.define(e,t)}):customElements.define(e,t)},Ie={attribute:!0,type:String,converter:D,reflect:!1,hasChanged:R},ye=(e=Ie,t,i)=>{const{kind:r,metadata:A}=i;let s=globalThis.litPropertyMetadata.get(A);if(void 0===s&&globalThis.litPropertyMetadata.set(A,s=new Map),"setter"===r&&((e=Object.create(e)).wrapped=!0),s.set(i.name,e),"accessor"===r){const{name:r}=i;return{set(i){const A=t.get.call(this);t.set.call(this,i),this.requestUpdate(r,A,e)},init(t){return void 0!==t&&this.C(r,void 0,e,t),t}}}if("setter"===r){const{name:r}=i;return function(i){const A=this[r];t.call(this,i),this.requestUpdate(r,A,e)}}throw Error("Unsupported decorator location: "+r)};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function Qe(e){return(t,i)=>"object"==typeof i?ye(e,t,i):((e,t,i)=>{const r=t.hasOwnProperty(i);return t.constructor.createProperty(i,e),r?Object.getOwnPropertyDescriptor(t,i):void 0})(e,t,i)}
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function De(e){return Qe({...e,state:!0,attribute:!1})}
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Re=(e,t,i)=>(i.configurable=!0,i.enumerable=!0,Reflect.decorate&&"object"!=typeof t&&Object.defineProperty(e,t,i),i);
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function ke(e,t){return(t,i,r)=>Re(t,i,{get(){return(t=>t.renderRoot?.querySelector(e)??null)(this)}})}
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let xe;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Pe=1,Me=3,He=4,Se=e=>(...t)=>({_$litDirective$:e,values:t});let Oe=class{constructor(e){}get _$AU(){return this._$AM._$AU}_$AT(e,t,i){this._$Ct=e,this._$AM=t,this._$Ci=i}_$AS(e,t){return this.update(e,t)}update(e,t){return this.render(...t)}};
/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const{I:qe}=ue,Le=(e,t)=>void 0!==e?._$litType$,Ue=()=>document.createComment(""),Te=(e,t,i)=>{const r=e._$AA.parentNode,A=e._$AB;if(void 0===i){const t=r.insertBefore(Ue(),A),s=r.insertBefore(Ue(),A);i=new qe(t,s,e,e.options)}else{const t=i._$AB.nextSibling,s=i._$AM,o=s!==e;if(o){let t;i._$AQ?.(e),i._$AM=e,void 0!==i._$AP&&(t=e._$AU)!==s._$AU&&i._$AP(t)}if(t!==A||o){let e=i._$AA;for(;e!==t;){const t=e.nextSibling;r.insertBefore(e,A),e=t}}}return i},Je={},Ve=(e,t=Je)=>e._$AH=t,Fe=e=>e._$AH,ze=e=>(e=>null!=e?._$litType$?.h)(e)?e._$litType$.h:e.strings,Ye=Se(class extends Oe{constructor(e){super(e),this.et=new WeakMap}render(e){return[e]}update(e,[t]){const i=Le(this.it)?ze(this.it):null,r=Le(t)?ze(t):null;if(null!==i&&(null===r||i!==r)){const t=Fe(e).pop();let r=this.et.get(i);if(void 0===r){const e=document.createDocumentFragment();r=ge(_,e),r.setConnected(!1),this.et.set(i,r)}Ve(r,[t]),Te(r,0,t)}if(null!==r){if(null===i||i!==r){const t=this.et.get(r);if(void 0!==t){const i=Fe(t).pop();(e=>{e._$AR()})(e),Te(e,0,i),Ve(e,[i])}}this.it=t}else this.it=void 0;return this.render(t)}});
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var Xe=g`
  :host {
    display: block;
  }

  .input {
    flex: 1 1 auto;
    display: inline-flex;
    align-items: stretch;
    justify-content: start;
    position: relative;
    width: 100%;
    font-family: var(--sl-input-font-family);
    font-weight: var(--sl-input-font-weight);
    letter-spacing: var(--sl-input-letter-spacing);
    vertical-align: middle;
    overflow: hidden;
    cursor: text;
    transition:
      var(--sl-transition-fast) color,
      var(--sl-transition-fast) border,
      var(--sl-transition-fast) box-shadow,
      var(--sl-transition-fast) background-color;
  }

  /* Standard inputs */
  .input--standard {
    background-color: var(--sl-input-background-color);
    border: solid var(--sl-input-border-width) var(--sl-input-border-color);
  }

  .input--standard:hover:not(.input--disabled) {
    background-color: var(--sl-input-background-color-hover);
    border-color: var(--sl-input-border-color-hover);
  }

  .input--standard.input--focused:not(.input--disabled) {
    background-color: var(--sl-input-background-color-focus);
    border-color: var(--sl-input-border-color-focus);
    box-shadow: 0 0 0 var(--sl-focus-ring-width) var(--sl-input-focus-ring-color);
  }

  .input--standard.input--focused:not(.input--disabled) .input__control {
    color: var(--sl-input-color-focus);
  }

  .input--standard.input--disabled {
    background-color: var(--sl-input-background-color-disabled);
    border-color: var(--sl-input-border-color-disabled);
    opacity: 0.5;
    cursor: not-allowed;
  }

  .input--standard.input--disabled .input__control {
    color: var(--sl-input-color-disabled);
  }

  .input--standard.input--disabled .input__control::placeholder {
    color: var(--sl-input-placeholder-color-disabled);
  }

  /* Filled inputs */
  .input--filled {
    border: none;
    background-color: var(--sl-input-filled-background-color);
    color: var(--sl-input-color);
  }

  .input--filled:hover:not(.input--disabled) {
    background-color: var(--sl-input-filled-background-color-hover);
  }

  .input--filled.input--focused:not(.input--disabled) {
    background-color: var(--sl-input-filled-background-color-focus);
    outline: var(--sl-focus-ring);
    outline-offset: var(--sl-focus-ring-offset);
  }

  .input--filled.input--disabled {
    background-color: var(--sl-input-filled-background-color-disabled);
    opacity: 0.5;
    cursor: not-allowed;
  }

  .input__control {
    flex: 1 1 auto;
    font-family: inherit;
    font-size: inherit;
    font-weight: inherit;
    min-width: 0;
    height: 100%;
    color: var(--sl-input-color);
    border: none;
    background: inherit;
    box-shadow: none;
    padding: 0;
    margin: 0;
    cursor: inherit;
    -webkit-appearance: none;
  }

  .input__control::-webkit-search-decoration,
  .input__control::-webkit-search-cancel-button,
  .input__control::-webkit-search-results-button,
  .input__control::-webkit-search-results-decoration {
    -webkit-appearance: none;
  }

  .input__control:-webkit-autofill,
  .input__control:-webkit-autofill:hover,
  .input__control:-webkit-autofill:focus,
  .input__control:-webkit-autofill:active {
    box-shadow: 0 0 0 var(--sl-input-height-large) var(--sl-input-background-color-hover) inset !important;
    -webkit-text-fill-color: var(--sl-color-primary-500);
    caret-color: var(--sl-input-color);
  }

  .input--filled .input__control:-webkit-autofill,
  .input--filled .input__control:-webkit-autofill:hover,
  .input--filled .input__control:-webkit-autofill:focus,
  .input--filled .input__control:-webkit-autofill:active {
    box-shadow: 0 0 0 var(--sl-input-height-large) var(--sl-input-filled-background-color) inset !important;
  }

  .input__control::placeholder {
    color: var(--sl-input-placeholder-color);
    user-select: none;
    -webkit-user-select: none;
  }

  .input:hover:not(.input--disabled) .input__control {
    color: var(--sl-input-color-hover);
  }

  .input__control:focus {
    outline: none;
  }

  .input__prefix,
  .input__suffix {
    display: inline-flex;
    flex: 0 0 auto;
    align-items: center;
    cursor: default;
  }

  .input__prefix ::slotted(sl-icon),
  .input__suffix ::slotted(sl-icon) {
    color: var(--sl-input-icon-color);
  }

  /*
   * Size modifiers
   */

  .input--small {
    border-radius: var(--sl-input-border-radius-small);
    font-size: var(--sl-input-font-size-small);
    height: var(--sl-input-height-small);
  }

  .input--small .input__control {
    height: calc(var(--sl-input-height-small) - var(--sl-input-border-width) * 2);
    padding: 0 var(--sl-input-spacing-small);
  }

  .input--small .input__clear,
  .input--small .input__password-toggle {
    width: calc(1em + var(--sl-input-spacing-small) * 2);
  }

  .input--small .input__prefix ::slotted(*) {
    margin-inline-start: var(--sl-input-spacing-small);
  }

  .input--small .input__suffix ::slotted(*) {
    margin-inline-end: var(--sl-input-spacing-small);
  }

  .input--medium {
    border-radius: var(--sl-input-border-radius-medium);
    font-size: var(--sl-input-font-size-medium);
    height: var(--sl-input-height-medium);
  }

  .input--medium .input__control {
    height: calc(var(--sl-input-height-medium) - var(--sl-input-border-width) * 2);
    padding: 0 var(--sl-input-spacing-medium);
  }

  .input--medium .input__clear,
  .input--medium .input__password-toggle {
    width: calc(1em + var(--sl-input-spacing-medium) * 2);
  }

  .input--medium .input__prefix ::slotted(*) {
    margin-inline-start: var(--sl-input-spacing-medium);
  }

  .input--medium .input__suffix ::slotted(*) {
    margin-inline-end: var(--sl-input-spacing-medium);
  }

  .input--large {
    border-radius: var(--sl-input-border-radius-large);
    font-size: var(--sl-input-font-size-large);
    height: var(--sl-input-height-large);
  }

  .input--large .input__control {
    height: calc(var(--sl-input-height-large) - var(--sl-input-border-width) * 2);
    padding: 0 var(--sl-input-spacing-large);
  }

  .input--large .input__clear,
  .input--large .input__password-toggle {
    width: calc(1em + var(--sl-input-spacing-large) * 2);
  }

  .input--large .input__prefix ::slotted(*) {
    margin-inline-start: var(--sl-input-spacing-large);
  }

  .input--large .input__suffix ::slotted(*) {
    margin-inline-end: var(--sl-input-spacing-large);
  }

  /*
   * Pill modifier
   */

  .input--pill.input--small {
    border-radius: var(--sl-input-height-small);
  }

  .input--pill.input--medium {
    border-radius: var(--sl-input-height-medium);
  }

  .input--pill.input--large {
    border-radius: var(--sl-input-height-large);
  }

  /*
   * Clearable + Password Toggle
   */

  .input__clear,
  .input__password-toggle {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: inherit;
    color: var(--sl-input-icon-color);
    border: none;
    background: none;
    padding: 0;
    transition: var(--sl-transition-fast) color;
    cursor: pointer;
  }

  .input__clear:hover,
  .input__password-toggle:hover {
    color: var(--sl-input-icon-color-hover);
  }

  .input__clear:focus,
  .input__password-toggle:focus {
    outline: none;
  }

  /* Don't show the browser's password toggle in Edge */
  ::-ms-reveal {
    display: none;
  }

  /* Hide the built-in number spinner */
  .input--no-spin-buttons input[type='number']::-webkit-outer-spin-button,
  .input--no-spin-buttons input[type='number']::-webkit-inner-spin-button {
    -webkit-appearance: none;
    display: none;
  }

  .input--no-spin-buttons input[type='number'] {
    -moz-appearance: textfield;
  }
`,je=g`
  .form-control .form-control__label {
    display: none;
  }

  .form-control .form-control__help-text {
    display: none;
  }

  /* Label */
  .form-control--has-label .form-control__label {
    display: inline-block;
    color: var(--sl-input-label-color);
    margin-bottom: var(--sl-spacing-3x-small);
  }

  .form-control--has-label.form-control--small .form-control__label {
    font-size: var(--sl-input-label-font-size-small);
  }

  .form-control--has-label.form-control--medium .form-control__label {
    font-size: var(--sl-input-label-font-size-medium);
  }

  .form-control--has-label.form-control--large .form-control__label {
    font-size: var(--sl-input-label-font-size-large);
  }

  :host([required]) .form-control--has-label .form-control__label::after {
    content: var(--sl-input-required-content);
    margin-inline-start: var(--sl-input-required-content-offset);
    color: var(--sl-input-required-content-color);
  }

  /* Help text */
  .form-control--has-help-text .form-control__help-text {
    display: block;
    color: var(--sl-input-help-text-color);
    margin-top: var(--sl-spacing-3x-small);
  }

  .form-control--has-help-text.form-control--small .form-control__help-text {
    font-size: var(--sl-input-help-text-font-size-small);
  }

  .form-control--has-help-text.form-control--medium .form-control__help-text {
    font-size: var(--sl-input-help-text-font-size-medium);
  }

  .form-control--has-help-text.form-control--large .form-control__help-text {
    font-size: var(--sl-input-help-text-font-size-large);
  }

  .form-control--has-help-text.form-control--radio-group .form-control__help-text {
    margin-top: var(--sl-spacing-2x-small);
  }
`,Ke=Object.defineProperty,Ge=Object.defineProperties,Ne=Object.getOwnPropertyDescriptor,We=Object.getOwnPropertyDescriptors,Ze=Object.getOwnPropertySymbols,_e=Object.prototype.hasOwnProperty,$e=Object.prototype.propertyIsEnumerable,et=e=>{throw TypeError(e)},tt=(e,t,i)=>t in e?Ke(e,t,{enumerable:!0,configurable:!0,writable:!0,value:i}):e[t]=i,it=(e,t)=>{for(var i in t||(t={}))_e.call(t,i)&&tt(e,i,t[i]);if(Ze)for(var i of Ze(t))$e.call(t,i)&&tt(e,i,t[i]);return e},rt=(e,t)=>Ge(e,We(t)),At=(e,t,i,r)=>{for(var A,s=r>1?void 0:r?Ne(t,i):t,o=e.length-1;o>=0;o--)(A=e[o])&&(s=(r?A(t,i,s):A(s))||s);return r&&s&&Ke(t,i,s),s},st=(e,t,i)=>t.has(e)||et("Cannot "+i),ot=new WeakMap,nt=new WeakMap,at=new WeakMap,ct=new WeakSet,lt=new WeakMap,dt=class{constructor(e,t){this.handleFormData=e=>{const t=this.options.disabled(this.host),i=this.options.name(this.host),r=this.options.value(this.host),A="sl-button"===this.host.tagName.toLowerCase();this.host.isConnected&&!t&&!A&&"string"==typeof i&&i.length>0&&void 0!==r&&(Array.isArray(r)?r.forEach(t=>{e.formData.append(i,t.toString())}):e.formData.append(i,r.toString()))},this.handleFormSubmit=e=>{var t;const i=this.options.disabled(this.host),r=this.options.reportValidity;this.form&&!this.form.noValidate&&(null==(t=ot.get(this.form))||t.forEach(e=>{this.setUserInteracted(e,!0)})),!this.form||this.form.noValidate||i||r(this.host)||(e.preventDefault(),e.stopImmediatePropagation())},this.handleFormReset=()=>{this.options.setValue(this.host,this.options.defaultValue(this.host)),this.setUserInteracted(this.host,!1),lt.set(this.host,[])},this.handleInteraction=e=>{const t=lt.get(this.host);t.includes(e.type)||t.push(e.type),t.length===this.options.assumeInteractionOn.length&&this.setUserInteracted(this.host,!0)},this.checkFormValidity=()=>{if(this.form&&!this.form.noValidate){const e=this.form.querySelectorAll("*");for(const t of e)if("function"==typeof t.checkValidity&&!t.checkValidity())return!1}return!0},this.reportFormValidity=()=>{if(this.form&&!this.form.noValidate){const e=this.form.querySelectorAll("*");for(const t of e)if("function"==typeof t.reportValidity&&!t.reportValidity())return!1}return!0},(this.host=e).addController(this),this.options=it({form:e=>{const t=e.form;if(t){const i=e.getRootNode().querySelector(`#${t}`);if(i)return i}return e.closest("form")},name:e=>e.name,value:e=>e.value,defaultValue:e=>e.defaultValue,disabled:e=>{var t;return null!=(t=e.disabled)&&t},reportValidity:e=>"function"!=typeof e.reportValidity||e.reportValidity(),checkValidity:e=>"function"!=typeof e.checkValidity||e.checkValidity(),setValue:(e,t)=>e.value=t,assumeInteractionOn:["sl-input"]},t)}hostConnected(){const e=this.options.form(this.host);e&&this.attachForm(e),lt.set(this.host,[]),this.options.assumeInteractionOn.forEach(e=>{this.host.addEventListener(e,this.handleInteraction)})}hostDisconnected(){this.detachForm(),lt.delete(this.host),this.options.assumeInteractionOn.forEach(e=>{this.host.removeEventListener(e,this.handleInteraction)})}hostUpdated(){const e=this.options.form(this.host);e||this.detachForm(),e&&this.form!==e&&(this.detachForm(),this.attachForm(e)),this.host.hasUpdated&&this.setValidity(this.host.validity.valid)}attachForm(e){e?(this.form=e,ot.has(this.form)?ot.get(this.form).add(this.host):ot.set(this.form,new Set([this.host])),this.form.addEventListener("formdata",this.handleFormData),this.form.addEventListener("submit",this.handleFormSubmit),this.form.addEventListener("reset",this.handleFormReset),nt.has(this.form)||(nt.set(this.form,this.form.reportValidity),this.form.reportValidity=()=>this.reportFormValidity()),at.has(this.form)||(at.set(this.form,this.form.checkValidity),this.form.checkValidity=()=>this.checkFormValidity())):this.form=void 0}detachForm(){if(!this.form)return;const e=ot.get(this.form);e&&(e.delete(this.host),e.size<=0&&(this.form.removeEventListener("formdata",this.handleFormData),this.form.removeEventListener("submit",this.handleFormSubmit),this.form.removeEventListener("reset",this.handleFormReset),nt.has(this.form)&&(this.form.reportValidity=nt.get(this.form),nt.delete(this.form)),at.has(this.form)&&(this.form.checkValidity=at.get(this.form),at.delete(this.form)),this.form=void 0))}setUserInteracted(e,t){t?ct.add(e):ct.delete(e),e.requestUpdate()}doAction(e,t){if(this.form){const i=document.createElement("button");i.type=e,i.style.position="absolute",i.style.width="0",i.style.height="0",i.style.clipPath="inset(50%)",i.style.overflow="hidden",i.style.whiteSpace="nowrap",t&&(i.name=t.name,i.value=t.value,["formaction","formenctype","formmethod","formnovalidate","formtarget"].forEach(e=>{t.hasAttribute(e)&&i.setAttribute(e,t.getAttribute(e))})),this.form.append(i),i.click(),i.remove()}}getForm(){var e;return null!=(e=this.form)?e:null}reset(e){this.doAction("reset",e)}submit(e){this.doAction("submit",e)}setValidity(e){const t=this.host,i=Boolean(ct.has(t)),r=Boolean(t.required);t.toggleAttribute("data-required",r),t.toggleAttribute("data-optional",!r),t.toggleAttribute("data-invalid",!e),t.toggleAttribute("data-valid",e),t.toggleAttribute("data-user-invalid",!e&&i),t.toggleAttribute("data-user-valid",e&&i)}updateValidity(){const e=this.host;this.setValidity(e.validity.valid)}emitInvalidEvent(e){const t=new CustomEvent("sl-invalid",{bubbles:!1,composed:!1,cancelable:!0,detail:{}});e||t.preventDefault(),this.host.dispatchEvent(t)||null==e||e.preventDefault()}},ut=Object.freeze({badInput:!1,customError:!1,patternMismatch:!1,rangeOverflow:!1,rangeUnderflow:!1,stepMismatch:!1,tooLong:!1,tooShort:!1,typeMismatch:!1,valid:!0,valueMissing:!1});Object.freeze(rt(it({},ut),{valid:!1,valueMissing:!0})),Object.freeze(rt(it({},ut),{valid:!1,customError:!0}));var ht=class{constructor(e,...t){this.slotNames=[],this.handleSlotChange=e=>{const t=e.target;(this.slotNames.includes("[default]")&&!t.name||t.name&&this.slotNames.includes(t.name))&&this.host.requestUpdate()},(this.host=e).addController(this),this.slotNames=t}hasDefaultSlot(){return[...this.host.childNodes].some(e=>{if(e.nodeType===e.TEXT_NODE&&""!==e.textContent.trim())return!0;if(e.nodeType===e.ELEMENT_NODE){const t=e;if("sl-visually-hidden"===t.tagName.toLowerCase())return!1;if(!t.hasAttribute("slot"))return!0}return!1})}hasNamedSlot(e){return null!==this.host.querySelector(`:scope > [slot="${e}"]`)}test(e){return"[default]"===e?this.hasDefaultSlot():this.hasNamedSlot(e)}hostConnected(){this.host.shadowRoot.addEventListener("slotchange",this.handleSlotChange)}hostDisconnected(){this.host.shadowRoot.removeEventListener("slotchange",this.handleSlotChange)}};const gt=new Set,pt=new Map;let vt,mt="ltr",wt="en";const ft="undefined"!=typeof MutationObserver&&"undefined"!=typeof document&&void 0!==document.documentElement;if(ft){const e=new MutationObserver(Ct);mt=document.documentElement.dir||"ltr",wt=document.documentElement.lang||navigator.language,e.observe(document.documentElement,{attributes:!0,attributeFilter:["dir","lang"]})}function Et(...e){e.map(e=>{const t=e.$code.toLowerCase();pt.has(t)?pt.set(t,Object.assign(Object.assign({},pt.get(t)),e)):pt.set(t,e),vt||(vt=e)}),Ct()}function Ct(){ft&&(mt=document.documentElement.dir||"ltr",wt=document.documentElement.lang||navigator.language),[...gt.keys()].map(e=>{"function"==typeof e.requestUpdate&&e.requestUpdate()})}let Bt=class{constructor(e){this.host=e,this.host.addController(this)}hostConnected(){gt.add(this.host)}hostDisconnected(){gt.delete(this.host)}dir(){return`${this.host.dir||mt}`.toLowerCase()}lang(){return`${this.host.lang||wt}`.toLowerCase()}getTranslationData(e){var t,i;const r=new Intl.Locale(e.replace(/_/g,"-")),A=null==r?void 0:r.language.toLowerCase(),s=null!==(i=null===(t=null==r?void 0:r.region)||void 0===t?void 0:t.toLowerCase())&&void 0!==i?i:"";return{locale:r,language:A,region:s,primary:pt.get(`${A}-${s}`),secondary:pt.get(A)}}exists(e,t){var i;const{primary:r,secondary:A}=this.getTranslationData(null!==(i=t.lang)&&void 0!==i?i:this.lang());return t=Object.assign({includeFallback:!1},t),!!(r&&r[e]||A&&A[e]||t.includeFallback&&vt&&vt[e])}term(e,...t){const{primary:i,secondary:r}=this.getTranslationData(this.lang());let A;if(i&&i[e])A=i[e];else if(r&&r[e])A=r[e];else{if(!vt||!vt[e])return console.error(`No translation found for: ${String(e)}`),String(e);A=vt[e]}return"function"==typeof A?A(...t):A}date(e,t){return e=new Date(e),new Intl.DateTimeFormat(this.lang(),t).format(e)}number(e,t){return e=Number(e),isNaN(e)?"":new Intl.NumberFormat(this.lang(),t).format(e)}relativeTime(e,t,i){return new Intl.RelativeTimeFormat(this.lang(),i).format(e,t)}};var bt={$code:"en",$name:"English",$dir:"ltr",carousel:"Carousel",clearEntry:"Clear entry",close:"Close",copied:"Copied",copy:"Copy",currentValue:"Current value",error:"Error",goToSlide:(e,t)=>`Go to slide ${e} of ${t}`,hidePassword:"Hide password",loading:"Loading",nextSlide:"Next slide",numOptionsSelected:e=>0===e?"No options selected":1===e?"1 option selected":`${e} options selected`,previousSlide:"Previous slide",progress:"Progress",remove:"Remove",resize:"Resize",scrollToEnd:"Scroll to end",scrollToStart:"Scroll to start",selectAColorFromTheScreen:"Select a color from the screen",showPassword:"Show password",slideNum:e=>`Slide ${e}`,toggleColorFormat:"Toggle color format"};Et(bt);var It=bt,yt=class extends Bt{};Et(It);var Qt="";function Dt(e){Qt=e}var Rt={name:"default",resolver:e=>function(e=""){if(!Qt){const e=[...document.getElementsByTagName("script")],t=e.find(e=>e.hasAttribute("data-shoelace"));if(t)Dt(t.getAttribute("data-shoelace"));else{const t=e.find(e=>/shoelace(\.min)?\.js($|\?)/.test(e.src)||/shoelace-autoloader(\.min)?\.js($|\?)/.test(e.src));let i="";t&&(i=t.getAttribute("src")),Dt(i.split("/").slice(0,-1).join("/"))}}return Qt.replace(/\/$/,"")+(e?`/${e.replace(/^\//,"")}`:"")}(`assets/icons/${e}.svg`)},kt={caret:'\n    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">\n      <polyline points="6 9 12 15 18 9"></polyline>\n    </svg>\n  ',check:'\n    <svg part="checked-icon" class="checkbox__icon" viewBox="0 0 16 16">\n      <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="round">\n        <g stroke="currentColor">\n          <g transform="translate(3.428571, 3.428571)">\n            <path d="M0,5.71428571 L3.42857143,9.14285714"></path>\n            <path d="M9.14285714,0 L3.42857143,9.14285714"></path>\n          </g>\n        </g>\n      </g>\n    </svg>\n  ',"chevron-down":'\n    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-down" viewBox="0 0 16 16">\n      <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>\n    </svg>\n  ',"chevron-left":'\n    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-left" viewBox="0 0 16 16">\n      <path fill-rule="evenodd" d="M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z"/>\n    </svg>\n  ',"chevron-right":'\n    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-right" viewBox="0 0 16 16">\n      <path fill-rule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"/>\n    </svg>\n  ',copy:'\n    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-copy" viewBox="0 0 16 16">\n      <path fill-rule="evenodd" d="M4 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V2Zm2-1a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H6ZM2 5a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1v-1h1v1a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h1v1H2Z"/>\n    </svg>\n  ',eye:'\n    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye" viewBox="0 0 16 16">\n      <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.133 13.133 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.133 13.133 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5c-2.12 0-3.879-1.168-5.168-2.457A13.134 13.134 0 0 1 1.172 8z"/>\n      <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z"/>\n    </svg>\n  ',"eye-slash":'\n    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye-slash" viewBox="0 0 16 16">\n      <path d="M13.359 11.238C15.06 9.72 16 8 16 8s-3-5.5-8-5.5a7.028 7.028 0 0 0-2.79.588l.77.771A5.944 5.944 0 0 1 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.134 13.134 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755-.165.165-.337.328-.517.486l.708.709z"/>\n      <path d="M11.297 9.176a3.5 3.5 0 0 0-4.474-4.474l.823.823a2.5 2.5 0 0 1 2.829 2.829l.822.822zm-2.943 1.299.822.822a3.5 3.5 0 0 1-4.474-4.474l.823.823a2.5 2.5 0 0 0 2.829 2.829z"/>\n      <path d="M3.35 5.47c-.18.16-.353.322-.518.487A13.134 13.134 0 0 0 1.172 8l.195.288c.335.48.83 1.12 1.465 1.755C4.121 11.332 5.881 12.5 8 12.5c.716 0 1.39-.133 2.02-.36l.77.772A7.029 7.029 0 0 1 8 13.5C3 13.5 0 8 0 8s.939-1.721 2.641-3.238l.708.709zm10.296 8.884-12-12 .708-.708 12 12-.708.708z"/>\n    </svg>\n  ',eyedropper:'\n    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eyedropper" viewBox="0 0 16 16">\n      <path d="M13.354.646a1.207 1.207 0 0 0-1.708 0L8.5 3.793l-.646-.647a.5.5 0 1 0-.708.708L8.293 5l-7.147 7.146A.5.5 0 0 0 1 12.5v1.793l-.854.853a.5.5 0 1 0 .708.707L1.707 15H3.5a.5.5 0 0 0 .354-.146L11 7.707l1.146 1.147a.5.5 0 0 0 .708-.708l-.647-.646 3.147-3.146a1.207 1.207 0 0 0 0-1.708l-2-2zM2 12.707l7-7L10.293 7l-7 7H2v-1.293z"></path>\n    </svg>\n  ',"grip-vertical":'\n    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-grip-vertical" viewBox="0 0 16 16">\n      <path d="M7 2a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 5a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"></path>\n    </svg>\n  ',indeterminate:'\n    <svg part="indeterminate-icon" class="checkbox__icon" viewBox="0 0 16 16">\n      <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="round">\n        <g stroke="currentColor" stroke-width="2">\n          <g transform="translate(2.285714, 6.857143)">\n            <path d="M10.2857143,1.14285714 L1.14285714,1.14285714"></path>\n          </g>\n        </g>\n      </g>\n    </svg>\n  ',"person-fill":'\n    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">\n      <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>\n    </svg>\n  ',"play-fill":'\n    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-play-fill" viewBox="0 0 16 16">\n      <path d="m11.596 8.697-6.363 3.692c-.54.313-1.233-.066-1.233-.697V4.308c0-.63.692-1.01 1.233-.696l6.363 3.692a.802.802 0 0 1 0 1.393z"></path>\n    </svg>\n  ',"pause-fill":'\n    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pause-fill" viewBox="0 0 16 16">\n      <path d="M5.5 3.5A1.5 1.5 0 0 1 7 5v6a1.5 1.5 0 0 1-3 0V5a1.5 1.5 0 0 1 1.5-1.5zm5 0A1.5 1.5 0 0 1 12 5v6a1.5 1.5 0 0 1-3 0V5a1.5 1.5 0 0 1 1.5-1.5z"></path>\n    </svg>\n  ',radio:'\n    <svg part="checked-icon" class="radio__icon" viewBox="0 0 16 16">\n      <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\n        <g fill="currentColor">\n          <circle cx="8" cy="8" r="3.42857143"></circle>\n        </g>\n      </g>\n    </svg>\n  ',"star-fill":'\n    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star-fill" viewBox="0 0 16 16">\n      <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"/>\n    </svg>\n  ',"x-lg":'\n    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-lg" viewBox="0 0 16 16">\n      <path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"/>\n    </svg>\n  ',"x-circle-fill":'\n    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle-fill" viewBox="0 0 16 16">\n      <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM5.354 4.646a.5.5 0 1 0-.708.708L7.293 8l-2.647 2.646a.5.5 0 0 0 .708.708L8 8.707l2.646 2.647a.5.5 0 0 0 .708-.708L8.707 8l2.647-2.646a.5.5 0 0 0-.708-.708L8 7.293 5.354 4.646z"></path>\n    </svg>\n  '},xt=[Rt,{name:"system",resolver:e=>e in kt?`data:image/svg+xml,${encodeURIComponent(kt[e])}`:""}],Pt=[];function Mt(e){return xt.find(t=>t.name===e)}var Ht=g`
  :host {
    display: inline-block;
    width: 1em;
    height: 1em;
    box-sizing: content-box !important;
  }

  svg {
    display: block;
    height: 100%;
    width: 100%;
  }
`;function St(e,t){const i=it({waitUntilFirstUpdate:!1},t);return(t,r)=>{const{update:A}=t,s=Array.isArray(e)?e:[e];t.update=function(e){s.forEach(t=>{const A=t;if(e.has(A)){const t=e.get(A),s=this[A];t!==s&&(i.waitUntilFirstUpdate&&!this.hasUpdated||this[r](t,s))}}),A.call(this,e)}}}var Ot,qt=g`
  :host {
    box-sizing: border-box;
  }

  :host *,
  :host *::before,
  :host *::after {
    box-sizing: inherit;
  }

  [hidden] {
    display: none !important;
  }
`,Lt=class extends ve{constructor(){var e,t,i;super(),e=this,i=!1,(t=Ot).has(e)?et("Cannot add the same private member more than once"):t instanceof WeakSet?t.add(e):t.set(e,i),this.initialReflectedProperties=new Map,Object.entries(this.constructor.dependencies).forEach(([e,t])=>{this.constructor.define(e,t)})}emit(e,t){const i=new CustomEvent(e,it({bubbles:!0,cancelable:!1,composed:!0,detail:{}},t));return this.dispatchEvent(i),i}static define(e,t=this,i={}){const r=customElements.get(e);if(!r){try{customElements.define(e,t,i)}catch(r){customElements.define(e,class extends t{},i)}return}let A=" (unknown version)",s=A;"version"in t&&t.version&&(A=" v"+t.version),"version"in r&&r.version&&(s=" v"+r.version),A&&s&&A===s||console.warn(`Attempted to register <${e}>${A}, but <${e}>${s} has already been registered.`)}attributeChangedCallback(e,t,i){var r,A;st(r=this,A=Ot,"read from private field"),A.get(r)||(this.constructor.elementProperties.forEach((e,t)=>{e.reflect&&null!=this[t]&&this.initialReflectedProperties.set(t,this[t])}),((e,t,i)=>{st(e,t,"write to private field"),t.set(e,i)})(this,Ot,!0)),super.attributeChangedCallback(e,t,i)}willUpdate(e){super.willUpdate(e),this.initialReflectedProperties.forEach((t,i)=>{e.has(i)&&null==this[i]&&(this[i]=t)})}};Ot=new WeakMap,Lt.version="2.20.1",Lt.dependencies={},At([Qe()],Lt.prototype,"dir",2),At([Qe()],Lt.prototype,"lang",2);var Ut,Tt=Symbol(),Jt=Symbol(),Vt=new Map,Ft=class extends Lt{constructor(){super(...arguments),this.initialRender=!1,this.svg=null,this.label="",this.library="default"}async resolveIcon(e,t){var i;let r;if(null==t?void 0:t.spriteSheet)return this.svg=W`<svg part="svg">
        <use part="use" href="${e}"></use>
      </svg>`,this.svg;try{if(r=await fetch(e,{mode:"cors"}),!r.ok)return 410===r.status?Tt:Jt}catch(e){return Jt}try{const e=document.createElement("div");e.innerHTML=await r.text();const t=e.firstElementChild;if("svg"!==(null==(i=null==t?void 0:t.tagName)?void 0:i.toLowerCase()))return Tt;Ut||(Ut=new DOMParser);const A=Ut.parseFromString(t.outerHTML,"text/html").body.querySelector("svg");return A?(A.part.add("svg"),document.adoptNode(A)):Tt}catch(e){return Tt}}connectedCallback(){var e;super.connectedCallback(),e=this,Pt.push(e)}firstUpdated(){this.initialRender=!0,this.setIcon()}disconnectedCallback(){var e;super.disconnectedCallback(),e=this,Pt=Pt.filter(t=>t!==e)}getIconSource(){const e=Mt(this.library);return this.name&&e?{url:e.resolver(this.name),fromLibrary:!0}:{url:this.src,fromLibrary:!1}}handleLabelChange(){"string"==typeof this.label&&this.label.length>0?(this.setAttribute("role","img"),this.setAttribute("aria-label",this.label),this.removeAttribute("aria-hidden")):(this.removeAttribute("role"),this.removeAttribute("aria-label"),this.setAttribute("aria-hidden","true"))}async setIcon(){var e;const{url:t,fromLibrary:i}=this.getIconSource(),r=i?Mt(this.library):void 0;if(!t)return void(this.svg=null);let A=Vt.get(t);if(A||(A=this.resolveIcon(t,r),Vt.set(t,A)),!this.initialRender)return;const s=await A;if(s===Jt&&Vt.delete(t),t===this.getIconSource().url)if(Le(s)){if(this.svg=s,r){await this.updateComplete;const e=this.shadowRoot.querySelector("[part='svg']");"function"==typeof r.mutator&&e&&r.mutator(e)}}else switch(s){case Jt:case Tt:this.svg=null,this.emit("sl-error");break;default:this.svg=s.cloneNode(!0),null==(e=null==r?void 0:r.mutator)||e.call(r,this.svg),this.emit("sl-load")}}render(){return this.svg}};Ft.styles=[qt,Ht],At([De()],Ft.prototype,"svg",2),At([Qe({reflect:!0})],Ft.prototype,"name",2),At([Qe()],Ft.prototype,"src",2),At([Qe()],Ft.prototype,"label",2),At([Qe({reflect:!0})],Ft.prototype,"library",2),At([St("label")],Ft.prototype,"handleLabelChange",1),At([St(["name","src","library"])],Ft.prototype,"setIcon",1);
/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const zt=Se(class extends Oe{constructor(e){if(super(e),e.type!==Pe||"class"!==e.name||e.strings?.length>2)throw Error("`classMap()` can only be used in the `class` attribute and must be the only part in the attribute.")}render(e){return" "+Object.keys(e).filter(t=>e[t]).join(" ")+" "}update(e,[t]){if(void 0===this.st){this.st=new Set,void 0!==e.strings&&(this.nt=new Set(e.strings.join(" ").split(/\s/).filter(e=>""!==e)));for(const e in t)t[e]&&!this.nt?.has(e)&&this.st.add(e);return this.render(t)}const i=e.element.classList;for(const e of this.st)e in t||(i.remove(e),this.st.delete(e));for(const e in t){const r=!!t[e];r===this.st.has(e)||this.nt?.has(e)||(r?(i.add(e),this.st.add(e)):(i.remove(e),this.st.delete(e)))}return Z}}),Yt=e=>e??_,Xt=Se(class extends Oe{constructor(e){if(super(e),e.type!==Me&&e.type!==Pe&&e.type!==He)throw Error("The `live` directive is not allowed on child or event bindings");if(!(e=>void 0===e.strings)(e))throw Error("`live` bindings can only contain a single expression")}render(e){return e}update(e,[t]){if(t===Z||t===_)return t;const i=e.element,r=e.name;if(e.type===Me){if(t===i[r])return Z}else if(e.type===He){if(!!t===i.hasAttribute(r))return Z}else if(e.type===Pe&&i.getAttribute(r)===t+"")return Z;return Ve(e),t}});
/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var jt,Kt,Gt,Nt=class extends Lt{constructor(){super(...arguments),this.formControlController=new dt(this,{assumeInteractionOn:["sl-blur","sl-input"]}),this.hasSlotController=new ht(this,"help-text","label"),this.localize=new yt(this),this.hasFocus=!1,this.title="",this.__numberInput=Object.assign(document.createElement("input"),{type:"number"}),this.__dateInput=Object.assign(document.createElement("input"),{type:"date"}),this.type="text",this.name="",this.value="",this.defaultValue="",this.size="medium",this.filled=!1,this.pill=!1,this.label="",this.helpText="",this.clearable=!1,this.disabled=!1,this.placeholder="",this.readonly=!1,this.passwordToggle=!1,this.passwordVisible=!1,this.noSpinButtons=!1,this.form="",this.required=!1,this.spellcheck=!0}get valueAsDate(){var e;return this.__dateInput.type=this.type,this.__dateInput.value=this.value,(null==(e=this.input)?void 0:e.valueAsDate)||this.__dateInput.valueAsDate}set valueAsDate(e){this.__dateInput.type=this.type,this.__dateInput.valueAsDate=e,this.value=this.__dateInput.value}get valueAsNumber(){var e;return this.__numberInput.value=this.value,(null==(e=this.input)?void 0:e.valueAsNumber)||this.__numberInput.valueAsNumber}set valueAsNumber(e){this.__numberInput.valueAsNumber=e,this.value=this.__numberInput.value}get validity(){return this.input.validity}get validationMessage(){return this.input.validationMessage}firstUpdated(){this.formControlController.updateValidity()}handleBlur(){this.hasFocus=!1,this.emit("sl-blur")}handleChange(){this.value=this.input.value,this.emit("sl-change")}handleClearClick(e){e.preventDefault(),""!==this.value&&(this.value="",this.emit("sl-clear"),this.emit("sl-input"),this.emit("sl-change")),this.input.focus()}handleFocus(){this.hasFocus=!0,this.emit("sl-focus")}handleInput(){this.value=this.input.value,this.formControlController.updateValidity(),this.emit("sl-input")}handleInvalid(e){this.formControlController.setValidity(!1),this.formControlController.emitInvalidEvent(e)}handleKeyDown(e){const t=e.metaKey||e.ctrlKey||e.shiftKey||e.altKey;"Enter"!==e.key||t||setTimeout(()=>{e.defaultPrevented||e.isComposing||this.formControlController.submit()})}handlePasswordToggle(){this.passwordVisible=!this.passwordVisible}handleDisabledChange(){this.formControlController.setValidity(this.disabled)}handleStepChange(){this.input.step=String(this.step),this.formControlController.updateValidity()}async handleValueChange(){await this.updateComplete,this.formControlController.updateValidity()}focus(e){this.input.focus(e)}blur(){this.input.blur()}select(){this.input.select()}setSelectionRange(e,t,i="none"){this.input.setSelectionRange(e,t,i)}setRangeText(e,t,i,r="preserve"){const A=null!=t?t:this.input.selectionStart,s=null!=i?i:this.input.selectionEnd;this.input.setRangeText(e,A,s,r),this.value!==this.input.value&&(this.value=this.input.value)}showPicker(){"showPicker"in HTMLInputElement.prototype&&this.input.showPicker()}stepUp(){this.input.stepUp(),this.value!==this.input.value&&(this.value=this.input.value)}stepDown(){this.input.stepDown(),this.value!==this.input.value&&(this.value=this.input.value)}checkValidity(){return this.input.checkValidity()}getForm(){return this.formControlController.getForm()}reportValidity(){return this.input.reportValidity()}setCustomValidity(e){this.input.setCustomValidity(e),this.formControlController.updateValidity()}render(){const e=this.hasSlotController.test("label"),t=this.hasSlotController.test("help-text"),i=!!this.label||!!e,r=!!this.helpText||!!t,A=this.clearable&&!this.disabled&&!this.readonly&&("number"==typeof this.value||this.value.length>0);return W`
      <div
        part="form-control"
        class=${zt({"form-control":!0,"form-control--small":"small"===this.size,"form-control--medium":"medium"===this.size,"form-control--large":"large"===this.size,"form-control--has-label":i,"form-control--has-help-text":r})}
      >
        <label
          part="form-control-label"
          class="form-control__label"
          for="input"
          aria-hidden=${i?"false":"true"}
        >
          <slot name="label">${this.label}</slot>
        </label>

        <div part="form-control-input" class="form-control-input">
          <div
            part="base"
            class=${zt({input:!0,"input--small":"small"===this.size,"input--medium":"medium"===this.size,"input--large":"large"===this.size,"input--pill":this.pill,"input--standard":!this.filled,"input--filled":this.filled,"input--disabled":this.disabled,"input--focused":this.hasFocus,"input--empty":!this.value,"input--no-spin-buttons":this.noSpinButtons})}
          >
            <span part="prefix" class="input__prefix">
              <slot name="prefix"></slot>
            </span>

            <input
              part="input"
              id="input"
              class="input__control"
              type=${"password"===this.type&&this.passwordVisible?"text":this.type}
              title=${this.title}
              name=${Yt(this.name)}
              ?disabled=${this.disabled}
              ?readonly=${this.readonly}
              ?required=${this.required}
              placeholder=${Yt(this.placeholder)}
              minlength=${Yt(this.minlength)}
              maxlength=${Yt(this.maxlength)}
              min=${Yt(this.min)}
              max=${Yt(this.max)}
              step=${Yt(this.step)}
              .value=${Xt(this.value)}
              autocapitalize=${Yt(this.autocapitalize)}
              autocomplete=${Yt(this.autocomplete)}
              autocorrect=${Yt(this.autocorrect)}
              ?autofocus=${this.autofocus}
              spellcheck=${this.spellcheck}
              pattern=${Yt(this.pattern)}
              enterkeyhint=${Yt(this.enterkeyhint)}
              inputmode=${Yt(this.inputmode)}
              aria-describedby="help-text"
              @change=${this.handleChange}
              @input=${this.handleInput}
              @invalid=${this.handleInvalid}
              @keydown=${this.handleKeyDown}
              @focus=${this.handleFocus}
              @blur=${this.handleBlur}
            />

            ${A?W`
                  <button
                    part="clear-button"
                    class="input__clear"
                    type="button"
                    aria-label=${this.localize.term("clearEntry")}
                    @click=${this.handleClearClick}
                    tabindex="-1"
                  >
                    <slot name="clear-icon">
                      <sl-icon name="x-circle-fill" library="system"></sl-icon>
                    </slot>
                  </button>
                `:""}
            ${this.passwordToggle&&!this.disabled?W`
                  <button
                    part="password-toggle-button"
                    class="input__password-toggle"
                    type="button"
                    aria-label=${this.localize.term(this.passwordVisible?"hidePassword":"showPassword")}
                    @click=${this.handlePasswordToggle}
                    tabindex="-1"
                  >
                    ${this.passwordVisible?W`
                          <slot name="show-password-icon">
                            <sl-icon name="eye-slash" library="system"></sl-icon>
                          </slot>
                        `:W`
                          <slot name="hide-password-icon">
                            <sl-icon name="eye" library="system"></sl-icon>
                          </slot>
                        `}
                  </button>
                `:""}

            <span part="suffix" class="input__suffix">
              <slot name="suffix"></slot>
            </span>
          </div>
        </div>

        <div
          part="form-control-help-text"
          id="help-text"
          class="form-control__help-text"
          aria-hidden=${r?"false":"true"}
        >
          <slot name="help-text">${this.helpText}</slot>
        </div>
      </div>
    `}};Nt.styles=[qt,je,Xe],Nt.dependencies={"sl-icon":Ft},At([ke(".input__control")],Nt.prototype,"input",2),At([De()],Nt.prototype,"hasFocus",2),At([Qe()],Nt.prototype,"title",2),At([Qe({reflect:!0})],Nt.prototype,"type",2),At([Qe()],Nt.prototype,"name",2),At([Qe()],Nt.prototype,"value",2),At([((e="value")=>(t,i)=>{const r=t.constructor,A=r.prototype.attributeChangedCallback;r.prototype.attributeChangedCallback=function(t,s,o){var n;const a=r.getPropertyOptions(e);if(t===("string"==typeof a.attribute?a.attribute:e)){const t=a.converter||D,r=("function"==typeof t?t:null!=(n=null==t?void 0:t.fromAttribute)?n:D.fromAttribute)(o,a.type);this[e]!==r&&(this[i]=r)}A.call(this,t,s,o)}})()],Nt.prototype,"defaultValue",2),At([Qe({reflect:!0})],Nt.prototype,"size",2),At([Qe({type:Boolean,reflect:!0})],Nt.prototype,"filled",2),At([Qe({type:Boolean,reflect:!0})],Nt.prototype,"pill",2),At([Qe()],Nt.prototype,"label",2),At([Qe({attribute:"help-text"})],Nt.prototype,"helpText",2),At([Qe({type:Boolean})],Nt.prototype,"clearable",2),At([Qe({type:Boolean,reflect:!0})],Nt.prototype,"disabled",2),At([Qe()],Nt.prototype,"placeholder",2),At([Qe({type:Boolean,reflect:!0})],Nt.prototype,"readonly",2),At([Qe({attribute:"password-toggle",type:Boolean})],Nt.prototype,"passwordToggle",2),At([Qe({attribute:"password-visible",type:Boolean})],Nt.prototype,"passwordVisible",2),At([Qe({attribute:"no-spin-buttons",type:Boolean})],Nt.prototype,"noSpinButtons",2),At([Qe({reflect:!0})],Nt.prototype,"form",2),At([Qe({type:Boolean,reflect:!0})],Nt.prototype,"required",2),At([Qe()],Nt.prototype,"pattern",2),At([Qe({type:Number})],Nt.prototype,"minlength",2),At([Qe({type:Number})],Nt.prototype,"maxlength",2),At([Qe()],Nt.prototype,"min",2),At([Qe()],Nt.prototype,"max",2),At([Qe()],Nt.prototype,"step",2),At([Qe()],Nt.prototype,"autocapitalize",2),At([Qe()],Nt.prototype,"autocorrect",2),At([Qe()],Nt.prototype,"autocomplete",2),At([Qe({type:Boolean})],Nt.prototype,"autofocus",2),At([Qe()],Nt.prototype,"enterkeyhint",2),At([Qe({type:Boolean,converter:{fromAttribute:e=>!(!e||"false"===e),toAttribute:e=>e?"true":"false"}})],Nt.prototype,"spellcheck",2),At([Qe()],Nt.prototype,"inputmode",2),At([St("disabled",{waitUntilFirstUpdate:!0})],Nt.prototype,"handleDisabledChange",1),At([St("step",{waitUntilFirstUpdate:!0})],Nt.prototype,"handleStepChange",1),At([St("value",{waitUntilFirstUpdate:!0})],Nt.prototype,"handleValueChange",1),Nt.define("sl-input"),function(e){e.OFF="off",e.ONCE="one",e.ALL="all"}(jt||(jt={})),function(e){e.ALBUM="album",e.ARTIST="artist",e.AUDIOBOOK="audiobook",e.PLAYLIST="playlist",e.PODCAST="podcast",e.TRACK="track",e.RADIO="radio"}(Kt||(Kt={})),function(e){e.BOOK="book",e.CLEFT="cleft",e.DISC="disc",e.HEADPHONES="headphones",e.MICROPHONE="microphone",e.MICROPHONE_MAGIC="microphone_magic",e.PERSON="person",e.PLAYLIST="playlist",e.RADIO="radio"}(Gt||(Gt={}));const Wt={book:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAdxklEQVR4nO3dC/xv9Zzv8ff6791NDApTor13JCqNuxOhQeMyg1ySa3vvmBwxjIM4zpyhGXNmGscDuXQmpDou43aigyEh93PGICSG0N4kopCu+/Jf81hZjUa3/67///dda32fz4e/e/0+JXu9ft/1XevbtG0b6N06ycr+Z6ckO/7OT/ef37z/7940yVZJmiS3KDw3MD7zSX7V//OLkpyf5IIk5yU5J8m6JGcnOatt2+82TbOp8LyT0wiA6myXZK8k+yTZO8nu/QV/VZLtSw8HcA02JDkzyRlJvpTki23bnt40zcbSg42ZAJj+xf7eSe6f5O79Rf+OSZaVHgzgRrokyf9LckqSjyX5WhIXtC0gAKalW6J/QJL9ktwvyT36ZXqAqftJkg8meV+STyXZXHqgoRMA49Z9k79PkkckeXiSeyaZKz0UQGE/T/KeJG9N8pXSwwyVABif7j79nyQ5MMkB/eY8AK7Z6UnenOTEfrMhPQEwDtv2F/uDkjy234EPwMJdmOT4JK9Osr70MEMgAIare7zuwUkOTfJoF32ARdE9OXBCkr/pHzOslgAYnu75+zVJnpnkDqWHAZhwCLwtyV/17x2ojgAYjocmeXaSR9m5DzAzFyd5Vf/TPVpYDQFQUNu2WzVNc3CSFya5W+l5ACr2oyT/Jcl7UwkBUMbN+nv73YX/9qWHAeDffSTJ4f2riCdNAMxW9x79FyT586u8Ux+AYbkoyYuS/EMmTADM7tn95yY5IskOpYcBYEG6VwyvTXJuJkgALP3z+89J8pL+Nb0AjMtPkzwtyamZGAGwdLrd/K9NslvpQQC4UTYneWX/yGB3jPEkCIDF1+3mf02S/UsPAsCi+kCSp0/llcICYPF07+T/2353v+N2Aabpq/15LD/OyAmAxfHkfrn/NqUHAWDJ/bCPgK9nxATAjXPbJG/oD+gBoB6/SvLIJF/ISDk7/oYf1NPt7v+2iz9AlW7ePyY42v1eVgBu2Lf+4/vjeQGo26VJHpPk4xkZKwBb5sAkX3PxB6C3Xf90wIMyMgJg4f8Dvy7JSUluVXoYAAblJklOTnLvjIhbANdvzyTvT3Ln0oMAMGg/T7JvkrMyAlYArttj+h2eLv4AXJ9uhfijY3n1uwC4Bm3bLk/yqn7J36l9ACzUHZL8nyTbZOAEwNXdummaU/qjILvH/QBgS+zX7xsbNHsA/qM7JvlIkt1LDwLA6D0jyXEZKAHwWw/sl/x3KD0IAJNwWb8p8PQMkFsAv3FQ/0YnF38AFsu2Sd7ZPyY4OAIgeVmSd/f/QwHAYrpLkqMyQDXfAug2+P19v9kPAJZKd6F9RL/SPBi1BkDTH9/7vNKDAFCF9Un2SnJRBqLGWwDLkrzVxR+AGdo1ySsyIFWtALRtu1XTNO/oN/0BwCxt7s8L+GoGoKYVgLmmabpjfF38ASi1Av2GobxkrpYA6P5kH5PkKaUHAaBq90vy2AxALbcAjk7yZ6WHAIAk3+tPmt1QcogaVgD+h4s/AAM7MGht6SGmvgLwrCT/q/QQAHANjwXeKcnlKWTKKwCPSfLG0kMAwLU8FnhoCprqCsA9k3w6yfalBwGAa3F2fwpt93jgzE1xBWBlkg+5+AMwguvVY0p9+NQC4Gb9xX+n0oMAwAK8IIXMTexZ/+P6dy0DwBjsl+RuJT54SgHw4iRPKD0EAGyhIo8ETmUT4IP7YxaXlx4EALbQBUl2SXLZLD90CgFw+yRfTnLr0oOwpH6a5BsZsQPf/Ik9fnTBL7q/XkfrkPve6f8/b/99fl16jiF72DEfu+v5F/769zNi//WBe33m8fveZSnfUrdNv1H7Fklum2TbJfyssXhikvfO8gPHHgDdwQqn9fdQmLb39v8HGa3mbWe/Ls3Ij6Gea+7RHrJiECeZDVVz/Lr3JO3YDx3buV2z8icz3L/VPRO/d5L9+xXde6Q+75v1YXVjXzJ/mYs/wKh130LX9T8f7v+97g15T+vf5nqb1OGR/arIxbP6wDFvArxvkr8sPQQAi+47/a/vK/uzXGa1GlHSTfoImJm5ET/v//YJrGDMynzpAQBugEuTvCHJnftTXYu8MW+G/mSWHzbWAHhd//pErtv3+9sk3auRAcbqV0men+SAJOdmug7o90TMxBgD4OFDOEZxwLqdu+/p/0LaPcnfVrJ8Bkzfp5LcPcmXMk07J9lnVh82tgC4aZJjSg8x4KWybolstyQHJznV0j8w0UeCH9z/GjdFD5nVB40tAF7Zbwrhty7uL/x37JfIzik9EMASuyjJo5N8JtNzv1l90NzIdv0/t/QQA1vqf3WSVf2F/8elBwKY8arno8f+grBrIACuqm3brZK8uX/xD8lH+/tEL0rys9LDABTcHPj4JL+e2D6AVbP4oFEEQNM0hye5a+k5BrKrvzs7+hFJ/rX0MAAD8N0kz8603H0WHzKGALhVkpenbpv73fzdUccnlx4GYGDekeTjmY69Z/EhYwiAI5PcMnV/639Q/zz/TE+KAhiR7o2BGzMNe8/iQ+ZG8CfhsNTruCR3S/L50oMADFx3W/RdmYY9Z/EhQw+A11T6ut8LkzwuyTMmtrkFYCn9XX+40NitrD0AHtr/1Oas/jGQk0oPAjAy30ryuYzf9v3+t2oD4K9S5+N9907yzdKDAIxUd1DcFKyqNQC6IxH3TV1e1Z8E9cvSgwCM2AcnchtgpxoDoKnssb/uL9QXJDmigqMuAWZxVsC3M3471hgA3Ytu7pM6dBf8Q5O8tvQgABMyhX0AOyz1Bwxxh/1fpJ53+T81yftKDwIwMVNYAdihtgDYP8k9M32X9e+v/kjpQQAm+nrgsdu2tlsA3eE2NSz7P93FH2DJnJ/x27qmANijP+Rm6roNf5b9AZbOFF6gtk1NAfDCgc2zFF6R5PWlhwCYuCmcm7J8qT9gKBfcW/XL4lN2TH+wEQAUN5QAWD2LDQ8Fnda27fNKDwEAQwuA7ln4qfpJ97hf0zSbSg8CAEMKgAfO6ujDArqzqZ+Y5MelBwGAoQXAn2a6Xpzks6WHAIChBcAt+xfiTNHJSV5XeggAGGIAHJRku0xPd6Lf4aWHAIChBsDBmabnJjmn9BAAMMQAuHW/AXBqPpTkHaWHAIChBsATBngY0Y31iySHlR4CAIYcAE/KNF/1e27pIQBgqAGwc5L9Mi3fbdu2e90vAAxeqQB4xAA2IC62I5qm6V78AwCDVzIApuQzST5QeggAGGwAtG3bbfx7aKajTfKi0kMAwKADoGmafZPcItPx0SRfKj0EAAz9FsDDMy1/X3oAABhDAPxRpqP75n9a6SEAYOgBcNMkd8t0HFV6AAAYQwDcd0Jv/zvLzn8AxmrWATCll/+8Jcnm0kMAwBgC4H6Zhvkk7yw9BACMIQDm+lsAU3Bqkh+WHgIAxhAAeya5eabhxNIDAMBYAuAPMg0XJjmp9BAAMJYAuGum4cNJLik9BACMJQD2yTT8U+kBAODGEgBbvvv/Y6WHAICxBMAOSXbJ+H05yXmlhwCAsQRA9wTAFFj+B2ASZhUAu2UaTik9AACMKQBWZfw2JvlK6SEAYEwBsCLj980kl5YeAgAWgxWAhfuX0gMAwNgCYGWm8QQAAEzC3Iw+43YZP/f/AZiMWQTALZMsz7i1Sc4oPQQAjCkAbpXx+5n3/wMwJbMIgB0zfutKDwAAi0kALIwAAGBS3AJYmPWlBwCAMW4CHDsBAMCkzCIAbpJpbAIEgMmYRQBsnfHzBAAAkyIAFkYAADApAmBhBAAAkzKLANgm4ycAAJgUKwAL4xhgACZlVocBjd2m0gMAwGKawsUZANhCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCAgAAKiQAAKBCy0sPAHB9mhPP2TGbN+6Xpr1PMrd70u6aZIck2ybZmOTipD0vac5KkzPTNJ/Ndiu+3h6UzaVnh6ESAMAgNcefvVOSg5M8Ocl90qRJ97e01/ZbdH/3kCv+47ZNLj77F83xOSlp/zHrVn2ifXnmZ/tHAMMmAIDBaI7MXHb9/oPTLDssyYFJtroRv7tbJjk0aQ7NirPPaY7P27O5PaZ9xqp1izgyjJYAAIbybX91VuSwZG63a/+Wf4PtkuQlWda8uDlh3SfTzh+bdetOal++v6O+qZYAAKbwbX+h5tK2D02ah2bFynOa489+e5bNv6l9+m7rZ/DZMCgCAJjat/0tWxXYPGdVgCoJAGCq3/YXyqoAVRIAQA3f9hfKqgDVEABATd/2F8qqAJMnAIBav+0vlFUBJkkAALV/218oqwJMigAAttiEv+0vlFUBRk8AAAs3nz9sjv/Bf0uaR0/82/4NWRVY17ztB29J0+xYeihYCAEAbIH21f0797m6FWmavy49BCyU44ABoEICAAAqJAAAoEICAAAqJAAAoEICAAAqJAAAoEICAAAqJAAAoEICAAAqJAAAoEICAAAqJAAAoEICAAAqJAAAoEICAAAqJAAAoEICAAAqJAAAoEICAAAqJAAAoEICAAAqJAAAoEICAAAqJAAAoEICAAAqJAAAoEICAAAqJAAAoEICAAAqJAAAoEICAAAqJAAAoEICAAAqJAAAoEICAGalySWlR4AFueSSi0qPwNITADA7vyo9wOQ0zVlJLi09xqQ07aYcvufFpcdg6QkAmJ1flh5gIi5L07w9aR/Yrl6xe7ae2yVNnp/km6UHm4S2+VWbtKXHYOktn8FnAJ12/qw0mvtG+E6S47Jhw1vbw+708yv/zfYpu/4iydHdT3PC+ntmfv6wNHlqku3Ljjta3y09ALMhAGBWlm3z1cxvLD3F2FyeNCen3Xxs1u72iev7Ztqu3vXLSZ7VHPv9I7LN3MFpc3iSP5jduJNweukBmA0BADPSHrLL+c3xZ5+TZJfSswxem2+lybHZvPzE9hm3u2CLf/PDduv2Wxzb/TQnrL9/vypwUJLtlmbgSfla6QGYDQEAs9TklLRZW3qMKXzbX6h29a6fT/L55tjvP8+qwAK0c6eUHoHZEAAwS217UtIIgAXc219sv7MqYK/ANTu9Xbvr90sPwWwIAJil7bc6NRdvujDJ76Vu3U7+96WdP7Zds+qzs/7wf98r8M71L83G+aenzWFJ9krt2vb9pUdgdmxJhhlqD7rdpWma7ltozd/2X5oNG27frl7x9BIX/6vqniBoV688ul2zcu80c/dKe8UKQa3PwF+epnlL6SGYHSsAMGvNstem3fS8JFunDktyb3+xVf8EQZsT2rUrf1J6DGbHCgDMWHvI7bonAY5LDTv5kxdk8/LbtmtWPLFdu9upQ734/+5egXb1ymPbNSvvlmZuv7Q5sYK3DV6W+c2vKj0Es2UFAErYeu5l2TD/uCS3ybSM4tv+QlX0BMFR7TPu0L1WmYpYAYACrnh7XZsjMhUj/ba/UBNfFeje/Pd3pYdg9gQAFNKuXXlCmrwt4/62/9608wdk7cq92jUrX3tDXtozxlWBdu3K1dkwv3OaPGvkL865LG3zpHbNystKD8LsuQUAJf1mSXmfJPfMeMzkuf2hm8h7BZ7drl3xldJDUIYVACjoim9emzYdOIIDWC5L2nekaR/Urlm5R7tm5VE1X/yv6QmCdu3KZ2XruduP5mTCpvmLds3K40uPQTkCAAprn3nHHyV5YJIzM+Tn9teselq7etVnSg80ZKN5r0Db/vd29Yq/KT0GZQkAGIB2zRXPXz8kyRAusL7tT3dV4PLu5kW7dtUrSw9CeQIAhhQB687uIuDIK3YHlPq2327a1bf9Sa4K/DDJ/u2aVW8u8NkMkE2AMCDty/fflOQVzYnrPp02R6dt957Bt/33d0fvuuDP+AyCDfOHJFecQbDnEn/sxiRvzIb5V/QbF+EKAgAGqD1kxaeaI0+7e1aseHaauSPStrdbguf235xlW53YHrLL+Yv6+2Zh74FIXtf9NMd9f7/MLTusOykiybaL+DHzSf5v2rmXtWt3HeL+EgoTADDs1YDXN0eedkx2Xfn4NFc8Mnj/JMtu4O+yu9B/ME17QrvGt/2haA/d7XNJPte8c/3z+5MJD07yn27ELdrzkrwrzbLXt6tv/71FHpcJEQAwjhB4d/fTHPudW2XrrR6RNN1egb375ePtruOC3z3j/eW085/I+vWn9b8vhrsqcHT305z4o12yedOj0+S+Se6Rpr1L2mb5ddzbPzNp/jlt++GsX/ml9uVXfPuH6yQAYET63fj/u/9Jc2TmsupHO2fj5dtl+VY3T9POZ+P8Bbn80vPbw/e86D/+1rsVmpobeGDUMf1PmiNPW57dbr9DsnzHzDc3yaaNl2duq0vSXvqz9tA9fl16XsZJAMCI/eab3hUXCyasX7k5r/+BReExQACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgAoJAACokAAAgArNIgA2Z/y2KT0AAAu2bcZv0xQCYEPG72alBwCgql+zL59CACz5H8QM3Kr0AABU9Wv2hqX+AAGwMLuXHgCAqn7NvmwKAXBBxm+P0gMAUNWv2RdMIQDOz/jdr/QAACzYAzJ+P1/qD7ACsDB7JblN6SEAuF47TWQF4BdTCIBzM35NkseUHgKA6/WY/tfssTt3CgGwLtPw1NIDAHC9npZpOHsKAXBekkszfg9McpfSQwBwrfZMcv+M30VT2QPQzqJkZqBbUnpJ6SEAuFYvncjy/9lTOgvgzEzDU5LcqfQQAFzNnZM8OdNw5pQC4IxMw1ZJ3lB6CACu5jVJlmcazpjFhwiALXeADYEAg/L0JA/PdJwxpQD4aqblmIm8ahJg7Lpn/t+UafnqlALge0l+mmmdNPX+JDcvPQhAxW6R5H1JbprpOHdqmwA7X8y03DXJPyXZvvQgABXaLsnJSfbOtHx+Vh80ywD4QqZn3yQfmFh9AoxhFfbkibzzv9i1cpYBcGqm6aFJPpnk90sPAlCBnZN8qv+1d4o+McUAOH0i5wJck3sn+XqSh5UeBGDC/jDJl5PcM9P0kyTfmGIAtBNeBUh/WuCHkxxtcyDAorpl/w6WU/sVgKn6WH+tnFwApL9ATtmyJH+W5F+TPLffpALADXOTJM9L8u0kzylwzZq1D83yw5q2nVlspN8sd15FF8buj/XYJO/o/wIueT722G+/vDfJE0sPAczEXfoXrh2W5Napw8X9XrLuH2dieYETjj6a5LGpQ3db4C/6n6/1mztO6+/xrE8yX3pAgMK6b/Ur+sf5unv8D0myT+rzkVle/EusAHSelORds/7QAbo8yTlJftWHUfevl8rW/XHGY/bTWW6OAZbUNv2jfN1+qdv2/7p2B/UvNZp0AGyb5Mf9pg4AqN35SXZZ4i+CV1NiQ8VlSd5Z4HMBYIjePuuLfwruqHxroc8FgKF5W4kPnSt40tHM3ncMAAP1mX6T+MyVfKbyNQU/GwCGoNi1sMQmwKu+NOc7SXYrNQAAFPSDJLsn2VzbCkD3B/zqgp8PACUdVeriX3oF4Mrn07/TvwQCAGqxvv/2v6HUAKXfq7yhLyAAqMkrS178h7ACcOUqwLfsBQCgEme1bbtn0zQbSw5RegUgfQEdUXoIAJiRF5W++A9lBeBKn57A++oB4Lqc1h96VNyQAuAeSf65fzwQAKZmU5J7Jzk9AzCEWwBX+kqSo0sPAQBL+NKfQVz8h7YC0LlJkjOSrCo9CAAsonVJ9u6Pfx+EIa0AdC5JcniSQVUJANwI3TXtsCFd/IcYAJ2PJnlT6SEAYJG8PskpGZih3QK40rb9hsC7lh4EAG6EM5PcK8mlGZghrgB0LktyyBD/hAHAFtzWfvJQr2VDDYD0OyW7eyYAMEbPSfL1DNSQA6Dz9iT/UHoIANhCb0xyfAZsqHsArmqbJKcm2a/0IACwAJ9JckDpw36mEACdHZN8IcmdSg8CANfhe0n2TfKzDNzQbwFc6fwkf5zk56UHAYBr0V30HzaGi/+YAqBzVr+k8ovSgwDA77gwySP7FYBRGFMAXPlkwB8P7W1KAKT2x/0eleRfMiJjC4DOF5M8bqjPVQJQlUuTHNhv/BuVMQZA5+NJHp7k16UHAaBaFyd5dH9NGp2xPAVwbe7Vnx3QPSUAALPyy/6ef7cqPUpjXQG4Une/5cFJflh6EACqsT7JA8Z88Z9CAKR/zeJ9k3y59CAATN7Xktw/yRkZuSkEQOfcJPsn+UDpQQCYrPf3F/8fZQKmEgDpHw3sng748yQbSw8DwGRsTnJkkoP6jX+TMPZNgNem2xfwjiQ7lR4EgNGvMD8lyWmZmCmtAFzVJ5Psk+SDpQcBYLQ+muQeU7z4TzkA0r+LuXs5w3/2vgAAtsCvk/xpkkck+Ukmaqq3AH7XbZMcneTxpQcBYNA+lOQ5/aN+kzblFYCr+nGSJyR54lR2bwKwqNb3G8kfVcPFv6YAuNJ7k+yR5KVuCwCQ3+zqPyrJXklOSkVquQVwbbcF/jLJ2iRblx4GgJnakOStSf663+lfnZoD4Eq7Jnlhkmcl2ab0MAAsqe49Mf/YP9f/vVRMAPzWTv0TA891uBDA5FyY5Pgk/9P5Mb8hAK5u+ySrkzwzyd1LDwPAjfKVJG9JcuKU3uK3GATAdesC4ND+6YHblB4GgAX5aZJ3JzmuP7yHayAAFmZZkgf1jxJ2LxfaufRAAFztce8P9E97fbZ/fz/XQQBsuaZ/zfAfJTkgyb5Jblp6KIDKdAfAfSHJx5Oc0h8NzxYQADdS27bLm6bpguB+Se6dZO8keybZtvRsABNxWZIzk5yR5EtJPt+27TeaptlUerAxEwBLd8vgDknumGRl/3O7/umCWyfZIcnv9f/dmyVZXnhegFnbdJUXsnU79M9P8vP+H7s3tp7d/5zVP65nST+L698AxZItY7lbfGsAAAAASUVORK5CYII=",cleft:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAA8bklEQVR4nO3dCXxcdbn/8e9zJk3pxlZ2SpOUylIEFRQURBGVK4or9uJC2wSxevXidlVcLyJ/FcUdFS1L0hYRqQsoCiIKl10QRJZKoSSTguylQNuUZpnn/zrTFAp0SdKZ+c35nc/71byatsnM0yad831+57eYuwsAANTUGEl7rvO2l6QmSbtI2lnSaElPSnpa0v2Slki6RdI1km6U1LO5BRgBAACAqtlN0h7rXOTXXvAnp9fgET7mSkm/l3S+pIslDYzkQQgAAABUvptfe9Efr+q6V9JpkjokrR7OJxIAAAAYmm0k7SNpmqQp67zfLClRWIslnSDp0qF+AgEAAID66OYrYa6kjw7eJtgoAgAAII92q8K9+Xpxh6SjJd29sQ8iAAAAYtUoadJ6hu33kzRBcVsm6c2SbtjQBxAAAABZF3M3vzmekvSWwaWDL0AAAABkQZ67+c3xuKRXre92AAEAAFBP6OYr7x5JBw3eFngGAQAAUGt087V3rqQZ6/4GAQAAUC108/XlHZIuWvsLAgAAYHPQzWdH92AAK+8YSAAAAGR9FzwMXbpb4I/SdwgAAIBYdsHDpv3b3ZvNrJ8AAAD5Qzefb29LTxMkAABAnOjmsSEXSnonAQAAso1uHsOVHhQ0kQAAAPWPmfaotMMbKv6QAICRYt08auVQAgAA1BbdPOrB3gQAAKgOunnUMwIAAGwGunlk1XYEAADYNGbaIzZbsgoAANZg3TzyxBkBAJA3dPOAZAQAADHi3jywCQQAAFlGNw+MEAEAQL2jmweqgAAAoF7QzQM1RAAAUEt080CdIAAAqAa6eaDOEQAAjBTdPJBhBAAAm0I3D0SIAAAgRTcP5AwBAMgXunkAZQQAID508wA2iQAAZBfdPIARIwAA9Y1uHkBVEACA+kA3D6CmCABA7dDNA6gbBACg8ujmAdQ9AgAwMnTzADKNAABsHN08gCgRAAC6eQA5RABAntDNA8AgAgBiQzcPAENAAEBW0c0DwGYgAKCe0c0DQJUQAFBPdpf0FkmHSNp/8NcWuigAiBEBAKFtLWmGpOMHO3sAQA0QABDywv8pSR+XtGXoYgAgbwgACOFYSd+WtGPoQgBgBB6RNFbSeGUYAQC1lHb6Z0maHroQANiEPkn3SeqUtFDSnYPv3y7pYUlXSTpUGUYAQK3sJemPklpCFwIAz+vm/yXpbkmLJN01+HOXpAFFjACAWnilpIslTQxdCIBc6pW0eJ2L+6LB99OL/jLlFAEA1bbfYOefbtwDANW0bD1D9gvdfZGZ9Ycurt4QAFBN6SY+l3HxBxCymzdjO5H1IQCgWkZL+jUz/QFU8t68uxfp5iuDAIBq+YqkA0MXASCTM+3vkPTQ+j6Bbr5yCACohpdJ+nToIgDUVTf//CF7uvnACACohnSTH763gHyhm88YXqRRaW+UdHjoIgBUDd18JAgAqLR0f38A2UY3nwMEAFTSFElHhC4CwJDRzecYAQCV9B5JSegiADwH3TzWiwCASnpH6AKAHHt+N1/u6OnmsSEEAFTKBEn7hy4CiBzdPCqGAIBKSTf9KYQuAogE3TyqjgCASpkWugAgY+jmERQBAJVcAQBg49383YPv080jOAIAKmWH0AUAAdHNI3MIAKiUcaELAAKdN7/2Qr86dHHAcBAAUCmNoQsAKnze/HMm4A3+vN7z5oEsIgAAyCu6eeQaAQBAzIZ9bx7ICwIAgBjQzQPDRAAAkBV080AFEQAA1Bu6eaAGCAAAQqCbBwIjAACoJrp5oE4RAABsLrp5IIMIAAA2t5tP3386dHEAhocAAGBddPNAThAAgHyimwdyjgAAxItuHsAGEQCA7KObBzBsBAAgG+jmAVQUAQCoL3TzAGqCAADUHt08gOAIAED10M0DqFsEAGDz0M0DyCQCADA0dPMAokIAAJ5FNw8gNwgAwLO2l/Rk6CIAoBaSmjwLkA0DoQsAgFohAAAAkEMEAAAAcogAAABADhEAAADIIQIAAAA5xDJAAAA2bBdJ0yRNkbTPOu+3KOMIAACAvBstaep6LvR7SRqnSBEAAAB5sbFu3pQzBAAAQExy2c2PBAEAAJBFdPObiQAAAKhXdPNVRAAAAIRGNx8AAQAAUAt083WGAAAAqCS6+YwgAAAAhotuPgIEAADAhtDNR4wAAAD5RjefUwQAAMgHunk8BwEAAOJBN48hIwAAQPbQzWOzEQAAoD7RzaOqCAAAEBbdPIIgAABA9dHNo+4QAACgcujmkRkEAAAYHrp5RIEAAADrRzePqBEAAOQZ3TxyiwAAIA/o5oHnIQAAiAXdPDAMBAAAWUM3D1QAAQBAPaKbB6qMAAAgJLp5IBACAIBqo5sH6hABAECl0M0DGUIAADAcdPNAJAgAANaHbh6IHAEAyC+6eSDHCABA/OjmAbwAAQCIA908gGEhAADZQjcPoCIIAED9oZsHUHUEAKA+uvl1L/R08wCqjgAAVBfdPIC6RAAAKoNuHkCmEACAoaObBxANAgDwQnTzAKJHAACedYOk3SVtEboQAKg2AgDwrLTTB4BcSEIXAAAAao8AAABADhEAAADIIQIAAAA5RAAAACCHCAAAAOQQywABANi0f0tatM7bhyTtrQwjAAAAsEavpPslLZR0p6TOwfdvk/SUnutoZRwBAACQN8ued5Ffe6G/S9KAcoIAAADIezefSwQAAECW0c2PEAEAAFDv6OargAAAAKgXdPM1RAAAANQS3XydIAAAAKqBbr7OEQAAACNFN59hBAAAwKbQzUeIAAAASNHN5wwBAADyhW4eZQQAAIgP3Tw2iQAAANlFN48RIwAAQH2jm0dVEAAAoH66+c71XOjp5lEVBAAAqB26edQNAgAAVB7dPOoeAQAARoZuHplGAACAjaObR5QIAABAN48cIgAAyBO6eWAQAQBAbOjmgSEgAADIKrp5YDMQAADUM7p5oEoIAADqAd08UGMEAAC1QjcP1BECAIBKo5sHMoAAAGAk6OaBjCMAANgYunkgUgQAAHTzQA4RAID8oJsH8AwCABAXunkAQ0IAALKJbh7AZiEAAPWLbh5A1RAAgPDo5gHUHAEAqA26eQB1hQAAVBbdPIBMIAAAw0c3DyDzCADAhtHNA4gWAQB41rck3S5p0eAb3TyAaBEAgGedImlF6CIAoBaSmjwLAACoKwQAAAByiAAAAEAOEQAAAMghAgAAADlEAAAAIIcIAAAA5BABAACAHCIAAACQQwQAAAByiAAAAEAOEQAAAMghAgAAADlEAAAAIIcIAAAA5BABAACAHCIAAACQQwQAAAByiAAAAEAOEQAAAMghAgAAADlEAAAAIIcIAAAA5BABAACAHCIAAACQQwQAAAByiAAAAEAOEQAAAMghAgAAADlEAAAAIIcIAAAA5BABAACAHCIAAACQQwQAAAByiAAAAEAOEQAAAMghAgAAADlEAAAAIIcIAAAA5BABAACAHCIAAACQQwQAAAByiAAAAEAOEQAAAMghAgAAADlEAAAAIIcIAAAA5BABAACAHCIAAACQQwQAAAByiAAAAEAOEQAAAMghAgAAADlEAAAAIIcIAAAA5BABAACAHCIAAACQQwQAAAByiAAAAEAOEQAAAMghAgAAADlEAAAAIIcIAAAA5BABAACAHCIAAACQQwQAAAByiAAAAEAOEQAAAMghAgAAADlEAAAAIIcIAAAA5BABAACAHCIAAACQQwQAAAByiAAAAEAONYQuAACQPdZR3EJS8zNvph1U0kSZtpPSn22i3MdISt9S4yWNGnz/CUkuaUDSU5JWSFoq6VG5PybZUpl1y1VUqVD0D0x6POBfNVoEAADABtlPFo7X2LEvlmk/ue8n2b6SXiRp5+d8YHo5t3V/nf7GBm2z4Sdc+yC+5vEK/WnYSENCp8zukPx2lfRPeeF2P263Bzbvb5dvBAAAwDNsXuceKiUHy+wQuR+ssWP3Ll/ay9fzda/wNbWlpJfK/aVrikzfBtJg8LCk62V2jUzXaczKm336tN5QRWaN+cZTGjBUf5R0pLJtwuBQJJAb1r54eyWjjpCXjpTsjZJ2UHY9XQ4D0qUq2SXeNnlhFZ/rKkmHKsMIAKgUAgCQEdZR3Evy6ZIdJenlEU8I7y6HAS/9SuOnXOHTy3MOKuUqAgCwBgEAqGN2dleTCvaOwQv/IcqfxyX7g1RaoO7uS/ykw/o38/EIAMAgAgBQZ+z0xaM1ofA2WTJb7q8PeRO/zjwgab6kn3prc3GEj0EAAAYRAIA6YXOX7CP5h+V+rKStQ9dTxwYkv1RuZ2pJ8+/9JJWG8bkEAGAQAQAIzM7pfLUKhRPl/ha6/WHrlPRDFcac5TN2XDmEjycAAIMIAEAAtkAFreh6r8w+LekloevJPLPH5DpDScMPfOau6eZEG0IAAAYRAIAaspOVqKnraMlOkbRn6HqiY7ZC7j9WY/JNf9/kZTEGgFiXfgBAlCy9NM3rfqeau/8p2QVc/KvEPd26+ET1ljqtvetL5R0RI0MAAICMsPbu/dVRvFIl/43cXxy6npzYWmanaOzYu21ucXb5lkskCAAAUOdszt3bWXvxBzK/UdJrQteTUzvL9TOtLN5oHV2ZHvpfiwAAAHV8n986uk5QY2OnTB9Lj8YJXRO0v2T/N+7z5+35jctuVZYxCRCVwiRAoIKso/NFUjJH0mGha8H6JauWa+d7rtT93z1BWUQAQKUQAIAKsDk3j1LjxC9ISt8aQ9eDTRu7+G+a/fIWfe8dBypLuAUAAHXC5ne3qHHbKyR9hYt/dvRMPUg/fHicdv/cmcoSAgAA1AGb2zVTJd2W04N6Mq80epw693qjJnzqTLVfd6eygFsAqBRuAQAjYD9fvKX6CudIdnToWlAZo5Y9oMPHrdCls49QPWMEAAACsXO69lRfw/Vc/OPSt80uuixp1uRP/Uj1jAAAAAFYe/HtSuxvkqaFrgWV5w2Num+/o7TVx36sv9xxt+oRAQAAar2Vb0fxGzL9VtJWoetBdT21/1t01IX36CuX3aJ6wxwAVApzAIBNsNMXj9aEhnMkvS90LaithmUP6p0Tn9YFM1+nesEIAADUgJ19/7aa0PBnLv751L/Nzvr1yu100HfSgZ/6QAAAgFqs728YSO/3R7GHPEamNGaCbtr6xdrjS+kgUHgEAACo9kz/kq6S+9TQtSA8L4zSPVNeWxcrBAgAAFAl1r5kmhL7q9wnha4FdSQp6L5936IdP3Ja2DKCPjsARMrmLjlAVrpK0i6ha0EdMtMjB07X9h/6RrASCAAAUGHW0bmvvPQnSRND14L69tir3qsdPnRqkOcmAABA5Y/x5eKPIXv0lcdo10/8ULVGAACACrH5nZOlJF3qt3PoWpAhZnrgJUfV/DRBAgAAVIDN+/dEDSSXSWoKXQsyyBJ17XG49v/mBTV7SgIAAGwmW7CwUQN9CyTtGboWZJcnBf1zm3111JnpIFL1EQAAYDP39lfPuLNlqp89XpFZpcYx+tPT2+iTF95Y9eciAADA5pjb/VW5Hxu6DMSjf8J2OuOuJ3X+9Qur+jwEAADYnCN93b8Yug7EZ/VOL9IHf3NDVZ+DAAAAI2DzOveQae6auwBA5a3Y53DtfMJ3VS0EAAAYJvvJwvEqJemxbluFrgVxe/hlb9fB37uwKo9NAACA4Ro3do6kaaHLQD5WBtzYMEnfuOzWij82AQAAhsHmds2U672h60B+DEzYTl+7svITAgkAADBENr+7RW6nh64D+bNyj4M16VOV/dYjAADAENjJSjTg7ZK2DF0L8umBvd+o98y7smKPRwAAgKFoKn5G0mtDl4H88lFb6ML7Vulvd95TkccjAADAkE7400mh6wBW77q33v7jiyryWAQAANjUVr+yMySNCV0LkHrkZUep7RfXanMRAABgY+YWPyjZ60OXAax7K+CChQ9ocxEAAGAD7Oz7t5Xr66HrAJ6vZ/dXaM8vd2hzNGzWZ2PIbMH9Y9RX2kKrexukxgnl32zw0eq31Ws+oq9Po0etUG/JvbX5ibDVAigr9H1Vsomhy8g4l5S+pq2Q1Du4dfLW6XZKkkaHLi7LOrfdU7+7+S697YC9RvT55p5+bTBSdvKVDZo8ZbLkzUrUIqlZribJd5Rre5m2k5S+gIwdxsMOSFoq11KZHht8f4lMXZKK5bfeUpfPnvKk6scfJR2pbJsw+CIFyOYu2UcauFVuNEqb9pCkf0q6S65Fki3SQN/dKo173Gfv3LPx189J28iSZrntKWkvWbKH5PtI2ptzFjZt4tXz9djZX9ZIEACGOxxY6DtArpdItq+kfWVKv1EbA5W0RPLbJbu9/J+vYP/UjKa7fE3irjUCAKJiHcVLJf1H6Drq1HKZ/U3ul8uSyzVr8i2Vft2x9sXbywqvlOwQSW+QtD+B4IWSvqf1ye2f0rffcaCGiwCwEXb2vVOVFA6Rpd+AfkhGEulSmV0v92slv1bLB270E6YO3maoKgIAomFzu46Q259C11FXzFao5L9RksxTcfIVfpJKtV+KWZgh+bFSebQVgybc8gc99cOPargIAM+/T7+i9xBZ8ga53iYrX/CzbpXMri0n9YL9zmc0/atKz0MAQDSso/g3ScNvqeJ0teRnqjD2Nz5jx5V1sSxzbtehcpsl6f3MI5CsNKAZYx7U3Pe+enifl/cAYB3FdDLKOyQdI+l1OfhmWiT5r5Xolz6z5bYKPi4BAFGwuV1vk1tldlrJNL9WVjjJZ03+i+qUzb93Bw0UPiLpk3nfonnCbZfpqe/OHtbn5DIA2PyHx6m/551KkmPkfkTAe/ih3SXpl0pK5/nMKXdv5mMRAJB55e6yo3iLpJcqvy6SJaf4rMk3KyMG5wt8QrJPDHPCdTxKAzqm4T6dP/OwIX9KrgKAtS+ZJivNlPRBSduGrqfO3CzTHK0efe7GZu1uBAEAmWcdxXQ08LfKI7PFKvl/e1tzZuc+2NldTSrYDyS9XTk0/vbLtfw7xw/546MPAHb64tGaMOr9Mv2X3F8eup4MWCZpnqxwus/a7d5hfB4BAJlnHcV0f9WDlS9PS/qmpFO9tTl9P/OsvfMoWfLDvE0WNB/QR7Z+VD965yvzHQBsTudWakxaJaUneO0aup4MKsnsj5Kd6rMmD2XTaQIAMs06iumr5vXKE9c/VCi9pwK3AOtzUvfK/u9J+pByZKvrL9ATP/tsPgOAzbt/V/nA5+R+XG7vBVWcX6sk+ZrPbLpkIx9EAECmWUfXryQ7Wrlh89Xb+OER3vLLDOvofpfkZw/uPhi9pHeVvrdHnz522H75CQA25+7t1Nj4aUkf49SuqrlB8q97a8vv1/NnBABkls3vbtGAp4esFxS/pyQ/3ltbFignynsIePJLmV6mHNj++vP1yM8+F/9hQOlQv3UUT1VjY7pF7olc/Ksq3ZXrd9ZRvGJwuBSIQ8k/mJOL/4Mq+WvydPFPeeuUe7Si/1WSfqMceGKv1+hf994bbwCwk5XY3K6ZakwWDV7404MlUBvpOpPrrKP7gvKsWyDDyvvRu9JNZWLXKSsc6se1pHv25055R9Rxzf8ps7MUub5tdtFxF94WZwCwed2vU1PxFrnNlbRj6HpyyiSfroLdaXOL/9t+3Z156J4Qo5aWt0raRTEz+7sKA68a5sqe6Ph0DWhWU7pbzsmK3B0PLI1rDoCdt2QbrS6dKiuv46/3PflzpbB86aqX9HSOufnE6cow5gDkkHUU/yDpzYrXzSqtfp0ft+fy0IXUE2vv+n8y+6IiZf29+ubkHn3miJdmfwTAOrqmq7d0l0xpeuPiX2cGJkwcc8uOr9D4z87VNy67NXQ5wJBYR3GnyE/8u0eFgTdz8V+PtpYvS3amIuUNjfr+H/5vox+TZOE/qM3t/r1kF0jaIXQ92LiV016rL99d0t5fmR+6FGDT3N8d8eS/B1Sw//AZuz8SupB65OmPcU3/VT4bJVLLtm3ObgCw9mKazG+R+1Gha8HQDYzfVnc1H6oJnzpT869fGLocYMPMMn3PaqNH9yZ+pM9o6gpdSt3PCZClxwtfpwit2u3FOvHim7I1B2DNsbz96b3+Exjuz7aGZQ/qlfaYrv5EOs+q7jEHIEfs3O6d1e/313sjNDI+01tbGIYbIjtr8SSNGvUPuW+nyOx882/0wOmfWu+f1d03vnUU99KK/vRgmnRDHy7+Gde/zc66dstp2ukj3w5dCvBcAz69Hl8DN5vZWVz8h8ePn3r/4FLQ+uuIN9Oy7V+0wT+rq29+6+hK28QbZNo7dC2oHE8KevjAd2vCZ9p17nV3hi4HWMMV463FO7W68eOhi8gib236o1ynKTJPT5qm0zYwMbsuAoAtUME6il+R7ML0LIPQ9aA6VuzzOh133VL957wrQpeCnLM5D6bnhByquPTKkmNi39u/qpYU02WBNysmSUFnXnXL+v9Igdk5iyZoRTHdW/6keqgH1dW33WT9euV2Oug7+TxyHXVidO/rJG2huHzXZ01miG0z+EmH9atU+nD5NNSIPLSyd72/H/SCa+fct4uS0VfKMn+IDIahNGaCbtp6XzWf+LPQpSCvvBTba8596un5WugiYuDHTfm7pKj2B+jZ/cD1ng0QLABYR+e+SgbSs7f3D1UDwvFCg7r3OkLbzD51SIdWAJVlb1BMEvu4f2QaK1gqZaDhC5IeVURLsz//f+l5eXUQAKy9+FopuVbS5BDPjzphpicOfo8O+uGfdOvCxaGrQU5Y++LtJe2haPhffGYT99QqyD8w6XFJ/6uI3PTPO8IHgPJBPoldPLjmGtDyl71Zh7ZfravvTI9jB6qt4eColhi7nRK6hCj1Lj07nRaoSDzVMC5sALD2zqNU8j/KfXwtnxfZWCHwpvNu1u9uvit0KYid2SGKxw3e1rzxDd8xIj77gD5J31Mknp60T7gAYO1d75Ylv4lw5i0qpOdFr9R7L7xdl96yKHQpiFopHQGIQ2JfDV1C1HpHz5H0SCybsn36whtrHwDKe/qbnStpVC2eD9nVs/sr9O5f3cztAFSFnZy+5tnLFIdbNbPp0tBFxMzLeyrYDxSJS2+7u7YBwOYueb1M6QY/o6v9XIjDyj0O1pHzrtffCAGotN260n1R002AIuDnlE+0Q3WVko50Ir0i8GCxs3YBwOYuOUReuohhfwzXyr1fozfO+TNLBFFZifZTHPrkA+eHLiIP/LjdHpD0V0Wgd7vJtQkANve+3eWldGnKC6ceAkNcHXDIKfNCl4GoJPsqDn/wtqnRrFOvfx7F4Uqrt2+pfgCwOXdvJx+4RFK63hYYsWWvbVXTZ84IXQZi4f5iRcGiuCBlRmHsb2SW+Y2W+reb9JyVVhUPANZR3EKNjemw/4bPIASGykz37X2EXv7NX4WuBDEwTVX2Pa1xhbTBQo34jB1Xykt/Usa5FXTenQ9VJwDYms010gkT8SyzQV0cJ/yPrfbS+8+7KnQpyL5mZZ3rep8+aVXoMnLHkiiOMf3X/Q9XaQSgvet/JB1T0ccE0om4W4zXggdNc6574XaWwJBvTcawA6l5FBeizEnimAj42MNVGAFYs8WvvlGpxwOer2/ibvrU725lZQBGpqEh+91/ygpRXIiyxmc0/UvSv5VxPauermwAsPZ7d1PJz5dbQyUeD9iQlXu9WoedxnwAjECh0KTs69HYFTeFLiLH/k8Z17fVjpULAOWdtayQrtXaYXMfCxiKRw96t153enqeFDAMrmdf+bLrXz59Wm/oInLsNmVcafw2FRwBmNyVnpt82GY/DjCMmazXDkxU+3V3hi4FWWKezgHIOOe0rLAWKeMGxmxZmQBgc5ccILOozkxGNvRtvbM+fgGrAjAMJU1U9mX+ApRxdynjKhIA7CcLx8tLv+CAH4Sy/KVHas8vp6tOgSEwz34AMAJAUL1L0xnI6THBmVUau9UzE6lHPgIwZuzX2OwHod27y/465bJ/hC4DWeC2rbKulCwOXUKe+ewD+mTWrQzzQoNuePjpkQcAay8eJNNHK10YMJLhrNMu/XvoMpAN2T+UzPzx0CXknvsyZdxDK/pGFgBswcJGmc5OF9VUozBguJbv90a97Ou/DF0G6p1FcCR5Mmp56BKgzH8NHunpHeEIwMqxn5e0TxVqAkbsjrFNOpdVAdgYs0Zl3ZgnM3/xicByZdwTq0YwAlDe8Ef6bLWKAkaqf+uddMJPOR4dG+Ge9QDQxx4AdcAs8wFgVd+aADC8nfus4TuSj61STTErSbov3YZ5TXr0lXJbmQax8n1J83GyZCu5T5DZOLlPkcS/8zA9eeix+q8F1+uM6a8KXQrqkWtU+biy7EpfMxCae+a/Dj39/elPPuQAYB1dh0o2vapVxSGdpHOV3G8uL9kp6W5NGHX3cE7vKp+qOL9zNw3YnrJkD8n3kes1kqat+WOsj48arfk3LiIAYP1M5Ve9DMv+JMYYuMZk/VV4i4byFL6ehiFv99tk3696Vdm0WtJfJPuLEl2hrqZ/+knljn/EPP0xY8oSSenbn9f+vp3VtaMKdphMr5N0ZLoPY0X+BhFZOe21OuT7F+naT7w9dCmoP1kfPt/C5tw8qrwUDSFNUMaNGVXevmf50EYAJhfTI373r3ZRGXOzpPny/vO8beqjtXhCP74lPcg5ne7+y3Io263zYFkyQ6b3SHp2e6c8M9MtKziTCuvh6s1656bx24+XlPllaJmW2AS5K8u2HVOeDvPoJl8pbYEKMp1Uk6rq33LJfioNnOmtU+4JWciaUYYp10i6xuY8+EmNevpdMvsfSS9Vzj09aR+95Ovn659fSHMRMMjKo3XZNtCfdp8EgJDcMz8CsO3Y8gjAok23SiuLMyTtqXx7StIZGmj4ln9gUt1txOGzd+6RdG76Zu2db5CSr8qU6xvhi2zb8naXe+++e+hSUD+yHwDcth68NYhwtlLG7Ti+HAD+tdFlgOn9JklfVn6tlOyLKq2e5K3Nn6vHi//zeduUy72tOb018AZJtyinVu+8h941/7rQZaCeWHmCbraVLF0hhEAsvfUqNSvDrDSgQ3cck7571cb3ARg18X2S8voN9xv5wN7e2vR1P27PzK379FmT/6JxzQfK/YTB5Ya50zU6huPfUTm2VNmX99HYsCYvac76aoxk1VPpyGg6GnZdstGlaKb0nnLe3KvE3uytzUd72+7p2v3M8uka8LaWH6nf95JZeosgd6MAB33nt6HLQL1wz34AMAJAUOZ7KeMKPU+mP12SLgPc8AhAe/EISfsqT9KLZE/PS31mU/qPE4109YDPapoh1zvyNoHojsezf9sXFeKebsSVbSVl/gKUae6ZD2BJTzqlTfPL72/wo/LV/adnI34ivUj6R6atUKS8rfkiFUovlet65UTP1IN0dPsVoctAXbCaLNetKtO0wfvQCME88+fgJL096aZ0fyi/v74PsLlL0r9kOoksD+6SJS/31uYfKAc83WBofM9hkp2uPDDT5f9YGLoK1IOCxTB7fiu1dL8kdBH5ZYcp43zU6L+tXRGz/iRZKs3OyZazN8n7X+OzJufqGLn0QBFvbfqY5B8bPKcgaiv2fb3aOSkQiYqKgevw0CXkkc3vTHdezfy64tW77Hnx2vdfEACso7iFTMcqev4XlVa/vla7+NUjb205XbJ0n4eotxYtjdpCJ/2K2wC5d2zTQ+ldIWWdl9KtwFFr/cnrFYFS45i7177/whEAs6PTjYIUNf+5eh8/MovL+yrNW5vOk+utsZ809sjEzAd3bKbyGRtRbKJjrxncowW1ZBZH8BoodW04ALh/UDEz+5XGtcziQI1neVvzn2T+rggOS9mg1bvurbedc3noMhCc36vsm6DGbTN/LzpLrBy4/E3KPlfj+PUHAGu/dzepfOxsnFxX6Km+Y9P18aFLqTc+q+UySbNinhNw9Q3p+U3IN7tdMXDLwW3aOjJ62/T01e2VfZ0+Y8eVGxgBSI6JePLfbTK9y0+YysLwDfDW5vMlS3cOjNKKfV5XPh8AeRZJADAdbT9ZmJ4MiJpI0rlS2ee6bd1fPjcAmE1XnP6tfj/CW5tzuSXucHhr008kfV8R6t9qB330j3eFLgNBDcQRAKRxGjcmvW2HKrM5nVvJ/S2Kw+3rDQA2v7tF0isUnwG5zUx3wwtdSGb0Lv1suk+0InTLnewJkGu9y+6KZq6LW1voEnJhVJKeiVM+PSfzzO9Y/whAf+noOIf/7X+9remvoavIksEJku+PcdvglXvHO8UFQ/7ejmUU4DBrLx4UuoiY2clXNkS1K6413LKBWwD2ZsXnrxrX9M3QRWSRtzYX5aWZa1ZPxaN/qx3ZGjj3LKbRrS+ELiBqTU3vjWHzn0EP+azd7n1BALBzFk2Q6RDF5Sk1GDP+N4O3TblYpg5F5uob0p0wkVvu1yoWprdae/f+ocuIkaVnLliS3g6Ng9k1z/+tNSMAyeh0h6NGxcT0ZT+26cHQZWSejfqMzLJ/ito6Vuy0R+gSENJAfzwBoHzb1k8MXUSUmrqOlvuLFYuSv2Dka+0tgBg2OFjX7SoW09ns2Ew+c9elcv+yIvL05P00/3omA+aVHz/1fkndioVpup3T+erQZcTEFtw/RrJTFRMrbWAEQFEdLuFK7EN+0mH9oQuJRnfzHEk3KBJeaNB3r4hlHhhGxBTTxGBToXAG2wNX0MqBz0uaongsU/eSfzz/NxNrX5zubjRVsXAt8JlNuTnvvhb8pHR3QI/nXpik4l3PWQ2D3PFLFZN0qLpx4kdDlxEDO/veqZJ/RjFx/Xl9TXEiazgkouV/Lhmz/qvAW1uulnSVIrF6CvOmcm1U4c8yj22U8Ks27/5dQxeReYXCjyRtoZiYLlnfbycyi2n2/8Xe1vScdY6oIPOvKRJP77KXrr7zntBlIBB/3+RlcsW2HGSCSv3n2gIVQheSVdbRlW6F/h+Ki6tUSM96eYFEXnqV4vH10AXk4MCgmxQBbxyjU67iXIBcc/uD4nOYVha/FLqILLK5Sw6Q7DTF5x9+3G4PrO8P0nWOL1EcrvbW5mgmqtUvj+Y/yF33LA5dAkJKChcoTv9rHV1vDF1Elli6F46XzkvP/VN8FmzoDxK5R3KilEW3YU1dGrfqIklLFYGnVsd2CxjDUd4VzfWCmdERSCSbx3yAYWz4k4xOrx9xbhBihY0EgDisUu/Ar0MXkQc+fVp6kMoGv6GypHeH9Pwr5Jrpl4rTTir1/8nOvn/b0IXUvebityXFerLiTc/f/jfGAPBbnz3lydBF5IbbfEVgNQEABbsgtvMu1rGPCv1/tPkPjwtdSL2y9uLn5fqkYmW20YAbSwCI4oKUGW1N18ss8zfQS2O21IkXRzGnESPkM5q6ZBbT1sDPd5D6V51XPtUOz2HtxTaZolnZtB4D6uuLPgD0aHk/x7vVkKc/3KOYQX3tYo6LyL2Sn6WYmd6mpuZfWkcxrrXtm8E6uo9T4nMi2gPnhcwuGdz2OuoAcK2fMHV16CJyxxVF6HrgoYdCl4DQxjektwGWKW7pPe5LbU7nVso56yh+XPKz5Bb5qEjpzE19RPYDQCQXoszpK11ZHmLKuCcffTh0CQjMp09aJfkvFL/XanThmryuDrC0J27vSif8fT/qzn+Nh7T68fXu/hdXADACQAiDky4zv+ti3/iJoUtAPUj0M+VBemZAqf8am9d1oHLEzluyjdqLF8rsf5QH7mf77AP6Yg8APeou/j10EbnlnvmzAfq33il0CagDPrPlNsn/onxoluta6yiemHbFipyd0/ly9Zb+Xp4LkQ+rNSr58VA+MNsBwLWIY39DsjuVcQNjtgxdAupFknxHebHm/vepaVcc614B5SH/9H5/klwb2dG+m+Dn+rFND8YfAEyLQpeQb5b5f//SuK1Dl4A64TOb0num/1SepF1xof9Om9s1M6bRAJvXuYc6in8avN/fqPxwWeF7Q/3gbAcAEQCCKhXuUsYxAoDncP1A+bOT3Oaqo3i5dRT3UobZTxaOt7ndp6mU3CEpj+chXOKzJt+ZjwDgBICQ/AOTHpfZY8owb2jUuddl/k4GKqVv6bmSOpVPh6cjIOkF1M7q2lEZYnNuHmUdxVaNG/cvuX9a0ijl0ynD+eBsBwBTV+gScs898y+WNz+yMnQJqBODM6eH9SIamcbyBbTBuq29+DNrv3c31TFbsLAxvX2h0dstlNQu90nKK7OLh3sibrYDQMHY/z80s6eUcU+s2uRqGeTJuOZ0a/G7lW+jZZotKyy2ud1nWnvxINURO+e+XdJVDFo5tqt8+8J9qvLNVdJJw/2kbO+EtLpveegScq/ky7M+dWhlX3rAIbCGT9eAddjJkv88dC11MiJwvEzHW0cxveV6vqwwf2MnzFXLmq2M/a2yZKYKpTfFv5PfsPzW25qGvS9Ltv8BSwkBILzMfw16VrOSFM/T3XS+moqfknRA6FLqyJ6STpIPfNk6yvuv/FXyv6p3i2t99s49lX4yO1mJduvaV2aHK7F0fsLrJBsnTw9vzHjXUVnpEOYXR/KJ2Q4ADy5ZmavlnfXIfHnW/zOu6uMWAJ7LT1LJzil9QkmSbnaV7W/wyktvHac7CR4o2efUuLrXOop/k+sfku5Sktytvt5FmzqIZl3lMwoatYfc0pCxl2TT1GyHym278geUL/rYgB97a/Nd+QoA5v1sAlQHXE9n/eWxt/eZIw1KYStBPfHjplxj7cUFMv1n6FrqXLrO/lCZDi3/yktSQ0M6ZJ+OCjya3mWTtKI8X8hLT5a7eLPxch8vKV2Hu7UakzWbEa37WsJFf9PSVVjuJ2uEshsA3Brs9MWjOQkwsPQ/csaNGV1eMZSmgFWha0G9Gfi0VDhK0tjQlWRQ+m/W9Myv1h265+JeGSX/krc1PzHST8/2KoCtxmT+4hOBCcq4sWsCwIryeAawDm/b/T65fyN0HcALmP1d45vP0mbIdgAo9WX+4hOBzH8Nxm1RDgD/Dl0H6tSS7lMl3Rq6DOAZ5v3pMs10xYpyGwBUyvzFJwKZ/xqMH1W+E8aukliv8lyjxD80eJsIqAN2ms9sSiddKscBIOEw9/Ay/zXYYezo9Kd073BgvXxmy42STg9dByDpHo1tqMhulRkPAP6i0BXkWXmdrrS7ssxdRzSXDwS6InQpqHOFMV9ipAiBDciSNp8+qSITlrMdALy8MQVCaSpOzvrs6GT1Sh26z4vS5UrXh64F9c1n7LhSbu9LV46GrgW59f981uRrK/Vg2Q4Alm4YgWAiCGCFVeWjDC6S9HToWlD/BrdbHfae60AF3KTepV9TBWU8ACSZvwBlWpL9AJD0lM+TSo+ABYamu/lbcm4ZoaaekifvGTytsmKyHQDcW8pbSCKUlyrjktU96S5lfwpdB7K1TbAG/L0sHUWNuOTHe9vkih+9nu0AIBXUaK8JXURueXo4R7b5FuOvY3kXhsuPb3lYiU1nPgBq4Fve2rKgGg+cRLAbUuYvQllkc+9LZ/83K+N6d9qD7h8j4jObrpf806HrQMRcV6i7mK4+qYrsBwBXekwkas37o/h3LzUkFR9WQ354a8vpks0PXQei1C31H1PNQ++yHwCkfW3O3WuOjETtxDPyUgxdADJu3MrjJf01dBmIylNK/G3eNjU9TbFqYggAiUY1Hh26iDyxBfePkestyj5X/9OLQxeBbPPp03o10JDOB2CTIFRCn+Tv9pktt6nKkkgORpgRuoRcWdH/jsFzvLOuy4/bc3noIpB9/oFJj6tgR0p6OHQtyDjXCd7a8udaPFUcAUB2iM3r3CN0FTkSS+CqesJGfviMpi6p9Nby8C0wIvZFb2v+mWokkgCQzuZK0i06UWV2VteOSvyNioEZBwChorx1yk1yO1JmK0LXgowxfc9bm75ey6dMA8CDikOrzbm5fLA7qqjB2uRWPj83+0q3h64A8fG2putUGngn20tj6PzHPqv5U6qxNAD8XXFo0qiJjAJUkXUUt5D0McXCLT3iFag4b5tyucyPYaMgbJqfrdaWExRAGgAqdrJQcIl9yRaoELqMiH1I0s6KwwPe2swSQFSNz2r5nRJ7E7cDsEGmM9TdMjvd61cBJCqV4gkA7lPV08WSwCoYvL1S8yGqqnFdE7oExM9nNl0hL72ZiYFYj2/6rOaPlM+WCCRRkqS3AFYrFs4oQFWMmphudjJZsTClZwAAVeetLVfLdYSkx0PXgrrgkj7vrc2fC11I4q3N6USVmxWPfdXT/eHQRcTE5v17okynKCZuV4cuAfnhbc1/08DAQZLuDl0LguqVeau3Np+qOrB2GWBNNh2oGfev27ndsdyrDs/702/WiYqF2WNa0nRr6DKQL/6B3RcrGXWwzLj9lE/L0jkhPqtlnurEmgDgukRx2VJ9XhcJK+uso/MVcj9Ocbk05H035JfP3HWpxhaOkPzXoWtBTXXJk1eX54TUkTUBYEnzTeWuKCamGTavO5YDa4KwBQsb5cnPotowao1LQxeA/PLpk1aptSU9OyC9BzwQuh7U4EjfwsArvW3yQtWZ8gv7mm7I47oNkEaAkp9nHcWdQheSWT1jT5XpZYpLSUl/bN/ryJh02Ze3Nn9T0hskPRK6HlRtst83Nb75jT5j97r8Gj/b2ZX0e8Unvfi328nRdbBVZ3O73ibXJxQb19/q9T8j8sdbm6+UdFBkE7EhPSHXO9OZ/j69fkd5nr0wrupJA8AqxedNaip+NnQRWWLt9+4mt3PKoyixMf0ydAnAusobUnUXXynpZG4JRMB1vTw5wNuaL1KdM/dnNyCyjq5fSRbfRjrm/XK9uVZHLGaZzX94nAZWpRNVXqH4lJQ0TPaZk/4duhBgfcrzllzz5D4pdC0YyXXGvqZxzafUc9e/rucOjZsuUIzKh9fYhTav+1WhS6n73f76Vy2I9OKfuoaLP+pZeZZ4f+Elkv88dC0YljvlfrC3Nn8lKxf/FwaA1VtcLGml4jRWJb/I5nXuEbqQemTpj8btzpbpSMXKPQ03QF3zD0x63FtbjlVi6RbC3aHrwUb1lSf6Le8/oHwUdMY8JwD47J17JMX8Irm9SsmfbN79u4YupO60d50m+QzFa7UKjb8IXQQwVD6z6RL19LxYrh+Wb1+hzvi1KthLyhP9Tpiaye30Xzg73u1Mxa1Zpf5rGAl4tvO3jq7vyOx/FLffljdhATLEPzJthbc1f1yJvVzSVaHrQdmDMn1I3S2v8RlN/1KGPWcS4DO/2VG8Q9I+ilt6MTjKW5tvUJ43+lk5dq6k9yh2bq/3tqa/hi4D2BzW0fVWyX4gqSV0LTnUK9dP1dj/ZX//1ChOd9zQ+vjYRwE0uLf9ZdbemW7EkTv288VbauXYS3Jx8ZfuVVt9bcEJjIS3tvxe4xr2GdxFkBGt2hhI10epYHulozGxXPw3HAAGGuZHPBlwXROU2CU2t/jZ8iS4nLB5Xfupr+FGSYcrD0xz0p3XQpcBVGor4fIugj09zYNB4InQNUXKZXaxSn6AtzbN9BlNXYrMem8BlP9gbvfpcv9v5YXZ5eorHevHtzysiNncrplyO6O8KiIflkua7K3NvEgiSnbekm3U659MZwxEdWpnOAOSfiWVvuatU25XxDYSAO7bXT6wSFJBeWF2v1R6v89qiW6yjc3p3EqjkzPkeq/yxPQ9n9X8qdBlANVmpy8erS0Lx8jt85L2Cl1P5pitSM+PUaH0HZ855W7lwAYDQNQ7A26cS3auCv2fjmXP+PLEIUt+krvdxdKduRLf3WdMWRK6FKBWymefNHe/U9KH5Z7e5uMslI0xWyz5mRqVnOnvm7xMObKJAFDen/p65dPjMn1exeazsnp2vLUvmSYr/VjSYcol/3l5QxUgp+ysxZPU0PB+Sf8lqSl0PXVktWS/kw/MUduUv+R1jtBGA0D5A9qLf4x6d7hNu0XSKWptvigr3yTWUUwnB50o6QOSRimfBlTyffy4lvQ2FpBrdvKVDWpqOULy/5T0dklbK38GJE9PX/ylBkb9Ot1xUTm36QAwd8kB8lK6xWFuZslvwJ0y/5aK3ef5SYf1qw5Z+5IpUulEmdpyfOFfa663NreGLgKo07kC/yEl0+V+ZOQTB3vTM0Ak+7UK/b+K5bZuzQJA+YM6ihcOpkak94vcz5YP/Nzbdr+vTjbzSfcMnyXpbdzvK+uTJ3t52+TO0IUA9T9fYMnL5KU3yOwNUumwNYenZdpDkv1ZKv1evX6Zz57yZOiCsh0Azul6iRJLh8K5uDyrJPkVcpuvxv7f1nJziPJ/2qbigZIfK9l7Ik/ww+ea423NHwpdBpA1ds6iCbJRB8mSV8vsELkfImmM6lunZNfK/BopuVazJi/Myu3aTASA8gd2FNslMaS64XWjt0q6vHxARKn3Sj9uz3T9eWWH95PSG+T2aslfL2mXSj5+RJarwfb0Y5seDF0IEMUR4aO221fyNW9m+0lK33YMUE66Od2dMrtN8ttldrsa7Na8zdwPEwDO7d5Z/Z5OqJpQ0QrilJ4MlR4SsUiu9N/sLiXJ3SppmUZrmVY8usJnH5AeI/ncdfoNo8ZJ/RPUkEzRgO8l055y7SHTtED/4bLo897afGroIoDoRwqSUc0ya5GsWV4+m2CHwdHI7cpvZhPlPn6Ir5ePy2yp3JdK/pikh+XpviwqypTuwFf01uaHavBXy5UhB4DyB7cXPy/T16taUX6k3/Q9gxstbRm6mEh0ann/tKwezQnEyn6ycLy2Hv+cicl07lkLAB3FLcpDMNKUqlYFjERi7/KZTb8NXQYAZMGwJvV5a/PTkj5avXKAEfsjF38AGLphz+r31uZL0x3Whvt5QBUtlw98OHQRAJAlI1vWlzR+XBIbKqA+uH+hHvZkAIDoA4DP3HWpzDhhDfXgOi1p+UnoIgAg6kmAL/jkjuL5ko6paEXA0K1UUto/L0d3AkAlbe7Oful9V45aRRiuE7j4A0CAAOCtzU/IfMbgTnhALf3G25rT3SkBACOw2Xv7+6yWqySdtrmPAwzDfWpMjg9dBABkWWUO9xnX/CVJl1XksYCNWy2VjmYXMQCogwDg0zWgZNT7yvs2A1XlJ3jrlJtCVwEAWVex433LSwMTT1cEsA87qsTme2vLmaGrAIAYVCwApHxmy40yY6tgVMMNks8OXQQAxKKiASDls5rOlukblX5c5FqX+v0dg2dRAABCbwS0wQdNf8ztnif3Yyv+4Mibx1Xyg/24lkWhCwGAmFR8BCDl6Q/3D8rsmmo8PnJjtczfycUfADISAFLl4drVA0dJurlaz4GoDUg+Y3CfCQBAVgJAymdPeVLef6SkhdV8HkTHJZvtrS0LQhcCALGqagBIedvUR9Xvh0tiGBdDkU5K+Yi3Np0TuhAAiFnVA0DKj295WNKbJHXW4vmQWen0kY97a/NPQxcCALGryiqADT5ZR3Enmf1Z7i+u2ZMiKwZk9qHyMlIAQBwjAGt5a/ND6i+8VhJbueJZ5v3pzSIu/gAQ6QjAM0963pJt1Dvwe8kOqfmTo970yEvHeNuUi0MXAgB5UtMRgLXKJ7ktH3i9pPNCPD/qxkNS6TAu/gCQkxGAZ548/dFRPElS+oZ8SZeGvsVbmzlBEgDyFgCeKaKj64OS/UhSY+haUANml8t9urc2PxG6FADIqyC3AJ6vfMRrqZTOB+gOXQuqyuX6oYpdR3LxB4Cw6mIEYC1rX7y9rPALydL5AYjLcrkf520tvwpdCACgTkYAnrNrYHf3m2T27cEd4RCH2yQdyMUfAOpHXY0ArMvauw+X+TxJu4auBZs15H+m+kZ/0mfv3BO6GABABgJAyjqKW0s6Q9J7QteCYXtEZsf5rKY/hC4EAJCxALCWtRdnyfRdSduGrgVDcp68/xPlWzoAgLqUiQCQsvn37qCBhm+nZ8SHrgUb9IAS+2+f2fTb0IUAACIJAGtZe+dRsuTHkiaHrgXr7OXv9mP19HzJPzJtRehyAAARBoCULbh/jFb2f0zSFyVNCF1Pzv1ViX/SZ7akM/0BABmRyQCwlp1z3y5KSqdKfuyanYVRM2aL5aUveGvLgtClAAByFgDWso7OV0jJVyW9KXQtOfCA3L+h8avm+PRpvaGLAQDkOACsZfO6XyXXV+X+htC1RMfsMbl/W+MafujTJ60KXQ4AYPNEFQDWsvbia2X6rKQjuTWw2brl+oEaxszxGTuuDF0MAKAyogwAa9nZ905VUjhBpg9KGhO6noy5Vebf0+rHf+GzD+gLXQwAoLKiDgBrWUdxJ7naZPqApN1D11PHnpb813I709ua/y90MQCA6slFAFjL0h9zlxwuL6UjAu+QNDp0TXXiNsnPUmPhXH/f5GWhiwEAVF+uAsC6bE7nVhptb5eS6XI/QlKj8qUo1+/kpQV+3JRrQhcDAKit3AaAddnZ92+rhoF3yv0oSa+PdHOh9Av9D7lfokLya5/Z9I/QBQEAwiEAPI/NuXmUttju1RrwN8mUjgzsK6mgbHpI0pVyXaoBv9SPb3k4dEEAgPpAANgE+/niLdXb8CpJB8v0akkvl7Sl6s+ApEUyu04lv0algWv9A7svDl0UAKA+EQBGwOZ3t6hU2ldK9lXJ95P0IpmaJW1Tg6fvldkSuXfJdIdKul1JcpvGJgvZoAcAMFQEgAqyjuLWkprlapJpZ5lNlPt2kk2UfKLMGuWezi9okCuRaSu5VsvUU34A11NKbECuZTJ/TLKlck934FuqREtUKnVpye7/9pNUCv13BQAo0/4/5EcyKO16EWAAAAAASUVORK5CYII=",disc:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AABfEElEQVR4nO3dB5idRdXA8f/cTQ899JLshgBSpXdpgoKg1IC0ZEMJigJiLyhNEFFQRFRCySZBFCICggLSS6QjglQh2Q1Rigk1hZS98z1nM/HbhJQt996ZOe/5Pd9+G0HhJLv7znln5pzjvPcYY9Llve/hnFsdWA2QzysBK4fP7T/6A/3C517AikCP8Lm95YCei/y1ucD0Rf7au0Ar8B4wB5gBzAyf313k453w+S358N7/1zk3r8p/NMaYbnCWABgT1arAusB6wKDw63XC5wULvnzOkSQD/w2f/w1MCR+TgdfCr6fGDtKYorIEwJjqKgEDgSHA+uFz+1/3pdhkR+FV4JXw0f7XkiSUYwdojFaWABhTOWsDmwCbtvu8ZdiSN503JyQCzwHPt/v8YjiaMMZ0gyUAxnSS976nc25DYJt2H7bQ1z4xeHKRj1mxAzMmJ5YAGLPsLfyPATsAOwLbhzf7RS/Rmbjmhh2CR4FHwmfZKbAHnDFLYAmAMR+9Ib9L+Fiw4C96i97k4b12CcFDwMOLqXQwprAsATBFt1xY6PcGdgW2CyV0Rh+5N/A0MCEkBHcDb8cOyphYLAEwRdMb2BnYJ3xsHbb5TTETgqeAO8PH38L9AmMKwRIAUwQbA/uGBX/30CzHmEVJg6P7QzJwG/BS7ICMqSZLAIxGdcBOwAHA50ICYExnTQrJwK3AHbY7YLSxBMBosWJY8A8EPg2sEDsgo+5CoSQBN4eE4P3YARnTXZYAmJytEhb9oWF7X873jam22cCDIRH4XWh1bEx2LAEwOS76hwGHh/N8GXZjTCwy8Ohe4Drgj2EokjFZsATA5KBPeMM/NmzxW5meSXVnQO4MjAduCJcKjUmWJQAmVVKatxcwDDgIWD52QMZ0gtwRuBEYC9xnQ41MiiwBMKmRMbhHAyOBwbGDMaYCZOzxb4ErwrRDY5JgCYBJQd9wrj8C2EO+L2MHZEwVlMNuwGjgD8CHsQMyxWYJgIlpA+D48LFq7GCMqXFZoVwc/EUYYmRMzVkCYGI06dkTOA3Y3972jWmbTXCJ9/4m55xMNTSmJiwBMLUib/gnAScDa8cOxpgE/Rv4FTAKmBo7GKOfJQCm2jYEvgScYD34jelwOeH1wE+AZ2MHY/SyBMBUg2zr7wd8NZTy2Ta/MZ0nD+e7gItDG2J7WJuKsgTAVLp2X871fwBsGzsYYxSRnYCfeu+vdc5J90Fjus0SAFMJ0oP/COCMcLPfGFMdzcDPQ0+BmbGDMXmzBMB0h3Tn+zJwOrBa7GCMKZC3wtHAZcD02MGYPFkCYLpiuVC7/x1gjdjBGFNg04BfAj8LvQWM6TBLAExnF3650f/NMJXPGJNWIiDHA+/GDsbkwRIA0xFSvnci8F1g9djBGGOW6G3gwtBhcFbsYEzaLAEwS+S97+mck/78Z1rzHmOyayokfQR+DcyJHYxJkyUAZknlfHKr/xxgSOxgjDFd9i/g+6GxkD3szUIsATCL2hG4CNg5diDGmIp5EvgacH/sQExab3rGLGjZK28JD9vib4w624RRxLfYrp5ZwBIAs2q4MPRPYGjsYIwxVXVAGD8sZYNWyVNwdgRQ7OTvmLDdL0mAMaZY3gHODuWDrbGDMbVnCUAxbRd+6LePHYgxJrqngVOAh2IHYmrLjgCKZS1gLPCoLf7GmGBL4IFwB2i92MGY2rEEoDhfZ+ng9yJwrI3nNcYswoU7QDJ18Iv2jCgGOwLQT278jgL2jB2IMSYbE0L3zxdiB2Kqx3YAFHfxA74Vbvfb4m+M6YxdgH8AFwC9YgdjqsN2AHTaCrgS2Dp2IMaY7MlLxAnh7pBRxHYA9A3tkYz9cVv8jTEVshnwN+ByYPnYwZjKsR0APfYFfgMMih2IMUatZuALwB2xAzHdZzsA+RsAXAPcZou/MabK6oHbQzmxPHtMxmwHIG+fBMYA68QOxBhTOG8CI8LLh8mQ7QDke8P/LOCvtvgbYyJZA/gzcAnQO3YwpvNsByA/GwO/DTf9jTEmlUqBo4FnYgdiOs52APIyLNzwt8XfGJNapYCUCZ5mXQTzYTsAeVgduBrYP3YgJivzgA/Cr2cBH4ZfvweU202AqwsvAyuG/9wH6Bt+LWVfPWoct8nbLcDxwH9jB2KWzhKA9H0mLP5y3maKaS7wWrh0NQ2YGj5PCw/Zae0/vPdTnXOy+Ff03olzTm59L/qxWvi8aru/tmYYKmOJQ3G9ES4ISsWASZQlAOmSN7ALwxAf21LTTd7E/wNMCnXWi36ektu8du99D+ecXFBtCKVj9eHXC/6z/D07gtRNFpdLQ0vyBbtPJiGWAKRJHpA3WDc/dWTb/dXQY/3Zdh+TgTkUS6/Qt0LOjjcHtggf61tioM4TwKHh+9wkxBKA9Mjgnt+Hc3+Tr/fCzejngOeBJ4G/AzNiB5ZBYrABsA2wCbApsJ0dgWVPjqeOCqXLJhGWAKRDtvm/CZwXLmWZvEwMI1QfCp9l0bcfrspZO0yo2zV8lkoY2ynIixxj/RA4J+yGmcgsAUiD3LQeHbbJTB6X8p5pt+DfGy7mmdpZAdi+XUKwS7vKBZN+lYCUNL8bO5CiswQgPtni/COwYexAzFLfXB4NLU/v8t4/6ZyTJMCkdXQgxwZ7A/uF5MB20tL1InAI8ELsQIrMEoC4Dgy9/BfUX5t0SHndfcCt4ePt2AGZTlklzMrYO/TPsJbZ6ZkOHAeMjx1IUVkCEEddOOuXM38r8UvnLf9pecMPC77MP7dzSl07bQeEhGB3QOZpmERKBb33X7ddtdqzBCDOm8kfwm1/E5c8cO4GrgduAt6JHZCp2c/gQcDhYZfAGhbFd1f4etjPYA1ZAlBbg8P0rI/FDqTA5K3+4bDt+PvQXc8U18rAZ4GhwKdtZyCqV0Ln03/FDqQoLAGonR2AP1l9f/RF/7rQptSYRQ0I9wUkGdjXdgai9Qs4MFTYmCqzBKA2DgPGWplSzUkt/pXhTf/12MGY7PoOfB44IYzgNrUzEzgGuDF2INpZAlB9Mh7zYmtaUjMfhjrjUeF8377BTXdJeeHIMO++f+xgCsKHhkFnxQ5EM0sAqnvT/5IwzMfU5m1/bHjjl21EYypNynWPAL4QOhGa6rvCe39ypadbmvksAagOeUv4XbhcZKpnVijZGxVuERtT612BI0MnT1M9d4R7GR/EDkQbSwCqc3Yoi5K9IVRPS9hdkbd9eyiY2C2JTwhHfQNjB6N8oqC8UNkF3gqyBKCyZHrZ7cB6sQNR/BC4yHv/B9sSNCnx3vdwzslb6tdtjHdVE/99QxthUwGWAFTOVmGrarXYgSjjw2W+X4TLfcakTgYUnRp63ds8gsp6K/RrkK6dppssAaiM7cKbv3QYM5UxO3TouyBc8DMmN0OAU4ATrQS4ot4NDYOkt4fpBksAum/P0OBnudiBKKoB/hXwk5DtG5O7NYBvheoBSwQq44NwJ+D+2IHkzBKA7pGxozfYD3VFzAGagLOB/8QOxpgqkC6gXw0XBvvEDkbJLuHh4QXMdIElAF332dBatnfsQBQM5Pl9aPgxMXYwxtTAeuGy4En2/KjIi8NR4UXMdJIlAF0j33BjrFd4t/vzyw/td8MQEGOKZlD4/j/OniXdHuV9QthBNJ1g7Wk7T7L2cfYD22U+NEnaOGzf2eJvilzWJs+TzcOQKnsb6xqptLgqNGYynWA7AJ0jbX0vlT+32IFk6nHgK8DfYgdiTIK2BX4O7BI7kEzJYvYN6RUSO5Bc2A5Ax0ld7y9t8e+S/4Q3nR1t8TdmqY2uPhF2xmR3wHSOPJt/GpIA0wG2A9Axx4W2s7b4d75XvzTwOc9a9hrTKf2Ab4YPqzLqHFnUTgZ+EzuQ1FkCsGzHhAt/tlvSObeGJijNsQMxJmPrAueH55C9gHTukvEw4LexA0mZJQBLd2goUbMLfx33VKhzfih2IMYoslsYgLVl7EAyMi8cp9wYO5BU2Vvtkn0qZI+2+Hd8u//bwPa2+BtTcQ9477cLl2hnxA4mEz3CC9z+sQNJle0ALN4uYbBP/9iBZOKB0O/85diBGFMAg4HLgb1jB5LRy4nMDrgvdiCpsR2Aj5Kb6rfZ4t/hoRxyu38PW/yNqZmJYYdyODAtdjAZ6BvuJMmURtOO7QAs7OPAPTbVr0NuDcNN/h07EGMKPmhIBmcdGzuQDLwH7BXuKRlLABaySdgiWi12IImbEhoi2QAOY9JxEHAZsHbsQBInE0Z3B16MHUgKLAGYT35oHglDOsySSQvkLwPvxw7EGPMRK4Yk4OjYgSSuJRz1vkHB2R2A+Q03pEzEFv8lez9sMUpdrS3+xqS7xX1MKH17J3YwiQ9hutXueVkCIEMkrg2la2bxHga2Aq6JHYgxpkPGh34BUp1jFm+bMIBJ1oDCKnoCIIM3DowdRMJNNM4Ovcnl1rExJh+TgT1D34A5sYNJ1P7hyKSwinwHQAZGXBg7iERNCluJNrjHmPxtF5qabRA7kESdHl4GC6eoCcBhYfun6DsgiyNDj6zbmDG6LB8GczXGDiTRuQGHAjdRMEVMALYL5X5y+c/8vw/DBK3RsQMxxlSNVAiMsuffR8wKPQKkGqwwipYANIRLbdI8wyx8XnhomEdujNFNLgjeEFoKm/83FdgJeIWCKNIW+Cqhxa8t/gu7LTwQbPE3phieDjuhMu/E/L9VQ4OzlSmIQiQA3nuZCvUHYKPYsSREtn7OAQ6wmmFjCuftcAv+vPAsMPNtDFxflPLAQiQAzrkfh5IYM9/7Ycv/zHABxhhTPK3AGcBnw2AvM9/eITFSrwh3AA4O510udiCJkB7YhwAvxA7EGJOMDcJzcvPYgSRCFsYjQlMltbQnAJuGW53LxQ4kEXK+dZSV+BljFkOek78PRwMGPghdYtUODtKcAEjd66PhTMfAKO/9l5xz0uHPFJAb9WRPeqwymDo2oszqlFw/PH3xzKG0ICl0M/Dl+Z3jvH+HurpWKE9jXo+pzJg9zZ8yZHbc34WpsrrQFEeGfhl4KSQBKmegaE0AXNi6kXPuoltw2e+s2IGY2nNjJm+D9wfi2BPvdwB6du8f6Kbj/bRQMjUV5/5LudxCqTQJXHPbx+y3JvuR28yt2G/CxHAacHFR7oktw83hKFndYqk1AZCLLefGDiKR5j6NoeuhKQg36vV+9J59Ap6R4RgsxuWyf4eW0q/i+Sel0jOU5zzjRwz5b4R4TNccHIaAWdMg+JbG1vEaEwC5wXl7Uco4lmJaGHQ0IXYgpoZb/L1XPRXv5WG1GmmSGezP4tw/oPws88pPMWX95/2ZVo2SqB3C3aHVKbYy8BltvRO0JQCDQkMbaehQZK+Eb9Z/xQ7E1Ia7euKulEq/ifTG311SgvY3nPsbZf8Qc3s/7keuNTN2UGahDqp/AT5Gsb0NbBt2tlTQlAD0BR4CtqbYZAb4Qdbcpxjc2ZSob/kOlM/CO2l4pYHcH/j7/GmU7k7m9LrPEoIkOqnKTsAuFNvjYUS6isuwmhKAS+3matvRxyFhsIVRzjU19wF+FxI+7XdZ7m/7/i772/xxDXIz29Se3AX4I/Bpiu1i4GsooCUB+HToaV/kZj+3AIeHh6VRzv3q+eXo1+9WYHeKZxL42yiVbqXvjLv90E3mly2aWugVkk550SgqH1qoy7FI1jQkAHLZ6RlgTYrr9977Yc45K70qymW/XgMk4Sv6m5h4F9wtUB7PnLdvt/LDmpAL1lcBwymuN4GPh8/Zyj0BcKFGU3pZF9UVwBesp39xuDEt4/D+mNhxJMe5qXh/A95dz3KD7vdD28oRTXVIf4DLgRMorptzP37LPQH4cjj7L6rLgFM0Nqgwi+eaJp0oewCx48jAG3jG4spX+sbBVg1TvRewi4DTKa6TpMsqmco5AdgklPzJ7f8ikgmH344dhKkd1zRxAyj9o8Df810hD7j7wV0B/o++sd7uyFSe9J24gGKaCWyT67yAXBOA3qHPv5zBFNH3gPNjB2FqyzU1/zn0dzBd8x6e6/D+V/64BkmkTOUUufvqk8DOQHaXUXNNAGTb6asU0w+B78cOwtSWGz3xAFxJLv6ZivB3UypdxLBBt3s7QquU84DvUkw/znFHNscEYJ9Q717EIRVy3+HU2EGY2nNNzRPCW4apLLkfcBn9e4zyQ9e1/hnd9xPg67GDiKAc1qZ7yEhuCcCAUPK3NsW87S8XTrL6gpnuc2Mm7YZ30gjHVM8b4C6lte43/vh1peWr6frFwFEFrQ6YAmyRUxfW3N6iLyno4v8H4Iu2+BeUdyNih1AAa4I/j7p5k11Ty4Vu1MtFnyfSVT68qFxL8awb1qhs5LQDsJ+GzktdcJP3fqhzbl7sQEztufFT+jJjnjQbWT52LAXzAc5dQk93sT9qYDZvdIk1C5KOgUMp5hjlm8hALglA/7YRovOnUhXJnaHJkYrBE6bz3OiJe+NK8n1g4vgA+JWUufnGeplaaDrXNvjGAlauvB6mciafOOZyBHB+ARd/mep3oC3+BefcnrFDKLjlQ537K66p+VttOzKmo+aEHQCZ0loka4XLkMnLIQHYHvgSxfJiaDFpt5ILz8n8cZPGBeQLmNn6shszaZgr9uCxzjbKkReZok1wPD6HWR2pHwH0Ck0WNqM45Lx3p/kTz0zRuabmFmBg7DjMR0gjsq/4xvpHYgeSifWBh8PwtqJoDkcBkgQlKfUdgO8UbPGfFS6Q2OJv5k/9m3+z2KRnB2CCG9Nyhbty0hqxg8nAq8D+KS+GVVAP/ICEpbwDsBHwNNCH4jSSkPOyP8YOxKTBXTVlFermTYsdh1mm98GdTf9Bl9gEwmU6FLg+g5fPSpHqre3CWpacVL8IEteVBVr8xdds8TcLm2ulf3lYAfxFzGx5xF09qajzSTrqhnCpsih6hLHJSa61SQYFnAzsSnFI56yfxw7CJKZUll0hkwvvt6WOJ9zo5kvcuDeldNks3k+BX1Ic2wMjSVCKRwBrh1vwRXn7uSWc+9vWoVmIu3byyswpW1vaPL2KK53khw+8O3YgCTcKujncCyiCd8Ox9lskJMUdgAsLtPhLc6MjbfE3i9Vz4Ps4bx0g87Q+vnynG918ubv6paI8zzpDnnmfB56jGFZqKyNNTGo7ALsAD4aBEkXICOVyyCuxAzHpck3NLwMbxI7DdEsz5fKx/rjBRWuI0xHyvf04sCL6+TDRM5nS0VJiW0K/LMjiL98Ix9nibzpAjsNM3uqpc/e6pknfd+PbnnNm4XHMxxZk0JkLa1wy624ygYRpd1tSDOeEHtnGLINL5m3BdIN3PcCdw4zmCe6qV4fEDicxcg/qRxTDNuHlLwmpHAHI6E3Z6lwZ/f4SBvzYDW+zTK6pecfQQc3o8T6Ob/jh9VL9Y+arC8/GT6Hff4ENwzFwVKnsAJxZkMVfWkMOs8XfdFhL8xOhPbTRYwU8l7um5qtcU3ORep0s61KgXIieiH6rAWeQgBR2ADYKt+Gl7almH4ZLjk/FDsTkxY1pvhjP6bHjMFXg+Ts93KH+2EHW/ns+aaT0N6Af+iclbhr7HlgpkbI/7Yv/gjsOtvibzpvXenVBLkkVj2MryjzmRk/cO3YoifgHcBL69Qpj7gu9A7A7cB/6SVvjE2MHYfLlxrTcgvcHxI7DVHUL/Ie01J/jz7QjQqAJGI5+nwAeKmICICURjwHbFmAK1lbAB7EDMflyTRO3g9KjBSmTLbI/MnPmcH/yJtMptuXCjqn2HhiPAXLR1xftCODIAiz+0sXtaFv8TXf5xsHSLGV07DhM1R1Cv35/c6NfXY9imx6enXPRPyfgsFj/8igJgPdezvzPRj+pbpC3NmO6b86cb6XWS9xUxea4uglu7KQtKDZJes9Dvx9672VqYDESAOfcCYD2ZhhyrvPj2EEYPfzIDadSctI/3WZH6LcevjTBjWkpyrCcJTkXuB/dNnTODS/KHYC+oenPuuj1XihnaYkdiNFHWsq2dZUz+skwqDJf9CMa5CJxUa0XqgM094r5d7jvMEv7DsBpyhf/BSV/tvibqvCNDfJWdHnsOEyNWgg7d4VrmnSeK+4F0NeAU9FtHeAL2ncAVgydnlZBr3Gh258xVdM2VGZmy2/wXo7TTDH8hpb6LxW4TPC3wFHobhE8OFyAVLkDcKryxX8K8OXYQRj9/FBaGT5oJM790JoEFcYXGNTSVOCJgl8C/oPuFsFf0roDsAIwSXkCcDBwU+wgTLG4pkmflf+v/GfLLDw973DfWC/txYvmgPD712oa0FCr0vFa7gBof/u/zhZ/E4NvbLiFefM+Dv6G2LGYmpBpoje48VPkQnXR3NrWLEmvAeEOmaodgOXC27+M/dXobWATm9pmYnNjJn0K784O3cWMZp57mTXzcwXsGrgm8LziqoCpYRdgupYdgFMVL/7ia7b4mxT44Q1/9Y31O+HdJ4Hf17qsyNSQY0/69bvVjXpd++S8Rb0BSFMsrVat1S5ALXYA5JuzOVxw0Ogu4FN2EcukyI2auCK93KfA7RXGUW8I9I4dl6moO/hg3oH+lCGzKQ4pibwH2AOd3gTqwxj5rBMAefu/BJ1mAluEgT/GZFI++Fo9fu4qeFbE1a0A5Too9cR5OaqTVLYfjhUoMwDnB4CTc0n5WBPn12qrTTdp8dzI5ObD/Zl7yPyRotggNAjSehfiZODX2SYA0t/YOfcKMAidvg5cFDsIY2rFnX1fDwbVSyOvenzbOaW8pXwM15YIywO5qCVqCfC/paVhWMH6BHwHOB+dJnnvpU3wvFx3AI4JjXE0eipMcrK+7Ma07S5M6cvM8iaUy1vg3Fbgd8b5j9uOQS25K2gcdJIvyJFkeMl8MuzEanRkuMuTXQLgwiK5JTrtBjwYOwhjUubGvdmfeR/ugCvvAm5X4BOKt2zT4P1FfkSD7E4WhXxfPRDWHG3+AWxVrTtm1UwAPgP8GZ1+HzIzY0wnuKbmPvjyrrjS3oB8bBM7Jp38qb6x4VKK4w/Aoej0aeCvuSUAcjteSpG0kbKqjW3YjzHd50ZPHgyth+Dc4cB2seNRpBX8wW1NooqhIfQG6IM+dwD75pQAbAY8o3RLRpqsnBU7CGNUJgOufDiew3Ft256me2bgSrv74QPljLwIzg+XAjXaAng2lwRAZlcfj86ZzRu1/WAZY6rGjWvZmFY/HOeOx3vNTcSq7Q1a/Y7++IYi7FhKGetLwNroc3k1xgVXIwGQhj8tSi/6HA1cGzsIYwpVWTBj7mHgTggXb03nPcec8i5+5OD30G84IIOxNB49rxeGBSWdAJwBnIs+jwA7W8c/Y+JwTc1bgvsq+M8DPWPHk5k76F+/f9sYad1ceFZLibY23wV+lGwCEGoype3vOujiw3CVx2IHYkzRuabmNcN26CnKJ4xWmD/fNzZ8D/3kRe0hhXfQpnjvGyrZGKjSOwCHhnIMbX4HHBU7CGPM/3NXv7Q8rtdpOCfDuFaKHU8GPJ6D/Yj6m9HvemAo+hwC3JhqAqCx9K81VDW8GDsQY8wSEoFS75PDDfAVY8eTuA+oczv4Ywe9gG4bhrJAba2p76hkSWAlE4AhwMsKt11GA8fFDsIYs3Ru1Mur0rPnt3HuyzbxcKmeY+bMHf3Jm1R93nxk14SL25r4UIn2r0r8w0pUzskKF/+5wA9jB2GMWTY/csOpbS1wW1s3a5t7aJZkU/r2G+v0Pa8XJf1atE1HdMAJqe0ASMnfFIUXcqpSe2mMqT43ZvIn8eWfAZvHjiVNhWgXfJXCHdypoSTww1R2AA5TuPjPBs6LHYQxpmv88IF309K8NXC6Ne9aHHehu+pVud+kmZSkz0GXVYGDKvEPqlQCoC3DWvD2/1rsIIwxXefP3GOeb6z/ebjIKxeozP/rQ13d79uaLeklZelXo8+IVI4A6oFXK3yfILYPw6VGaf1rjFHCNU0aCu6y0LHUzPdz31gvuyRaSWvgV5R1py2HAUiTu/MPKVUoE9G0+Itf2uJvjD6+sWE887zcCfhL7FgScpob3SwjZ7X6D3AFupSAYbF3ACSIicAgdL39y+/nrdiBGGOqo+0G/JjmE/HIJcF+seNJwFvM81v4ExreRKe1gEnKykMnhp3qLi/i3X1z30vZ4i/G2OJvjG5eOpcPrx+FK20fRpcX3er0cL9Br9cVDnIb3N0BWd1NALq9BZEYyaQuiR2EMaY2/PCBzwE74JyMMC+6g+bfkVDrQoXD3IbFOgLoA8h20Qro8SfgwNhBGGNqz42ZNAzf9has6bJYZ71Ba49N/fHrvo1OcvdjP/R4H1gzjAuu6Q7AgcoWf3FR7ACMMXH44Q1jKbldwllxUa1J3byfoJe2Z/wK3UloupMAaJuO9wTwQOwgjDHx+GGD/s6cOXIv4EGKa0RbF0Wd7gaeQpejap0ArAxoKxv5aewAjDFpzBSg/8y9cU6GyRSRw5evdOPe7I9OF6PL/l0dh93VBGCosnKKFu/9DbGDMMakwQ/dZA7DBw3D+6K2A6+n9cMzUch7f72yLq99gENqmQAcgS4/d85pmxpljOluqeCIhjPAHY/zBXw++K+4cS0bo4xzbq7Caq/Da1UFMKDtpij0QIcPgHXCZ2OM+Qg3euIBuNL48LZVHM7d5YcP2id2GFW6PPdvYDl0kKRmDeCdau8AHKRo8Re/s8XfGLM0fsTgW9tuWzs3nSLxfm/X1PIZ9HkfkKMALXoCn+3s/6grCcCh6KKtR7Qxpgp8Y/19tLbuFxaP4nBc4sY/3wt9rkCXQ6udAKwIaCoPeSaU/xljzDL54wY/RMnLlvh7FIX3Q5je70vo8wjwD/T4dGd783Q2ATgA0JQJXh47AGNMXvywhscouWIdBzh+4Ea/onGE8tXoIZV5n6lmAiDn/1rMCuf/xhjTKX7YoIcptx4cpocWwUq4urPQZywwEz0+V5UEwHsvlww03Qa9rrM3Jo0xZgE/YvBd+LaXotkUgjvRjZ4sE+g0eRe4ET0+E9bqyiYAzrndwx0ALbRdADGmw7z3PUJHT/kYGEaLyseq4a/1ix1jDvyI+jtw7niFU+YWpyeu/D30uRI9VnTO7VyNPgA/B05DhxeBTQryQ2uKaT1gM2D9tq5u8z/WDX08Vu1g61A5JpsWPmSeenO7j+e99y+GpiqF50ZPOgPnzkW/Vsp+U39cw0vo8gLwMXSQYU7frHQC8Ep4mGjwVeBnsYMwpkJkHKhk/bsCWwNbhLf4apsTHpxyk/ph4CFJDIAyBeSamn8NfAHtnLvGDx90LLp8E/gxel5wN65kArBx+MHWoBzehOSNxpgcyZCWvcIYULmXM4S0zlTvA24DbgcmUxBu1JM96TXgz8ruSi1OK3Vuc3/sIEn+NO2YtbTVO+ggz4RXK3UHoMvzhhN0vy3+JkOyZd8I/CVsyf8J+GJii/+COA8KJbYtodfGDxRtry6RH7nNXOaUZVDay+hWRytno8trwN/QY9+O/Jc6mgBoymg1tX80+i/qfS4s9m8Co0MyntMkzs2hbbFYcFRweriHoJIfOfg9XOkQ/T0C/KFuzORN0eV69NinUkcA0vjn7bDtmLtWYG3grdiBGLMUa4ez5OPCoCptpGzuj4CcmT+IQq6p+aDwe9SypfxRjtF+eL18j2q6SzOlbYcjfx947wcs65JuR3YAdlWy+It7bPE3CdsibJ3L2d33lS7+hB2MI4EHgCeBYWG3Qw3fWH8T3l+MZp6j3dWvSbKqxRvhIqsGyzvntl/Wf6kjCYBt/xtTXXJz/5awRT6yYCNn5fc+xjknN5eHKXn7mm9yy7e17nAEvahr/TK6XIce+1TiCECG5WxD/mQrZK1wgcqYFEgvCqkdP1j1VnHnSCJwJjBeQ58Od+Ur69KjxzM1KsuM4R1mzhzoT95Ey52H1YD/KBl5L6W5O3dnB0Bu9G6FDnfb4m8SIYvBBcDfgUNs8V/Ix8Jb2KPLenjlwJ8wZArey66OVivTv5+mewD/DZViGmwnRwHdSQA+0YWBQanStLVj8lQKpXvSVOtbyiZrVuPh9WCofJDOhdnyIxr+IM1z0Mpzujv7Pg1vzNrWih7d3QHYDR3mATfHDsIUmtTr3wX8ClgldjCZKIXeB1JXn/dbdI+5XwotlDWqp77hQPS4MVSMaSAzfLqcACz1f5zZWYhN/jMxyKU2uQz2T2DP2MFkfGQi1RF/DqVa2fFHD3kfr3hokPcnosdU4HF02K2rCcByis7/pSWpMTHai8pb/48ya96Tqs+EzoKdmnmeCj9i0D14xqHTPq6pWQZOaXE7eo7S+nUlAdhFyU1IQl9yY2rpkLBY7RE7EGVWC8d5l2V5h6Ku51eV9iIp4RmBHrehg/yM7NCVBEAaAGlp7vB07CBMobb8zwplbB0ZuWu65uTQu30QGfHD1pkGTtoh61Nyx7nxavo4PBEqAjSQy/ydTgB2RM9Wjs5zN5PiWfVtoY5dS/VMyrYJ5YJLfMClyDcOuha4E228X5fpE/dTNDX2r+iwxLV8SQ8pqUveFh20bOWYtDUAE5R1zszBGuGexTHkpM6dFpqT6eJKJ6DH7eiww5J6jZSW0qFMw/Zla3g4GFPtH7BHgI1jB1JQcs45FvgemfDHDnoB/Ci0cX5/19ScZaXGEhIA2QnInZQdb9iZBEDL9v8jYZKhMdWye9jOXT12IAUnbzg/DH0W8jh+6VX3fXXdSb3rAX4oesoBn0SHxa7pS/pBWeKtwcxo2cIx6Zal3basdpumpqTT4pgcpgv6owa+g+MctHGlw9HjNnTYoTMJgNQOamDb/6ZaDgwdw/rGDsR8xDHOudFZ7ATMnvZrYBKaeL+LGzdxIDrcRcESAGlYsin5mwU8FTsIo9LewO+zrEMvDrkUeFXqg5b8yG3m4v356OKYVzoUHR6TNI38bba459XiEoDNgZ7o+MLNiR2EUXnmL41o+sQOxCyTzBG4iNQt1yC7FS+hieMIdJit5B5Ar3C5f5kJwNboICVZxlSS/ADdtLTWmiY50nTn6yTMD5VqJX8eumyvqDXwBHTYqiMJgJb+/1q+aCYNUtr0FyXlsUVzIXAUKevfcG2YeqiFU1QNMAEdCpMA+FACaEwlyEW/W3JrO2v+R+4BXJlydVPbLoDnYjRxpSyHNi0hAfBFSADqwh2A3L1g9f+mgi5T1BmzyEmcVG2sRaqmz2sKs0t08H4nd9UUaUKjoR/Ay+Tv44teil00ARis5HxTy5aNie8UUDXlrMhk8R/vvU/ykrM/ZYhcOPsNetRRN/eT6DCB/Em/koFLSwA0lP9p+WKZ+LbP4ha56YxdnHPnkqrWHpcCM1DD7YsOE9Bh06UlAB8pE8iUli+Wiac/ME5JSaxZ2DeAvUiQP37dt8HJhUAt9nWJ92Io2JqyydISAA3DTKS39quxgzDZ+8WSBmiY7JXC8KABJKn1CvRYm6snbUH+XgbeQfkOgIYjgGeU3Ng08XwWOC52EKaq1gFkuz05vnHw43j+jhYltx/588CzKN4BkF9vhI4EwJiuWiFMlDP6HQmkWapWctLGWAfPp9DhGXQkAG5xCcBAJRUAGrI0E8+PgXVjB2Fq5tIkpznObr0GmIkGjh3d+Oc1zM14lvwt13Yss5gEYAg6aMjSTBzSKGZk7CBMTcmLz5kkxo8c/B546VugQV+m99PQYO4ZdBiiNQFoBZ6LHYTJkgslf+mPkDWVdmqix5/XoYVzu6BjB6CM0gRgffL3ipptM1NrR0uNeOwgTBRS6vlTUtN/1h16Opp6DT9bM4BJ5G99rTsAWrZoTG31BrTNZDedcwCQVNc6P3QTGWf+J3TQkABoWWPUHgFouKRhau8kYL3YQZjo0usQWHLXo8Ma7qpXNawxz6A0AZA5ALmzBMB0Vh/gm7GDMEnYCUirZv3DqXcB78YOoyLq6nYlf8+iMAFYVUkJoF0ANJ31xdAUxhhxNgnxI7eZC+5OVPDbkb/nyJ+Uva7UPgFYaEJQxhUALbGDMPnw3vcAvhI7DpMUWaR2Jy23o4LTMGq+WUklwHrtEwAN55//BuTSjDEd4pw7XEnyayrra6SkB7cpaW++hYLBQB8Cb5C/gdoSAMnMjOmM02MHYJKtCPgYifDHDHpdydnzioybqGGtmUT+1O0AaPiimNrZNnwYsyh5Sz2RlHglxwDz0DAZsBllCYCGS1AaviimdtJ6wJvUDA/9IdJQcg+ggavTkABMIn+WAJjCkoEYn48dhEnaAOAgUuH9BB2Xz7yWi4C5W0v+n9yCFmuQPw1ZWcW4ayevzJzyRnhWxHkZcQuuNJOyn07rvFf9CUOmUFwHh7G/RSetTV8Ln9+R5rPhYw0lz4TuOjaVfvy+sf5d19T8ArApedOQAEwif2u0TwBWJ38asrIuc6MnD6ZUPgDPXqGhyfyvadud23Dx1vv5v+zRAzemZTrePwXcA9xBY/2jXsdN444YSjE9DdwN3Bs6msnivyQrAhsDnwD2DB/SNKlI9gFWSagf/0MKEoAh7mxK/sysdzOaUZIAuHK53MM5NzvzKWhz20ZOzu8FUBhu1JM96TngKEruBHzbsI2ul9g49wrl8hjqev3aD1tnGnqtFMp40jnfrS75Wl4JjAWe7+af2+GhbfLWFMcJwFUkwI2ZNAzvxpC7Uo91/bB1pWw72/4hzrlZ7V6gc1T23vcuOedWz3zxF1OKtPi78dS50c0n0WvAKzia8F5abHavvtb7ITh3Ln5es2tqudA1Nbd1ilLoswVZ/GXh/zpQD3y7m4s/oR3tKGAb4DPAYxTDoaSiXPcEGsyb00DGnHPzQt+ZnMnaP6Ck5KxP6mQLwV09cVtmND+K4zdVaWLj/XLgvwG86Ma0yIhcbdLq9V55PryxSh37RcD0Kvw7bgvHTCMT2h6vlj3C7mJ8kye+DMhubd5KLusEINDQDGh1SQBWI3+at6zbSAct19R8GqXShPAWVm1r4P01rqn5BkW7AXXAp9BrWtjhkG3rqVX+d8kZ7hXS3Q14EL36ptIa2J+5h7x5ykXA3MmuVO6moiQBWJn8afhiLJG79JXeNE0aD/wc6FXjf/0heP7mrpo0CB193qW8SyPpFLcV8Oca/3v/7b2Xi6eXolc6u0ZewThap2IHYBr5W0kSAA1vd2oTAHf1S8uzXI/bwMU7i3RsTJ2b4MZM3lTBdq5Gcjt8t2Xc6q/2meipwPfQKaHvG59/S+Cy7QAkYmUtCYCGbGzxb/6lXjfi2kqwYlsHX77TjWvJOXvXMI98UU+ES3kpzIw/HzgTfTZL5jlZV8p/HK1TkQBMI39qdgA0fDEW0jY1a/keY8B9knSsRau/o63JUH6kSmJHdHk1LP4fkI5zoO2CqialZL53yl5DE5o1yd808reilgRAw3bMwsY0nwIcQXo2YK4fm+FYzw2Vnf/PDnX5/yU9pwGPo4tUPaTShCb3hl193bg3peNkzqai5AhAOn7lTlUpkmuauDmeC0mV9wfQ1CwNYXKiYQhJe1LbL50cUzQnzFqoRgliLB8nAb6xXsk8+hm5J+PTUHIEIINRcqchG2sz/8269IsMmtX82F3T0jZQIhNJPMAr5MkMbt1PBM5Fj3R62HsFrWjn1a1K3qaRv/6SAPQjf2oSAJpajkzr1vESrcC8ck4P+HQe4N335Rw6X3rvfwa8hA5y+XV5UuAUDKNx5dx3AKaSv36lZLpcdc97aHn7d3yHbLhhrqk5lxu90hlPg9uBR8iAc05mdPwIHeTOywYkwed/BOBd7jsA76IkAch9B8CraI8pRjd/Du+l5CgXPcF9lTwe3pVvmxzHBWTEe/9bJdPTxGCSUFKw/exz3wGYTf76akgA5MKRFseRHX90W7+CtK2lZJTtv4AHyEhoEpT/BLv50tjtcj7/7Wfnck8AynKTgbypOAJQkQC4US+vikuo5WjHrcKKPaUWPWUa2hgTRvrmWAI2LtO400wAcPnvADin4fL5bBTsAOT+ZpT7F2G+nr32mb+lnqFy8omLhsYj4hbybVikYYiNjE6Pz/v8E4Cyr/VMk2qYjYIEoAd5U7EDgHMptPvtIp9St8LFyX27UchDP+c+8PeQvzQurpX9O+TOJV/mXIS1p4eGBCD3LCzwO5CvwW70KymPlV6F/D0czh1zJWOsc5dKIinNgPLmaj7VtBpmk7e6UpiRnrPcszDc2W29xhMpMeoiX9qIdOU4u2BRL5I3Df0A0vg+6lnK/pmHV3EEMAcFOwCWAMQ28NV1sr+M6UopJzC9lVQA5Oxl8pfGfam5pdzfPNP5s+ye3L8OKnYAZis4/9cwkCnl34OGBCD3i18zFPyspvHW2kNDAuDS+LMs9sun7QAkwdel0WK0O0qJtEldPA0PGw2DdVIaW5xvIjlvev7PPB0/k7NRsANgYnPl3JMwqfJOuaGUhu/z3JuOCGkNnLM0fk5fe30WufNZX2hVo5TDUBH1maR3+Wf0ad/qzf/PV8fUzpR3ibJ54/Nn7iHJYN5JgON98tebvLVqSABy/yLID0MSD5Zu8T7lr4OGBGAFMua9l3Lj/uQtpZ/T3IfR5B6/SPmlpyPmaUgAcv8iSAld/guUK6X8dUjpwd2dcbTZcs7Vh6FMOUvn+8g56a6YL+9fIX+9yZuKHYCUF56OKbl0Hixd5ZP+Ycj98plIuc9CEeJPbex43n0hnIq+EL1QsAOQ++WilBeejinPyX8HIO0jgPynp8HW5C33+MXbpMKXHyNfHtzj5K83CnYALAGIrVXDEUAiXdJ01tCLjwHSMCpXe5G/dBLJ1vK95Mq553xj/RvkrxcKdgBy7yud+xcBeig4AkinT3raD+7ukYmRuV5g3In8JZNI+uPXfyXj7pC3o0Nv8jZLEoCZ5C3/BKD/zNy/BqknAK+hw1Hk6VAFD0vRQlL8OHLUWr4GHXqTt5ml7OtJFSQAfugmcgSQd12scwMSf3BraDwiY5fXIz/D0KGZpLhxGV7ifsof1/AP8ldSMElXxQ6AU5CJJbW92CXeL+eamlMd8CEJ1n/In/y8nk5+l/92R4dJJMQ31ktCch1Z8RegQ2/yN0vDDkDqg2iKc07d6tcgXRrqjsVJwOrk4ywF9f8LpFd770rnZ7QL8DwtDTegw8rkb6aGHQCxKvnLewdA9GAQ6XoWHWTmwnnkYW/gs+gwLcVdJD984HPgfkUOXOlUf6aKozgta05bAqBhyljK588d41z+OwBll3K3umfQ43hgZ9LfIv0leqSbQM5p/X6KycnC/G/98IF3o8cq5G+GJADvkL/8szHv898BcEi711Sl+wDvPNlSHwusSLp+oqT7X/IJpB85+D18W4VIqkcBLbT2PBVdViN/b5eUDGXIfwfA+/x3ANLuVy83jzX0W1hgfeDKRM/XDwNOQZekO9f5EfX3A2fEjmMxZuJKh/rj102ni2JlDCB/75YS629d3B0Ax5vkL+UEQBpePYUustD+grTsADShz4MkzjfWXwA+nfsAzs/DucP98IFPos+q5O892wFIR2I1xl3g3CakbQL6fDmhN79tgL8oGPu7qH+n1wRoCVoaTgF/VRKlt2V3jB8+6M/oNID8vWMJQCpay0nVGHeJ96u6q19bm3Ql/xbXRecCP4t8HCA3/u9Vcjkq2++btlv2jQ0n4vhRxDA+AH+AH1GfWY+CYh4B2CXAFKwwe7KKbnWl1i1IlyxQ+Q9eWryvAH8Fat2LQZKO0wB501sene4gI15S8eH13wUOjvB8fx5X2sk3NtyJbgNQkgD8l/wNUNEO2LnES3k6wm9Ouj5QegzQ/i1cLqvtW6N/n7QlvgX4uYaW3Evgc0sAFvCN9TdR5xYcy1TbHPDSlGib+b0J1FuV/L0lCYCGy2drooH3+R8DuFLKOwDiNnRbL/wepePakCr9O+SM/9vAC8D+6CbVI6+TKX/soEm+sX5/Su4QnPtnNf4VeG4EPu4bG77nG+tzny7bUSl3Pe2o/5a89/9VsPW8nvc+98EMsnrmfxGw7OWNI2U3UwyHAC8CMnmtUl8TaUH8ndAT/0cKL/stzk0o4IcNupHhg7YIxwJ3VKBnwHs4dyWtrVv4EfWH+MZ6+V4rBO99T2Bd8iZf/6nOe9nhajsGyH1Loz6bm7pL4EY3n43jB+TN09pj1cTrfv8ObEmxyLbs74G7vPdPOOfmdeLnaq+wcMjRgoJEu1M2DomUKm2XdV3rgZTcXnj/iQ680cpL4ss47sW7u8D/pUBv+4sanORciM6Rnf81e7T7D5YAROf/lWZfl05xlOZIm9pbSdd1BUwANg3VAuc65+QuxPNhYZsc2oG/G+YMLBcWgw3D4pfj+OFKdv9Tt/gLf9x6ct/o1+EDN/bfA2CefM3XpFxeDuf64nkfX55OnZtM2b1c4AU/p34nHdV29N8+AZAHRO5fFOmGlS/Ps/mv/233AHbJIAGQgTpyB6aIlg8Ne+TDLNm1FIQfto60In84dhyZqEdJArDgAZjtJRdVWdnys15QUqYmCUDK5Az7nthBmKTJEcm42EGYJNWTvzfaJwCvkb+UR9F2vBQQXiJ/27mm5j6k7YrYAZikSXmjgrJcUwUN5G+ytgRAwxdFy9S6Pji/G+nf7n4rdhAmWTJoyRita81r2hIADdsyWhIA8G4/0ia7LekMTjEpkV2422MHYZJVT/7U7QCso6MbmUt27ngnpZ4AiF8CM2IHYZJzkYLeKKY6+ihpPKduB6BOwz0A5s3VkgBs5Ma1pL5VNi00yjGm/e1ou/xnlvb2r6F6aArtfiPTlLwJbUbm/AlDpiipypB3qM+Qvh8pqbwwlfFTwOrdjdo1Bnh/wRTg9pnMRPKXeh/6DvJ/QwPvDyN90jxqdOwgTDKlUXYvxGhfY15Z8IvS4v5ixlKeRNdx3mmZWLdbW8vR9J0DzIodhIlOptnNjB2ESdoWKE0Acu9trOWLA3VeSwJQws2ToTSpk3rvy2IHYaKS59+o2EGY5G1O/l7VmgCsr2JC2Ydv/13Nm0ipdAR5OGdBdyxTSF8DZscOwiTfQrsBpQmAhiOAkoKZBviR28wFHkcD73d2V76Sw+hMGZCT+yRG0zX3FGhMtOne279D6RHAv9BBxzEAio4BevYcTh6uBh6LHYSpKakAOSV2ECYLm6HDYhOA15SUAm6uZOv8IbTw/nh3dha1s63ACYDswJhi+FEYjWxMEV4up7efcdH+oVxWMohGwxcJXJ8HFNUjNzBo0ifJpxXzhbGDMDUhz7sLYgdhsrEF+XuubfB8sOhb2fNKvkjZn9P4Y9eQ3ZgHUaN0Ivk4F9DSkdEsnuzyDFeUZJvqckp2lxda4zUmAKsAQ9DAcxtq+APdlZPWIA9yG/xI6w2g2tnAo7GDMNn4GLAS+VOfAIhd0MBpSgDoRQ/3RfIhPwvfjh2EqQq5X2Nb/6Z4a8r8I4AlJgAL/c2Mqfhi+cb6F5W0aF7gy27cmzn1abgUGB87CFNRb4XdHbnwaUyh1pRlJQCTlFQCaPliyS7AHegxgNZZx5IPuSxznKKdsaKTRf+YBZPQjOmEndExBOi1pSUArUouP8l5zaqo4G9Hl69mUhLYvmzmsPDDY/L2LeDO2EGY7KwGbED+nm5fASAW9yCWNrQabmzuiAaz+9ylZFdmgQ0Y1Pw58vICcDgwL3YgpltNni6KHYTJ0q4aKssWt7ZrTQDUHAP4kWvJTIBb0eWczHYBhBzFfCF2EKZL7gVyuoBq0rILOnQoAXgKHbR80ST5vB5dNmfgpBymBC7qKuC82EGYTm97HhRa/hpT5LXk74v+Bef9QkcColcYjCKfcya13CtqmPDlmpr7AG8CK6DH87TUb+7PbOtAmZufhulxJm0y32Q3m/JouqEv8K6G9dB7v7xzbu6ydgDmKCkH7A1sjQK+sf5D8LegyybUt0g5Vo6+YbPjkzcZ2McWf9NN2ylY/MU/F138xZLOYbVMRNsbLRzajgFkSNDZbvzzOf5w+XAf4JexAzGLJeXMewItsQMx2dsHHR5Z3F9cUgKgpUXmvmjRb5aUA76DLuszo+9p5EmSgFOBi2MHYj5SsbGrsgZaJp590eHRziQAi80WMrRDW/MZBfzQTebguAl13BkZzQhYXBIgdwHOWrS+1kTxMPCJ9uNOjelm/f/WFHAH4EUlb5t1qo4BKMktdG1WoGfph+Q/WGaE3TSP6o+AjJyeFjsQo+rtv0T+5GfilcX9jSX95uRt5nF02A8l/PCBE1S2pfX+ODe2ZSvyNiZ8r2lInHPzE2CoTW80FbYvet7+F7tDubTs5hFFX0QNXZzm81yJPiXK/nI3vm3HJmf3AFsCT8QOpCBkwW8EvglZlpOadJWAT6HDEu/0LS0BkLdNDeR8Ofe3y/9X13Ms8CH6bMeM5lPQUX62O3BN7EAKUOO/fdh5MaYa5X+rosODXUkA/gZ8pG4wU3qOAYatI+c5Ci8DtjnPjZ48mPxJ++Zjw/wAaSJiKmt8WPz/GTsQo9Z+6DBnaWX9pWVMQdPSFljLWc583l2BTv1w5SucniMbWai2VVRWG5vcrzjCEitTA/uiw6PhhWSxlnXD8QF0kMmAq6DFiEH3hi1QjfZidLOc62rxqvde6tK/EpJq0zUyEOvjoLAhlkmx/G9blG//FykB6BEGgqjg5f+8/wVaOS51YyduiBLOORkjfEm4ICjjnU3HSU2/DI76LPBa7GBMIRwSSsg1uL87CcBDQCs6yNahHnP7XI1zU9GpP77ut27Ukz3R5dXQWvRz1qmuQ2eXkuRuDNwYOxhTKIejw7xwl6/LCcC7ixshmKm9gNVRwo9caybl8uVo5f229BxwBjrJYKdNge/aWfZH+LDN/zFA2kS/HzsgUyhrhioeLef/Sz127EiXo7+ig6pjgDbO/VLDuOMlcnzPNU2S1q4aSSnnj4CBwLeB92IHlIC7QvnVEWGgjzG1dpii7f87l/VfKFXiH5IRLVs7bXxj/RvgNdeb14Eb78ZOWQe9PgB+DGwAnAtoPdZZktZQLbFdOB55MnZAptAOR49lrt3O+2XOMJFxrVJ7vhz5k25h6wKvo4S7etJGlNzzSnpWL57nYZabuUfbQCT9+gHDw6RB2QbX6v3QxOfndh/CJGItYIqSZ+n73vtVnXNL7eXTkd/oHEXVAPL7PRhF/HENL4G/Dc0cOzG9n/R7LwKp2f11uPwmpUijgBnoIW/4JwHrhCTHFn+TiiOULP7i7mUt/nTiN2vHACkrcY76cbSOU92YlqMplgWL5erh+1Zq4XPcBXk+TEz8WLukxnoimNQcjh4dWrM7cgQgNgojglFyDLCetpnhrqn5T6FWWrMP8e6TfsSgpZa2KLdy6FImH58Osy5SMzs0ILkd+LOiZ4fRayDQrGhw3Pod2V3raAIgXg4XlTT4GnAxirimiZtD6WlFW1hLMo1SeWc/bLB8PxadfK23AKRSYmdg13DHpdZmhJKjh8IQsQnKji2Mft8CLkCH50OZMZVMAGTBPB0dXgpnrKq2zV3TpD+AOxT9XsXP28mPGPLf2IEkaPWQFGwRHgLyJlAfEoPuljdNDW9JUqL3AvAs8ExocKSlYZgpHhfWBC0vuD8OpcUVTQCkkc7d6PGJ8MaihhszeVN8+ZkC7AIQtpg/5RvrNY5GrjjvfU/nnDQ5GRB6ncvnFcLfXqnd1qeczcvloQ9D9c+CD6mcsXN7o9GewD3osduyZgB0OgEID5C3wsNCg7Gh3EoVN6b5WjxHUgx38MG8A/0pQ/Q2QzLGVNu1oOaZ+bb3fo0wf2SZOvymGEoKtHQFFEPDhSpdXPms8AZXBJ9muR5j3Xg1nbuMMbW1irLS8Ns6uvjTha3im9GjL6CurCxcjvsVReE4nOnNV7uzC3HsYYyprGOBPuiaM9JhpS78wzWduZ6IRr1KZyueFPhRjmEMmnSp01PCY4ypjRHoIWvzX6qZAHygbJ75FqEHuSr+qIHv4DmTQnEnM6ZlrDv7Phn6ZIwxy7IT8HH0uD2s0R3WlW3TG9BF5y5A/0EyKlgqAorD+2MYVH+NG/Vkz9ihGGOSdyK6dHpt7kwZYPtLE28AWh6y00NfcnVzx93olr1wXlPpZgf5P4M7zEoEjTFLsCLwb3lVQoc5oSvou9XeAXgbuA89ZMrhCSjkRwy6R9nFzQ5y+4O/1Y2aKD/kxhizqJMULf6Eo/lOLf6iqzenr0eX07z3Os+OfemrYcJcwbhP0qs0wV01aVDsSIwx6ZCeNsAp6DK+K/+jriYAfwgDP7QY6JzTNAnqf/yIgRPxvmAXAv9nU+rcI+7qiTKBzhhjpKfNkZFmZlSLHHXeWMsEQLYatM2glwFBOi3X8DOce4JiWpNS6T43uvnA2IEYY5KgZaZN+/L89+iC7jRP+R26bB16Qqvjh9KKKx9foA6Bi+qP40bX1HyBdQ00ptA+BWyJLr/r6v+wK1UAC/QJ1QCaLlrJ7PIDUMqNaT4fz3coMs+99Gj9vD92fZlrYYwpljtCEqCFvPnLkK8Pa70DIP/Cm9DlM8AmaOU5B5BWwcXl2JPWukdcU7O2twBjzNJtDuyDvst/H3b1f9zd/unj0MUpPB/6n7a6eOel+UWZYmsAHnZNzadZ+2BjCuPr7cZea9GtNbg7RwALEohXgXr0+DAsEHK8oZIb3fxjHN+MHUcSnLuL1tJwf9x6/4kdijGmaqTZ20SZlIIerwAbtu3tRtoBkDfJMegidxu+gWZzp50BPB47jCR4vzel1qfdmEmfix2KMaZqvq1s8RdN3Vn8K7EDQHj7l12AkrJdgA2AKSjlrnp1CD16/B3vpROiaePGM2f2yX7khsWZpGiMfusB/wJ6o0c5rL2vdecfUolFu1lZa+AFuwCSMarlj1//FcrejgEW4ofSq9dLbkzzyNiRGGMq5gxli7/4a3cX/0rtAIhjFF4InB3OVyajmBvdfDMO2/7+CP9n6vzJ/tjBqr/+xig3GHhR0fC6BT4PXEc3lSo4hnAauvQOmaNy82QQ0uuxo0iP25/W0guuqflMN+r1frGjMcZ0yQ8ULv5TK1WCX6kEYJbCy4CiEVgfxfyIIf/Fu8PCOEmzMFn4z6LX7JfdmEnDrGTQmKzIPa6j0efKSs3iqdQRAGGhfFnZZUAxFhiOclITD/w8dhxp8xNwdd/ywwdOiB2JMWaZrgVk8I8mPhxNSwlgUgmAuBPYG11aQwepF1DONTU3FSHZqUjvAFf+nh/W8FjsUIwxi7Up8IzCF9Lbgf0q9Q+r9B/Or9FHhscUY5xuXd8vhR8as6zeAWX3qGtq/pO1FDYmSWcrXPzF5VRQRXcAvPc9nHPNoeuSJvKHtDPwCMq5pmapLZXRwQNix5IPL0cCP6ax4VbfzcYcxphu2xV4QGHb39e894Odc/Mq9Q+saIYUAvsV+sg30i+VZpQL8Y31zfiyXH4s+ryATnC7gPsTTc1PudGTjnGjntR269iYXMgz+mKFi7+4rJKLfzXuAIhVQoMCjaVTw8OlQPVcU8tXwV8UO45M/Rvc1eCvbkuojDG1cny4Ja/NTGBgpcvtq5EAiFGATJ3T5s1wA/N9CsCNabkU778cO46MlXHuHnx5FP1n3eyHbmKllsZUz/LAS8Ba6PNr4ORK/0OrlQDIDcxnlW7DnFeMBkFtnfHrmNlyE94fEDuW7Dk3Fe9voOSuo++gB/zQtuoSY0zl/BhUTjn1YU19IZcEYEGv4n3QRwYFbRxmIKjnfvX8cvTrdz+wdexYFHkD/A04rqdfwwRLBoypSMvf5xX2/Bd/AfanCqqZAOwL3IZO44HDKQh3TctazPMPA4Nix6KOc9PnD9PytzB33l/8CUPUTqA0popuBA5Cp32Au3JLAMRTwFbotAcgb8aF4K56dTPq6qS0ZuXYsSgmP4z/aPu+8v4hepYm+GMG2ZwGY5ZuL+BudHo67L76HBOAo4DfotPT3vvtKl2WkTLX1LxjONqRyzamNiaCm4AvPwbuWXqXnvFHDXwndlDGpMB739M5Jy+am6HTEcD11fqHVzsBqAu3MrUO1PkWcCEF4pqa9whnUn1jx1JYzk2h7OWSrXxMpOQn4Xwz75Vb/ClDKjIkxJhMyIXsc9FpYqg6a801ARBfCk10NJIpiFtUajBDLtzYlv0oexlH2St2LGYh8sP8H0DuEUwDNw38NLyf/2vnZbfq3fn/TS/fux9ScnOgbgZl3mG56VOsVNFkZMNwZNYHnU4KJfXknAD0DTfmV0ene4FPVuuMJlWuqeUQXPk6vOsROxZTMfKm0Yxzf8fL93Xrnb5x8L9iB2XMYkiJ+X3Abuj0eqhskKqzrBMA8W3gR+h1AnAVBSNtb3FuTBFaJBfYYzg3llKfJn/sGjNiB2NM8AWlw+cW+DpQ9U6stUoA+gOTgNXQ6b3QqOHfFIwbM2kYXtrett33MJobGZXLl9Cj388sETCRrRVq/ldCp6lAAyAlwlVVqzc3eWD8DL1WBH5OAfnhDWPBHwnY2bFm3q+Kc+fSOut519Sstd7a5OEyxYv/go6GVV/8a7kDIJYLtxq17gKIQ0JDisIJFwNvsOqAonDjqOvzRdsNMDV2WGjEptXUWr39U+OzW/kNXYJuvwy7AYXjhw26De8OCJ3tjHr+WMofPuJGv7pe7EhMYUgTsl+g24W1WvxrvQMgVgi7AAPQSxofHUNBudEtO+P8n5Vv0Zn/9xq+tK8fMVDOZI2ppt8Bn0evt8LN/5rtqtX69raM0b0A3Y4OHRALyY8Y9DdKTlpzWgvbYlgPV77LjZ4sDy5jqmWY8sV/waTZmh6p1XoHgNC04eW2B4deUhWwZVEmBi6OGzdxIOW6P+O91hadpj3nXsH12NEPW2da7FCMOg2hJ77sIGvVAmwE1LSTZ4z6bWls8EN0k3sA1xS5NM4fO3gyM2bsFNoGG+28H0Lr3HFufoMWYyrCe98jHKtqXvzFWbVe/InYwEWa5ryIbrsA36XA/MmbTGfONCkZkz4BRjvHfjQ1nxY7DKOHc+77gLxIaPaS915eGGsuxhFA+ylHv0e3eaFV5cMUnJu/MFxsXQPVm0mr38Qf3yBbmsZ09yXq/gLspB4K/DHGvzjmw1hGHD6ObrJ9dU0Btq+WyTfWX4JvuxxpdeO69aPOSSMTY7p7jDquAIv/wzF7x8RMAGTr4WvoN7gA/Q86xI+ovw7YFs8LsWMxVXW4u+pVu/xputvtTy7/aVYGTo05SC72duyDsbY+aqwROC52ECnwjfUvMrcsZ3q3xI7FVI2jVPeN2EGYbJ0Yyqm1awKeiBlAzDsA7d+QpYlIb3ST6odPxP6Cp6LttnhT8zdD7av2bb4iku/3tXxj/buxAzFZ2QqYUICW4h+Esr+o/VJi7wAQOgNqHuvYvv+B9MpfNXYgKfBS4dNYL2fFBwBvx47HVFwfcDIbw5iOWiU8I7Uv/oQXn+jN0lJIAMS5QBEaiAwsen+ARfnG+tvxrVuG275GE+8luTOmI+rCxXDt5/4LXnqTmB6bSgIgb4BnUAyfBs6OHURK/Ij1X6Oxfk/gKzZWWBHHnm68JbumQ84HPkkxfC1G059U7wC0T0YeAbZDP/lDHxq2u0w7rmnidlCSzl8bxI7FVIArbeaHD3wudhgmaQeGUrgidJG8J6VEJ5UdgAUlEfIGmExGUkXyjT4a2Dh2IKnxjYMfp3+Pj+PVj/0sCP+x2BGYpG0IjCnI4t8KnE5CUkoAxN9C84ciWB4YDywXO5DU+KHrzvIj6k8DJx2y3ogdj+kG720nxyztGXhTaPpTBFcAz5CQ1BIA8a0wTa8INg3tkO2cdDF84yDpEbExnlEF2RlSyMnNbmMWN+Tn+gLtgr4DyFyDpKSYAMgb33cojv0LUgbZJVJH7kfUn4Tze8jQjNjxmM7yhW+DbT7KOSfdUfelOL4BTCUxKSYA4vLQJbBIna++HjuIlPnhDQ8wp/fW4H6C8zJkyeTAOdvdMov6NnAyxXF/qhNRU00A5ELgCaGbWFFcCBwZO4iU+ZFrzfSNg75JubRDAQZJKeGl45kxCwwNTXCKYlZYy5I8wkw1ARAvh9rQonAhS9w5diCp8yMGPUVj/Q74thkL/4kdj1kKX5j7PGbZtg/971NedypNer68QqKS/kJ4738EPE1xSLvgm60GvoOthEfUj2FO7w3CD1mRdovy4f2rsUMwSRgcBoD1ozie8d5fTMKSTgCcc3LWe1KonywKmRVwG7Ba7EDyORaoP4t58zYANy7VrbbCct4ubpoB4Zm2OsXRKhNgnXNzSVjSCUDwGHApxbJ+GJNcpGy5W/wJQ6b4xkHD8OwZ+kmY+GbTv9c/Ywdhouof3vyl4U+R/Ax4ksSl1Ap4aWQhfDZsIxXJXcBnbXu789zoiXvjSucXpLV0qu7z82c8mGLqFY40i1TuJ5qBzYAZJC6HHQAxE/gSxbM3cJ33vmfsQHLjRwy+K1wUPCi17lsFckfsAEwc4Zn1hwIu/mJkDot/TgmAuD2M0i2azznnfmfdArt8UfBmWuq3An848HzsmAqkTKuX71tTPHXOuTFh97JoRgN3kolcjgDaXyb5B7AOxXNVaBiU1RcsJe5sSgyatD84abq0W+x4lLvHN9YnM/XM1LSc+Uq5AEfxvAZ8PLT9zUJuCYDYPYxUzGn3olJ+CZwSOwgN3NiWrShzOq58JN5JX3JTSZ59/Yh6OwIonp+GefdFUwb2CWtTNnJMAMRPCtw6V7ponRE7CC3cuJYGWv1pOHc83ttkxsp4zMv9C1M05xdsjkt70rPmu2Qm1wRAbpc+AmxFMclUqR/GDkITN2riivSqOxq8HLNsGTuejJUpuV39sEEPxw7E1PyZdA7F9IT3fufUa/41JQCEMZJPFLhW/sdhqIapMHf1xG1xpRNxfB6waXad4q7wjYPkFrQpjrOAMymmGcA2uU4qzTkBIEyUuozikjHCXw7nT6bC3K+eX45+/Q/H+xNw7BQ7ngy8xMyZ2/qTN5keOxBTswt/0ur2KxTXieHSY5ZyTwAIjSY+R3Fd470fEdommypxoycPhvIROKSc0I4IPmoGZb+LP65BqnSMfnVhbPvxFNdNwMFkTEMCID3z5aGzFsUlzYKOzfEMKkeuqbkeOBD8UHC7xI4nAXMpuQP9sEHS790o573v4ZyTyaXHUlz/AbYAppExDQmA+FRoFCRbUkV1a5i1bW2Da8iNmbwp+IPw5f3A7VjAhk2SdA7zjfW/jx2IqYnewO9yf/PtpjLw6dCqPWtaEgBxCXAqxXZf6L5lZ7ARuGsnr8zc1n3A7YtnP2BNNHNuOmV/mNX7F0a/sO0t9e5F73XwDRTQlAD0AR4EtqXYHpq/Pc3bsQMpMif/N7ZlS8r+03h2w7EzsCJ6PIcvHe5HDLT2ysUwIEz1K/pl2EdCM7o5KKApARDrhRGMci+gyF4FPgO8HDsQ074N8cRN8aVdKbmd8X5XQO4S5Djn/JfM6f1dP3ItGdJl9JMprH8BNqLY3golf1NQQlsCIPYKU8iK3t51Wjink10RkyB39WtrU1feibKXy0Sb49ouFTWk2+ba3y1zFHxj/dOxIzE1s2OotFqdYpsXjj7kmFUNjQmA+BZwQewgEjAbaATsglZOvQf69tsU57fAlSQh+BjeN4TdLemAWWuzwd9KqXSRdfcrnEOBcUDf2IEk4Guh54EqWhMAqQa4LtyKLzofWnRKty6TKTeeOqa/ujalkiQD9Xgnn+Vj7XDkNSB8dL8zpnNT2950fPmvtPa8wR+/rt0nKZ7TwoKX6G5UTd0YkiF1i6XWBEDIYJdHgU1iB5KIK733X7SGQbq58VP68t6HAyjVDaCublV86yrh7/TH0Qvf9kBfcBmxLx6H89PxvIOjhVZe5viGyV7hw850iJSx/iJ0WTXwIiCDrd5HIc0JwIJ5AZIELB87kET8Gdr621uZoDFmUfKcvB7YN3YgiXgP2F7zZWrt2zsvhG5VqrOcTtg/DFCyXRFjTHsbAnLHwxb/+Xxoc6x28S9CAkC4wfqT2EEkZKNQyypnWsYYI83DHgM2jR1IQs4HbkA57UcA7c+1pFXw3rEDSYh84X8E/CDUdhtjikWei+cB3yx4G/VF3RF2S9U/F4uSABAuPkmXvM1iB5IYqWs9IjS5MMYUw4DQ07/obX0XJZ0tpUnXOxRAkRIAQuc12f5eI3YgiXkNOCxsAxpjdNs6bG/n2Imymt4IjY9aKIgi3AForxk4oG12uWlPmsw8AJwQOxBjTFUNCzuhtvgvbBZwUJEW/yImAIRb8MeGkY5m4TGfVwBNVjZpjMoj0GuAMdbZ7yNawzGolIwXShETgAWdnb4eO4hEDQeeDedgxpj87RCGpB0dO5BEnR4mHRZOURMA8bPQ8cp81CDgXpmn4L3vGTsYY0znee97hLkoMhBs/djxJOpi4FIKqmiXABeXAN0Qzn7M4sm22DHAK7EDMcZ0KomXLX/byVuyW8OzX32535IUeQeAcA/gqCKe/XRh+3Bk7ECMMR0iQ9BkZLMt/ku/C/b5Ii/+oug7AAusGcoDJWs2S3Yt8CXg3diBGGM+YiXg12FhM0s2CdgJeJOCK/oOQPv6T+mBbc1wlk52S54DDo4diDFmIYeGJja2+HfsWf9m7EBSYAnAwmMfpVWwzT5fOpk//8dwa3bd2MEYU3Cyezke+AOwVuxgEic7l5/RPuCnMywBWJiUv+0HfBA7kAxIQ6V/AqfZ95ExNedCU5/nQhdPs3TvA58C/h47kJTYHYDF2xn4K9A/diCZkM5iJ4ZdFGNMdUlJ3yhgr9iBZGJmePO/P3YgqbE3t8X7Wzjnnh07kEzsGjLrs4BesYMxRnldv+y82eLfMXPCDokt/othOwBLJ0nA9YD84JmOeSYcC8iUQWNMZXwS+LlNM+2UeWHxvzl2IKmyHYBltww+sui1op20RegiKJcEB8cOxpjMDQTGAnfZ4t/pHi/S1twW/6WwBGDZ/hDOt22rpPOXBF8ALgFWiB2MMZnpH47UXgrDy0zHybP65NC3xCyFHQF03KlhMTOd93p4mF1luynGLPN2vyz4Pw4lfqbzvgH8NHYQObAEoHO+FAZHyA+p6bwnw+QtGU5ijFnY9uElY8fYgWTKhymvMuDHdIAdAXTOZcAXwvmS6bxtwm1cuVi5SexgjEnEpuGoUdqR2+LfNeUwr8QW/06wHYCu+Xy4mGOjcrv3AyuTGM+wzlymoBqAbwPHA3Wxg8lYa/gzHBM7kNxYAtC9S27SgrNP7ECUJALftZHDpiAGhe/346zEuCJ1/keG9uSmkywB6J49gT8By8UORIG5wO+BM8O0LmO0WS+cUZ8E9I4djJIOfweHrq2mCywB6L7dQ8378rEDUeJD4PJwC1qqB4zJ3Tqhg5+cUdvCX7ne/rILaxeKu8ESgMpdbrsDGBA7EGVbe9cBF4bWp8bkZnPgy2Fojx0VVs47obe/XJo03WAJQOVsErp12UjOypsQdgRutYZMJpPZGPLGv7+VDFfcm2Gqn7QcN91kCUBlfQy4PVzyMZUnA4cu8t5f75yTOwPGJMF739M5dwTwNWDL2PEoJXeD9rWqocqxBKDy1gx3AraNHYhir4WGKVeEs0BjYlkxtAqXAVjrxg5GsUeBA8MOgKkQSwCq18f7t+Eb1lT3wuAtYTa6HL8YUyvbhEt9R1kVUNXdBBwdbv2bCrIEoHrqQlcqmSFgqu9FoCnMG5gaOxij0krA4WHQzMdjB1MQvwjtw637ahVYAlB9sjV4kXX6qpnZoTeD7ArcbZcGTQXf9o8B+sUOpkDd/U4Ps1dMlVgCUBsHhSMBe3jU1sthR+B34d6AMR01MHSYkxazG8QOpmBmhD97Od4zVWQJQO1sF76h14gdSIEnEY4L7Zv/EzsYk6RVgUNC3f7OVsIXxRvAZ4EnYgdSBJYA1FY98Bdg49iBFJicJT4cEoHrwgPHFNeAUK8/NJSYWW/+eJ4LX4uW2IEUhSUAtbdyGIe7d+xATNs5430hEbjRLg8W7k3/iNDK2+7nxHdH+Hq8FzuQIrEEIA554Hw/fJRiB2P+tzPw91BOeJf3/j7n3LzYQZmKkJ+xrULSLR972Jt+Mnxo9/29kJCbGrIEIC456xobyotMWqYB94SEQFoQ272B/N7y9wwLvvycWYvu9HwAjAjjwE0ElgCk0T5YZlnbvYC0dwfkEuFtwJ3hgpI0ITLp6Bu6b+4D7AdsbbtryZ/3yzGMtfWNyBKANEgnsavDRSSTPjka+EcYUvQQcD/wVuygCtiCd7sweGeX8Nkm7uXh5lBpYW28I7MEIB0udA38CdAzdjCm0yaGhODJkBQ8ZU2IKmrwIou97JhZmV5eWsNZv5z5289GAiwBSM9uoUrA+gXkTW4zvwI8H5IC+XgamB47sMT1Co13tgkfMmZ7C2D12IGZbpkamvvYzI6EWAKQpvXCxRjZ4jR6+LBTILPMn2330RxaGBdJb6AB2AzYPHx8PPw1e7PX5ZFwvDkldiBmYZYApP2A/BHwFXsgqic/hK+HeeeTQkLwv8/e+ynOublkxHvf0zm3Xmh+1RA+L/h1Q7iVb9/X+i/PXhy2/efEDsZ8lCUA6ftUmHJnZUzFvnT475AkTFvkY2q7jwV/7e0q7ChIQrpKKK8bED5Wa/frBR/y99cE1rUGO4Um36+NtuWfNksA8iAP1SuBA2MHYrLzTvg8u9089Q9CUrGg8UpdaIyzfPjP/cKCv6BzpTGdIV01TwzJqEmYJQB5kdKZy0LZoDHGpGQW8B3gktiBmI6xBCA/G4XRwnJD2hhjUiDNsY62xj55sU5Z+XnJe78jcLb1zjbGRCZvkL8I/Rls8c+M7QDkbc8wS0AuXBljTC29Fo4lZaKmyZDtAOTt3tAkZVzsQIwxheFDZZL0bbDFP2O2A6CHDEC5PDQRMsaYapD+FCeFoVgmc7YDoMdtoZvaKOuzbYypsHnhrF92HG3xV8J2APQ2D/pN6LhmjDHd8XfghDDgyihiOwA6/RXYNFQKWAtOY0xX6/rlGSJVR7b4K2Q7APptHu4G7BQ7EGNMNh4ERgIvxg7EVI/tAOj3bJiffjLwbuxgjDHJt46W7f7dbfHXz3YAikWGtfwA+LIlf8aYRSb3SYfRrwNvxQ7G1IYlAMUkbYQvtWMBY0zoJ3I68I/YgZjasrfAYnoytO4cbtm+MYXu5CfPgL1s8S8m2wEwKwHfA05pNwLWGKOXjIM+H/hZGBNtCsoSALPAQOCHwDHyfRE7GGNMxcnD/hrgm8AbsYMx8VkCYBa1PXBRqBwwxujwOHAa8HDsQEw67A6AWdRjwG7A4VYGZEz2XgAOA3awxd8synYAzLISxEOBC4DBsYMxxnTqgt8PvfdXO+ekj78xH2EJgOmIPsAXge8Aq8UOxhizRG+FC34yC8Qu+JmlsgTAdEb/0CXs28CasYMxxvzPVOAy4GLg/djBmDxYAmC6kwh8C1grdjDGFJgt/KbLLAEw3U0EZMbA14A1YgdjTIFIGd9PgV8DM2MHY/JkCYCphF7A54HvAhvFDsYYxSYBlwCjwrheY7rMEgBT6aqB/YEzQj8BY0xlSKvei73319qtflMplgCYavkU8NXw2ToLGtN58nC+PbTsvTN2MEYfSwBMtW0Qxg8fH+4MGGOWTsr3rgd+DDwXOxijlyUAplYGACcCXwLWjR2MMYk27/lVON9/O3YwRj9LAEyMewIyfnQkcAhQFzsgYyIqA/fIou+9v9HO900tWQJgYlo/7AocZx0GTcG8A4wLN/onxg7GFJMlACYFvYGDgRHA3jakyih+25fLfKOBm6xVr4nNEgCTmnWAY0KnwSGxgzGmQmf71wKXhzp+Y5JgCYBJlZQO7g4MC3cFVowdkDGd8C5wAzAWeDCU9BmTFEsATC5HBNJPYGgYT9wvdkDGLMbssMU/HviDteg1qbMEwORmxZAEHB6qCXrGDsgU2hzg7lC3/0cbyGNyYgmAydlKwD7AZ8MxgTUaMrXwIXAXcAtwI/Df2AEZ0xWWABgtlg9zCA4EPg2sHDsgo4o05rkDuBn4MzA9dkDGdJclAEYjaS60ZdgZOADYJnZAJktSn3+rvOl77+93zs2NHZAxlWQJgClKw6F9w0XCPYAVYgdkkvQecG+4yCdDeKxBj1HNEgBTKN77Hs65HcPdAfnYDugROy4ThbTdfSws+H/13j9mrXhNkVgCYIpOLg7uBOwK7BI+94kdlKkKWdz/ES7wTQj1+VKvb0whWQJgzMKkx8AOwCfCZ9ktWCV2UKZLpgGPAo+ExV5+PSt2UMakwhIAY5bdkXDDdsmAfN4M6BU7MPORevxnwyK/YNF/OXZQxqTMEgBjunaPYKNQXSAfmwBbAQNix1YQHwDPAM8BzwNPAk+E+nxjTAdZAmBM5awdkoFN233eIvQoMF1rrftqu4V+wecXwmQ9Y0w3WAJgTPWPENYJkw2HhJLE9r8uenLwfljkX2n3ecGvp8QOzhjNLAEwJn474/WAgeHzgg/ZTVgDWC18lMhLObTIfQt4E3gdmBwWdRmP2xI+S+29MSYCSwCMSZ8s/qu3SwZWDh8rLfLRL+wo9A6/7h8uK664SAIhZY59F/l3zFrkDL0cFme5XDcjTLabHd7YZ4XyOfl4Z5FfvxUWfvmwbXpjSNf/Aav13uddPCYdAAAAAElFTkSuQmCC",headphones:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AABJ2klEQVR4nO3dB5xdVbXH8d++M5NKJ/SQuZOEFjpYaCLSBYQnElCEZAISFBVF9OnTp4g+sT4BeSJGSCYJojRFpBcBJTSJQgKhJZmZ0EuoqVPuep99c8AgIUy59+5z9vl/P45DIMysMDN3r7P23ms5M0NEUmsNYBNgQ2ADYF1gbWCdf3sbCqwJ1Ce/pz75dSH5/b3xOtANvAF0Aa8k7/2vlwCvvsvbC8CLwDPAoir99xCRCnFKAERqz8zqnXN+YR8BbA4MT977X2+cvG0EDCabliYJwbPJ+3bgSeCp5P0CM3vGOecTCxEJQAmASPUMAEYBWyTvRydv/q8bk6f0POtOEoN5wNzk7c2/fgLoCB2gSMyUAIhUZqHfJnnbdqX3frHP+yLfV74yMB94CHgEeDh579+Whw5OJAZKAER6vye/VbLA77rS26DQgeUoMXgcmJkkBXOAu4CFoQMTyRolACKr36ffAdgN+GDytkVysE7Sw5Jtg3vffDOzB5xznaEDE0kzJQAi/7IesBewd7LY7wIMCR2U9MmypErgE4K/AXcCL4UOSiRNlABInm2YLPR7AvsDO+vpPmr+TMEtwAzgdn8TIXRAIiEpAZA88U/zeySL/f7JE74LHZQETwj8203Aa6EDEqklJQASM5c81R8MHJAs/v7Evsi/8+cF7gZuBm5Itg/04ihRUwIgsRmclPQ/Bnw8aa4j0lsvJonAn4Ebk+6IIlFRAiAxGAb8B3AEsF+Gu+dJeg8U3gb8Cfhj0tlQJPOUAEiWF/1DgLHAQUBD6IAkF0rJVsHlwJVJa2ORTFICIFni++MfnbztrhP7Eph/8bwHuAy4NJl7IJIZSgAk7Xw5/zBgnJ70JSOVgd+q54BkgRIASWsHvoOTRd8v/trTl6ydGbgOmGZm16kjoaSVEgBJE99j/1PAhGQsrkjWvQxcAfwKeCB0MCIrUwIgaRiu8+ai7/f1RWJ1HzAFuETXCiUNlABIKFsDzcBEYN3QwYjUeIvAnxU4G/hn6GAkv5QASC0NSO7qT0zu66sNr+Sd7zg4CbgYWBI6GMkXJQBSq+t7pwAnJwN4ROTtFiaJwC+Bp0MHI/mgBECqyffh/2xymn9Q6GBEMqAbuB74UTK1UKRqlABIpRWStrynAXuFDkYkw+5OzglcmfQZEKkoJQBSyf39TwLfALYJHYxIZGOLf5FsESwNHYzEQwmAVOIa34nA6Zq8J1JVLyT9BM4FXgkdjGSfEgDpq3WALyVvusYnUjuvJRWBc5JGQyJ9ogRAemvN5ET/17XwiwS1CJgMnAU8HzoYyR4lANJT6yUH+04F1godjIi85Q3g/4CfawiR9IYSAHkvQ4EvJIf7fNlfRNJpcZII/DDZJhBZLSUAskpm1uCc8/35vwtsEjoeEelVU6GfJocFfdthkVVSAiCrusd/HHAmUAwdjIj02YLk53hq0mBI5G2UAMjK9gX+F9gpdCAiUjGPAt9JBhCJvO1pT2Qr4DLgVi3+IlFO3vQ/3zcDO4YORtJDCUC+bZg0FnkIGBs6GBGpqv1Xmj7oB3RJzmkLIIfMrN45d0Jyf3j90PGISJAbAz9LXgM6QgcjYSgByJ8PA+cB24cORESCezzp5nlD6ECk9rQFkB+bAtOA27T4i0hiy2T88J916yd/lADEzwETk5PAxye/FhFZ2WHAnKTFd13oYKQ2tAUQt22BC4HdQgciIpnxAPCZ5MCgREwVgEi7+CWZvP8B1uIvIr3hrwLfk3QS9K3AJVKqAMRnD+A3wJjQgYhI5s0DTk56hEhkVAGIxxDgR8BftfiLSIWMShoITUsmgkpEVAGIwyFJQ58RoQMRkWg9B3wRuCJ0IFIZqgBk2zDgEuBaLf4iUmUbJ/MEfAKwUehgpP9UAciu/ZIpX5uFDkREcudF4MSkf4BklCoA2TMw2eu/SYu/iASyAfAn4NfJ+SPJIFUAsmUb4LfAzqEDERFJPAJ8Gvhn6ECkd1QByFY3v/u1+ItICh9M7k56j2hNyRBVANLPH7aZnJz0F3kvy4ElyV8vAjp9byjg1eTvdSST4FY2JNla8tZJEs56YM1V/HOR1fFXBpuBZ0IHIu9NCUD6+3NfBGwYOhAJ5nWgDXgWWLjS20srvX/zrxeutPhX2uBkdPT6ye2TDVb69cpvmyRDZdauUhySfv778STgqtCByOopAUinwcms7s9peE/0liQLfOu/vX/zr18mm9YFmpJkoLjSX7/5Xi1m4zcJOK2KSan0kxKA9PEvjlcCu4QORCpqWTJtbRYwO3n/UNJcJa9bW9slo6n92w7J8Cqf/Eo8/Pf5kUlLYUkZJQDpclByyt+XUiW72lda6B/0783sCedcV+jAUs6PoR2dJAM7rJQY+KqBZNcryShy37BMUkQJQDr4Mv9/Aj/QLO7M8Yv648CdwAzgjiQBkMpWCz4A7ArsCewFDAodlPSKX2h+AnwTKIUORlZQAhCeP2k9BfhE6ECkR94A7k0W+5nJ8KXXQgeVt3HXzrkdkkTAJwQfSQ4mSvpdn/QM8FUBCUwJQFh+z/MPwJahA5HV7t3/LXnhuilpeqInmPRV0Pxd9P2BjwIf1lmCVJuXPPD47TEJSAlAOEckvfx1XSp9WpP7zLcANyZX8SQ7BieVgf2TN791IOlLrE9Jqp8SiBKA2qtL9vr9nr+u+KXnxejOZMG/JSntSzxGrpQMHLxSgyNJx1XBLyYNqqTGlADU/m60H6W5b+hApLzoXwdcBlyziu54Em91wHfVPAY4VINsUsEn3x9PGghJDSkBqJ2m5BqM36uUcG1yb05mmvsuZSrt59vgpCowNrmrruZE4cxPErJHQweSJ0oAasNfYbo6uc4ktdUN3JMs+r7Hgp4yZFV8JWC/5L764Zp9EMTLSSLmr9JKDSgBqD7/DX2xTiXXnN/HvzAp8We1na6E4QciHZX0s/fJu9S2SueHCf0+dCB5oASgur4E/FwjMmvm9eSFwx8s0kE+qQS/ZTce+Iw6dNaMX5S+B3w3dCCxUwJQvZP+5wBfCB1ITsxMFv1LkhG4IpU2MNkamJhsFegGT/VNMbOTnXN+pLVUgRKAyvMHiX4HfCx0IJHz3fcuBX4FPBA6GMkV37jrBGCCRnVX3S3Jdoy6bVaBEoDK8rPQ/6zGI1U/LfwL4DcaMyqBDQA+mfT08F09pToeSm4ILAgdSGyUAFTO1knXuBGhA4mU773/s+Q2hVrxSpq4ZIE6HdgndDCReiZp4uQnbEqFKAGojG2T++W+AiCVU0qa9fwQuCt0MCI9sBPwlaQy0BA6mMi8kjRx8td6pQKUAPTf+4AbdEK4ohYnd/b9DYrHQgcj0gf+YeDk5CaQv1YolbEomaPyl9CBxEAJQP98ONnzV2/xyv1w+/39/9XdfYmEX/y/DJwGrBU6mEj4sz//kVRdpR+UAPTdR5L96DVCBxJJ8w8/GfEM4LnQwYhUwXrAqUoEKsYPD/pUMk5d+kgJQN8clrSWHRQ6kAh+iFuAM5NDPiKxGwZ8NUkG1B20/22+/XXMaaEDySolAL33yeQbTgd8+q4z6dj33eRan0jebJDcGvBnBPQg0b8k4LNJ22/pJSUAvePbgf5arX37dap/evLE3xo6GJEU8NeG/zt5kvUdRKX3LDln4c8PSS8oAeg5n6mfrRagffbXZP/zH6EDEUmh7ZPXF99mWPrmm8mVYekhPcn2zBeS3v5a/HvvqWSYim+QosVfZNV8g5v9k3kD80IHk1FnAf8VOogsUQXgvfnFa7KSpT5d1fkp8GNgaehgRLLCzBqcc6ckW2Vrh44ng76aXCWW96AEYPU+kQyc0d5cz/lvqCuSH0L17hbpO99c7DvA5/Ua1OvXoJOTeSGyGkoA3t0RyVU/nfbvufuALybvRaQy/HCxc4E9QweSsdsBn04e4ORdqKy9avsn19S0+Pe83P8NYA8t/iIVNxP4UPJU+3roYDKiLrlxpLHsq6EKwDvtkUz1U4e/nrkhuYfbHjoQkZzMGDgv2Z6UnjUb822Drw8dSBqpAvB2OwPXavHv8WQu/0TyUS3+IjXzLHBUclvg6dDBZMCA5EzS3qEDSSNVAN5+D/c2TfXrkcuTg0kvhg5EJOeDhvwtm5N0Rfk9vZ70WLg/dCBpogRgha2AO4CNQgeScv5J/3Mqp4mkyn5Jh9JRoQNJuYVJP5KHQgeSFtoCWLHo+wVNi//qTUmqJFr8RdLlVmAH4ILQgaScr+5eB2wWOpC0yHsFYHDyw7N76EBS7DXANyW5JHQgIvKeDkombG4cOpAU8xWAvZLXtlwr5PzPfrEW/9XyZyK20+Ivkhn+BtOOyWFmWTX/mvY7M6sn5/KcAPhWkUeGDiKlupI2pAckvfxFJDteSO6/n5z06JB3+qhz7lfkXF63ACYmh2bknR5NOmhpcI9I9o1JKni+KiDv9DXgZ+RUHisAPjM+P3QQKfXrpO2oFn+ROMwBdgN+kfTIl7f7cdJXIZfyVgHYJbnup0Y/b7csud7nDw+JSLwPP749riYMvvP1bz/gLnImTwmAv/pxDzA8dCApMzdpKzordCAiUnVbAn8Atg0dSAp7BOwOPEGO5GULYK3k/qcW/7fz/00+oMVfJDceT7YEfHtceXuPAN/jZANypJCTP+OlSaMMWaEEfDcpCfqe/iKSH4uAo4H/Ssbmygq+k+Lv83Q9MA8JwPeAg0MHkbKe2J9Irvn5REBE8sfv/f4o2ft+PnQwKbKvc+6H5ETsZwD8E+5VOUl0emJW0vtgXuhARCQ1hidbAh8MHUhK+EXxk8BlRC7mBGAL4L5kYpas6BA2FngjdCAikjoDk3kfnwodSIq2SXYDHiZisT4ZD01OumrxX2GSmR2mxV9E3sXypAGY3xoUylfF/xD7lclYE4CLkn7PeWfJD/TJzjnf3ldEZHWvF/5w8GeAztDBpOTK5DRfKSdSMSYApwPHhA4iJc0tPpX8QIuI9OYB6tDkwHDeHQ58g0jFdgZgz2SCXQP55ptaHAHMCB2IiGTW9slUwc3JtxJwWNInICoxJQCbADOT93nv7HdI3jpaiUhVbApcA+xMvr0MvB+YT0Ri2QIYkBzYyPvi/7eks58WfxGphGeAfYBbyLf1kmuBg4hILAnA95MrG3l2W/Lkr85+IlJJrydnAvxDVp7tCkTVJCiGLYC9gb8AdeTXNckdf3/wT0SkGvxr7GRgHPllSYM5fzYi87KeAPh7/g8CI8gv37t6nHNO13ZEpBZJwK+BE8mvF5LZMplvoZz1LYALcr74Tzez47X4i0iN+OFBJwFnk18bJl0TM98fIMsJwAk5v+9/PtCsBj8iUmO+bPyVnHcN/CjwWTIuq1sAI4EHgDXJpx/H3JxCRDLj68lUwTxalty6mk1GZa4CkMxqviTHi/8ZWvxFJEUPI777ah4NAqYm19AzKXMJgHPujByPrfT7bt8LHYSIyEp+DnyHfNoZ+B8yKmtbAL7V7x05vfL3S+ALoYMQEXkXZwH/FTqIQK2CDwRuJWOylACsnez7F8mfycmErsx8sUQkl87L6YPK08nVQN8yODMKGdtryuPif6WZnazFX0Qy4FTgN+TPZslWSKZkpQLgu/3dHsO9y1662syO0j1/EckQv0U7PRlHnjcHATeREVlIAAYC/wS2IV9uSVpOqr2viGSKmTU4565MXsPypB3YDlhEBmRhC+A7OVz8ZwBHaPEXkSxKqpZHJ3Na8qQxSze10l4B8Icq7gcayI95wO7Ai6EDERHpp7WSMeX+tTxPtwL2Au4m5Qopj+2CnC3+C5ORvlr8RSSWUcL+Ne0p8qPgByb5bRBSLs0JwGnJk3Be+HL/4cDjoQMREanwFbkjsrIvXiHbO+e+RsqldQugmPRXXoN88F+E44Hfhg5ERKRKfCXgT4Bv554Hy5NOgY+QUmmtAPw6R4s/SW9/Lf4iErPrgM+THwOTbezUXl9PYwLQnLRVzIsLgZ+EDkJEpAYmJTNN8mJvYCIplbYtgPWBx5L3eXC9mR3unOsKHYiISA0fPK8APk4+vApsBbxAyqStAvCDHC3+jwLHaPEXkZzx1+SOAx4kH9YBvk8KpakC4A9L/D0nk/4WJSON54QOREQkYNOcmTl56CsBH0j+vKmRlgqAPyRxbk4Wf59xnaDFX0Ryrj2ZF9BN/ArJGpeqA4FpSQDGAR8iH/xUw8tDByEikgI3p7U8XgV7AkeSImnYAlgzaX6zMfkY8HNwTjJeEZGePoheDRxK/FqBMWmZ85KGCsB/5WTxXwAcq8VfRGSVhwLnEr8m4CukROgKwPDk2t8Q4rYsuQ/qDzmKiMg7bZ8M0BlK/IfAtwKeyXsF4Ic5WPxJul9p8RcReXez09w0p4J8l9uzyHkFYOdk1G/oJKTaLk76/IuISM+6o55I3AzYDbgvrwnA7cCHiVsbsBPwWuhAREQywm8B/APYkrjdndwMCLYIh3r6/lgOFv9SMtdAi7+ISM8tTg5MdxC33UNfCywE+pzfI37/A9wROggRkQzyHfPOJH5nmVl9nhKAY5OyeMzuNzOfAIiISN/8CLiNuG3pnPNXIOM/A2BmDc65R4BRxF2+2iVpbiQiIv27Ku6HBq1H3C2RtwKWR10BcM5NjHzx976gxV9EpCKeysHVwEbg5NgrAIOBecAmxMv3+D86dBAiIpFpAcYTrxeAkUkFOcoKwMTIF3//Bfxc6CBERCJ0alINiNWGIdaPWlUABiV9njcjXp8ELg0dhIhIpPywoGuI10vJrADfKjiqCsBJkS/+12nxFxGpqmsjH6U+rNZnAWpRARiYPP3705wxegPYFngydCAiIpHzk2PnAOsSp+eTswBLYqkAfCbixf/NccZa/EVEqu854KvEayPgs1FUAJJ7/08k1xxidE/Sy9m3/RURkepzwI3AAcRbBSgmY+SzWwFwzh0b8eLfkUys0uIvIlI7ltwqq+mVuRpXAWoyQbZQ5Swt5lLN/yR7USIiUvtJqzHPlPk6UJflLQA/8e9q4uQX/p1zMK1KRCSV/BAd59zfI54tMxa4IqsVAJ/BxOorWvxFRMJxznUlrddrN9Cmtr6VVNIzlwDslRyOi9E1yQEUEREJawZwJXHaCdg3iwnAacTJP/WfHjoIERF5W0W2JvfmAzgtawmAP/V/BHE6T5P+RERSxfdhOZs4HQJsnaUE4Iu1OL0YwIvJyX8REUmXsyJtyOaScw6ZSADWSO7Gx+i/gVdDByEiIu+wJHmNjtEEYL0sJADNwDrE50HgotBBiIjIu5oO3Ed8hlTrwbqSfQB8qeIRYCvi409i3hY6CBERWa3dk5sBVb0+F0A7MAroTmsFYN9IF39/7U+Lv4hI+t1d7eY5gfjD9R+t9AetZALwOeLjyyPfCR2EiIj02H9X+kk5JT6b1gRgE+Bw4vMH4J+hgxARkR7zV7V/T3w+mkwJTF0C4CczNRCXUuTDJkREYvVdwLcKjkkBOKnSH7DfAxmAzxAfn0HOCh2EiIj02lxgGvE5CRiYmgTAOefLEsOJi98/OjN0ECIi0mffj3Bo2wbJpN3UbAH4JgUx3idVy18RkexqAyYTn+a09AFYH3i6kiWJFOhMei/PDx2IiIj0y6bJdsBg4qpQF4GnQlcAxkW2+JNkjFr8RUSy7xlgEnGpA45LQwXAt8jdgXj4U6NbJKUjERGJowrQCgwgHo8B2yS9aoJUAHaNbPH3rtTiLyISXRXgEuKyFbBHfz9IfxKA44lPrDOlRUTy7H/7+7ScQseF2gKoSw4gbEw87gD2CR2EiIhUxfXAwcTj5aQLb0etKwD7Rbb4v5khiohInGJ7jV8POLA/H6CvCcCxxMXf+b82dBAiIlI1t0Q42+XYWicAg4D/IL7M0Pf+FxGReP2cuBwBrFHLBMC3IVybeLyYdP4TEZGImdmlwJPEY0h/Hsj7kgAcTVx+CSwNHYSIiFSXc853ev0FcRlbq1sAvp3iC/0pOaSMPz25efJnEhGR+K2dtLAfShyWARsCb1S7AnBwRIu/d5UWfxGRXHkNuJx4+HN5h/TlX+xtAvAJ4vKb0AGIiEjN/Ya4fKKqWwBm1uCcex5Ylzj43tCjdfpfRCSXHgK2JQ5Lkm2AxVWpADjn9o9o8fcu1OIvIpJbFxLXbYADq7kF4O8bxjT1ryV0ECIiEsz05ABdLA6vVgLggEOJxzXJhCgREcmnhcAficehvT3X19PfvBMwnHjEdgBERETyvRZsAHygGgmA7/4XCz/F8MbQQYiISHC3A08Qj0OrkQDEVP6fDHSHDkJERIKzZE2IxWGVvga4UbJf3tfJgWmzNfBY6CBERCQVGpNr4f6sW9b5BX1EUul+Tz1Z1A+MaPF/QIu/iIispB24lzj4JOagnv7mnizsBxCPy0IHICIiqXMZ8TigUlsALhmasAlx2AKYGzoIERFJleFJJaAQyfXGDXvS6O69/rDbRbT436/FX0REVuEp4C7isD6wc09+43slACr/i4hIHlxGPA6sRALg+//HwCIb/ygiIpV1RUTzYQ7oVwJgZvXAXsTBn/BsCx2EiIik1rPAX4nDHsCgPicAzrldgTWJQ0ylHRERqY7LiMPAnrQFXt0WwN7E4w+hAxARkdT7Y7JlHIMP9ycBeM9/OSPmJNc7REREVuc54J/EYe++JgD+7+9JHK4PHYCIiGTG9cRzDmBAXxKAHYF1iEMsX0wREam+64nDEGCXviQAsTz9LwLuDB2EiIhkg5n5W2OvEIe9+pIA7EYc/gIsDx2EiIhkg3OuC7iFOOyW5wQgllKOiIjUzvXEYffeDgPyfYRfjGQ28ihgfuggREQkUzYGnolkHdw8mXXQowrA7pH8oR/V4i8iIn28DvggcXjXiv6qEoAPEodYSjgiIlJ7NxCHD/YmAXg/cbg1dAAiIpJZtxB5ArCqMwAvABuQbf4PNQx4OXQgIiKSSUOBVwE/GC/LXgfWXdWkw8IqDgtkffF/s/2vFn8REemrxZGcA1gLGLmqf/DvCcDOxGFG6ABERCTzZhCHnXuSAKy2bWCGxPJFExGRcGaQowRAFQAREZEV7sxTAuCHAGXd88C80EGIiEjmPQO0kX07vVcC4A8KjCD79PQvIiKVMoM4Ohv6m3HvmgCMiaQDYAxfLBERSYcZxMGv8atNAGIQyxdLRETCu5M4RJ8AdAIPhA5CRESi8XDSEyDrto09AXgMWB46CBERiUYpSQKyLvoKwOzQAYiISHRmEXEFYHDSBjjrYvgiiYhIuswm+zYC1l5VAjDqXSYDZo0SABERqbRZxGH0yr8orOpvZlgsXyQREUmPWcQh2gTgFeCp0EGIiEh0XgaeJtIEwG8BZF0sGZqIiKTPLLLvbWu9EgAREZF8HARcZQIwkux7KHQAIiISrdlEmAD4/v/Dyb4YGjWIiEg6PUz2bWJmDSsnAP5u4ECyb37oAEREJFrzyb6Cc26zt34RSQOgZcBzoYMQEZFovQa8SvZtHlsC0A5Y6CBERCRqrWTfiNgSgBi+KCIikm5tRFYBiOEAYAxfFBERSbdWIksANiH7lACIiEi1tZF9G//7LYCsiyErExGRdGsl+zaKLQGIISsTEZF0ayP7oksAYsjKREQk3VrJvg3f/AtnZl1AHdm1BBgaOggREcmFF4ANyLYhwNJCxhd/7/nQAYiISK4SgCiqAG8OA8qyhaEDEBGR3HiJ7NsglgQghi+GiIhkw0Kybx3/f0oARERE8rXmrBtLAhBDNiYiItmwkOyLpgIQwxdDRESyYSHZF00CEEM5RkREsuElsi+aBCCGbExERLJhIZEkAPVkXwzZWL+4y58azGvL1qduwFoUGFz+m1ZaEyvVU3AFSqwF9uqK3+yWY3UL6e5eyNpNL9lYugOHLyKBuMup47XWYdTVrY/rXh+zgck/WYcCr1OyEq7QhSu8Uf7bJZZSV3iNUtdCay4uI59eIvuGvNkJ0Mi2nYAHiZA78/Z6Got+XHOx/GY0ld87NsEYhmMYsP6bX8w+KOHcM+X+1iWbj2MOBTcL6mbZuOFPV/iPIyKBuAvnDqe+YQewHcCNwdGEWVMyDbavleDF5adhYyGOFzGew5Vb5fp++W10WytPtT9tZ+zju83GZAvgcbLtMuCYGBKApqwPaHBnUqD4ZBNW2hFs+/KbK+wIpSLmwlRpnHsKszsxm0Gd3WTjRmb9G14kN9zk1q0ocCC4PXFuT8yGhwnEujDXinMPgs3GudlYYRbjN59vYBluovMC2XYN8LEYEoBNgWfJEDfp8WEMbNgDc3uUfzh9FcNsDdJtPrhrwS6x5uI9oYMRkX8r5S9u+xDYUeAOSR6M0su5RZj9E5gBdheFAXfZuM2ysre+NrBiSzW7bgX2jyEB8GXwVH/juOnzNqSrcCAFty/G7sDWZNtjmF1Miel2YlN76GBE8spdNG87CnUn4Tga2JjsMoxHcXYXrnAbpc6bbMLoF0mnQX6QDtl2N7BHDAnAmsAi0paNL2r/IAU+ChyM2S6R3Lj4d/57568Yv2JB8XI7g1LogERy8rQ/FuNUXPmBIkb+tWQmxvU4rmdo8e8pOrBcgNTE0lcPADvHkAD4bGx56CDcpJkNDBq2PyU7xu+tAOuRL/6MwA/pWPhbm7hrZ+hgRGLjLp8zgMVDjwP7RnIQLU/8QcOrMS6jY+GtKXiN6QAayK7HfCU66wmAJeOMLVgm/sb83XGFsTg++eaIxZxbAPycofWTbOzwrJfJRIJz580dyFp1x2DuO8Co0PGkwCvgroHS5XS8fEOgZGARMJTsmuuTyKwnAD4LS+6t1o6bNn9LSnWfARuvRf9dLQB3mjU3/iF0ICJZ5aa0HkWhcHawU/zp9xwwle7uC+3EUX5Rq5WFGa/y+ptzTVlPAHxzirVqloWvWXc4rjARs/3836rF543AX4DPW3Px0dCBiGSFm/rkKErd5+HK54ikZ2bimMTygRfbxE2WVPlzPZvxQ5dPAiOyngAsTG4BVI2b9tRmdHf5wzafyXjGF5LvGPYj4Mc57h4m0rOunou6voHjP5PzTdK3deFCSnW/sBM2943OqvUE3Uh2+QRm06wnAP6Lu1k1PrCb3LojhcLpYJ/M+GGP9DAewZWOseaRs0OHIpI2K15z3KXAVqFjiYTfIv4dBfu5jWuaVYVDz1uQXb6R0UZZTwDK+xiV/ICupfUAXOE/Mdu/kh9X3rIUs1NtQtOFoQMRSQs3pe1kHOfoqb8q/Bp3M67wExs/wjfAqYTZwHZk18u+jXzWE4D5lToV6ybP3wtX+B6Oj1Ti48l7sSvpsBNt4sjXQkciEoqb/NiaFAZeABwbOpacuAtz37YJjf5sUn/v0e9Idr3it7RznwC4qQv2xErfA/atXFjSQ49hhSNtwog5oQMRCdLFr67uDxkvJWeTc7fg+I6Na/Qd8fpCCUCWEwA3dcG2lEo/1Snb4F6m4A7rxw+iSOaUK46FwtXAuqFjyTe7Fqv7zz48hCgByGIC4C56aj0KXWdQsFOCTdqTf7cE54628Y3Xhg5EpNrclPmH4QqX9mOMt1R6YmHJTYau/+7F/IEoEoAY+9Ovkjvz9no3tW0i9d2P4ThVi3+qDMHsT25Kq79qKRIt19J6PK7gy/5a/NPCXD2Oibj6x1xL29fLLZdzIhcJgJvaujcjirMwfo1ZVfsGSJ/V4dwk19L25dCBiFSDm9J2mn810rXi1Fq33K9k8ZB/lLdociDqLQA3af7aNJRP9n8hL8lOBAznTrLxjReFDkSkok/+KxZ/dRDNznji3zCg62v26dGvr+KfawsgzdzU9kMZUJhdLvdr8c8Sh9mv3bT2j4cORKQSXEvrx3BM1uKfKa68LdBZ/6hraT+SSEVXAXCTHh/GgIHng40NF5ZUwBLMHWATGu8KHYhIP0/73wQMDh2L9MulFBo+b+M2822GPVUA0qbcxW/AgAe1+EdhCM7+7KYsGBM6EJG+cC3zt6dQ+LMW/ygcQ6nzQTd1gR8EF40oEgA/qc+1tP0I3A1+wEHoeKRi1qNgf3K/nVuTiY8ileLOn7MGFC4H1gkdi1TMZljpZjel7dyrZz4axXZO5hOAckOfNevvA74ew59H/o3ZaDrrfxU6DJFeGTzEH2LVUJ84zwacetRtL2xx9LTbyLpML5iNp5+/Bla6F9ghdCxSVceqR4BkhZvS9jkcR4eOQ6qnc9iIwVcs35TGr/kxDtmVyUOA982Zy0HnXMGre/hJvZITy4DdrbnoD9+IpHffn4J/KNG+f06s9Y9ruebkA/nQtpka6ZDNVsDfvPZ+zp75LMtGbB86FKm9R4GdrbnokwGRVHGTnh3CgOU+Qc3USiD9N6j9Qb76vuF8/9BdyYjs3QLY97xr+cl8tPjn19bAN0IHIbJKDcu+qcU/n5Y17siP5hsH/sqfQ8+OzFQAtv7uNB7f7ANYw6DQoUhYyymUdrBxIx8PHYjIm1zL/C2gMBsYGDoWCcd1LmPrZ+5nzhnHkXLZqQBsfMrPeKxxLy3+4g2kVDgvdBAib2OFc7X4izUM4pHNd2fjL/wvWZDqBODeh59gnc+fw/MfOApcqkOV2jow5vacki1uStsxOD4aOg5JiUIdz7/vE6xzytnlNSzNUrsFcMM/HuOoK2ayeMs9Qoci6fQkQ+u3srHDl4YORMj7wT+/HbVZ6FgkfYY++jeuOPoDHLxL6lpCpHcL4Pd3z+HIP87W4i+rszmLOk8MHYTk3IDlE7X4y7tZvPWHOPLqR5h+9xzSKHUVAP8f6uQbH2dpcafQoUj6PcnQJaNt7JiO0IFI/rhJMxsYsP5cYEToWCTdBi2Yzbn7NzFxj+1IifRVAM6+7UFO+ku7Fn/pqc1ZMvT40EFITg1cf4IWf+kJf3X91Due4Yc3pauPWWoSAP8f5hv3LWT5ZtuEDkWy5RvucupCByH54s68vR4rzx8R6ZHlm2zJd/+5MFVJQCoSgPNvn82ZM1+gY6ORoUORLA4LWtx+TOgwJGdGNPo+5HrBkl7p2GgUZ97/PJPueog0KKThwN/pd7SWsyORvrHPho5Acsa5z4UOQbJp+aZb8aW/LEjFwcCgCcCtDz3Oidc9zLJGDfOTftnLTX1yVOggJB/cRfNG+8FUoeOQ7Fo2fAwn3/AoV8/0401ymAD4iX6H/+4fLBn1/lAhSDwc1p363psSiUKdP3jqQoch2ba0aReOvfIfQZsFBUsADjj/WpZssVuoTy+xce44pxdlqbLy95hDyaZUhO91c8CvbyJXCcCwk37A6+87IsSnlpgPA05pV1lWqmtq64d0+E8q6Y1dDmXDk39ELhKALf97Mgv3+FStP63kgSt9OnQIEjlzx4YOQeLz4m5Hs9W3W+JOAPY7/zrmNu6hwT5SJe6Q0BFI9DT0RyrPFXhixO7sfd411FLNVuJTr7qXO2xTjfSVaiq6lratQwchcXIXzfN9XNX5T6rCGgZyV2EzTrvqPqJKAPxkv0kPv0L30HVq8ekk3w4KHYBEqq7+wNAhSNy6h67LBQ+9VL4iH00CcPTUW1m+mR7MpAac2yt0CBIr8wcARareI+DIC64nigSg+PVf88bO2pqVGjFTAiDVonvLUhP+ltyIr/wy2+OAD/zVDdzSMBKrH1CtTyGwHGgDngMWYryE4xXMFuFc51u/x9iEgtsUsz2BJmLWbUU7sak9dBgSDze9vYlum0/c5oObAfZM8noysPx3zRpwbg1w64GtD/i3TYDGt36PVJzrXM5HrZ1rJx5YtXHA9VTJxXc9zO1L1sDW1+JfIa8CD4KbBaXZWOFhrNDGCZs/a9CrJM5Nbt2RAieBmwg0EJs6fG9pJQBSOV22Q6RtpjrA/ZpC6UIb1zSr102RJj+5CXXWhHWPwRV2wGx7wM9zX7t6IefnUODNLw4sz8v55O5jslUBWOtL56v03x/OPUXJ/kKBGVCYQduIR+wMShXvaV5XuADcfkTFfcuaG88KHYXEw7W0fhvc94jLTVjhczZhREUrG+5MCgyfN4ZC3Z44tyfYvsBmlfwcebLWzD/z2nlfrEoFoCoJwNbfncZjxb0r/WFj5xf3v4FdC3aDNY+cXbO55o1NPwer+HdYOPZba25Su1apGNfS9nsgprHT5zK0eLqNpbsWn8xNa90BcwdjHAb4bUg1g+kpM7Z9cgYPfee49CcAX73qPs55dhDdg9eq5IeNleHcDKx0GfWFK+y4xmdDBeKmtJ2L41TicJc1F/2LjEhFuJa2e4EPEIdzrLl4WqhP7iY/uSl13Udh5YTKt++Oc3OlguqWvMbpIzr48WHvT28C8Mi8eeza8g+WasLfe3kR56biun9j40bW5sJnTyoBxabrMduf7HvWmoubhg5C4uFa2p4HNiT7bmJo8ZBaPfm/Fze5dSscJ+HcOGCD0PGk2ZC597H4f45ObwLQ+LULWLDtwZX6cPEx/gn2c9ZYepmNHdNByripT47CuucAWT+5aQxdMiiN/40le1xLm29fuiSCJ9Xl1Llt7PjGVlLGXT5nAIsHHwPuK8khQlmFpkdvYv6P/NntyiQAFduH+fa1M3l65B6V+nCxuRFz+9mE4i42oenitC5MNn7zeRgXkH2ON9YcFjoIiURX17AIFn/vgjQu/p5/TbTmpunWXNwZV/BVyJtDx5RGCxp344c3PVCxj1exBOCcO2Zr3/8dbAYFt681Fw+2CY1/IQsKhUnEoL78oi3SfwMa4ihN17lfkwE2fsSt1lw8kILbA+zW0PGkiV9jz7rh7+lKALb7/m9ZNGafSnyoWMzGSgdYc9NeNq7xNjLExo94GOfmknXdbt3QIUg0Yhhi8rgd3/gIGWLjGu+25qb9cXYQzj0UOp60WLTDAex41qXpSAB8w5/H1t6yIsFknnMvAZ9jaHFnmzDyFrLK7E6yzjE4dAgSjRhGmGb2Z9rGN91EW+vO4D5f7nYqzBk8gitnPhI+AfjiBb+na604KmT94y5n+fJtrLl4QVpO2PaZ2dNknbOsH2SUtChZ9tvdOufb+2aWnbFPlzU3ng+MxvDblFVrYZ8FXetuwsTzrwibAHzhj/fw2ody329l/opyf+PRNnFLXwHIPoe/8pRtpczfZJC0MKtay/SaKZWej+JL0Vx81SYUT8aZv26WygONtfLKB4/itKvuC5cATL370XK/4vxy0ykt3ynT5f5VemuIUHYV1GlMKiSG7yXnuohIeVugtHzHpBqQSzZgMBf+9cF+fYw+f2Pvdc7VLNrmw+TUyzh3lDU3jrMTtnojdDAiInnjX3uTasAxyb323Fm0/f7se961tU0AfMe/+5cM9FklOTSTbtvFxjdeGToQEZG8s/FNl1Hndl3RaC1nnOPu11xtE4Ajp9/F8k23Inecu5iOgXtr1ryISHqUGxw5fN+Ai8iZZcPHsP33L6lNAvDAnLnMH5y7yY7+VP+XbXzj8TZxE98SVEREUsSai8usuekz4E5PpqvmxhMNG5Qr81VPAI6+5K90bDSSHFmM8QlrLp4bOhAREVk9a278OfCJZH5DLizfeAs+Pn1GdROAex9+gra1R5EjCynYvjah+KfQgYiISM9Yc/EqYL/yge2caB2yeblCX7UE4FPTb6Nzg0Zy4jm6u/excU39u2gpIiI1Z83FeyjYRyCCviY90LFhE0f99q9UJQHw+wtPr7cFueDcUxRKH7YTR6n/tIhIRtm4plmU7MPl1/QceGrNEdVJAI699P5yhpEDL2B2gI0b+XjoQEREpH/shKbH6OrylYBnidzyjUfzvh9fUfkE4LFl2e+G2aNhPt3d+1lz8dHQoYiISGXYiaPmQumgPAwTeuSNUmUTgMMn38LSpl2ImnOLwB2ssr+ISHyseeRsCnZI+WZXxJaMej8fn/yXyiUAtz/UGnvXv25KdpyNHzEzdCAiIlId5UPdzvnWwd3Eyjlunf14ZRKA79/0TxZt67dPImZ8UVf9RETiZ+MbrwU7jYgt2m4/fnjTA/1PAM678kasLub9f/ulTSj+KnQUIiJSG9bcdF7MkwStroFz/nBT/xOAV0fvTsTuYejSr4QOQkREaqxz4RfAet8+LyNeGb3be7YHXm0CsMfZV8Xc+Od5SnWfsLFjOkIHIiIitWUTd+2kq/uT5avfEeocNoKT/vxw3xOA2U+9RKQM5060EzZ/JnQgIiIShn1mtG8QNL68JkRoVvszfUsAzr7tQRZvszdRMs5bcRBERETyzJqLN4BFeQ5s0Zh9mHTXQ71PAM65ZgZWP4AIPYzj66GDEBGRlBja8FWMR4iMNQzih3+a0fsE4MUhGxKhEuYm+rnRoQMREZF0sLHDlwITymtEZF6oX7t3CYC/P7hs5M5E6Bc2ofGu0EGIiEi62ITivTFuBSwd9X5++i49AVaZAJx/w98wV0dkFrBkybdDByEiIinV0P1N4GkiYoU6/u/Gu3qeACxcczPiY1+1U8YsCh2FiIikk3169Os4F90ZsZeGbNCzBKBc/i/uSFScu5Pmpp7PSBQRkXwa33gJxt1ExA/z+8Xts947Abjo9pmxlf8N3Jct0nueIiJSOeb/V2dfjqk3gN8G+OWt/3jvBOCFZbEdgnRXaMqfiIj0amogRDUg7tnXl6w+AfB9g5c07UJEStD9/dBBiIhIxnR3+0Pj0TwRLxn9wXfMBnhbAvDlm+bSveb6xMN+Z80jZ4eOQkREssVOHOVb6F1OJPza/vU7Wt89Abj/7/cSlQI/CR2CiIhkVekHMZ0FuPvev797ArB0xPZE5AYb1/TOY48iIiI9kFSQbyESizfcYtUJwH1z5rJ8s22Ihiv8LHQIIiKSccb/Eonlm2/LvQ8/8c4E4L/vmEupYRBRMB6x8SNuDR2GiIhk3ITiTcBjRKA0YDBnzGh9ZwIwa/a7jwzMoN+EDkBERCLpC2B2IZFYea1/KwFYtMaqWwVmUAd0XRw6CBERiURnZ4uvoBOBNwat+84EwO8NROKPNmH0i6GDEBGRONjELV8Cu4YILNt8u7cnAF+96j661hxGJH4fOgAREYnOpUSga60N+Oa195fX/vL/3Tzn7c0BMuwNhtbfGDoIERGJTMega3Euiomy182aX/dWAvBseywJgF1tY4cvDR2FiIjExSZusgSza4nAM/Pn/isBWLpGJOV/c38OHYKIiETK4jgHsHStDf+VAHRsOJIIdFPXEE3HJhERSZnOzhtiGBDUsWFxRQLwt4efoHPYCCJwr43bbGHoIEREJObbAGR+vHznsMY6d+bt9YVJDz6H1dWTeRZPv2YREUkru5mMs7oGGDFyROHhJ58lCs7uDB2CiIhErlCIZK2xYuGF558nAt102H2hgxARkcgt674Ly/wxAH8CsKmw6MXniMBDNnHka6GDEBGRuNnEka81vPzMMrKuVGoqdG88mghk/lCGiIhkw4AX5i8h6wqFxkLn2hsRgdmhAxARkXwY8Py87FcAzFcAYpgBYG5W6BBERCQfNho5OvsJAG6zQveQtci87tLDoUMQEZF82GuLkdlPAJwbVrCGQWTcYvtMUxRXGUREJP0+//6NOl1XB5lmtka5FXDGtYUOQERE8mOn0aOpfy37z50RJACmBEBERGqq4dXsX6GPIAEoPBM6AhERyZe6118k6yJIAEwDgEREpKbqlr5B1kWQALjsp2EiIpIp9c7IuggSAHs5dAQiIpIvg4euSdZlPwFwlv2WjCIikikDBmX+Cn0ECYC5jF/GFBGRrKmvryfrsp8AoARARERqq6GhgayLIAEodYaOQEREcsUGDFACEJ5Z9o9iiohIlixxOLIu+wmAiIhIbb1BBJQAiIiI9M6zREAJgIiISO88RgSUAIiIiPTOw0RACYCIiEjv/M2wEhmnBEBERKR3Xl22dNlcMk4JgIiISC+9/MJzfyXjlACIiIj00ssbb3MLGacEQEREpJc6Nh+zkIxTAiAiIpJDSgBERERySAmAiIhIDikBEBERySElACIiIjmkBEBERCSHlACIiIjkkBIAERGRHFICICIikkNKAERERHJICYCIiEgOKQEQERHJISUAIiIiOaQEQEREJIciSAAKdaEjEBGRnHGFejIu+wmAswGhQxARkZwxBpJxESQABSUAIiJSWy77D5/ZTwBgUOgAREQkdwaRcdlPAEqldUOHICIieePWI+OynwA4t37oEEREJGcMJQDBRfBFEBGRjHGW+YfP7CcAsHHoAEREJGdcYSMyLvsJgKMxdAgiIpIzZk1kXPYTACiGDkBERHKnSMYVcNZFtm3oJj07JHQQIiKSD27yY2sCWT8D0FnA3Ctkm2Ng5zahgxARkZyoHxDDmvOy3wJ4lqwrlbYLHYKIiOSEFbYn+54uYLSReRbDF0NERLLALIaHzjZfAch+AuDczqFDEBGR3NiJrHO0F3Cunez7oDvz9syPZhQRkXRzfq1x7n1kX1vBZwFk31AaizGUZEREJM0aR+yM2RpknrUVKNFKFNweoSMQEZHIucLuxKDbbwEsXfx4uaN+5tl+oSMQEZHIGfuTfSUahswt2CljFkVxEBD2d5NmNoQOQkRE4uQunzMA2Ifsm2fHb7R4RStgYzbZtxb1634wdBAiIhKppUP3BHwXwKybvdIsAIshAYBC4bDQIYiISKS6S4cSA+OhfyUAzpV/EYGjQwcgIiLxcf5/zh1FDJytnAAU4qgAQJOb1q6mQCIiUlnTWt/vLwESg7rCSgnAkBGPAm8Qg5KpCiAiIpXVHU2F+TXmNz72VgJgY+nGuXuJw/HucupCByEiIlF1/zuWONxtZ1Ba6RBg+VDA3cRhM5a0Hxw6CBERicSIoj/8twkxcP9a6/+VABSiSQD8NsCJoUMQEZFonEAszFaRAJTKf7NcFsg8x+FuentT6DBERCTbXEtbkYIdQhxKdNh970gArLn4KvAIcaijxCmhgxARkYxznIq5WKbNzraJI197ZwVghVuIhdlE99u5a4UOQ0REssn5NcQiKv87d/PKv3x7AlBwNxKPtehqOCl0ECIiklGd9Z8D1iYWVrrp3ROAwXW3+27HxOMb7vw5EcxtFhGRWnLTnx8KnE48ljK04c53TQBs7PClODeDWJgNY8hgn8GJiIj0XNfSU4ENiIVxe3mNX8m/nwGAUunGyPK4r7lJ8+Mp4YiISFW5lrZ1cFE9/fvDjG8r/686AaDuOuKyAQ2Fb4YOQkREssK+DaxPTAql694zAbAJI+YA/i0eji+7i+aNDh2GiIikm5v65Chwnycus2zcyMd7UAEo7xVcQVwGUFf349BBiIhIypW6fw4MJCq2yjV91QmAK8WWAHhHuiltR4QOQkRE0sm1tB/pO8kSm7pCzxMAax45G4umK+C/OM5zkx9bM3QYIiKSwqY/jnOJjXMP2fGNj/S8AlD+J+5K4rM5dYPOCh2EiIikTFf9jzAbTmxs1eX/1ScA3aWLy6cBYmP2edfSHstgBxER6Sc3pe0gjM8SH4PSJb1OAOyEpscgohHB/+LAprjp8zYMHYiIiITlpszdAEfLirUhOn+15pFP9L4C4BkXEqcN6a6b5OL8gouISA84/z9XNwXYmBg5m7y6f7z6BKB+8GXA68TpCFra/jN0ECIiEsiU1m+BO5Q4vc7yQVf0OQGw4zdajHM+CYjVWW5q64GhgxARkdpyU9r3xbnvEivj9zZxkyV9rwB4JYt1G8ArYG66m97eFDoQERGpYbe/Apf6G/LEypXec+1+zwTAJhTvBe4hXhvSbde5SxasGzoQERGpLnfRU+th3deWp8VGy2ZY88i/v9fveu8KgOfsbOK2NR2lq9x5cyNr/ygiIm9yk2Y2UNfpt7W3Imau0KM1u2cJwJAm3xSolbjtzZr1l7gzb68PHYiIiFSWu5w6Bqw/Hdx+xK2NIY1XVSwBsLF049wvid+RjChe5M7sYWIkIiLZuO63pP0C4Bjid255ze6Bni90y7v9gYI3iJ1jHI2t56lHgIhI9pVfy1ta/w+zzxC/12joWu3d/z4lADZx5GsYvyIX3ClMbZ+m7QARkYyX/ae2Tyq/pueB2f/Zp0f3uHdP70rddQ0/yUUVwDM7jsbixeVDIyIikinlB7hFbZNz8uQPzi2is/Oc3vwrvUoAbNxmC4E8nAV40zE0rP8njRAWEcnYaN/G4jXlLd38OMcmbvlSb/6F3h92KzT8LDdVAM/xUeoG3eWmzx8ROhQREVk9N/nJTemovx04iPx4na66Xl/X73UCUK4COP6PPDHbju7CXa5l/vtDhyIiIqvmprR9kEL333HsTK64c+3E4S/39t/q23W3rnpfBXiFfNkMCn9zU9pODh2IiIi8nZvS9jkcfwU2JV8Wgv28L/9inxKAcqZhfJ/8GYjjAtfS1uKmPz80dDAiInnnzp+zhmtpn4bjfGAAuWNnWnPx1b78m31veNO50G8DPE4+jad76Ww3dcGeoQMREcmr8rbskCEz/exa8ulROl72DY6oaQJgE3ftxPhP8qsJK93mprZ/S/0CRERqx7/mupbWb+PcXcCW5JVzXy2vxX3Ur5a3NqH4J+Bm8qsBs/+hsTizfPgkGm49ss4V+vxDIfI2Vugi+9YhEm5a+84Um+4G9z3M5fnh6y82vvHa/nyA/ve8L9nXcBbDD0h/7IBjhmtpO8dNmr82WefYhKwzOkKHIJGw7ux/L1n2f6ZdS9s6rqX9F5TsfszeR7510t39pf5+kH4nAHZC04NQ6FX3oUjVAV9iQOEJ19L22UxvC5hlf1RmqXt56BAkEgWX/QTAsTWZLve3n4JzT4B9sSIPrtn3v3biqIf6+0Eq8x9y+YAzcjAuuKc2AH5FY/EBN6XtiKwNFSp30IIPk3V1rsf9sEVWy6L4Xvpw8rOdGf61001r/ziNxQfBfonZsNAxpcQ8htZ/rxIfqCIJgE3cZAmQj2ELPbctjqtoabvfTW09PDOJQGfdEVFcpbF637ZapAJKMXwvDaSj7nCysvC3tP0HLW3/oGR/AMaEjild7HM2dvjSSnwkZ2aV+DgrPlhL22+BYyv2AePir0yez9D6SZX64lVaedtiRHEWjm3IuoautXszFUvk3bhLFqxLR6nXXdZS6HE6Fm7Xn1Pj1eQunzOAJYM/ibmvAtuHjied3HRrbqzYfIPK7qXUdZ+Gc70aRpAj/qrKOSzuanVT2s50F7U2kjbF4ilRLP6wmE+Pzs+8CqmuY0f4JiupTNp7aUsGDptIyriWtqJraf8ei4cswNxULf7v6kWs83QqqKIVgPIH9KUb+GNFP2icSsCtGFPoHPinZBslGDetfXdKdlu5VJh9D1tzcbvQQUg8XEvbI5Ddg3QrWQZ8xJqL94QMotxJtXvZEVA6AdxHdLCvB5wdYeObribNCUD5g05t/01uZjBXxhKcuw5Kl9Pdcb2dsFVNn17dRfO2o67O93PYmBg4d42Nb/xY6DAkHq6l7XrgYOLwHK6wv40f8XAtP2l5rLobeAjOxoI7BBhcy8+facYkm1Cs+Bya6lxVW7z4NIYO3Qez0VX5+PEZgtlR4I6iMLDTtbTdhXEjrnQL7Qv+aWfsU7U+C/6mAnV104E1iYWV8tqiWqrFeBwXTQKwMVa6y7W0HmfNTX+u6pmipsZdKBX2BzuIwsDdy83TMnIeOkUep37wV6rxgatSAXirpGylv+a8U1MlLMa4j4KbgdlMXN1s2jZvtTPKWwh95qbN35KSOwvckSsO3kbEOMEmFKeEDkPi4aa0fgbnfkNcDNwV0P0tax75RH8+kDuTAsPnjaShfnu6S7vinJ+T4sena2ha/3RCaU9rHvl3spQAlD+479Xs2zVKpS3GuUco2Xygrfzm7Clc3ctYaSHWtZDOQodNHPnam/+Cmz5vQzoLm+D4EIWC33vbJ9rkrFR6v50w8v7QYUg83LTWD1By9xIj38nV3G049ye6S3fSUHrWjh/1wlv/2Hc3HWwD6a5bD1dYH+teD3PD/bHh8ptjFJQPDw8J+weJkPFNm1D8YbU+fHUTAJ8VNrb5EpPf7xGpBd8BcB1rLvrDTiIV4S5/ajCLu16NokeGZMWfaS4eYeVKTXVU9eRluUw9oHBcuXORSE3Y/Vr8pdKS3h3/CB2H5IRzc4Fx1Vz8qcXVCzt2xCsUzO8zB73mJnnh7gwdgUTKbEboECQXllHiGGsu+opTVdXk7qWNa5qF8YVafC7JvdtDByCRKhR8nwyR6nJ2sk1orEm1qWbNF8qnso1f1OrzSS4tZWj9HaGDkEgVBvnkUttLUj2Os2180zRqpLbdl9Yo+ruMVbt3Krl3R1rnLEj22fEbLQb+FjoOidZVtBX9HASiTABsLN0MrT8GuK+Wn1dywvk7zSJVZFwZOgSJ0kzqBh/X3/4uvVXz/svlJ7R65+cFLKj155aoLcNML85SXZ2l30cyGEjS42kK9UckFaaaCjKAwY5rfBZKhwFvNaoR6ac/1eLUrOTbiuZa7prQcUg0XsUVDrJxw58O8cmDTWCy5pGzy8M1nFsUKgaJiavZwRnJOVe6OHQIEoUlYIfXeijTyoKOYFwxkrK8HaCTtdIfL9Dxkp9mKFJ9be3XAc+HDkMyrQP4hDU3BT1UGnwGs40fcSvY0SuGHoj0gdl0m7irvn+kJsrTOR2XhI5DMqsTK33Cmos3hA4keALgrRhJ6T5ZHkoh0jud1Jv6S0htlbrPTp7iRHqjhDHeJoxMxTmSVCQAnjU3/gErjFcSIL3jWuz4kbpRIjVlE0Y9CTY9dBySIc6vbe54m1D8HSmRmgTAs+bGSyjZx3UmQHqoG7p/GjoIySlX/0M9sEgPdWCFY8prXIqkKgHwyqWRgjtEtwPkvblLrHnkE6GjkHyy8ZvP84OCQ8chqbcEZx8rV7lTJnUJgGfjGm/DSocAr4eORVKrRB0/DB2E5FxX91nl70WRVXuNUukgG990EymUygTAK1+PcIV9gWdDxyKpNMmOb3wkdBCSb3biqIdwbnLoOCSVnqHgPmInjEztiPLUJgCejR8xk0L9+4EHQsciqbKQjo5vhw5CpKyr7us491LoMCRFnHuIutLuNq7xn6RYqhMAr9wiccmSDwG++YaI91WbuKVecCUV7MThL2Olb4aOQ1LjZpZ375WF20mpTwA8O2XMItrbjsDxq9CxSGg2g+bi1NBRiLxNe9NFGHeHDkNCs4voWHjoipkR6efMjCxxLW1fBn4CNISORWrMX7ly7GrjmmaFDkXk37lp7TtTsr8DdaFjkZrrxPFVG1/MVFOyTFQAVmbNxXMolXQ4MI/MfVuLv6TViv1eOzN0HFJzz+AKH8na4p/JBMArn6q0rh3Bbg0di9TMDbQXfeVHJL3am34ApPLKl1TFX6l377PxI2aQQZlMADybMPpF2tsPxuF7cmdrH0N662msa5ydofvWkm7l79EuG6cKZfQM535Ge9t+dlxjZr/WmTsDsCpuauuBmJsCbBo6Fqm4bswdaBMa/xI6EJGeclPaPozDVyh1HiA+L2ClE9My0CeXFYCVlbssWddOGFeHjkUq7lta/CVrbELxDpw7I3QcUnFX0dGxbQyLfzQVgJW5qa3joPBLzNYIHYv026+tufjZ0EGI9JVraf8F2BdDxyH9thT4L2sunktEoqgArMzGN02jq2tn4PbQsUh/2JUMLX4+dBQi/TK08TSMP4YOQ/rBuI3u7h1iW/yjrACszLW0jsUVzsdsWOhYpFd88vZRay5qLLRknrt8zgCWDL0Ws/1DxyK98gqObzC++BuL9KB5dBWAlVlz0+UUurYFUjWDWVbrATpK/6HFX2JhY8d0sLz7KODB0LFIDzl3Mda1lY0vTop18Y++ArAyN6XtIBy+hLNV6FjkXfhWqnUNH7Nxmy0MHYpIpblpT69PqdMfHtstdCzyLoxHcPYla266mRyIugKwMptQvJH2tu1wnFy+xiFpczO2/CAt/hKr8vd2x8D9NNgslV4GvsEaS3bKy+KfqwrAytwlC9alo/R1wM8VGBg6HnHT6XjpRJu4a2foSESqzZ15ez2NjReAOzF0LEInxhQ6O76VxwmjuUwA3uRa5m8Bhe8DY/NUDUmZH9Nc/K+Y99lE/p3z/5vS+lOcOz10LDlVwnEpXd3fsRNHzSWncp0AvMlNWTAGZ98AO1adu2rmDYyTbULxd6EDEQnFtbQfWR4hC+uEjiUnSjh3HWbftubiA+ScEoCVKBGoEeOflLqPznPmLfImN23+lpQKlwI7hY4l8t79/iqmFv6VKAF490Tgy2DHA4NCxxMX+yVvdJ9uXxy9PHQkImnhWtr864wfbKbOl5W1FGO6HxpnzcVHQweTNkoAVsNNmbsBru6z4HxHuo1Cx5NxTwNfsObiVaEDEUn5lsB5GmzWb89h9ks6Oy/I4+G+nlIC0APuvLkDWbP+U1C+Qqg7vL3TidkvWLr0u3bKmEWhgxFJOzf5sTWpG3hmeYaAufrQ8WSul4hjEm90/U5VxvemBKCXXEvb1kBz8qaqwOr9DUqft+aRs0MHIpI1blrrDpQ4H9yeoWNJuVcwLsfsfDuhSd0We0EJQH/6ey8eehhm43EcpH4Cb/MYzn2f8Y2X6HqfSD+vC7a0Hgfu28AWoeNJEd8q/EYKbirLXrpGPUT6RglABbhJzw5hwLL9oDAW7Eg/A4w8cu4hKP2UIU2/tbF0hw5HJBbuTAo0th4K7gxgV/JpGc7dAqXLqe++yj49+vXQAWWdEoBq7N+5gYdR4GPgDsjJJML7cPYDxjf9WU/8ItWuCLQdgXPfwux9xO/Fcptw+DNLllyjc0SVpQSgytzUBdtipcNwbn/M9gYGEIeXMa7AStPthJF3hg5GJKevLcdHdh7JVw79Pf1bKJWu4cmRd9kZlEIHFSslADU/3Ttgd8ztDrz5thbZsQzjaihNZ8GCG+yMfbpCBySSd27SzAYGrHcwFI4H+1jGepe8BtwD3A12F6WOe+yErd4IHVReKAEIva83fN4YCoXdKBR2pGTb4tgBWJ/0mA/chHEDS5fcqhKcSMofMuoH7U+3HYzjAKCJ9FiIMYuCe5hS6UFKpXt4atQcPeGHowQghdzF7ZvQVdoO3JjkB7iYvDVWuWf4Czg3CyvNwnEv3fV32gmbP1PFzyciVeSmPbUZ1rknuN0w2wGcf8DYoIqf8lWgDWgvv3fMp1Sagys8ZM3F56r4eaUPlABkjGtpWwdKm0NhfZxbH7MNyu+x9SkxFOfWXfE7bQDOrbiNYFaPc2+W61/F7HWMlyi4F6D0JGatdHS1qmOWSPzcpMeHMahhJOYfKgqbU7INcQzDubXeesBY+TXDbDG4juSvX8HZIlzhZcwW4tyL5feUFtLBAps40pf0hWz4f5KzQEQSk5j/AAAAAElFTkSuQmCC",microphone:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAQAElEQVR4Aex9C5wcVZX3udWTZCY8ZYHVAMnMJGQVwRV5CQlIeImI+EIQDWZ6AoSXiw9egq7xEw0Ku7IojwCZnkB0+aJ+RLIfICBBQBNABBRdAsn0JJEQDbAEEyaZma67/zPpgUmmu6er6t5b1V1nfvdMVd2695xz//fc/71V1V3tkfzVHwK5fDPlVn2MOruvpFz+Tsp1PUa57t9RLv8nSBfkZerIv47tZkgBshFl12O7mnJdL1Au/yxkGWQJ8n+IsrOoc9UUWrhyl/oDK90tEgKo9f7/cdcEDM4vUGf+RhoY6PkNaFKeyL+btL4K+6cTqSlE+iAi2g/SAnknKeLBPAb7HAM7oOzu2N+HSO1LRO+DHAY5GvkXouzNpP3HaJPHpLGaOrvvAaF8nzpWnkwLXtwZ5STVKAJejfqdXrfndf0TdXZ9gXL5myDLqVd1Y3DOJ03n0cBAJ9sDch/S+iMglEtIeYupr2ED5boeoXkrZ2Ol8GEhBKqpPyGAWuiued0fwSC7nnL558hTz5NW8+H2uZDJkAQkdSR53jexUriPejMvUWceK4RVX6Q71kxKgHPiQhkEOFsIgFFIogwO+o6uF8nT9xCpLxLReyHJTkrtSJqwQvCvp/7+F4UMkt1dQgBJ6p9c/oOU67qehg56pWp7Fh1GBvlzKZdvTBLsafZFCCAJvZ/Ln4hB8Z9wZSnxTF/rg57K/A2QAd2Es0+jvZdD3ol9STEiIAQQI/gYAJ+F3AsXWD6LbVrSu9HQORAmgjnAgI9xKMkVAoN2hAAGkXC57cxnEfSY7Yln/RNdmk6YLV4BXA6fmAhuIn7CgQNJ7hAQAnCHNdFtLx6I5+cLcZOsA2Y/CJG0FQG+J3AuZbzHqCN/6dYs+e8CASEAFyizjc7818jLPEKkP8OHIiUQ0Hp3PEr8HkjyMepcfUqJEpJlGAEhAMOADlM38Dgv/whm/e8SPyIbVkAyhiOgp5Au/AKXSfPksmA4OlFzhtYXAhiKhsn92dqjjq5rtz7DpyNNqk6RrvaBy4LO/HkparPTpgoB2IC7c8VBNGHV/Zjxv2pDfap08mWBphsp130LVgS7pqrtDhorBGAa5M7umaQz9+Na/1jTqtOtT5+N9t9P87qnYSvJEAJCAIaApLlrx1Ku60ek9W1QuRtEknkEDiHl30+d+S+bV50Ojdu3Ughge0TCHPOSf3QvZn11QZjqUicAAko14Ibqv+OS4PYAtaRoGQSEAMoAU3V258qPYsl/N5b8U6quIwUNIKDPpFz+PgOKUq1CCCBK93d0TSftYfDTuChqpG5oBD5Mua7HQ9eWiiQEEDYIcvlzcZf/DlQXDAFCfEkdinsCy+OzXzuWS3kqwVsKlZHyOrouRhH+Vhs2kmJHQNNkyuX/FrsfNeiAEEDQTuNXXyl1TdBqUt46AntQR1efdSt1ZkAIIEiH5vKfJX71VZA6UtYdAvyEIJd/xZ3B2rckBFBtH3asPA5F+eu72EhKMAL/gMuBPyTYv1hcK2dUCKAcMkPz562cSsp7YGhWje2/CX9fhDyMG5c/xiNLvoT5Emn9GVL6w8jPYv/ryL8R+4sgT6DcX4iUT7X5dwBI4Je16bpbr4UARsK7c9VBWPbXUjCtR5M6MXZPpULhAOrxdqNsyw6QyZBp1NY8nbKtl2L/P6i99WfU1no/9jux/x3kX4D9T0IOQ7l9KNucod6ecaQKB4MgZpEifuRZK6RwAuW6FwILSRUQEAKoAA51rnovaR8zJo2tVCwB554hpa4i3z+Ssi17QrLUNvHndNak5+j8Cf8Tyb9Z+71MbZOeAkHcQm0tH4euHbBSOIU04SmIXoPjBCescIQEKvaPEEAleLT/bzj9T5AEJv0ABv0l5Ov3Y8AfSG3N36CZEx8j23/Zls1YKSym9pbzsR1PfuEYkMEc+PI726bD6WcS6Pp+uLr1UatSK4QAyqGTy1+NU3x9jE2i0nyizKEYfCdg0F9LM1ufjdW7mZOWgAyugC+HwI9PktYPYpuwpC6hzvwZCXMqEe4IAZTqho786ci+DJKgpH9OnjoGs30bZcc/mSDH3nYl27IIlwrHgwTOROYySHKSr7+PG4Py9uHtekQIYDtAaP5fJpNCsGyfH98xbkDqUzDjn0ozmpdQLfy1ty4AUR0OV88DGTyHbfxJqb3hhFwKAIShSQhgKBq87/chSNR43o1X9G9wbf05DKQTMfgXx+tLSOvZlptpx1GHggQuIUX5kFpMVvsY5br+j0mFSdc1kn/eSAVSdZ4/5kvEd7rja7ZSG3GX/RwM+qm4tq79Dx6dtk8PLguuJb//MPL9b8UH7KBl9Q2SNw4PgkFCAINQzO8+kDzvksHDWLZKrcBMycv9W2Oxb9No+77raebE2UTev9g0U5Vu7V9aVbkUFBICGOxkX3NQjB08dL/Fkr+hYVrNXOeHBSg74Yek1HRU74XElPQUkh8gGcBeCIBh4C/5EH2Wd+MR3OHPtk6l6Xv/JR77jq22Nf+YyJ8Kq+sg8SQPjwbr/KfIqgFWCIBf5qmJZ/9q8DJfRtMPcL1/qnnFCdeYnfgk9b6Km63qT7F4yq8b91R8/R5Lo4cbFQIYveUSUnTgcGhc5OjTcKPvKy4sJdLGrIP7KNu8P5H+VUz+taf9hmC6CYBv/FFMs/+oUftg5v9pTIGfLLPZ1uPwqJA/du3er5TfEEw3AWhqR8S5v/Hnjdo9Ndf7ALiq1N56MSl1Q1VljRbCDcFcvs2oygQoq9aF9BLAbSsmAST3He+rI2jG3q/CtqTtEWhrvhBZv4C4TjNcG0yKvfQSQEPDDCw7d3TaEcqbQTObl5L8lUcg2/IJ3BN4qnwBK2eOplwedq3oTrTSdBLA3OW7o1fczv5afYfaJsiv2QD4EZO3hb+F+dcRy5ktkMpVQDoJYNSoNsz+/OUQsyFUVpv6KbU3f73saTmxLQIz3vMqaXXStpnWjz6BVcDR1q04MBDERPoIYPaSBvKwFA+CUrSyz1IDXRRNRQprtzf/nnz1KcctT90qIH0EML7585j98ezZSWj1kKaL6Mzml51YqzcjM5vvQpO+DHGV2uiWlZNdGUuCnfQRAJHDWUXPofaWXyeho2vWh2zLdfCd31SMjYPU4H3UgZXEmEgXAeTWHECKTnGCPn+zrzAqhufaTlrn1ojnucNRqZomgKAdky4C8Hs/HRSg0OV9fSOdtc9roetLxbcRmDHhQVJqwdsZNvf0sTS/6302LSRJd7oIwHN0U0nTs7TjJnezVpIiypYvWrvDU6dnFZAeAujswtJfHWArPrfRqxCsp+0f4/fdt/GmPg6yLcvQkJshDpIQgAOQHZvQjmZ/0r+hbGv9vdHHcXeVNJfJ8Cqgp+Q5k5laT6H5aw41qdKFrjA20rMCIDouDECB62jFQRq4mlSoAoEvjH+OXH1hSBeOrMKjmi+SDgLoXDUFPbUXxHb6JR771f6LPG2jFEV/H/EPmPLvH0bRMnJdTUeMXKj2S6SDAPTA66cc9JaW2d82ymc358n3mQQsW8JlgGULSVCfDgIgJ535Eq1adW8SOrXuffBGuXiD0D9SR/6wWsEyrJ8pIQDPwXJOPUSzp/WH7QipFwCB7PhHSdELAWqEK6r0UeEq1k6t+ieAzhUHEel/sN8l+iH7NsTCWwhocoC3qvsbgfVPADrjohMLVGi4+63glB0HCKgHrBvRJCsA6yBbN6D2s26C6CH52K8DlIeaWDVhES4D3hiaZXxf0S50e3eLcb2GFUZRV/8rANITowBUVV1NcvOvKqAMFpqtfHJxGVDwXX113CA41atKAQGQfQIoqEXVQy4ljSGg/buN6SqnSCshgHLYJD5/iW6AjxMg9hJ/8YefTduzIJrLIaA8fmFIubNm8hUJAZhBMgYt3d2TrFvVvsz+1kEuYyDb8jrOPAyxmRJNAFEbXt+XAMq3v/z31EtRO0HqR0BAqVci1K6mqhBANSgls4xnnwDIEwKIs/O1tk0AHnWscvEkKRYU63sF4Os9raPq+0IA1kGuYEBZJwCiDI2r4EFNn6pvAlDUZL13mhqFAKyDXMGAtn4JQOQ7iKMKTSx3ykR+nROAsk0AW+hz42wvQU30c/3q8H37+Gt/bL0CWN8EoG0zt9wAjH1gZEbZfzeAi5VkTEDWNwGQZQLQ/tqY+k3MDiLgZAVgOY4G2xLDts4JQNtduilZAcQQs9uazBTsXwIo65eS27apiiNTReqbAKxfAmi5AWgqEsPq2dzkgABkBRC2e+Ktp1SDVQd8/Xer+kX5yAjMGvfmyIUiligURkXUkNjq9b0CSCzs4pggkAwEhACS0Q/ihSBQNQImCwoBmERTdAkCNYaAEECNdZi4KwiYREAIwCSaoksQqDEEhABqrMPE3XQjYLr1QgCmERV9gkANISAEUEOdJa4KAqYREAIwjajoEwRqCAEhgBrqLHE13QjYaL0QgA1URacgUCMICAHUSEeJm4KADQSEAGygKjoFgRpBQAigRjpK3Ew3ArZaLwRgC1nRKwjUAAJCADXQSeKiIGALASEAW8iKXkGgBhAQAqiBThIX042AzdYLAdhEV3QLAglHQAgg4R0k7gkCNhEQArCJrugWBBKOgBBAwjtI3Es3ArZbLwRgG2HRLwgkGAEhgAR3jrgmCNhGQAjANsKiXxBIMAJCAAnuHHEt3Qi4aL0QgAuUxYYgkFAEhAAS2jHiliDgAgEhABcoiw1BIKEICAEktGPErXQj4Kr1QgCukBY7gkACERACSGCniEuCgCsEhABcIS12BIEEIiAEkMBOEZfSjYDL1gsBuERbbAkCCUNACCBhHSLuCAIuERACcIm22BIEEoaAEEDCOkTcSTcCrlsvBOAacbEnCCQIASGABHWGuCIIuEZACMA14mJPEEgQAtYIYP369Ttt3rx5ck9Pz9Fa64mQMQlqt7giCCQOgUGHeKxAJvLY4THEY2nwnOmtUQLo7e39QF9f3xXYPr3LLru84Xne8kwmswR5KyCbIffi3Hlo3J6mGyL6BIFaRoDHBI8NHiMQHisreOzwGOKxhHNPI5/H1gdMttMIAbz55pt7b9my5Rql1FI05Dtw8P2QYQnnTkTmjWjMMshF2JckCKQeAR4LkGUA4sbiGMHusPR+nPsOjzEeazzmhpUIkRGZAHiZ0tDQ8Gs4djEcHF2NDyjbgnLXodEPYitJEEgtAsUxcF1xTIyIA48xlL2YxxyPvRErjFAgEgHA+UN4mQIbrZAw6VjoeCNMRakjCNQ6AsXYP5bbEUJaeexBxyEh6r5VJTQBgIn2g5YnIFHTTmjEkqhKpL4gUEsIFGN+JwM+P1Eci6FUhSYA3JC4PZTF0pWOBiBzS5+SXEGgvhAoxvrRploVZSyGIgA04Bw4fxDEZDoHek3rNOmf6BIEIiNQjHEeP5F1DVFwEPSG0hmKAGB4JsRGytpQKjoFgQQhMCzGDfkWakwGJgAwDc/Shxpyehs1uLv5obfQpgAAEABJREFUiW0y5EAQqDMELMb4ocWxGQixwASAGw4fC2QhQGHo3svEo40AJqWoIOAMAY5tjnFbBqE78NgMTABgsHfZagDr9TzPqn62ISIIxIGA7dgOMzYTRwBgsXFxdI7YFARsI1Aqtk3adEIAaESjSae314VG7L59XuhjpftD162moqdMPMetxpKUKYfA3LVjy50ylp/J9JnQZTS2SzgUZmwGXgHAyKYSto1lAaSdjSnTqseYrpKK1F4lsyXTHQKNPeYmjHJeazISR0Zju4SvYcZmYAKAXasEAP3mCECZ6Tj4VDppLQRQGhl3uYWMfQKgwmZDDTIX26UdCjw2AxMAWGxjadtmcqHfHEiGmLtsy5Qn9yvKguPohOfZJwDtWVkBmEYIYyfw2AxDAIFZJkhDsYwxRwBEppi7TBNkBVAGGHfZhb49rBsztJI0HNvDmg0CCDw2AxMArAY2gjpBkkkCMMLcFZwfQz9Za38GquBA6k85WQEYu5Q0Gduluj7w2EwcAYAldynVslB5hpi7ou2ezXIfoCJAlk8qbZ+AvYyRicRobJeG1T4BoBGBjZT2tXQuljEGWdJ7vbQVg7meJwRgEM7AqrRyQAD0WmC/SlQYGtslTkfOCjM2vRBWrRIA/DFHAFqvgD7LyRcCsIxwRfXKAQG8vuWPFX2o/qS52C5tM/DYDEwAYVimtK9lc8ds2LBht7Jng5zo9+0TgC83AoN0ifGy2volwHL6l323RPW7GNNW34wdZmwmkQCoqalpYlTAB+rvMurFga3Nf5nMR22qF90VEFjwIs+oxl6sUdKS1kZmf2MxXdLJrZl1QwBoyKStTYr4/7R9+ObNSxG1VK6u9cG04C97Vy4kZ60g0NdwkhW9Q5Uq7w9DD8PuD43psDpGqgcb9i8BGhsbnx/JkajnPc8zswLY6oj9VUBvL7/ufKs1+e8QAX2yfWNmVgCGY7pks8OMzcCXALiTuQ5i9e46mMwcASht/z6AUg4CsWSfpzdz9mzErrJ/+aWNrQDMxXSJXucxCVlX4lTFLIBY8XzJkxigy0ueMJdp5hKA/dHqOd5YlpMpl9/Vsg1RPxSB8TOOx6FdzJX6H2qf0AU7JpK5mC7hTdgxGYoAYN/qZQCYzCBb+g/BX9spQ6Q5IG3bEf1vIaDs463JWOwMxvRb7pvfCTUmQxEAGhPKWLVtBpu9a926dTtUW75iuexE3MXV6yuWMXLSsx+QRvysEyVKu7jvYoQAOJY5pm0iH3ZMhiIA3/dtXwLQO97xDoOrAGWkIyt3oD6BFmqsBCqXkrMGEOjoPgJa3guxmzxaasKA2Vgu7VHYMRmKAOCC1RUA9BMYjd8+zLvRRevHoisZUcME2pS3/1hqRDdSUEA5udxaSzOanzaBptFYLu9QqDEZigBGjx4dylh530uemVYyN0ym0o+HqRa8jrogeB2pEQiBW7v5h2Vd4PxIIL8qFx6I5cpFop0NOyZDEQAYDZc0+oVoLleuDQPHVC4R4Gx24pO4SbcmQI2wRT9MHfkzwlaWelUgMIrORyn77wAgMjZpGI1lNH77BP0v8JjcPr+a41AEwIo9z7O6CkCD9tqyZcv72JYRUcrND5Aq7WJ2MgJJzSm5ffX+pB3hq81c/3MMcyzbxDrKWAxNAGiQVQKAfr4PcCRvjYj2f2FEz4hK1BTKdZ09YjEpEByBQoHJtSl4xcA1Hqf2FiMrAAx+czFcvhmhx2JoAsBdx2Xl/TF25ihjmla1LoIuq5ct0L81aXUBLXxu9NYD+W8EgVz+g9BzLsR+8v37DBo5inXZlChjMTQB4KbDr202qqj7GFzfjCruR9vMVj4pYhIg63+K/pk27sCzlXVTqTGgQKquGqu8e02YKsauuXtZZZyKMhZDEwCWNq/BHyPflIKecmn3/v5+c0soXzm6DEBzPHU+3bbGzHsNoC7Vaf6q43DtP90RBsaW/8XYtf3Goj8opXgshoInNAEUrVl/vo7ljbklVHvzb+G3ycc7UFcmaT2JMn2yCigDT6Bs33eJo5HZv9g+c5NXUWGJTaQxGIkAcPfR+mUA2M3wN+1c3QzkrlJXUOeqY3lPJCQCHV0Xo6a7n43XZOz6H5cAA7/WC/+tpahjMBIBZDIZF7PpQT09Pebe+tLvLySlXrHWI9sqbiTyb6R5q+UHRLbFpbqjjq7p6KtrqitspNR9pu7+F2PW3KdZyzQv6hiMRACYnfn7x0+V8c1YNhppbhVw9r5/gWOdEDdJ02TK+PPdGKsjK/O6D8fgv8Vxi4z1k9GYLQ/CU8UxWL7ECGciEUBRN19XF3ftbIwvpfr75yO47P5y8FAotD6Oct3zhmbJ/ggIZPSPUcLFM3+YGUjLKNty58CegX/GY7a0T5HHXmQCQEMjO1G6bW/nguUm446quVXAWZP4JSHuVgEDTdHt1JH/8sCu/KuMQC6/lDTxZ/4rlzN7dr4pdRyrHLOsz6aYGHuRCaBQKFgnAAYRTwPM3lApFIx1OPtXlSj6d7q1y9zHm6syWmOFct0L4TF/6AcbZ+l5WDI2IRiPVThXKpkYe5EJYOzYsavBdka+N12qkYN5sHHy+vXrdxo8jrydOfExUupnkfUEVdCgjHzENKjZmijfySsk/ZkYfJ2P5f9mE3Y5RjlWTeiqpAM2lvLYq1SmmnORCYCNgPHu4a1NwXJn3M4772zuMoCd9WNYBRA14lLAxceouYW1IwMf9sEKybnHejVMGpv9OUY5VqHTajI15owQAFp6N8RFOt2okfaJ/wV9cyFuk6LDKJdfJ58ULMKe6z6ffP+B4pHbjVbfxezPT7NM2X0rRk0pLKPHyJgzQgBjxozhjyPeX8ZRY9lY9ny8r6/P7GervTHfJRqYBYz5WaWif6RM/6uUW+3i02JVuhRDsVz+OuB/QwyW2eQv8Nzf2ATAsckxyoptCmzcz2POhA0jBMCOYNmzmLe2BXayRm3MGLeaeBYwqjSIssIjWA24+ZZbELdsl+Wf9erI3wMzF0HiSL2kaY5Jw8Zjs4xzsGNsrBkjANyRZKeM3Egp0+7B7Om9vb2HDB4Y2ba38Czg7otCw52+iTq7f5iarxDPW3kw9TX8nhR9ZDgUjnJ8fw5mf2M3ZIsxOd2B95uLY82IKWME0NTUtApLEyYBI46NoMTsKoCNbZ0Nenk3FtH6Qnpzx/tofveBsdh3ZTS38nPkeU/CnMG3PkNbsPQ47dSDS79glUYovU1MjlA29GkeYzzWQivYrqIxAmC9JpcmrK+CZGHr3RXOBz/Fb4DhWSF4TXM1tJ5GWt9H9fhGoY4X96Bc/ptEHn/CzxxmYTQx2Z+2vzGyL8aiEwKALaOTrFECGDVqFN+Z/GuYPglYpxFLLvOAz5w4G37EeSlAuC7dk0jdQrmux/C48Ayq9b+Fa5qIv9HnNfBym/GNuUX621j6G+3jYiw2OmjYX4tjzJgpowSA5ckGeGaUoaCvZIItXgXsVfJklExv1KUYhfxsOIoWA3XVFFwj/4RyeV4RmP0UpAHvqlKRy59LG/ueIKWuAbG5/mhvKRcXU7b1X0udCJuHGXkvjsWw9QPWWwxbPMYCVitf3CgBsBnP8+7mrQPZA8z7JeN2Zuz9AmkFEjCuOazCDxOpuynX9TPcH7D+fnky8cdf4+XP8xPdhMG/vwmVkXVozd8CNd6vxRjcY6h/tvZtjC3jBNDQ0MArgGdsgTBUL9jwYjx7/dDQPCP77S3/F3q+B0lQUp8mXz9EuXwn5VabfQpiqpW5/Cew3H8Ag/4OqHT9eX6YrJA8kHq2hT/zX6FQsFMcexyDwWqFLv1McWyFVlCqonECKBox9tHKor6yG9/3Ly97MsqJbAvr/WUUFZbqziAqPAEi+BV1dl9JHfnDLNmpTu387o/Aj2so183vhbgLg/+46iq6LKWvobaW/zRt0VrslXbUypiyQgC4UcHO5ku3w2wuGPhELMMsvTOu4RJ46+IXhWAmcDoGTwyuIkXLQAZ/wiD8IeVW2f+FYr6p15k/A/buoFz3S1iV3AM/LsZ9kw8EboGbCnzdb2PpfwHHnpsmUL44poybs0IAAGYDhEnAuMOlFOJGzOWQCaXORcrL7vNHUng+H0mJk8r7YRBeSOTfDzJ4lXJdC6ij61S6bcX+dOOqd0TyYO6f30WdKw4ivqHHNyQ3FTaSpp/A3nQiPS6SbvuVn6Q3N33OtBmONQivEIeptpHBYwmywYZuKwTAjuJ6pRNOh35dMeuoVmBnb1yP2emQtla+qfmlan1JQLndiNTnSamfUibzR2ryX8Pg3QR5AbKEOrsXUK7r+5TLXzRAEp1dJ2C/DftXUq7rBsrl74I8jnJrMMMXaHTTWtKZ3xHf0CPCDUltLWZgw1zaetPvFLpg/43mlG7VxLHGMbf1yO5/2HmNx5ItK9Y6E47zozRnqwAAdO7mzZvNfl0YSgdStuU/MOP928B+bf4bC7f3hRyNdnyeSPGlzXUDJKEV3+fIYf8q5PMPb/IbeA9Fub0xw1uLD7L5p3U/+f40w9/yG/C4GGMuv7vBEymPpQH7pv9Z7WBmLhBBwbTT5fThMcll5c5Fzm9v5evcH0fWIwrsIzCKDqazJq2wYchqjG3nMI8dHkPbZRs9tEoAaMAfcad0vlGPKyubumXLlqsrF4lwNtuK6171qwgapKptBJQ3lc5sfdaGmWJsTS2n23Q+jx0eQ6b1DtVnlQDYEBrh8jIAK1l1GTrqVLZtRbLNx2F5/CMrukVpNAR8/W5qm/CbaEpK1+aYwmC0t8IsYdbF2LFOAE1NTY/ijunPS7TPWhY6ag5sNlsz0N76Reg2/10EKJUUAgH+oRddGE8zW5eHqD1iFY4ljqkRCxosAJs/57FjUGVJVdYJgK2iMU5XAbA5CXdq7V0KwABuMHGbPsm7InEioH5Dft9+1D7J2uc1irE0yWUrXY0ZJwTQ2NjI79671SWAsHU6Og437rBnK2VbFkE1fz6/G1tJrhHQdDftMPZEat93vS3TxRga8T1/hu3fWhwzhtUOV+eEANgsrmeuBqut5X1XAntX9/T08AC1ZzLb8jCUYyWAmQg7klwhoO6gluZP02l7Gn/OP9gCjh2OocFjF1vYW8tjxYUttuGMAMBoXUopu8tybtG2ksEf3w8w93sC2+rfepRteYZ6R5+A5+Y3bM2Q/9YQ4Gf8ir5C2eYv0DTVb8sOBuJOHDvQn4E4SzxGeKy4MuiMALhBo0eP/iGA5Q+e8KErOay3t/dm68ZmjXuTsq0XklJnwdZrEEnmEXiStHcCtbX8wLzqbTUWY8bpF614bPAY2dYTu0dOCYCb4nJ5w/ZYwKqfK3YoH9qVtuZ5pApYDcjnBcwCrfge0gk0s3mJWb3DtXGscMwMP1M6x1RuHGPDOQHg0cbDYLprTYEWQM8sPMu9JkD58EXbJj1FqyacQFrX8seHw7ffZE1+xKfofCz5z6Fsy+smVZfSVYyRWaXO2czjMcFjw6aNUv5hN/MAAA5mSURBVLqdEwA7AZD5XsB/875LAavzC0SucGJztvKJPz7sq5Ng71GIpOAIdFDBn4ol/03BqwavgTv+V3CMBK8ZucZ/F8dEZEVBFcRCADvvvPOrcJRJABu3CUz7HYD9KWdWZzbfi5nrKFJ0BVYE1u5YO2uPE0N4oqIyHwduM219uGf7ZnBMcGxsn+/o+OrimHBk7m0zsRAAm8fNjtsB+ELedy1g+Z+jw9/j1G5byxzyC0cRqZ+S/JVGgJf7mi6jbDNm/fH8NezS5QzncixwTIRRG7UOjwEeC1H1hK0fGwGwwwCdf5zB2oc42EY5ge0/lztnLf+sfZ9GcJ+G1UA7bCyDSNqKwGZsbh5Y7re3fB/7TlMssbC1hethm8fA1qMY/sdKAGA+/tbWZTG0e8Ak7vaCgGN4q01bS46yLYfDCX7v/33YpjWtQ8P5UvBA4HGeq+U+bA4kdP44joGBg3j+XVYcA/FYh9VYCQD2CQDksI3tAzS48fMSgiCet+xmW+5E4H8E7We5E9u0JH4779fQWB74XwMGfIxDd4n7nPvencVhlm4oxv6wEy4zYicAbuyoUaN4FbCU92OSJ/r7+z8ek23CALgPwquBw0mpH0H4HfaxuWPNsFIPQvd5EB74V6PNvALAodtU7OsnolqNUH9pMeYjqDBTNREEgOugTZDL0SRjv9cGXYGS7/uLMCvwK7EC1TNaONuyjNqav0ibNr4HTwzOBBH8DGLt465GfS+nTKnn0IaryPcPQduOx6C/GbK5XHHb+dzH3Ne27VTQ38uxDtlUoYyzU4kgAG4tGPERbHklgE1s6QYsC6+KzfqgYX6RZXvrAgyYz1B/P5PBJRhEjw2eTvyW7+YrdRtp/2NowwGQb9DMifxi0VhdL/ZtbJebxcZfVoz14mG8m8QQAMOAa6LrsF0AiS3hxtCVmCVy2Nr9AlG1LeR327W3XotBdCQVCgeQ8maRpttBCFbeeVetWyXK/RZ53xsY9FsKk+Dv2dQ+8b+QF3viviz26ZUxO7OgGOMxu/G2+UQRALuF6zO+FHD/iI6Nvy1tmC0e4K+Dvp2VgL2zJj1HbRNuofaWGRhg+xI1TAYR8JeP5pOiP8DDHoj9xDM80eMwxIT9SWzfgWX9FMjlA4N+1kQr77CHncCJ+5D7EhXbIMZSCEV/LsZ2iKr2qnj2VIfTPHbs2JdwjcYkEE6BuVqHZTKZBxA8dl8qEsXf7D4vggjmYeC1UVvLP2M7lryGvaFyGml1NmZjfqb+/4j0b4gU/3QXEyv/YtM60sSDdAsR+ZBNpNQr2K4h0i9iy2TCA/xhHM9D2SvI16eTKhxMO/i7UlvzHrD1QciXIYsg1j+jD58CJ+477kNUdPqtPtgbljimObaHnYg5I3EEwHg0NjYuxrLtW7wfs2TgxzVYPt6JbXPMvlRnfsY+L2FAPkztzbdhNr4M+5+mbOtUyjYfTNmW90JaIe+i9pZdsW2EZCA7Fgf1eJSdjGMmEx7g03B8FsrOoZmtC4m/5HRacmb3coBwXxX7jL/85fT7/KV8UkrN5pgudS7uvEQSAIMyZsyY2ehI7kA+jFv49WIPbNmy5dS4HRH7lRHgPsLM/wBKnQ6JPXEM46ZfEiazklgklgDYW5DApdjGfdcWLgykSWDynyLArh44kn+JQ4D7hvsIjll9gSf0V5tuKMZwteWdl0s0ATAauGt6Ibb8aUFs4k8IsMuwvHx0s62fIYu/iTXnAfcF9wn3TYKczxVjN0EuDXcl8QTALgPIdnTug7yfEJnqed5iBN1NWOJNSIhPqXODsec+4L5A46dCEpE4VjlmE+HMCE7UBAFwGxoaGvjFGkl79n0uAvAxyAXso4g7BBhzCH846lx3VquytKIYq1UVjrtQzRAAWLUPN1MOBmCJ+mgs/OLHbj/C9ee9uPn0IfgnySICjDFjDRM/KmKPXXdpBEv9HKPwq2+Ecok5XTMEwIgB2A0AeDzvJ03g24lYkj6M4LwG272S5l+t+8OYFrF9mLFOYns4NuHbhiT6Vs6nmiIAbgQAfhnBcADvJ1HgH7938GkE6/fg57uT6GMt+cQYMpaY+Z9mbJPqO/w8AP69nFT/yvlVcwTADcGjlecA9hG8n1DZA/5dykGL69QbIfG8byCh4FTjFmMGuZExZCxRZw9IIhP8O4JjMpHOjeBUTRIAtwnLraW+7/MMm+TrrUb4yt9/fwLBfAeC+RgcS6qAAGPEWKEIf1+fsWMMcRh/KuFBH8cgx2KJczWRVbMEwOg2NjYuB/jjsPxaw8cJl+nw81dYzi6CnLF+/fpkfNswAaAxFowJZBFjBJemQxKd4Ocajj2OwUQ7OoJzNU0A3DYsv17BM9dm7POMgU2yE/z9OOQnu+666/OY6eb29/efnGyP7XnHbWcMGAvGBBLfW5mCNfMJjjn4y1+gClYzYaVrngAYT3SEjw45DKzs7FXSbDeKwNdxqH8OlpCLMfMtx0C4tqen52jk1XXiNnJbuc3cdjT2nCIW2E1+gq93c6xxzCXf25E9rAsCGGwmbsTwDDJ38LhWtgimyfD1q5lMZgkGx+8wOGbjWvh4BNto5Nd04jZwW7hN3DZuIxr01WKbsVsbqejl3GKMFQ9rf1NXBMDdAXY+F0GX2G9fsY8jyEEYHN9EG+7HEvllDJ7FkK9h8PCHoEaomozT7Cv7DFnMbeC2cJvg3UGQmkxow7c4tmrS+QpO1x0BcFvB0rM9zzsT+4l8UQX8qioh6HaDnAzhH494ErPoyxhcd0JmYv9969at26EqRRYLsQ/sC/sEuRP7/Cz8SfYZwr7vZtG8C9WvcyxxTLkw5tpGXRIAg9jQ0LAAsw5/f4DfhMNZNS9ozzvRCP6e+23Yf3a33XbbiFl2LQbeo5Ac9r+OAXgG9g/ZsGGDsYHHulgn62Yb2M9BHsX+WvaBfYFft0FOxz77iN26SE+hPSdxLNVFa0o0om4JgNuKxzT8/vWTMBPF8huE7INtQdveBRv8Tbg27H8bAfsTHD/R1NT0KgbpZsjfMHBXYPsUZAkG7S+wvQNyA/LnsPA+hD+nwOf4PsRTyOc6f0P+ZtbFOlk328A+v19vKvbZNg7rL6FtCxE/J0GW1l/r3m5RXRMANxNB+zcs33hm4mU0Z6VJxqCx/KnEidh+AHI0AvsUbPk5+/nA5nIWHJ8P4c8p8Dl+EvEB5HMd/vQd68Dp9CS0/bvFmPlbvbe67glgsAPB5FdifybkTYgkQaAUAhwbM4uxUup83eWlhgC453AXtwPszvcFnuFjEUFgCALPcGxwjAzJq/vdVBEA9ybY/deQo9DZ3+NjEUGAY4FjAvLr7dGo9+PUEQB3KDr87+hsvv49FscPQSSlE4GHEAvHFmPh72mEIJUEMNjR6PiHsOQ7FjfGLkdeKgMA7U5j+jv3Ofc9x0AaARhsc6oJYBAE3PHlywG+LPjZYJ5s6xMBzPjcx0cV+7w+GxmgVUIARbAwGzyD2eAzODwHsgoiqb4Q4D49h/uY+7qapqWhjBDAdr2M4LgVQXIEZopv41TNf90TbUh7eoX7kvuU+zbtYGzffiGA7RHBMQJmLQLmXwuFwiHY58uDN5AtqbYQeIP7jvuQ+xL7a2vLfTfeCgFUwLmpqakbwXO57/v8Tr8foGgPRFKyEeA++gH3Gfcd92Gy3Y3XOyGAKvBvbGx8AcvHryCgmAj4twoLVVSTIm4R4D65gfuI+4r7LIr5tNQVAgjQ01hG/gnBxb9VyERwM443BqguRS0gUOyDm6H6EO4bHP8J+5KqREAIoEqghhZDoD0NOQ/Xl+/H82R++cjKoedl3wkCKxl77gPuC8jTTqzWmREhgAgdimXmSjxPnv3666+/H2r4Fda/xVaSXQQY4/MYc8ae+8CuufrWLgRgoH/33HPPjZiBboZM8TzvU5iZ7jKgVlQMQYAxZWwZY8jNjPmQ00Z306RMCMBwbzc0NNyFmelTuBadAtXXQ5ZDJIVDgLG7nrFkTBnbcGqkVjkEhADKIRMxH3ejf4uZ6iLIuxHAx0OuxSz2XES1dV+dMWKsIMczdpCLGMu6b3hMDRQCcAA8AvhByCWYxfgHJD+E4Oa3E/3egelaMfF7xgTyIcaIsYI8WCvO17KfQgCOew+B/QjkSsxs/IrswzHjfQuB///hxquQtKRXuc3cdjT4cMaCMYE8guNYU9qMCwHE2OMI/GWY8WYj8E+GvBOD4gi4cxHkTuzXzUdXi225E+26CPtHcFshJ3PbGQPkS4oJASGAmIDf3iwGRj8GxVIMiOshZ2B/L8yQ70E5fo/hfGz5Ay5bsE16Yh/ZV/Z5JreB28JtglyP/aXc1qQ3Ii3+CQEkuKcxQz6PQdMBaYPsD2nkAQXhpwz8ktN5cJ/faNSFrYa4SmyLbbLteRjQV7JPkPewjxD2lX3u4Da4ckrsBEdACCA4ZrHW4AEFuQsz6Xcx0M6CHAuZiOOWQqEwzbZzbINtsU0I2z4Lx/wabX78+bxt+zb1p1G3EECd9Dpm4VWe51m/kcg22FadwJb6ZggB1FEIYEa2fuPQhY066pLEN0UIIPFdVL2DmJl5BWDzLUb8dh22Ub1TUjLRCAgBJLp7Qjln83sINnWHaqypSmnVIwRQZz3v+/4iW02yqduWz6K3MgJCAJXxqbmzjY2N98DpuRDTaW5Rt2m9oi9GBIQAYgTflml+LAfd/E06bIyk5UWdRpSJkuQgIASQnL4w5gluBq6GnG1KIeuCrDalL2l60uyPEECd9j5m7Ee11vy6skgtZB2sK5ISqZxYBIQAEts10R0bM2bMbAzgK8Jq4rqsI2x9qZd8BIQAkt9HkTzEAJ4DBQdDboFUm7jswcW61daRcjWIgBBADXZaUJdHjx79FGQWlvKtqMv3Bh7G7P4C9vkXkfmXcnn/YRyfzWW4LOQpHNd9SnsD/xcAAP//rCW1uwAAAAZJREFUAwDvbtZGMupaFgAAAABJRU5ErkJggg==",microphone_magic:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AABMl0lEQVR4nO3dCZycVZX38d+p7iQsAWR1IaS7QwQEFRUFWUTADWEQN5AtSXdQcEMc9dXRmREZHXUW9xlGI9CdhEUJCoi4I4igKIsKGrYk3R2CCBiQJYlJuuu8n9t5ogGydVJV97n3+X8/lEk6seqkU/Xc89zlHHN3pKF2BvYFXgC8ENgH6Cy+LulYCvQDdwG3F4/fAQuAeuzgRGTD7Nx5ExjTdgReOwTjebg/F3jmU/7YMszm4/W7oHYr+E8ZHLjZzzpsiMyZEoDNMg54KXAQcAiwP/Cs2EFJUy0BfgP8Arih+PHPsYMSkVWsb+AZuJ+C2ZTimrwpFoN/g7r3+fRJN5MpJQCj0wa8DHg98GpgvyIJkGq7E/gZ8APgauDx2AGJVI31ztsZa/8g8C5g2wY+9U+p2ad8asc1ZEYJwIZtDxxTDPqvAXaMHZCU2opiZuD7wHeKJQQRaRIL/83snwK1z+G+U/NeyL7LUP29fmrXIJlQArB2WwFHA1OB1wJjYwckyZoLzAEuVjIg0lg2e/4uDLfNLq7TrfA4cJp3d36DDCgBePL0/lHAqcCRmtqXJrgFmAlcADwSOxiRlNmswQOp+2Vr2dTXCl9isPMDflbaG4KVAMCuwCnFulFH7GCkEpYXywMzij0Dlf8QioyGzRp8PXW/tJitjcO5hCeGpvoZk8PnOUlVTgCOAD5QrO3XYgcjld5A+EVg1shxJBFZL+sdPALz75Viltb5DgsH3pLqkcFKJQDuPsbM3giEnaIHxI5HZA0PAecDXwb+GDsYkTKy3sGXYH4tsA2l4ed4d9d7SFBVEoCQKb4D+AgwIXYwIuuxrEgEPgPcFzsYkVKd71+1j2YSZWM+zad1hVm8pNRyv+MvdvKHndhf0eAvCdgSeE9RcfBrwLNjByRSEl8t5eAfuJ1j582fTGJyTQAMmGJmdxa7rsv5phFZt3D09DTgHuCzwHaxAxKJxXoHXge8jfLamra2c0hMjksALys2VYXyvCK5eBj4N+B/gOHYwYi0is24ZQzjdpqLewp32G/y7s7LSUQts+N8YQ3mVxr8JUM7FInt7UWdCpFqGLPjSYkM/sFZI5UJE1HLpIBP2NV/d5j2L6b/RXL1vKLM8IXqMCm5GxlMjQ+TjhfRN7JckYTUE4AXFN3Y/jtqQQiR1jupKC0c9gko6ZU89Q4eCOxNUmw6iaglfKzv34sjIZva7lEkh0ZVXyu6EHbGDkak4WoeqrQmxo8pjiyWXi3RKdBfAh8Lq0OxgxEpgdAI5XfFbIBIPnykP0tqtgALlWZLL6UEwIoL3M3Ai2MHI1Iy2xazAZcUGwZFkmYz79092f4sxuEkIJUEYBfgquICp7V+kXU7DrgVOCR2ICKbxYfDke40uSdRaj6FBOAlwK+Lpj0ismHhrumaovS1SKr2Il17koCyJwChjO/1yU4DicTTXlQQvHikSplIcizlCq7bWu+80h/TrZV4l/95RRnfUBtdRDbNCcWm2bCeKpIQT2In/TrVrfTlu8uYAIQNTD8EkjlLKZJAvYywjHZo7EBENpoznpSNaS9Ry+I0EoAw5XMD8MrYgYhkJiTWPyoKCImUX83SPuY97KGhV6mVKQE4oJiqTHnjh0iZhaW1C4BPxA5EROIrSwJwZLFrORz3E5Hm1tM4C/iCSgiLVFsZEoBjgMu02U+kpd5fbLINzbREpIJqJdih/K1VpRNFpMVC98wL3D3ttVYRSS4B6ClamuriIxLPCWb2TSUBItUTKwF4K/D1EsxAiAi8ycwudvdQPEhEKiLGAHwscJHWHkVK5S1mdq6ScpHqaPWH/TXANzTtL1JK04AvxQ5CRPJLAPYHLteGP5FSey/wr7GDEJF8EoBO4Dtq5SuShLOLRlwikrFWJADbAlcCz2zBa4nI5gsFgsJ+gFfFDkRE0k0AQi3kK4DnN/l1RKSxwj6dOSrNLZKvZicAYUPRYU1+DRFpju2LpbvStzUVkXIlAKcA72zi84tI8z0XmKW+ASL5aVbhj32BrzXpuUWktd4A/BPwmdiBSBrsooVh9mjzJF+Yqr7NZn8fFq9Y6mdMXk6TmLs3o+/4LcXOfxHJw3DRtfMnsQOR8rDz+jtos8OBVwB7A3sUY4A0zkpgAXAH+K1Y209Z/tCv/bT9wtdLlwB8Ezi+0U8qItE9WMzu/Sl2IBKPnbdoB9qHTsFHjoruFzueinoY45uY9/nUrl+XJQF4e1HjX0Ty9APgqDBBGzsQaS2bPX8Xhts/BB72dm0TOx75m2ux2qd82sSriZgA7A78Rm8Mkey9BzgndhDSGnY2NTr7T8Ht88COseORdTD7LkP19/qpXYMtTQBCK1EzuwF42WY/mYiU3TLgpcDc2IFIK+7622YDr40di2yUx3FO957Oi1t2DNDMPqzBX6QytgT61NEzbzZr8ECG227X4J+UbTAust6BL43M3LRgBiDs+vydmvyIVM4/Al+MHYQ0nvUNHgUeKkGqf0uybA6Pr5yyvmOEm5sAhAzj2uIIiIzOw8BdwJ3A3cAA8GdgCfBE8eMjsYPMxHhg6+KxffHjhKLMbUhg9wQmqtjNqIX36QuK965kwnoHj8D8e8C42LHIZruCwYG3+lmHDTUjAQi7Qf9vc56gIsI3/2bgmuLxm2Kwl3JNa4dzzIcCRxQ/hkZWsuFTAa+PHYQ0hvUOvgTzcFOnzdzZ8HO8uyts3G1oArBLceeqOuFrdz9wCfBj4LqRzRmSDHdvN7NwxjkUOTkOeEnsmEos1P0I08WSMDv/rm2ojbu5mBWTnJhP82ldsxqZAMwA3rHZgeXlr0WltFnufrmZbXalJimN5wFvg5HiJ12xgymZe4vllKWxA5FNZzMHLsI5MXYc0gRmT0DtRT5tt/mNOAUQqoFNb0xkWbizSIaeCRwT7oY0+GfnDuATwORiV/SVKobzN7sBH4gdhGw6m9n/Wg3+GXMfjw+f06gZgB8Br2lIYGm7DfgccGFRK12q5flAOAIbLpyJNy7ZbEuLWZKFsQOR0bGzr22no3Nu0flRcmZ+rE/rCi2+N3kG4FgN/vwSOBp4UdEqVYN/Nf2+WBLYB+it+PsgHBf7t9hByCbo6AgJrAb/KqjbJ2yN006jTQDC//Fsqn107/3AIUA4JqMpYKHYDDu9qI4XksOqOqWYBZCUWC3MYkkVGC9mZv9rNjUBOL5Y/6+aOjC7OC/+peLXIk/1W+BgYBrwENUTKgN+PHYQsvGsd+AA3MNSllSFW8+mJABtxSaoKq7zH1BM9ersvmyIF8tCoabA047dVMDxRXEgSYH5lNghSMsdaxfO23a0CcBJxVGfKvlaMfiHs7Eio/HnYiZgalExrypqFV8mTIyF1s5SLVuyov3w0SQAYe3/n6iOx4uE553F2X6RTTW72BsQ+mVUxRuLjZFSYjZ7QSh/rZoWVWSMKgE4qpjSrMo6bqgAt1HtFEU2Quj5cCBwHtVgRaMgKbNhC7ObUkXO/qNJAD5ENfwUeCVwT+xAJDvLgLcXp0i8IicCnh07CFkPH9nULFVkq/7tNyYBCHfDh5G/y4qz/Y/FDkSyFk6RdAO5V4oMneTW2oBESsJs99ghSDQ72EULt9+YBKAKU3n/A7xV6/3SIuF0wFuKWYGcvavosihl5GrkVmkr6tttKAHYsbhQ5exTwBk62y8tFnoJvA5YQr52KDopShkZ42OHIBHVfNsNJQDhCNMW5OurwL/GDkIq6+fFjvkV5Cvse5By0k1PlQ23DW0oATiVfF0OvDd2EFJ5oX10T8YX41dU6ARRWszCcWeprJWPry8BOCTjs7zXACdUvHmLlMdFwJnkS63Dy6juobeJVJOzbPkj60sA/lYvOMMObqGj4fLYgYg8ZSPqV8jTFHevervkEnIdd66u+/3dez+x1gTA3ccUa5O5CRuu3lZU+hMpFXf/YKbdBHcxs5HKY1IitdodsUOQaO4M/7PWBMDMXlfs4M1NOJc8N3YQImtjZiuLpanF5NkkSMpkqO2XGe89kfVxrg8/1Cr0Ye0DZsYOQmQDFhaFgnKrFhiOE4+NHYT8nZ864eGi26lUjY3sg1trAhAqeL2B/KY7tONfUvHdDPcDbA+8KnYQ8jRXxA5AWm4xWy/9xboSgCMgqwpR4U7q9MwLrkh+PlbMBuTkTbEDkLXOjOY22yTrY3axH7f3inUlAK8nv7Kr18UOQmSUlmRYhju3a0vyvLtzALOrY8chLeNY/eurf5F7AvAo8NHYQYhsom8DV5GPCRnXFklXnc/EDkFa5js+teu2dSUAk4DJ5CMM/vfHDkJkM5yZWZOqI2MHIE/mPR2hDfq1seOQphumZmev+YWnJgBHkY/bgRmxgxDZTPOBL5CPnGYY8+G191SgRXXF+Vd9asdv1pcA5LRL99Mq9SuZ+BzwBHk4JPMGY0nynolzi2um5GkQ7F+e+sWnJgAvJw/z3f3S2EGINMjijGazwjHjl8QOQtZisPPfwLUhMDfmQ1jtZO/u/Mv6EoDnAs8iD582s6HYQYg00H8By8jDwbEDkKfzs6gzxMnFspPkwnm3T5t4w9p+q5bhh/Je4ILYQYg02J+KM9s5yOVakx1/e9cDWNvrivebpM79X72762/H/taXABxIHkIFtZEiByKZ+XwmRVsOGilGKqXk03abj9cOxmxe7Fhkk4XrxNne0/Wp9f2hNROAl5G+sOnvwthBiDRJuCCPlPBM3M5AZ+wgZN28Z+IC2jgUz7I7Ze6WgJ3i3Z2f2NAfHEkAil7de5O+nwB/jB2ESBPlsrz1gtgByPr5KR33s3LxK8HC/hN1DUzD7Xhtf+/uuGhj/vBIAmBmexW7c1M3O3YAIk32TWA56Xth7ABkw/y0/VZ6d8eHqdlLgRtjxyPrtDRM+fP40MuKI50bpZbRhzGck1ZnK8ndI0W3wNRpBiAhIwVkujsPAg+dYm+KHY8UzJ7A+TLtNjlM+fsZk0d1cxCm/oPnk74rMiqWIrI+FwNvIW1KABLj4b/uriuBK61v4OXgU8DenNHx8VSsAP852AW0r/y2nzz5sU19InMf2VR8GfBG0jYd6I0dhEgL7AA8tI5mXqkYcvctVa8jfda7cG+ovwLjecCexSbPbYG2zXzq5yReNfK+BizXPQ7+BG7zMbsL91to3/J6n/LMhrS3X50A/BbYl7R1AQOxgxBpkVuBF5M2fWZlnWzm4M9xD6Wj0+S83Hs6f0WJrb6DSP1ITqhcpQuJVEno4EYGCYCIREwAtge2I23XxA5ApMVyeM8rARCJnACkfvcfqJe1VM11YR2dtCkBEImcAEwkfbfFDkCkxR4H+klbDtcekaQTgLBjM2WhQtU9sYMQieBu0rZT7ABEqp4ApP4hHAT+GjsIkQjuIm07xg5ApOoJQOofwtQvgiJVfe+nfvMhkrQcZgBSvwiKVPW9n/q1RySLY4Ap0/l/qarUNwFuW3QiFZFICcBWpG2T6yCLJC71976ZWcqlXkWSTwDGkv5xKJHKcfccml+lfv0RSToBGEfalABIJRWNdJaRttSvPyLJ0gyASNpSf/8rARCJJIcEIIdpUJFNpQRARDY5Adjcns2xrYgdgEhEqRfB0ikAkUj04RMRKTk7d94E2tsPAdsb851w2wlje9xXgC3G/M+43w/cCHaTd3emnhiC15eDkaw2L/3+HCUAIiIlZOcvOIS22nScw2lvL7q2+sh/f/9xzZ//bbBcYX39NwFX4MN93jP5IZJkaS9vWa308SsBEBEpCesb2AL8HWCnU6vt8/dBflTGgh0MHIy1f9L6Bi4DvuTdnTeSFF+c9AzAsuGHSWAPgIiIRGZ9/ccAfwD7MrBPAzdZngD80mYOXmmzFyTUgtlS7vL6gJ826VFKTgmAiEhEdv69z7G+ge+DfQeY1LQXcv8Hhmu/t77+M0iB+R2k604SoARARCQS6x18CbXhXwJHtugltwkzDNY3cLHNuL/cZeBt7A1AnRS5X08ClACIiERgM/unYv4LIMa0/AmMXX5tmH2gpHzqrouB35OiWts1JEAJgIhIi1nvwIm49UYuhPQyasPX2uz5u1BadgXpeZjHVmgGQEREnsxmLnwVRm9Jrr/PZbjtSpv9wNaU0fDQrFXnHFPi3/AzJi8nAWV4A4qIVIL1LXgB+OUlK4G8P8PLLrQSnrnzU3efByQxnV5wsK+TCCUAIiItYGdf2461nY/7eMrnWPoGeygjr3+GVJhd5d2dvyURSgBERFqho+OjuL+U0vIvWO/83SgZ75n0E+BnlF8d7BMkRAmAiEiT2fn9e4L9C+W2Ldb2FcrIau8BVlJmxtd82sRbSIgSABGRZqvZhxNpvX6szRp8MSXj0yb+AafMSwELGVP7ZxKjBEBEpIns3P5nAieRCucDlNHCzrPBr6ZszIew2kl+0sRHSIwSABGRZmq39wNbkAr3t5WxZ4CfNbLGfgownzJx3u3TJoaqhclRAiAi0syd/1DO3fXrNobh2nRKyLs7/4S1vQ74E6XgH/furmSO/T2VEgARkWbp7DgKCEsAqZlWxroAgU/bbT5tdhBm82KGAZzt3V2fJGFKAEREmsVtGmnqZGb/Kygpn9LRTxuHAqGXQqstCUsR3t2Z1JG/tVECICLSBHbeoh2Ao0lVyZMXP6XjfgYHXonzn6FocIte9jba7GXe3XERGVACICLSDO3DJ5as5O9ovbXsLYP9rMOGvKfzI8BLcUJb5WZZGqb82Xrpy3xKxx1kQgmAiEgzuE8lbdsydsUbScBI+d2ezoPB3wD8umFPbPYEzpdpt8lhyt+P23sFGQk7VEVEpIFs1oI9oLY/yfOwDJDEdLeH/7q7rgSutFn9++O1Kbi/GXjOKJ9q+UjpYfMLWbL02/7uvZ8gU0oAREQarV5L7ejfurzazp03wd8+eVHsQEbDp3aFWYDwOMP6BvbC/RBgL2q1PXHfBRhfLM/8BXgcWADcjddvYfzYG/y4CcuoACUAIiINZGdTo4OTyUONMe2himHYaJck7+68EwgPeQrtARARaaSJC44AStdVb5M5pT4NIJtOCYCISCPV2nIbMPe28xeUuI2xbColACIiDWKzH9gaSGLn/KjU2lI/0SBroQRARKRRhpcdh3vYYJYZP8m+Mi/lmgayFkoAREQaJ7fp/9V2ZJv218cOQhpLCYCISAPYef0dMFKfPk+OlgEyk8MxwLmUWygqsQRYDAwCdwE3AdcAC2MHJyO2KS7cB4+cFYY9gJ2AsJ6b4XSuNEXbyACZ702VcbTNuHsnP22PP8cORRojhwSg7MYVj9AY5LmhsMYav/cH4AJgNnBfxBiraEvgTTBy0X6VPguy+SyXs//rMpYxY04A/id2INIY+WaradgH+AzQD/QWd57SXNsC/wQMABcCr9PgL5vLegcPAvYkd7VarnscKkkJQDmMAbqLGYEvFVPS0njHFN/jkHSFcqAijWHJN/7ZOO4vtfPmPz92GNIYSgDKJdyJvg+4HXh57GAyEtbzQ5OQ7wATYgcjebG+gS2A46mKtrZTYocgjaEEoJzCbuLrQiOL2IFkIFQw+w3wD7EDkUzZSAva7amOKTaHtthByOZTAlDuZYEvF0sCFjuYRB0OXK27fmkqt6qtiz+Hpf1h46wkTglA+b0v5U5ckQf/7xeb/kSawmbP3wXz11I1qgmQBSUAafgQ8MHYQSTkxcDlxfFLkeYZbj8FtwqeIrE324wF28WOQjaPEoB0/OdTagjI2oWL0qW685fWqMju/6fbkrFtb4kdhGweJQBp/VvNGqnJLeszA5gUOwjJn/UNvAjYl8qqbPKTDSUAaXk28NnYQZTYkZU6jiVxWeXXwQ+13oVKthOmBCA904H9YwdRQmOBc2IHIdVgZ1/bjnMi1WbU6qoJkDAlAGn+m308dhAlFI5idcUOQipi4sQw2/Qsqs7pNh1TTpYSgDQdBYT1R/n7+/jDsYOQCrG2qk//r9bFzIWhD4IkSAlAmkLGfWrsIEp25n9y7CCkGlYdf3NVllzNvWqFkLKhBCBdJxTr3gJTYgcgFTK2dmLRTlpG+Ntsxv1bxY5CRk8JQNoNbtQwaNVsyNGxg5BK0R3vk23L2OWhH4IkRglA2o6IHUAJvLBIhkSazvoWPBc4IHYcpaPSwElSApA2zQDoeyCtb/yjXe9PZbzWLhgMdUokIUoA0rZX7ABKQN8DaYmR425mJ8WOo6TaWFk/OXYQMjpKANK2mxreaPe/tEjvYDhtoloT62LWHTsEGR0lAOn/+1W9I9f2sQOQijDVvt+AfWzWYOjEKYlQApC+bai28bEDkPzZ7Ae2Bt4cO47SqytJSokSgPRVfUNS1f/+0gr1paH1bdWT7Y1xks24ZUzsIGTjKAFI32NU2+OxA5AK0DG3jbULY3cIfRIkAUoA0lYHHqXaHokdgOTNZi3aFeyw2HEkRIWSEqEEIG33AsuptnmxA5DM1YfDgNYWO4x02DE2674dY0chG6YEIG13xQ6gBO6MHYDkztVrYnTGMrzy+NhByIYpAUjbL2MHUAK/ih2A5Mt6B0LZXxWbGi3TMkAKlACk7aexAyiB3wF/jh2EZKqmgWwTHWB9A0qcSk4JQLoWAzfGDqIEHPhe7CAkPzZn7lgcTWVvMi2dlJ0SgHRdDKyIHURJzI4dgGToiS1Di1ttZttkNs3maPNkmSkBSPeu9/zYQZRsKWR+7CAkM2Y6+795dmXpQh2fLDElAGn6PvCb2EGUrB7Cf8YOQvJhs+fvAqigzeaq15VElZgSgDQHu7NjB1FCM4H+2EFIJobbQttflbTdXMZb7Py7VEK5pJQApKcX+HXsIEooFER6d+wgJBMq/dsoW2Pj1ESppJQApOV+4J9iB1FiPwDmxA5C0mYzF+6Doba2jWJKpspKCUBaU//hg6Qz7+t3mpYCZLPUh3tih5CZw232YFfsIOTplACk4yPAT2IHkYC/AKF1q7oEyqiNHFszC+v/0jhGHX1PS0gJQBr+F/jv2EEkJJyQOFaNkmTUlg2+Fnh27DCy4z7NQiIgpaIEoPy+DLwvdhAJugY4CngsdiCSkLqr9G9zPJdZgy+PHYQ8mRKA8lpZDPxnFuv/smkFgl4FLIodiJSfzViwHRCq/0kz1F2bAUtGCUA5DQKHAl+JHUgGboaRHd1XxQ5ESm5c7W3AlrHDyNiJNmeRvr8logSgXIaKKf8XqtFPQ4WTE/9Q3N3dGzsYKSnXHWqTbceSleFzKCWhBKA80/19wD7FlL/WrZvjyuJ7/FHgwdjBSHnYefMngx0UO47sWU1JVokoAYhrLvAxYHcgnD2+O3ZAFRCOB34W6ARCu9IfFjMvUmW1tvBe0C71pqsfaX0Dz4odhazSXvwozTNUDDqLi7X9u4Cbig1qC2MHV2HLgAuKR6hV/krgYGAvYA9gJ2A8sFXsQKW5Ro6nGafEjqMS3NpxTgS+EDsUySMB2Bu4I3YQkrSQoH23eKTm98Wyhmyq3oFDMSbFDqNipYGVAJSAlgBEpNpq6Ox/a73Izu/fN3YQogRARCps5Fiao251rVZTg6AyUAIgItW1dDgM/qEAkLSUnWJnX5vDEnTSlACISHW5Sv9GsgsdXaHvgkSkBEBEKsnOv/c5wBGx46gsJV/RKQEQkWqqDYez/22xw6gs4w120cLtY4dRZUoARKSazHT2P64tWF4/PnYQVaYEQEQqx/oWvAz358eOo/JW1QSQSJQAiEj1WJsGnnI4yM7v3zN2EFWlBEBEKsXmzB0LnBA7DinUaifHDqGqlACISLUs2/po3EOvBykFn2pnayyKQd90EamWumv6v1w66Bg4NHYQVaQEQEQqw2bdtyPw+thxyNOoJkAEKsUoIpVg5y3agbaVXwIbRx7uLNpX5+AkmzkwDrPZbNnxIz+O4dgBVYFmAEQke9Y30E3b0N1g+Ww4M/sU8GvyMBbnROr+PZYM3GszB//LzpuvY5pNphkAEcmWXThvW1aOORc4jrw8xvKxlzF2xXbg+5OXZ+P+IdraPmR9A7cCs/Chi7xn8kOxA8uNZgBEJEs2a9GurGz/GXhug39wqZ/27KUMt30DWE6+XgJ8EWu/32YO/thm9k8daeEsDaEEQESyYzPv3Z360K+AF5EjZ9bID6dOeBi4ivy14f5q3GayZGiR9fX/j/UOHBA7qNQpARCRrNi58ybgw1cDu5Knfno6r/vbr8xnUi07gL0H40brG7jDegc+ar3zd4sdVIqUAIhINqxvYAva2789crY8V85sD/+72sDg94AHqKa9MD6NtQ1YX//1NnPgNDtn7vjYQaVCCYCI5OR/gZeRL6c+PPtJXzjrsCEg7AWoshrYwThfY6ut/mh9A73WN3CYKgyun745IpIFmzl4NDCdnJnd4KfuPu9pX3cb2RMgI7YBuoFr6BwctL6Bz9qsBXvEDqqMlACISB5T/+7h7j9vXl/rQO89Hbdi9vvWB1Ry7hOAj1Cv3WV9AzdY78Dp1jfwjNhhlYUSABHJgJ+R9br/KstY4Zes83fr9aptBhytgzC+CtxvvQPfDDNGdva1la6FowRARJJmX5k3DuyD5O8KP23So+v83WFmYx72A8j6bYFxPO7fpaPzAesd+JrNXLgfFaQEQETSts2YUN73meSutv51fn971wPU7cetCygLO2Cchtdvtr6B31rvwD/auf35v5cKSgBEJHH1vDf+rfIA/f0bM7g/6YSAjMq+GJ+n3e77W9XBGfdvRcaUAIhI2kV/sAPJndns4rjf+o1vvxxY9zKBjK7q4Njli6xv4P+sd/AgMqQEQETS1dZ2ZCWuY1bfqDt7P27CMszmND+gytgeeCfmN1jfwKojhb0LJ5GJ/D84IpIxewX5u9Wndt220X96eFinAZpj4siRQqvf87eqg+ffFWoOJEsJgIikq2ahW1zuRlfkZ/qkG4D5TYtGan+rOlgb96D1DV5iff3HpHikUAmAiCRppMyr+2RyFo71DfmoyvwWfQK0GbA1tljVbtq+Q0fngPUOfMnO79+XRCgBEJE07dq/86oLcMbq9r2R432j1TZyZPDvDYOkFXbFeB81+631DdxofYPvtvMW7UCJKQEQkTSN9e3Indkmref7lI5+4OeND0g20gHg/0vb0P02c/BK6+s/zubMHUvJKAEQkURZ3nf/8DCPr7xq0//vm5Y8SEONxf0fwC5hyVbhSOEXrXewNPtWlACISJrqtoKs+Tf8jMnLN/n/PmblpcDShoYkmyMsWZ2J+S3WOzDX+gY+Yef1R+1foQRARNJUa3+cnG1mi18/efJj4Jc1LiBpGON5wFm02XzrHfie9Q2cYHMWbUmLKQEQkTRtOeFPwErydLf3dP5qs5/FRnmEUFqtDeP1wMUsGbrf+gZnWe+CV1v4l2sBJQAikiQ/jmFggBw5fQ15nq26rgbua8hzSbNtF7ZvYrUf0zdwj/UNnGWzB7ua+YJKAEQkZbeQnzoMX9CwJMm5sBHPJS21O/AJhn2B9Q2EToVnNuNIoRIAEUnZjWTHv+89u9/bsKez+rmrkgpJ1H7AF2kbutf6+i+wmf2vtTm0NeKJlQCISMLq3yM/X2rkk3n3pHtCUtHI55QotgI7GbcfsmRg0HoH/sNm3htmCjaZEgARSdaqwY3bycfv6O76ScOf1Wufb/hzSuyqgx/Gh+8a6UVw/oKXbsqTKAEQkdSdTy68/qGiln9jn7an46fgm1FUSEqqbWSnR612k/UNXGWzF4SOhRtNCYCIpG1FvRezJ0id8x3vmdT4u/+/sQ+F71bznl8iO4rh2u3WO3D6xh4jVAIgIknz0yY9ivN/pO1BjNOb+QLe3Xkn7v/czNeQ6LbF+Cp9A1fY7Ae23tAfVgIgIhnwTwOLSVMdrMe7O0Nho+Za2BX2Avyo6a8jsR3D8LKf2Kz7dlzfHzJ3nwsjZQmlOYaAULL0L0Do0HU3cBNwTfFriS90lTsUOATYC3gusMuqXbe0vDxnxTwf+EMjnsh6+9+O2ddJjn3QuztatknPLlq4PSv9OtzD915y5tyBt73ap+/2x7X9thKAuO6EkSIdoVznwtjBVEwY3N8KTAEOX7WZRlJOAILQenVV97VEuH/Oe7rC2nxL2bnzJtDefj0QtRmNtMSvgVd6d+dfn/obWgKIK9xtfhKYD8xWItYSzwD+BRgEQrvUV2vwz0ht6NREygOHzf4fjzH4j7z42ycvotZ+cGZHKGXt9sf52tp+QwlAObQDpwC3FUVAto0dUKaOK2ZdQtK1U+xgpPF8yu4PYrUwA/Ao5bUU827v7grvw2h86oTQI+BQHBUJyp0x1XoH3vW0L2sJoJRCGdATgRtiB5JRH+6wzHJk7ECkuUsAq1nv4EGYf6/Y31Emvw2f7ZEd+SUxcmSsb+BM4LPAuNjxSNP8hbbhPUeS5IJmAMppN+Ba4B9jB5KBA4qLrgb/CvGejl9Qr4flnQcoh4cxzmTF4v3LNPivXovw7s4vMjz8fJzLYscjTfMMhts+s+YXNANQfl8uEgE18xi9I4DLgW1iByKtnQFYzWYt2pX60LeKRDCG+3E/h/qYc/zUCQ+TADt/wSHUauGac6z2x2SnTs1e6lM7fhN+oQQgDecA74kdRIKDf5gC1pRmhROAwObMHcuSrT4GfBQYS/OFFrzhrP1Mxi+9zI/bO8nqe3Zefwdt1gNMBZral15ayOj1aZ3TR36qBCAZ/wT8R+wgEmqfGZZQxscOROInAKvZzIX74PUwBXpMc17Afk+9PpMxtQv9lI77ycTIHoGZ/a/AbVpxdFablNO2NDQT8u7OvygBSEe9WMf+cexAEjjmd6vuWJLRsgRgNesdOIAaZ+K8ebNniMz+TN0volab5dMm3kLmbMb9WzFuxZtwD7MCr9ISQar8fd7d9RUlAGkJG5peADwUO5ASC+u94cIuaWh5ArCazbh7J8aOeRPY0cBhG31iwGweXg9T/Jez4uFr/bT9VlJBxf6KcHw5JAN7x45HRuXH3t35WiUA6ekFRtZv5GneCNrFnJhoCcDTp7nvnYQPvwD3CdRqz8R9zMhvuj+B2SK8voj62FtT2czXSta34GVY21Tcw/Hl9dafl1J4nMGBHZQApCf0Cj8IuDF2ICUTpnLvUmnT5JQiAZDGsDm08cSCw7G208CPbdGmS9kUVnup6gCkJ/R5Pit2ECUUditr8BeJyI9j2Hsm/cS7O45nxYpdw1ozZjfHjkvWol7fXzMAae90D5vdZFVBq3uASbEDkVHTDEAF2OzB5zHsbwPCSYLO2PEIYS753zQDkK7Q9ERWCbuRNfiLlJRP6bjDuzs/wWDn7tTrr8CZASyJHVelme+kGYB0hY1IzwaSLDLSYLOKtr6SHs0AVJRdOG9bhtreCLUpuL+qWN6UlrE5mgFI1w7FZsCqC+/h18cOQkRGx0+e/Bg29irq9SuA/tjxVI+PDW1oJV2HFxXvqmxftfYVSfikgJlOCsRg9pASgLQdGDuAEojV5EVERl+KOSzV9WC1XVadaJZo3P+sBCBte8YOoAT2ih2AiKydnX/vc6gNnQwjfQT2iR2PrMF9sRKAtO1WFMBZTnXtHjsAEfk76xvYAvwYrDaVtvqRuGmcKaMat+kfJm1W1C9/kOraPnYAkg87+9p2dtt9F2rDu2C1VY1u6ixj5dB9ftqkR2PHV1YjpZT7+g9Zdc7fjgPbFg9T/NrYX1LDtA/fqAQgfdtWPAHYJnYAki7rnbcztbbX43YE8BI6O56HD6+6LnpowFmMYWNr4c72UZxbMX5NzX7Ilh3Xhcp3VJj1LpyE1UMzoClgqsWRCue2cApDCUD6qr6Tpup/fxklm3HLGMbt9AbgnVj7EfjIUdJVfL13rNthIydvDqfuH2HJwGLrs29TH57F9Ek3eEXei6vO7485DvdpGOGuX7f5qTH7SfhBCUD6HqfanogdgKTBzqZGR/9bGLfTp3Gf3ICn3BH8HdRq76BvYKHBxVjb133abvPJ8Xu324KDsNoUrP1k8K1jxySbwa0v/KBKgGkLc5RbVXwT4HeAY2IHIeWuBGiz+l+I187D/aXNfi3gFowZDC+/2KfvmXSCrhr+WbrWuzvDTJZmABK3sOKDfzAvdgBS8s1pvf3/TI2zcG/V9W4/nK9RG/d5mzkwi5p9JdTCJ6UlkrE7vgXnfZhqjWTH+erqnyoBSNtdsQMoAX0PZK3snLnj2XKrCzF7Q6TV+a1x3sWwv9NmDn6Lun3EeyYuoMzJ0szBkxi746eBiVrZz1BozTzYMWf1L9ULIG2/jB1ACeh7IE9jMxZsx1Zb/RAjbPaLzXB/K1afa70DZ48cNSwZ6xvYi76BX+B+wcjgLzlyjPf5WSNLxyOUAKTtp7EDKIHbgYdiByHlYTPu34qxtR+WsFnWOIyPM7HzOps92EVJWF//O4CbgZfHjkWaapZP7XjSDZMSgHT92d1vjB1ECYTJ3atiByEl2q0+ZvkFpe4REdbVh/1m6x08KPaUv/UN/mdImUaWKyRnd7GifuZTv6gEIF0Xm9nK2EGUxOzYAUhJdA5+FONNlN8O1Pih9S54dbSOfH0DF4D/vxivLy31CNSPWVslSyUA6d71nhc7iBIJLZHviR2ExGW9gy/B/SxS4T6eWttldv6CVhxNfLInBs4BTmr560qrLcf8BO+etNbroxKANIUp79/FDqJEwqaW/4wdhESe+jcPU9ljSMlIElC7ymYvaNnGO5s5+M8Yp7Xq9SSax7Ha0T6t60fr+gNKANIc7M6OHUQJzQKyq8AmG6mz/5SR8/dp2oV624Uj0/JNZjMXHoy7rh/5Wwy81qdNvHp9f0gJQHrOLXbsypOtAN4TOwiJdPfv9nFS5n4IT/R/tJkvYefftQ1evxCan2hIVD+irf4S7+7c4CZxJQBp+SPwsdhBlFg4+vWN2EFIi3X0Hw3sTurMPmbn9Xc07fnbxoUEo3nPL7E9hnE63Z1H+pRJoUrsBikBSGvqf2oxtSPrFtY2744dhLTU6eRhS9osVOFruJHEwvnHZjy3RBfaVIc9UHv6tM4Zo+lKqQQgHR8E1rueIyNC85XjRz4Ukj3rG3gG2GvIxwk2897Gz2a0WRj8t2j480pMC8A/zJihid7T+RHv7vzTaJ+gdCUpZa3+C/hi7CASEk5IvBH4vi56ubOjwMeSjxo+/F5o3N36yNp/bVxPo55PonoMPNTyn0l31/WjudtfG80AlN+XgY/EDiLR2gCvX/WBkXzVDyY/PTZn0ZYNe7bauJOBbRv2fNJqw6v2N9nJbN3+LO/uert3d/18cwf/QDMA5d7VHu4CQsEO2fQkIPS9vkwNTnJl5S35u+m244mhMIN1cYOeb1qDnkda6w8Ysxhuu8Cn7xY2gDecEoBy6g9rgcCvYweSgVuBFwN9wDGxg5GG24Mc2ciG381OAKxvwXOhlmOSlKtHcObg9dk+fdL1zX4xLQGUy8piyn9fDf4N9TCMtIUNj406HiPlZ+ct2gHYhjy9xs6/9zmb/Sxu4e7fGhKRNMsKnMtw3siKxc/0ns7TWzH4B5oBKM90f2ho8xlVs2uqK4FrgHcVpyqeGTsg2QxtK3bM+B6mjdrQycUG4E0vkNRhUxobljTQ3JEKpm3DvT5l9wdXfamTVlICENdtwIXF477YwVTEE8VF9Ssw0jUulJB9TXI15IX8T3hY9+YkAHQuPBzX3peS+SPOpRi93t3529jBKAFovuXF2fQwDT0w0pcZbgJ+qkE/qr8Wa6zhMR54BRB2lO9VrCvvVHw91ynm9Fl7HQ/1sbK1t81cuJ9Pm3jLJv2/6/WpmvwvhaWYfRuvz2Kw62o/a6SoWynkkADsDdwROwhJflbg+8UjNb8H9qGKVq54lPYcLmEbGMRh1AmAzX5ga2r2ZnyzT4rJprsFYwbDyy/26XuGm8DSyfzTIyLZam//c1EiO9uNABgn2oxbPuSn7Rc2CG+8+tK34BZmsKSVzOaN3Oljs727M8z4lpoSABFJknd3/tX6Bu7NvMHNzozZ8Sjgik3Y/S+t8SjYd/DhWXRPuroRBXpaRQmAiKTL7Hbcc04AgmmjSQBs9oKJUDusuSFV3vBIdT5nFsYV3t0R9hQlRwmAiKTL/QbgH8iZcbTNuHsnP22PsOSxYfW2KeD5LouU4egezNyU5jtlowRARBJWvzrnLQCFsYwb9zbgfzfqT7uHjYPSOA8CFxWDfvSje42U/SdHRPLl3ZNuqkTxrI0c1G3W4IHZlkdureWYfRf8eFYsnuDdnf+Y2+AfaAZARNLm/g3M/pm87W+zB5/nUzrWf+S5rrv/zXTjyLr+uNo3/KSJj6z6Uhe5UgIgImnz9nOw4Q9nX81xeGRw/+i6ftvmzB0LWx3X2qCycB/Ot2jz83xqV6jOWhlaAhCRpBWtUsMabd7MTrE5tK3z95dseSywY0tjSpXZEyN3+m6vYrBzovd0nlm1wT/QDICIpG9o6F9obw93v1uRK/cJLOk/Arp+vNbft9pUVf5brzr4LzGbxfBfS1udr5WUAIhI8vztkxdZ30BonHMW+dcEeFoCYOf2P5MxHKnOv2t1F2azqQ3P9imT1A58DUoARCQPgwOfoqMz1ATYj2zZm+z8u7Z52t1rm52E63q+hr+AXTlSna8nrep8raQ9ACKSBT/rsCFq9ZNWXfyztRU27q1P+6qNzAxU3TBmP8F8GivG7erdHVO9Z9JPNPivmzJGEcmGT510t80cPAXql+OW5/Vt1WDf+7dfzup/Idi+VFc4nz+TtuGLfMruoWiPbCTNAIhIVnxax1U4JxX12nN0qPUunPS3X9Ureff/MM4M3Pbz7s4Xe3fnFzX4j54SABHJjnd3zcE5GUiyScsGGLX6KSM/OfvadrCQ7FRB+Lf8JtjRbN25i/d0nu49HbfGDipleU6RiUjleU/nN+38BfdRq80BnkVWbIrBJ+nseh3umf3dniQs4f9i5Oiec4l3d+a8v6PllACISLZ8+qTrbfb8fam3n4d7Pl0D3Sczc+FBI6V/8zz5NxAaGzM8NMtP3X1e7GBypQRARLJWrA0fYzMH34L7fwOd5MD9TIxjyMfjGJdSZyY9nddp937zKQEQkUrwaR3fsln991C335EFz6juv9/Aii1e66c9e2nsSKpEmwBFpDKKeu/ZtXVNn52rwb/1lACISLWEJjBSJkuoL/9W7CCqSAmAiFRL+/CFwMrYYchq9m015olDCYCIVG9ToNkPY8chhVCvX6JQAiAi1eN1DTrlcB/jJ10TO4iqUgIgItWz9bIrgMWxw6g8Y5Yfl23J5tJTAiAilePH7b0CCBUCJSZtyIxKCYCIVFPNNPjE9Wvv7rwzdhBVpgRARCrJp3b8EtAAFI3NjB1B1SkBEJHqMrsgdggVtYIVyy+JHUTVKQEQkepauTLchWoTWut910/b48+xg6i6WgZv/rGxAxCJaAvSNhTzxf3tkxcBP4sZQyWZa/q/JAlA2A2bsm1iByASUerv/+WxA9BO9JZbzFbLfhA7CMkjARgfOwCRiJQAbK72LS/F7InYYVTIBcUxTClBAhD/A1jtC6DIJnH30M57S9IW/frjU565hLp/O3YcleE6flkWOcwAKAGQSjKzHGa/ynH9qdU0KLXGH7yn49bYQcjfE4DUezBvGzsAkUhSf++7u/+VMhiYGOrRL4wdRv60+a9sCUDq9bA7YwcgEkkXafuLmUU9BbCan0UdXDUBmqvO0PDFsYOQvBKAPWMHIBJJ6u/9kl17vG/kTIA0y4+KY5dSEkoARNKV+nu/VIVgvHvSPaE+few4Mqbp/xImAKX6EG6CjgyKoYhUMQEo382Ha5BqksdYMe47sYOQ/BKA8Hd4buwgRCLYg7SV79ozrvaNMhxNzI7ZJX7as1PfcJ6dWiY7X18YOwCRCMdfJ5G20l17/KSJj2B2Zew4sjM8rJmVkiYAA6TvsNgBiLTYoUAbaeunjLyumgCNNcD0STfEDkLWngA8AjxK2o6IHYBIix1O+sqZAAwOfh/4U+wwMtLnOl1R6nbAqc8ChKlQ1QOQKskh6S3ldcfPOizUJgh7AWTzOdam+golTwDKmYlX74IosjF2BPYlbUPuXt4z4TXVq2+Qn/u03ebHDkLWnwDcQfpeFTsAkRZO/6/+7Kbq7rJUAVwbn9rxG+C22HEkz5RIldnqi0gOb/Rj1RpYKuJE0lf+a44Gr821DPdvxQ5CqpEAbF0kASI52x44mvTdTtmtrF+AeWlnKRJwmXd3/iV2ELKBBMDd7wbK0ZVr80yJHYBIk50QytWQvtInAP72rgeo249jx5EsRzMoKSQAxVpcDvsAXg3sGjsIkSY6hTyUPgEoqIDNpvkj4zt/EjsIWb81NxLdRPpCYZSTYwch0iSh5PWBpO/BcNqeFBhXhLbFscNIjnOBH8dw7DBk4xOAXCo1nQGMjR2ESBN8YGRISl+41iRRGMa7O/8KNid2HMmxus7+JyDHBGCC9gJIhp4FdJOHtK41ZloGGA2zm717UipLPJW2ZgIQijXcTx4+6u7tsYMQaaAPZ9T2OqkEwKdNDPHeFTuOZKiXQjKeWkzkl+RhdzM7PnYQIg2yM3AaeQinjUKRnbQYF8UOIREr8WGVUU40Afgp+fhoBt3SRFav/Yc6Fzm4HlhOaoY8LAPUY4eRgKu8Z/JDsYOQTUsAvkc+ng+8M3YQIptpMvB+8hE67SXHT+0KpxZ+HjuO0lMPhaQTgNAU6B7y8Wng2bGDENkMX8po7T/4Aaly1QTYgId5dGVON5HZq+WSoa/DtsB/xA5CZBO9FTiKfNwLzCVVy5bOweyJ2GGUltlFfsbk9JZ3Kiz3BGB15bTDYgchMkqhsdXnyUvS1xZ/995P4PVQGEjWxoc1/Z9BAnBNZpWvQuGUr6pToCTmM8Bu5OUy0qdlgLVx7vDuSTlUk6XqCUCYwskty90T+HrsIEQ20jHAe8jLn939alI32HV1sZQhazIlRrkkAME3ybOLWk/sIEQ2YCLQl0nJ3zV928xWkjg/a+QooGoCPFkdH9b3JJcEwN1DF6fF5OccYN/YQYisjbuPAUIRlR3IzyXkolY/P3YIJXO19+yuWZFcEoAiU89hve6pwnGqi4rTASKlYmZfyKTb31M9AFxLJnzqpLsz6Z7aGOqVkN0SQNBLnvYu9jjkdLZa0veRDNf9V5sNmbWGddeO9yAci1yyJLc9Y5WxvgTgF8AfyNNhxVSrSgVLGZxc7PrPVX5T5vUxYSZRZ97dLxk5HinZJQDBueTrWOB/YwchlXd0ppv+VrsOuIPM+KkTHsazKp2+aRzNhGScAMwqunfl6nTgU7GDkMp6RbE5LufW1fneRFjlB79BFnaqP0LGCcDDwKXk7Z+B/9mI74VIo2egfghsRb4WZ339WLH4KqC6ne+cmcWxSEnUxgx6/zXyT523sPnqW9oYKC0yrRgYtyRv4djtMjLlp+23EizsJaomd539r0ACcFtRHjh3byzaIeuIoDR7t39v5tP+FBvkQgKQt8oegfMbfHrXXbGjkM2zsdPen6MaDgeuL0oHizTSVsXA/9mMN/w99ejfn8icT5t4C3A7VWNW9f0PlUoAvp/xkcCnegFwc9FFUKQR9gJuBLqpBs+wk+G6GRdQLX/FM6rsWGG1UXygcz6n/FTjizuYczPfpCXNF/pP3FIkllXx7RyP/q3TcNsF2RU6Wr8rvLszp46xlTWane9hs8tcquVU4NfAy2MHIsnZBbiwKIJTpSQy7Ao/iwrx6bv9EQj9U6qhVtV9D9VOAEKG+wmqZ5+iKmJY89o5djCSxGdqarFkdhLV840KLReuoTJr4g/Q3//j2EFIY4z27Hs4uvRbqids2poChF2vZ6pmgKzDS4pkMdwh7UT1hJuET1JFW7eF5mn5T4u7X+BnHTYUOwxpjNEOZGEvwMepru2BLwK/At5Qkd3csnENpmYXHeIOoLrCXfCdVJAfN2EZeKglkre2ylc/zMqm3MleCfyIantp0VEw1EiY6u65n+mWtXthMejdVpwaqfLMUGgI8y9UWe6lgZ3f+NSu8F6XTGzqBetDFdv1ui7PD9O9ZhbWPE8DnhE7IGm60EHydcB3i+WwsDSkrpLwaSBshquuaV2hLv58cpV7glNBm5oAhMIXMxocS8r2AL5WFD4JMyTHufuY2EFJwzeDfqK4wP+g6OKnJaBVFgBfoOJ81RJpnjUBzMO6f3XLHmfK3De5zH/Y5HR3sS4uT/cgMKdYLrmuEhuEMhKWdcxsf+CIkNAV0/2ydm8pzv5XnvUNdBYJUW7J4ZXe3Rn2PUlGNicBCN6hmYCNEpZLbi16KlxT/DwkCFIeWxeb+V5ZlIQ+tCgIJesXOuL9Q+wgysT6Bq4rWj3nw/047+nKt7NjRW1uAhCy3J8ChzUupMp4pJhBubM4XjhQtE8Nm6mWAI8Xswa5d2JshfFrPLYrGj7tWpTo3aN4TIwdZIIeL/bBLIwdSJlYb//bMfs6+XiEx4ee7WdMDg2eJCObmwAEzwV+V4HWpiLyZO8DvhI7iLKxC+dty8r2+7OpAGn8n0/rfHfsMKTxGnFs6Z7KFv8Qqa5fV6Ld7ybwkyc/ho0cE86Da/d/rhpybtnd/6sojiMi+VtadDbUUeD8B8176O7UtT1TDUkAzGyoqHse1gRFJG8fqFS3v00x2PkjzBaRPOsrjjdKhhpZuSwcfXl/A59PRMrnezr5s2F+FnWci0lbnbbhPOsayIhGly4NrU+/2eDnFJFyeACYrpMpG8mtj6T5NT5lkk54ZKwZtcvfVcwGiEg+wjLfiUUSIBvBeybOLWp+pEmlf7NXa9L59jcVG4VEJA8fLYpYyWjYSGvoFC1hyTJVd8xcs7qX3VZUCRSR9F0OfC52EEmyMRcCK0jPpf7uvUNRskqysLf9ooXb24xbsu7p0ohCQOvzZeCMZr6AiDRVqFIZeiI8FjuQVFlf/6VgoV9COpzDvKfzZ2TMvjJvHNu0Hwi8HNizqAw6qagYumYRp5DAPYEziHE3zl2Y38wKv85Pm/QoCWtqAhA64pnZ94FXNe1FRKRZQmnqA4tiX7KJbFb//tQtpbP0N3l3Z0j6smOz7tsRHzoBr78J7KDNrGC7qseL8V3qtQu8Z2Jye9+aPQNAUXc99MlWNzWRdIS7niO17t8YNnPw57gfQgrM3urTOr5FRmxm/6HU7f3YSBvvsU14CcfsBup+DuM7L/Hj0iiS1YoEgKLxyo3AhFa8mIhslnBRmJptb/sIrK//GLDvUH73sHXn81IZwDbEZva/Fmr/2uLk6x6wz7J1x8yyfx9blQAE+wE/K9quiki5d/x/NnYQubG+gcuAN1JejvN67+n8IYmzWYt2pT78GfApEcP4HW7v9p6OX1CxUwBrcwtwLPDXFr6miIx+464G/2Zot3cXx6TLakbqg//I7v3egX+kPnR35ME/2Bfzn1vfwP/ZnEVbVn0GYLXXwUinrHGtfmERWa9e4FRV+mse6x2YhlHGCoGDjBl64Ugnw0TZjAXbMa7tXNzfStk4d1AfPt5P3f33VDwBCN5clAxuj/HiIvI0lwInqMNf81lv/39j9kHKIxxlO8y7O39LoqxvIBzhCyfOOikrs1BX4QSf1nEVFVwCWFOoMPV2XWxESuFb7h7K/Orz2Ao9Xf8PSjMLsAz8mLQH/wUvA64r9eAfuI/H/Qrr7Q9jX6UTgCCUyDwZWBkxBpGqu8jdTyhaeksLjLTXXbH4tOJGKKalmB3n3V3hmHaS7PwFh0AtHFXdmTS0YTbD+gbDfpDKLgGs6ehi+nGL2IGIVMzXgHAhqscOpIrChjX6Bj4MfLrlN2NmixgefpNPn3QzibLz5j+ftrZwsmwH0lPH/ESf1nVJ1ROA4DVAOCKjI4IirfHfQBh8SnEBqDLr7X8rZucVRdNa4Vraht/mU3Z/kETZufMm0N4eqis+h3Qtx3ldzJLLMZcA1vRj4HC1GhVpujDgnw2EdWgN/iXgPV2X0m574cxo8mxMKO38fgY7X5X04H/2te2MGXNx4oN/MA7jm3bB4LOp+AzAamETR9ghuXfsQEQyFGpwdBcncKSErHfwIMz/HXjlqlWChvjLSHIxdujfUz7mt5r1DXwG+Cdy4VzD+M7XxKgaWLYEIHhGsTkmzAiISOPu/kIhrhtiByIbZrMW7EG9Nh2zU3HfaROf5haMGdS2vNCnPHMJGbC+gZcX7+GyzF43hvsZ3tP1P7RYGRMAimYNoSLZ6bEDEcnAb4raGwOxA5FNmO7ebeKLqNUOAT8Et70xQkKw0xozBMswW4z7fTi/wvx62mvX+ykd95MRm0MbTwzchPFi8vNYWAZq9b9ZWROA1U4pdiqv2ZtZRDbeBUUivTR2INLgEwTnLdqesWOW53J3vyHW2/9ezL5CrpxZ3tM5rZUvWfYEIHhRKFQCTIodiEhCwrn+fwH+I3YgIpvLvjJvHNu0L8hg49/61Kn73j696y5aJIV1lFChav+if4CIbNh84GAN/pKNbcacmvngH9SoWejE2TIpzACsKfQoP0f1AkTWaQ4Qqsz9JXYgIo1gZ1OjY2Ae0EXuzIeo1yd5z+73tuLlUpgBWNMs4KXArbEDESmZx4o9M8dr8JesdC48vBKDf+DWDm3hc9wSqSUAwZ3AgcC/AStiByNSAqF2xvOBC2MHItJwXp9CtUxp1QultgTwVPsA5wLhbKhI1TwMhDXDUEFOJDs2Z+5Ylmz157ALgGp5cSs6NKY4A7CmPxSbnd4HPB47GJEW8aKb5h4a/CVrS7d8eQUHf3B/dSteJvUEgKJ2djgbumdxMVRPc8nZrUWZ2O6iup9IvtyqWRHWWvP3ziEBWO3+ouDJAcD1sYMRabAwDfr+4khssv3bRUbHX0E1vWLk9EOT5ZQArHYLcChwEnBP7GBENtMTwL8XhbC+pBkuqRYL+7yqaBsm9O/W7BfJMQFYvUYa2kXuVRyLCmdIRVKytOiH8dyiop/2uEil2IwF2wHPoqraR5a1myrXBGDN/QGhMErIIt8FDMYOSGQjBv5wp787cCbwp9gBiUQxdmSTa3XVm//3zz0BWC3UC/hqMY36BuDG2AGJPMWDwNlAR7HWr4FfKq62I1Vm1vS/f1USgDVnBK4sCgkdXvw8fE0klrlF6d4w8H+i2OwnIu7jqTL3ph9/bKe6ri0ezykqL51emXKTEttfi+QzHFu9utizIiJrMqt2AoA1PQGo2gzA2vyx6JoWNlsdDVwKLIsdlGQnDPK/At5dbGwKm1N/osFfZB284p8Na/7fv8ozAE8Vjld9r3hsCYRKTMcBbwG2ih2cJD3FP6eo069jqSIbq2ZPkHap+s1kocFXUykBWLtlxRRteJwBHFU8XgvsEjs4Kf30fijU8wPgCmB+7IBE0lR/PNwGV/vv31xKADbs0aKmwMXFkslLgCOLGYL9i9kCqa56cZd/bTHoX1Mc5RORzWG1hyo9A+DW9A3BSgBGf7G/uXh8yt3HmNl+wEHAIUVCsGvsIKWpQlb+m6Lc9C+KxyOxgxLJjm1xNywLGUBFpwHsrqa/QuLtgMsonN18IfCC4hGKEHUCz44dmIxKWH8bAMKH8Dbg9uLRr417Iq1hMwfvxX0CVVRv29Wn7xY2qTeNZgAab3ExDRwea9qiOGbYVZz53rlIFtZ8bAuMAdqKnzfCtsXzpTwQDzdoX0dYn6e4Yw938mGK7aHi3yw8FhUDfBj41WlPJLa6345RxQTgYabvFhrcNZUSgNYJg88dxaOV/gDsTboOLNbYRaRqjOuA11M913oLZhpVB0BERMqp5j+lityfOoPcFEoARESknLbsuqWSy3Ft/qNWvIwSABERKSU/Luz/8W9SJWY3+9RJd7fipZQAiIhIidlsKsVb9vdVAiAiIqXl3Z03FpuZq2AZ9aFQdK4llACIiEi5uX+WSrBzvWdyOJrcEkoARESk3MZ3XVyBZlorGa5/rpUvqARARETKvxnQ7Gzydo6f2jXYyhdUAiAiIqXn0zpCS+1c6wI8AHyi1S+qBEBERNLgtdCefQXZsQ94d+dfWv2qSgBERCQJ3jNxLthHyYlziXd3XBTjpZUAiIhIOro7voBzGTkwm8fYoXfEenklACIikoyRJjnjaqfiLW+s1miP4sNv9pMnh46nUSgBEBGRpPhJEx+hrf01QEt3zTfQCrz+Vu+edDsRKQEQEZHk+NQJ92G1o4EHSctKzE7ynkk/iR2IEgAREUmST5v4B7x2YEJFgpZQs2N9Wse3KAElACIikizvmbgAOBQIrYPL7H7q9cN8asf3KQklACIikjTv7vwTjw8djPPlVfsES8a5hnbbz6dPupkSUQIgIiLJ8zMmL/eezjPB3gr8iXJYBnyUhZ2v9lM67qdklACIiEg2vLvj26yo71XMBgxHC8Tsu7TZPt7d+Vk/izolZO7lmy2Rhgp9tPcmXfsAc2MHISLpsd6Fe2PDHwM7AWhr0ctei9snvaej9H0LlADkTwmAiFSanTd/MrW2MzBOBHZuwkssBS7Hauf4tIk3kAglAPlTAiAiEga8GbeMYcz2r6NWezPOEUDHZjzdYvBwt38lvvzbPn3Px0mMEoD8KQEQEVkLm3nv7nj9AIzn4ewJ3oHZDriPB8ZhNoz7YziPYiwCuxOv301b7Rb6O35X1rX9jaUEIH9KAERE5Gl0CkBERKSClACIiIhUkBIAERGRClICICIiUkFKAERERCpICYCIiEgFKQEQERGpICUAIiIiFaQEQEREpIKUAIiIiFSQEgAREZEKUgIgIiJSQUoAREREKkgJgIiISAUpARAREakgJQAiIiIVpARARESkgpQAiIiIVJASABERkQpSAiAiIlJBSgBEREQqqJ1qawO2Jf+/Y8rCv8/25OuvwLLYQYhI9Zi7UwHPAY4ADgb2AvYAdgTGxQ5MBAgfwsXAIHAXcBNwDXBb8XsiIg2XcwIQ7hpPBqYA+8cORmQT3AdcBPQBc2MHIyJ5yTEB2AX4EPBOYJvYwYg0QPiQXgl8qpgdEBHZbDklAGFD4ynA54vpfZHchA/rBUWC+2DsYEQkbbkkABOAi4FDYgci0gIPFUtbP4wdiIikK4djgIcBv9HgLxWyM/A94KzYgYhIulKfAXgD8A1gy9iBiETS5+7vMLOh2IGISFpSTgCOAb6tWgYizAam6cigiFRhCSCc5/+mBn+REWE/wCdjByEiaUlxBmDnYs1/19iBiJRI+CC/Gbg8diAikoYUE4CrgKNiByFSQg8DLwD+GDsQESm/1JYA3qbBX2SddijqYIiIZDUDEHb6zyvq+ovIuh0OXBs7CBEpt5RmAN6hwV9ko3w8dgAiUn6pzACElrYLgImxAxFJxEHAL2MHISLllcoMwGs1+IuMyvTYAYhIudUSOucsIhvvOGCL2EGISHnVEpn+PzJ2ECKJ2a4omCUikmwC8CJg+9hBiCR6GkBEJNkEYP/YAYgk6uWxAxCR8kohAdgrdgAiidozdgAiUl4pJAC7xw5AJFGhX4Y2AopIsgnAM2IHIJIoA7aNHYSIlFMKCcD42AGIJEwJgIgkmwAkUapQpKTqsQMQkXJKIQF4PHYAIgnT50dEkk0AQo9zERm9YeDR2EGISDmlkADcEzsAkUQNAitiByEi5ZRCAnBn7ABEEnVX7ABEpLxSSADU0lRk0/widgAiUl4pJABzgT/GDkIkQVfHDkBEyiuFBCD4buwARBLzJ3e/KXYQIlJeqSQAs2MHIJKYi81sKHYQIlJe5u6plDS9HdgndiAiiRT/eSHwh9iBiEh5pTIDELKUz8YOQiQRl2vwF5FcZgBw93Yzuw14XuxYREpe/Gc/4HexAxGRcktlBoBiPfOd6g0gsl7naPAXkaxmANZwLnBq7CBESlr5b1+V/xWRXBOALYEbi01OIrLKSuAwFf8RkeyWANawDDge+HPsQERK5L0a/EUk9wRgdY3zo4EnYgciUgJnATNiByEiaUk1AQh+DRwBPBQ7EJFIwvrd2cC/xQ5ERNKT4h6ApwrHAi8D9owdiEiLl8JOV5VMEaniDMBqdwAvAy6IHYhICxtkHaDBX0SqngAEjwNTgFcBd8YORqSJd/1hyv8lRWlsEZFKLwE81VjgBOBfgOfGDkakAZYDM4FPAotiByMiecgxAVizdPDripmBcGJgfOyYREZZ0vdXxdLWN4GHYwckInnJNgFYk7uPMbP9gUOAvYA9gJ2LpGCL2PEJVe/cFyr3/QVYANwN3AT8DHgkdnAikq9KJAAiIiLCk/x/WMjWlZb09GcAAAAASUVORK5CYII=",person:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAQAElEQVR4AeydB5wdVfXHz7z3tiYESCB0kg29iLTQkSYQqYIGVEqyCYICCigCIipFpChVUfkTdpciKlIExIAtgBQREJQidXcTEMGCJWXb2zf/33mbhM1m3+4rM/Nu+e3n3p15M3fuPed7bjn3zrx5KeEfCZCA3QTaFmwkbfP3k5s6j5CWjhnS2v45aWv/CvYvk9aO7yP+EPFexIekreOP0tr5Ovb/jti9NGIfx/LnOh7CMU2r13w/n4fmpXlq3lqGlqVl2k2N0pOA9wToAHhfBQjACgK3vb0GBvndMYA3Y4C+VNo678L2RWz7JOx/XcLcryUX3iWBtIkE10oYfAP7Z4nIZxA/hXgo4l4SynYi4UbYXxOxbmnEPo7lz8leOKZp9ZrPSCBniealeWreWoaWpWW2dfYtlUFlgUwdzdI2f3dRWZEJAwmQgMkEROgAmG0fSucbgdaOydLW+TEM9F/G4NqG/cex/Zf09PwDg/yjEkoLkJwtYXgEtltim8G2OiEMtWyVQWWBTJAtzD2al7W1419LZYcOHV/G/sdkTvuk6gjKUkmABIYjQAdgOCo8RgJJEdABv7VjJgb5VsQOFNuBQf0ODPTfxP4M7O+K7XhE28L4pbJDB/km9u+QdNAJR+A13Fa4HvFoufWt9W1TivKSgCsEVA86AEqBkQSSIrB8wG+fg1n+SyhWB/1WbGciTkZ0O4ThxritcCLij6Wv7004PX9CvEpa26fTIXDb9NTOPAJ0AMyzCSVyiUDLXzeQ1o5PSEv7d6S18xmotnTAD2Zjlr8FPvsetgGA00WC25c6BE9IS8eVQodA+EcC8REYyJkOwAAH/ieB6Ah8//WJ0tY5GwPZPRL0LkDGP5IgOFUk3B77DCMT2EUCOUOWOQQtHffkWSpT4R8JkECUBOgAREmTeflLYF6YwQz/SGntaJP69Mu45z1HAjnMXyARaa4Mw3BOnqmybe08UpR1RNkzGxLwkcAynekALCPBLQmUQ+DGzn0w6F8lnfNfxgz/TmQxA3F1RIZoCShTsA3vzLNu7bhKlH20ZTA3EvCKAB0Ar8xNZSMh0NqxLWb7X5W2zqckFf4WeZ4uA9+txy5D/ARCfY/B6Xn2aoPWzq/CCds2/nJZAgm4QOB9HegAvM+CeyRQmMD5YUra5p+IgeaXSPQsBvwLJQx3xD5DNQnkbRBeCBGezdtGbaS2wgEGEiCBkQnQARiZD8/6TuDa1+qkrf0UmdT5jIS564Fjf0QGMwnsn7eR2kptprYzU05KRQJVIzC4YDoAg2lwnwSWEbj5nTGYUZ4m42qeljD4Lg5ziRkQLAnb5m2mtmvtOE3UlpYITjFJIEkCdACSpM2yzCdw+xurSkv7mdLfpd/Zv1rCcGvzhaaEwxIYsN3VeVuqTdW2wybkQRLwhcCKetIBWJEHP/lK4PpX1sCM/xxZnH5GguBbwLAZIoMbBDbL21Rt29pxjqit3dCLWpBARQRSFV3Ni0nAdgKtHWtLS+d5Ulv7NFS5RPg0PzC4GvLfHrgkb2u1udreVVWpFwkMQ2DoIToAQ4nwsz8E2jrPhLKY8YcXYctfqgMET8IkCfI2f0YG6oAnalNNEliRAB2AFXnwkw8EWjumYbn/Idzf16X+dX1QmToOS2DdfB1o7XgI9WHasCl4kAScIbCyInQAVmbCI64SuOG19THj+w7Um4u4FyIDCSgBrQtz83VD64geYSQBDwjQAfDAyFQRBFo6TpJM5neY8Z2KTwwksDKBMDw1X0e0rqx8lkdIwGoCwwlPB2A4KjzmDoG213fH8u69EsgPoNRkRAYSGInA5Hxdae24V7TujJSS50jAcgJ0ACw3IMUvQODWf42Tto5vSpj+HVIcishAAqUQODRfd7QOaV0q5UqmJQHjCAwvEB2A4bnwqM0EWjs/JX3/fVRC+TLUCBAZSKAcAkG+Dmld0jpVTg68hgQMJkAHwGDjULQSCVz/diNm/d8TCX8oEnxA+EcCkRDQuoQ61dbxPdE6FkmezIQEkiNQqCQ6AIXI8LhdBFo6dpa63gcxY/usXYJTWmsIhPLZfB3TumaN0BSUBAoToANQmA3P2ELgps4TJBAM/uEetohMOS0lEKKOaV3TOmepChTbNwKF9aUDUJgNz5hO4PYXaqW1/VrJhTdA1FURGUggCQKr5uuc1j2tg0mUyDJIIAYCdABigMosEyDQ9voOsnjMgyLB54R/JFAVAqh7Wge1LlalfBZKAqMTGCkFHYCR6PCcmQRaO2ZKmMbgL3sL/0igugT2ztdFrZPVlYOlk0DJBOgAlIyMF1SNQBgGWPK/AuW3Ik5AZCABEwhoXWzN102toyZIRBlIIE9g5H90AEbmw7OmEJjz+tbS1olZf/AFU0SiHCSwIgHUTa2jNy/YesXj/EQCZhKgA2CmXSjVYAI3de4q6fRdOLQ/IgMJmExgf8n13ystb3zYZCEpmx8ERtOSDsBohHi+ugRaOg6UXO4BCLEJIgMJmE8glCYJUvdixeoY84WlhD4ToAPgs/VN1721fboEgsE/GGe6qJSPBIYQaJAwvFVubP/ikOP8SAIJERi9GDoAozNiimoQaGufLRLcLvwjAZsJpIJvS2vn5TarQNndJUAHwF3b2qtZyxtnSBjMsVcBSk4CgwmEX5K2jpsGH+E+CcRNoJj86QAUQ4lpkiPQ1vkd3D+9MrkCWRIJJEAglOOltePBBEpiESRQNAE6AEWjYsLYCbR2zMV901NjL4cFkEB1CBwAJ+C56hTNUv0iUJy2dACK48RUcRNo63wNRUxDZCABlwl8UFo63nFZQepmDwE6APbYyl1JWztCzPw3dldBakYCgwgEshZWAsJBR7hLApESKDYzOgDFkmK6eAi0dv4znoyZKwkYTqCl/U3DJaR4jhOgA+C4gY1Wr7XjVZFQ36NutJgUjgRiIRAE60tbx+Ox5M1MPSZQvOp0AIpnxZRREmjteALZbYLIQAL+EghlV2nt5Psu/K0BVdWcDkBV8XtaeGvH/dB8F0QGEiABCadLSwe/+sqaEAmBUjKhA1AKLaatnEBr583I5CBEBhIggWUEAjlD2jq/suwjtySQBAE6AElQZhkDBFo7rsY9/+MGPvA/CZDACgTC8Bu4HcCfu14BCj+URqC01HQASuPF1OUSaG3/Ki49DZGBBEigIIHwCtwO+GzB0zxBAhESoAMQIUxmVYDAje2niAQXCv9IgARGJxDI96S1Y+boCZmCBFYkUOonOgClEmP60gi0dnxCUsF3S7uIqWMksBB5/xXxJcTfL426r8f0HA4xGECgFSsBRxsgB0VwmAAdAIeNW3XVbl6wNWS4CpEhfgIYvINnUMyPJZALJQyPk1xqT8mGH5T+cDKOry7zJ6eluWkc4vqIWyHuujTqvh4bJ5pGZPX8NXqt5qF5aZ4iPxbJl4GyhH9xEwjkahloQ8I/EhidQOkp6ACUzoxXFEsg2385kq6NyBApgfB5ZHeNBMEJEoR7YX8dadaBffKO2H5SZjZ9XWZNuVVmT3pUPj3lz3LClPk4/h85P8jJaH+aprnpP/lr9FrNQ/PSPJubPinN+TLGIZt18mWrDCJXi8gfERmiJbC2DLShaHNlbiSwlAAdgKUguImYQGv7xRLIRyLO1c/sguBpkeA6CVJHS5idKM1TtpHmptNl5uQbZeaUR7Cf/I/LNDe9ky9bZWhuOgMy7CD9mQmSSh0qIpci8g13gFBx0DakbanijJiB6wTK0Y8OQDnUeM3IBG6a/3GR4FzhX5kEAtyPDzHghxjw+zfEQD9VmiefKjMn3S6zNvlHmZnGf9kJG7wnMyb9XJqbvoy4u2SCdXErYroIdBHVKX4R3CwhOFfybcpN7ahV9QjQAageezdLbluwkeRyuvTvpn5xahUEd2NZfYbkxmyBWf6pmGFjwN/4zTiLjDXv4yb/Dbci7sjrojoF4QxRHWMt1NHMtU1p23JUPapVKYHyrqcDUB43XlWIQJi/799U6DSPDyEQyB8kFF0t2QIz/SMx6N8ss9d07yE71WnmlJvzOopskddZdR+Cgx8LEmiSgbZVMAFPkECpBOgAlEqM6QsTaOk8DyePRGQYmUAPTl+Pe/oflplNO8uspkuwZP4yjvkRmptezuusugepD0Pp6xGVCTYMIxA4Ugba2AhJeMpHAuXqTAegXHK8bkUCbZ0HY/n6ohUP8tMQArh/H3xL0sF2GPA/g3v6vxly3r+PMyf9Js9CmQjYiICRfxiK1jgILxJta0VfwIQkUJgAHYDCbHimWAI3vbKehOHlxSb3MF07+HxVstntpXnyWXL85L94yGBklZWJslFGYaivjW4f+QKPz2pb0zbnMQKqPphA+fup8i/llSSwlECu5jLsbYnIsCKB5ySQ06Qmu53MmvIN+fQmbwn/RiagjJSVMlN2Is8J/4YS2FIG2tzQ4/xMAiURoANQEi4mXolAa/vnRIJjhH+DCfwbH86R5qbtcI//Wjl2k//hM0MpBJTZzKZr8wxFzsGlyhQbhgECaHP5tjfwif/9JVCJ5nQAKqHn+7U3dzaJpM72HcMK+odys4SpPTBw6arICqf4oUwCzU2X5Zkq2zKzcPMytL18G3RTO2oVPwE6APEzdreEbIiZWbieuwqWoFkYPo37/NNlVtMMmTXppRKuZNJiCChTZRuG08H56WIucT8N2l6+DbqvKTUsRKCy43QAKuPn79U3th+G+9sn+gtgqeahLJFQvi6L+vfAff47lh7lJi4Cs6bckWetzJV9XOXYkm8gJ4q2RVvkpZxGEaADYJQ5LBHm/DAlKSw/WiJufGKGv5FcgIG/6UL5/Cb8Hnt8oFfMWVnPAnNlL7DBimf9+6RtUdukf5p7r3GlAOgAVErQx+snzdel/918VH25zoFcK/PnT5MTJj+7/Bh3kiWg7NUGaotkSzastHA3ybdJw8SiOMYToANgvIkME/DG9g+K5OAAGCZXYuIEiyWUz8jMptPk/H2yiRXLgoYnoDZQW6hNBLYZPpUHR9Em823TA1Wp4lIClW/oAFTO0K8c0sHZIsEq4uffU5IKpsmsJn11rZ8ETNVabaK2EXnKVBHjlQttMt824y2FubtFgA6AW/aMV5u2zmMw+/1kvIUYm3ub9C+ZJjMmPWqshL4LprZRG4m0iY9/oXxStI36qLuHOkehMh2AKCj6kEdrx2qSwzKjD7qupGPwFWluapYTtnpvpVM8YBYBtZHaSr8lYJZkyUijbVTbajKlsRTLCdABsNyACYp/tgTB1gmWZ0ZRYfhpaZ78TTOEoRRFE5jVdCHS+vesykAbPRu6MzhNIBrl6ABEw9HtXFo7toWC/nWmufBwmTVlDnRnsJGAvkFQ5HTx7+8cGWiz/mlOjUsiQAegJFyeJg6l2TvN07KLzJ5yr3d6u6Zwc9M1IuFRrqk1qj4+ttlRobiTICpN6ABERdLVfNoWbCRB6JcDkA6myPFNT7pqUu/0ap7yUwlS4tsAsQAAEABJREFUO3qlt7ZZbbteKU1lSyVAB6BUYr6lz2Ux+AereKN2umGsHD+5wxt9fVF05qRnpDY13hd1Rb+qm2+7wj/nCESnEB2A6Fi6l9PNr0+UIIAD4J5qw2qkA8Txay8e9hwP2k/gmEn/FnXw7NekOA207WobLi41U3lIgA6Ah0YvWuX+tA7+6xad3uaEukSsA4TNOlD20Qmog6e3eEZP6UKKdWWgDbugC3VYSiDKDR2AKGm6lNeVbzZAnZmIHoTwKNElYg80pYogoLd49CFP7HoQZspAW/ZAVapYKgE6AKUS8yX96r06+9/cA3VPF31IzANFqeIgAvqQp37Nc9AhR3c3l4G27Kh6vqkVrb50AKLl6VBuKR9m/+dI/mtiDpmNqhRPQL/mqS96Kv4KS1N60ZYttU11xU5Vt3iWbiSBm+YfC7mmIrob9FWxAy+KcVdHajY6gfyLnoKvjJ7Q6hRTZaBNW60EhReJmgEdgKiJupBfLqfL/y5oUkCH8Icy8KrYAud52CsC+Vc9o064rLTzbdpl48WnGx2A+NjamXNLx+EQfF9EV8OLksuc5apy1KtMAgN14sUyr7bhsn1loG3bICtlHJZA9AfpAETP1O4cA/mE3QqMJn1wlsze8O3RUvG8ZwTydQJ1w2W1nW/bLhsvHt3oAMTD1c5c57RPkkB0BcBO+UeVGvd6myf/YtRkTOAngXzdQB1xVXtt29rGXdXPcb3iUI8OQBxUbc0zExwuoej3/23VoLDcYXiH5O/1Fk7CMySQryNaV1xEoW1b27iLulGnsgjQASgLm6MXheLm7D8MX5f+FO/7O1ptI1dL64rWmcgzNiBDV9u4AWjjFSGe3OkAxMPVvlxb39Cv/bn58F+Iwf/T/IEf+ypllSTWuqJ1pkrFx1zsvjLQ1mMuhtnbQIAOgA1WSkLGEMv/SZSTdBlBMEdmT7476WJZnuUEtM5o3bFcjWHFd7WtD6usGwfj0oIOQFxkbcs3lXJx+f9dCfsvt80UlNcQAgN1511DpIlODDfbenR8PMqJDoBHxi6oatsbB0sYbl3wvLUncpdL80avWSs+Ba8ugXzdQR2qrhTRl65tXdt89Dkzx1gIxJcpHYD42NqTc5h2b/YfyDwM/lfaYwRKaiSB5o2uFK1LRgpXgVAutvkKcPh6KR0AXy2/TO85L44XCd1zAELh0v8yG3NbGQEn6xLafL7tV4aGV8dPIM4S6ADESdeGvFONOvhPtEHUomUMguukuemBotMzIQmMREDrktapkdLYd26iDLR9+ySnxJERoAMQGUpLM9K3g1kq+vBiB29LwAf/hmfDo2UTGKhT75R9vYkXOtf2TYRcqUzxXk8HIF6+Zud+61vrQ0BdAcDGkZDrv0FmbLTAEW2ohikEtE4FqVZTxIlIjsOl5a8bCP+8JUAHwFvTQ/G+3l3x36GA2X9t+nqHFKIqJhEIsm0QZwmiOyHo3d0dZdzTJG6N6ADETdjk/MPALQdAZ//HTf6bycgpm8UEZmz0qkjg1ipAGNIBEH//6AD4a3uRQBxyADj7F/7FTyDXr6sA8ZeTVAlBarekimI5pRKIPz0dgPgZm1nCwP3/XcwUrgypOPsvAxovKZnA7I2eFgluEWf+wu2ltWOyM+pQkZII0AEoCZdDiZ26/8/Zv0M103xVUuLWbQCRvYV/xhFIQiA6AElQNrKMwJ2lP87+jaxhzgo1Y/I8EbkH0ZEQ7uGIIlSjRAJ0AEoE5lByV376t1/SNQ4tyTpUw1xWJQhvc0a9wKHJgDNGSUYROgDJcDarlIH7/9uYJVTZ0twnMzd8o+yreSEJlEOgselOXPYqov0hlC34HID9ZixHAzoA5VCz/ZrePoe++hPcZ7s5KL+FBI4K+iVIqRNgofDDisznAIbFUp2DSZVKByAp0maV48ry/78l7KMDYFbd8kea/uxdDim7l0O6UJUiCdABKBKUU8lSgRsOQCj3yaxN/uGUbaiMPQRm61cCxZUfneIKgDE1LzlB6AAkx9qMkua0T5Iw3NgMYSqVIuTsv1KEvL4yAmHoym2AyXwOoLKqYOPVdABstFolMqdlp0ouN+baUObLon46AMYYxFNB6tLqADjyK4HhVE+taJTaSQpDByBJ2iaUlQu3MkGMymXA7P/zm/RUng9zIIEKCBwz6d8igToBYv2fM32D9ZZITAE6AImhNqSgVHpLQySpTIxAHqksA15NAhERCMPfRZRTdbNxpW+oLsUKS0/2cjoAyfI2oTQ3HICa2idMgEkZSEACedIRCm70DY4YIwk16AAkQdmoMpy4BfCUHLv+W0ZhpTD+Emhu6oTyf0K0PDjRN1htg6SFpwOQNPFqltcy3w0PPwgerSZGlk0CKxMI/rDyMQuPuNJHWIi+GiLTAagG9WqVGfS78QBgmOPyf7XqEMstQCB8vMAJuw670kfYRX2ptMlv6AAkz7x6JbrylC/v/1evDrHkQgQeKnTCquOu9BFWQa+esHQAqsc++ZJdeMo3kFd5/z/5qsMSRyGQfw4gaB8llfmnXegjzKc8rITVOEgHoBrUq1em/c8AhLz/X73qw5JHJhC68NVU+/uIkY3Es4MI0AEYBMP9XRee8g2fct9O1NBSAg58HTB04zkh6ypQdQSmA1Ad7smX6srTvWHw5+ThsUQSKIKAK3XTlb6iCJP5noQOgC81wJWne7sW0QHwpc7apqcrddOVvsKi+lMtUekAVIt80uU68XRv8IacsvWipNGxPBIoikC+bqKOFpXY4ERO9BUG8zVINDoABhkjVlGCVEOs+SeReRhy9p8EZ5ZRPgEX6qgLfUX5FqzCldUrkg5A9dgnW3IQOOAA5OgAJFtrWFqpBAKx/5XALvQVpdrN0/R0ALwxfK7RelUzafs7V+uNQAVGJJBy4SFVB/qKEY1k1slqSkMHoJr0Ey3bhVsAfVwBSLTOsLCSCYQu1FEH+oqSDefnBXQAvLF7aPsKQE5mbvKGN+aionYSGKijOTuFXya19X3FMkUs2FZXRDoA1eWfZOm2PwPQkyQslkUCFRCwva7a3ldUYDq/LqUD4I29rffqbe9UvalpVFQsr6vW9xXWVMFqC0oHoNoWSKp8+7/a050UKpZDAhUSsLuu2t9XVGg+fy6nA+CLrUOxfVnP8lmVLxWNeoKA3XXV/r4CJrAhVF9GOgDVt0FCEli/rGd3p5qQlVmMEQQsr6vW9xVGVAIbhKADYIOVopHR7hWAQOxeVo3GhszFBgL211W7+wob6oiImCAmHQATrJCMDHZ/DTAUy2dVyRiZpRhAwP66andfYUAVsEUEOgC2WKpyOe326oOQDkDldYA5JEHA/rpqd1+RhI0rLsOMDOgAmGEHSkECJEACJEACiRKgA5Ao7qoW1lXV0istPAzqKs2C15NAIgTsr6t29xWJGLmyQky5mg6AKZaIXw67G3UgdADiryMsIQoC9tdVu/uKKGzoSR4pT/SkmiJ2N+pQ6mlEErCCgP111e6+wvhKYo6AdADMsUXMkgRLYi4g7uy5AhA3YeYfFQHL66r1fUVUdnQ+HzoAzpt4mYI52716yzvVZXbg1gMCltdV6/sKo6uYScLRATDJGnHKElp+C0B4CyDO6sG8IyVg9+0q+/uKSI3pcmZ0AFy27mDdUtYv61k+qxpsDO47TsDuump/X2Fw9TJLNDoAZtkjPmns9+rt7lTjsyxzNo+A3XXV/r7CvBphqER0AAw1TAxi2f4MQEpa5k+JgQuzJIHoCAzUUdv7Vdv7iujsGXFOpmVne0U1jae58jjh1ec+YC5gSkYCSsCBOupEX6G2YByNAB2A0Qi5ct6J+3ohHQBX6qOzejhQR53oK0ysYObJRAfAPJvEJZEDy3oBHYC4agfzjYiAE3XUgb4iInM6ng0dAMcNvFw9N5b16AAsNyh3DCVgfx11o68wrnqYKBAdABOtEodMYfhGHNkmmmcgW8j58zKJlsnCSKBYAlo3tY4Wm97UdC70FaayNUwuOgCGGSQ2ccLci7HlnWTG6zfZP8NKkhfLSo6AK3XTlb4iOcsXUZKZSegAmGmX6KVKpV6IPtMq5Bg48JR1FbCxyAQIuFI3XekrEjC57UXQAbDdgsXK39zUjaT23wZIp7aFHgwkYB6BVLCdeUKVLNEbMtBXlHwhLyhMwNQzKVMFo1wxEAjF/tsAYbhHDGSYJQlEQWDvKDKpah4u9BFVBWhX4XQA7LJXpdLa7wCITJVbXxtXKQheTwKREmjtWA35ubA65UIfAVOYFMyVhQ6AubaJXrIgcOM5gN7MrtHDYY4kUBEB+2f/qr4rfYTqwjgqAToAoyJyKEHOkW8ChDk6AA5VSzdUCfd0Qg9X+giDjGGyKHQATLZO1LK9Od+N5b10eveo0TA/EqiIQCg7VXS9KRe70keYwtNwOegAGG6gSMU7f58s8nsZ0e6gDwLyOQC7beiS9Hr/PwimOqDSyzLQRzigiikqmC0HHQCz7RODdKELqwD1wucAYqgbzLI8AsFuuK4O0fLgRN9guQ2SFZ8OQLK8q19aGLjgAIjwOYDq1yVKMEAg1+/G8r8rfcOAVYz4b7oQdABMt1DU8gWOvBEwlT4kajTMjwTKIpBKHVnWdaZd5ErfYBpXg+WhA2CwcWIRrb//D7Hkm3im4Q5yY+c+iRfLAklgMIGWjsPx0ZHfp8g9BV0YIiNgfkZ0AMy3UbQSnjBlPjJsR7Q/pISrAPZb0W4NguBjdiuwXPoF0tzUufwTd7wgQAfACzMPVTKYN/SInZ/DQ+X8kHXYTuPZL/Wc9kkioSMOQPCw/QYxSwMbpGHnaYOVopYxEEccANlENuw8NGo8zI8EiiKQzg/+jUWlNT1RmHvEdBEpX/QE6ABEz9T8HFPyuPlCFilhKuBtgCJRMVnUBNJuPPynWIIargAoh8iiHRnRAbDDTtFKefzkDmT4CqL9IcRtAH0Ri/2aUAObCNykD6CGrryRsl2aN3jNJvyUNRoCdACi4WhjLq7cBlhLgvAoGw1AmS0mkAuPtlj6FUUPAndWBFfUrGqfbCmYDoAtlopczpQ7jT6UEyPHwwxJoBCBmzu3wKmZiG6EXOhOX+CGRRLTgg5AYqhNKyj1e9MkKl+eYAdpa6cTUD5AXlkKgX5pRnIHXv0LLfIhxfv/eQ5R/bMnHzoA9tgqWkn1nl8QvBBtplXMjasAVYTvUdE3vLa+SOjO7F/kFZk16SWPLEhVBxGgAzAIhn+7Li39cRXAv/pbBY3TaR3816xCyXEV+URcGfuar0160wGwyVrRy+rQbQDA4SoAIDDERuDW18ZJEOjyf2xFJJ+xS5OA5OnZXiIdANstWIn8udSTlVxu3rVcBTDPJg5JlM3o7H+KQxqJBGk+AChR/tmVFx0Au+wVrbT5e3/hY9FmWuXcuApQZQM4XHwors3+H5OZk1502GJUbRQCdABGAeTB6Xvc0hGrAK0dZ7ulE7WpOoGBOrVt1eWIVgDH2n60cM0tiooAABAASURBVMrJzbZr6ADYZrHI5a35GbLMIboUzpaW+Vu6pBB1qSKBgbrkmlOJNp9v+1UEy6KrTYAOQLUtUO3y9euAobg2E1hdJOdah13tmuJx+fm6hDrlEAJt89r2HVKp+qrYJwEdAPtsFofErjkAIoEcLy3tHxf+kUAlBLQOaV2qJA8zr3WvzZvJ2Wip6AAYbZ6EhBub09sA7yRUWpLFnC3XvubQG9uSRMeyltYdF1eS3pGBNk8jR0jAxqzoANhotahlPmqj/yJL92YEQbCjjM242IHDXAyxE9C6o3Uo9oISL+AeGWjziRfMAs0iQAfALHtUT5pcv3sOwADNs2VO53YDu/xPAkUSGKgzbjqP7rb1Io0bRzI786QDYKfdopd69sZzkemfEd0KgTRKOvctOX9exi3FqE1sBLSuaJ0JUHdiK6RqGf9ZBtp61QRgweYQoANgji0MkCR0dBUg2E8mT77CAMAUwQYC+bqCOmODrCXL6GobLxlEpBfYmhkdAFstF4fcQc5RBwCwQvm8tHSchD0GEihMQOuI1pXCKew+43Ibt9syVZGeDkBVsBta6MyNn5Eg/LWh0lUuVhBcITfN36PyjJiDkwS0bmgdcVI5KKVtW9s4dhmiJGBvXnQA7LVdPJLngjviydiEXMMxkstdKXNeHG+CNJTBIAJaJ7RuCOqIQWJFKorTbTtSUt5kRgfAG1MXqeiibBtSvoToapgq6UY+D+CqdcvVa6BOTC33cguue0kG2rYFotolos3S0gGw2XpxyP75TXpEQnUC4sjdlDxnSkv7eaYIQzmqTKC14xxIMBPR4YA2nW/bDqtI1UomQAegZGQeXNDb1wot30R0NwTBRdLW8Xl3FaRmRRFoaT8W6S5BdDm8KQNt2mUdq6Sb3cXSAbDbfvFIf9Jm//RgFQAqyjXS2uH4zC+eKuJEri0de0kQ3OKELiMqgdl/vk2PmIgnPSRAB8BDoxelcjrVKqHoK4KLSm5xolZpfcPle78WmyZG0VvmT5FAHhLX/7QNa1t2Xc8q6Wd7sXQAbLdgXPIfP7kDHaTeCoirBHPyDYPfYiWg3hyBKEmsBK4PayQI/xBrGaZkHkiraFs2RR7KYRQBOgBGmcMwYVKhOgA5w6SKXpwgGItM30Bk8IFAbeefcf9nggeq5mSgDXugajVUtL9MOgD22zA+DWZM0Y5SnYD4yjAn53WxCvCYOeJQklgItHY8gnw3R/QgwIHPt2EPVKWKZRGgA1AWNo8uCtK+OABq1N3gBDypO4wOEmjrfA1a7YnoR/Cr7SZuUxcKpAPgghXj1GHmpMckkNvjLMKwvHeCE/CC3PzOGMPkojjlEvjh/NVh0wUShhuXm4V112mb1bZrneAUOEkCdACSpG1rWf39rr8YaKhltpJc9/Nyc2fT0BP8bBmBtvk7SF/uZUi9AaI/wb82m7Bt3SiODoAbdoxXi9kbz0UBtyH6E8KwSfrD38vNHTv7o7RjmrZ1Hixh/28llImOaTaaOrfJQJsdLR3Pe06ADoDnFaB49TOXioT/Kz69EyknSn/wG7mx/TAntPFJibY3PoYl/ztFgnHi1Z+2UW2rXimduLKuFEgHwBVLxq1H8wbPSxjACYi7INPyD8dIKrgH95DPNk0yylOAQGvH2RKm7sDZOkS/grZRbat+aU1tyyRAB6BMcF5e1jwZDkDwmJe6i1wqLR0/gSMw2VP9zVe7tWNy3kZqK/OljUFCtM18G40ha2Y5iIA7u3QA3LFl/JoEQYjZMJyA+IsysoRAjpIg+JXo8rKRAnoslNpEbaM28hVDCit02kZ91Z96l0yADkDJyDy/YMakn4PA9Yh+Bv0qmS4vt7Zf7CcAA7VWW6hN1DYGipeQSNfLQNtMqDh/i3FJczoALlkzOV0uxUz4reSKM7Gk4FzcDpiLuK2J0nkhU2vHtuA/VwS2EI//gkDb4qUeE6DqZRKgA1AmOK8va27qlFzuMq8ZDCg/DZuHpbX9S9gyJElggPnDKFJtgI3HQduitkmPESSnulsl0QFwy57JaTNryndR2AOIvodxIsHl0trxS2lr/5DwL14CylhZK3MRsI+3OAtyf0AG2qIFolJE0wjQATDNIjbJEwqXHd+31/4SBg9LW+dFcu1rde8f5l4kBJSpslXGIvtHkqcLmbANJmpF1wqjA+CaRZPUZ1bTwxKG306ySOPLCsPzZJXMw9LyxiHGy2qLgMpSmSpbW2ROQk5te9oGkyiLZThJgA6Ak2ZNUKlM4/kiwWPCv8EEdpYgdR9WA26Qttd3H3yC+yUQUHZtnTfkWYrsXMKVHiRFm8u3PQ9UNUZF9wShA+CeTZPV6Pi1F4uEZ0ogvr0meHTOYXiChOlH8y+nae3gw2qjExtIoaz0pUvKThkOHOX/ZQTybS08U/Jtb9lBbkmgdAJ0AEpnxiuGEmhu+r3kQj4JP5TLss8DL6fRrwzOlbb2o5Yd5nYIAWXT2jEXR+fCoSQngBg25NDWtM0Ne5IH4yLgYr50AFy0ajV0mjXl/yQM9ZsB1SjdljKnSRj8RFo7sSrQfoL8cP7qtggem5zKoAUslImyEeFKyUiwtY1pWxspDc+RQJEE6AAUCYrJiiCwqP9MpNLvZmPDUJhAuLsEwQ3S0/+qtHa0SWv7dLn+7cbC6R07o7qqzqq7MlAWAiaOqRmDOg/LQBuLIWtmOTIBN8/SAXDTrtXR6vOb9Egup07Ae9URwLJSg2ANSDxDJLhdantelZaO63GL4DC5PUyLa3+qU1v7YXkdVVfVWWQGHCFl4Jq2cejzXr5taRuLI3fm6SUBOgBemj1GpWdv9LQEok5AjIU4mfV64HaihME9srjzVdwmuFZa3zhSWjtWs1bbW/81DgP+4XldVCfVLZATRWQ9RIZSCGib0rZVyjVMGxkBVzOiA+CqZaup18ymVgxmV1VTBMvLniISfk4kdSf0+CsG0QcwiJ4rN3Vuh89mh7b5W0lL+6nS0nGXZBf+FfXgZwO6CHQyW3RjpQvkKtE2ZayAFMxWAnQAbLWc6XJ3Tj5TguDXpotpgXyNEsiBGEQvllz4R6wIdMIZmIN4pMx5feOqy68y3NR5BOT6PmR6XcLcCxIE35FAjpAwHFt1+WwXQNuQtiXb9bBafneFpwPgrm2rq9n5QU7SuTMhxLuIDNERmARnYDbinZJOv4aBtx+z7ZexvVda26/A/knS8vq+cutb60dWpOalebZ0nJQvo7XjXpSjZfbnZciFd6Gsz0CmjbBliI7Au/k2pG0pujyZEwksJ0AHYDkK7kRO4Lgpf5JQzog8X2Y4mEBKAtkMBw4VCb6A/R9IkP6N9PW9GbR1Zmtv7ly4yg87/z7hh/MXrP/jBa9uduebz29/71+f3mvuO48f/ODbj2jU/e3veesZPbfB7W++usZtCxboNXqt5qF55fMM5Af5MkQORTlaZkr4Fx+BUE4TbUPxlcCciyDgchI2YJeta4Jus5p+BDHOQGRImEAYhune/nDswt5wzX/15jZ4q6t/k1f+l936j//q3eHhd7p2vf/tnj016v4f3+vbXs+9uTi7yT97+jfQa/RazSNhsVlcnkB4osxq+kl+l/9IICYCdABiAstsBxFobroaM8ZLBh3hLgmQQEECwRelecoNBU/zRIIE3C6KDoDb9jVHu5lN50KYFkQGEiCBwgTOl+bJVxY+zTMkEB0BOgDRsWROoxFobtKH1+4fLRnPk4CfBMIrpbnpAj91N1Nr16WiA+C6hU3Tr3nKIRKGT5smFuUhgSoT+BmW/b9YZRlYvGcE6AB4ZnAj1J01ZaoEssAIWSgECVSdQPg8Zv5HVF0MCjCEgPsf6QC4b2MzNeyp2wKC9SAykIC/BEJZIgv7p/oLgJpXkwAdgGrS97nsk9ZdIv2hfpfcZwrU3XcC9XWThD/wY2Qt8EEoOgA+WNlUHU+YMl+C1I6mike5SCBWAmFqK/nUuv+MtQxmTgIjEKADMAIcnkqAwMxJz0gY7JBASSyCBEwisKvMmvSSSQJRlsEE/NinA+CHnc3WctbkP0o2XFuCIGu2oJSOBComkJMgvbE0N/2+4pyYAQlUSIAOQIUAeXlEBD495V1pTI9Dbi8jMpCAiwTelprs6jJzwzdcVM4lnXzRhQ6AL5a2Qc+jNujCzGgLkZAvC7LBXpSxeAKhPIu6vZ4cu8n/ir+IKUkgXgJ0AOLly9zLIaAvCxK5ppxLeQ0JGEcgCObKrKbtjZOLAhUg4M9hOgD+2NouTZubTpdQLrRLaEpLAisRaJOZkw9a6SgPkIABBOgAGGAEilCAwKymr0sQnlngLA+TgOkELsOyf7PpQlK+FQn49IkOgE/WtlHXmVOuEAlPtFF0yuw1gTMw+J/jNQEqbzwBOgDGm8hvAbPZ7OF9x26w/w/3GC9rNaT9hkHtjSegdfSW3cdL7zHrHdHb23tiGIZjjBeaAg4i4NcuHQC/7G2Ftu+9996q6DxPRnwsl8v9DJ3o9OmTGuT+fSfIfuvUW6EDhfSPgNZNraNHT25Q5T+Ef9f39fX9qaen54Lu7u5N8ZmBBIwiQAfAKHP4LQw6yi0RLx47duyfQOI6xN0Ql4dtVquR+/eZIKdtMXb5Me6QgAkEtE5q3dQ6OkSejYIg+FoqlfoTHNo5cAj2HnKeHw0i4JsodAB8s7iB+qJT/DA6xzZ0lH9CPBciTkIcNqQCkW9tv6rcsOvqMr6O1XdYSDyYGAGtg1oXtU5q3RyhYF26mo3VrHlwcuciHjNCWp4igUQIsAdNBDMLGY4ABv79Ee9Gp/grnJ+BmEEsKsyY0phfDfjQWnVFpWciEoiagNY9nfVrXSwlbzi50xBvhdP7B8SZpVzLtHES8C9vOgD+2bzqGmPQ3w0zoB9i4P8l4kfLFWiHCbV5J+DkTfmcVbkMeV15BLTO6eCvdbC8HPJXTcX/VjgBuiowHfsMJJAoAToAieL2uzB0dNsi/h8G/ccwA/pUFDTq0oFcPXU1+d5Oq8m4WlbnKJgyj8IEtI5pXdM6p3WvcMqSzuyN9nA7nOL7s9ksXxpUErroEvuYE3tMH62esM7d3d2bYNZ/FYr9A+KnESMPJ2wyJr8asNuavCUQOVxmmCegdUtn/VrX8gci/gcn4KBcLnc/2srtXV1dfFgwYr7MbmUCdABWZsIjERFYsmTJepjVXJxKpf6AWf/pyLYGMbaw8xq4JbDvBPkCvyUQG2NfM9Y6pV/x0zoWNwO0lenpdHoeVsv09sDUuMtj/krAz0gHwE+7x6o1OrAAs5gvoBP7PWY1+lT/arEWOCjzMZlALt1+Vfn1h9eQA9fVB68HneQuCZRIQOuQ1iWtU1q3Sry80uT6gKA+KHglnOkNK82M15PAUAJ0AIYS4eeKCOAe5tEY/J+AE3AFBv/1K8qsgov1Ce379pkgV++4qqzXyDcIVoDSy0u1zmjd0TqkdanKEM6oqal5HO3qi2hXrMwxGMPXLFO+Kk69oyWAzmltnl5AAAAQAElEQVQPxDtxD/PHyHlnRCPCyZuNlYcOWFM+vQm/KWCEQSwQQuuK1hmtO6aIi4F/PcRvo409jttqnzRFLsphNwE6AHbbr+rSd3d3T8G9ymvROf0O8ciqCzSMAJPGpOW6nVaTu/eeIPog1zBJeIgE8nVD64jWFa0zhiLZCStrt8ERuAtRXzdsqJg2ieWvrHQA/LV9RZpjsK9DB3Q27vM/jow+h2h8OHi9epl3wBpy0QfHybiawHh5KWAyBLQuaJ3QuqF1JJlSKysF7e8IxIfhfH8XTvhGleXGq30lQAfAV8tXoDeWII/A4P84OqBLEdeqIKvEL9Vh/+ytV5GHDpgonxj40ZbEZWCB5hDQOqB1QeuE1g1zJCtaklNSqdQTcAT0WzZFX8SE7xPweY8OgM/WL1H3hQsXromO5jtYgrwLl26PaG3YerWM3Lz7ePkZbgsctj6/LWCtIcsUXG2uttc6oHWhzGxMuWxNCHIVnPJ70T53xD4DCRRFgA5AUZiYKJvNHlVXVzcPJE5FdCYchNsCd+w1QX6+zwQ5csMGZ/SiIsMTUBurrdXmavvhU9l5FKtxh0Lyh+AInIUtQ1EE/E5EB8Bv+4+qPTqVdTGr+EEul/sJEm+F6GQ4YN16+fGe4+XB/daQoybREXDNyGpTta3aWG3tmn6D9BmDNnsZbtM9sGTJkt0GHecuCaxEgA7ASkh4YBkBdCLHYjbxED6fhOhF2GftOrl1j/Hym/3XkGOaGr3Q2WUl1YZqS7Wp2tZlXQfrhtt0B2YyGV0N+Mrg49xfkYDvn+gA+F4DhtG/q6trMmb9LehEbsHpTRC9C3tOrJPW3VaXhw9YU2ZsREfAtgqgNlPbqQ3VlrbJH5G8NVgN+Aba8m/gyO8VUZ7MxiECdAAcMmYUquisP51O/xZ5NSN6H3Zds1Zu2GV1eXzaRJm9caOsyl8cNLZOqG3URmortZnazlhhkxVsXzgCD6FtfzXZYk0vjfLRAWAdyBNYuHDhRMwUfrB01t+UP8h/ywnsOKFGvr/z6vL8IRPlezutJgevz+cElsOp8o7aQm2itlEbqa2qLJKRxaNtX4iVgAfQzncyUkAKlTgBOgCJIzevwGw2e0Rtba3O+r2511+uFdZuSIv+HOzde42XPx+6lly87TjhTLNcmuVfp8yVvdpAbaE2UduUn6MfV2Il4EBo+ls4Al/A1utA5UXoAHhcC9AZjMFs4IpcLncXZgfOPuEfl4k3H5eRL221Sv45Ab3frPt6LK7yfM9X2SpjZa1R9/WY71zK0F+/KXAFbgnchT6A7b4MgK5cQgfAFUuWqEd3d/eBmAXorJ8zgRLZDZecM9LhqFR+TGf1OrvXWb7O9nXWr6wrz5k5wOk/Aqt/v8UkwMOVP9pfCdABUAqeRQz8F6ZSqQegNu8FAkLUYfA96dv2GC+f23ys7DChNupinM1vlzVr5TQw+9Ge4/nMRcxWxgrARBTxAzgBt3R1dfHZH8DwKdAB8MjamPVvhmW/uWj0fBo4AbvrU+kfn9QgV+ywqjwxbU157aNry427rp5/hmDLVTMJSGBHER9cvWb5gN9x5DryyAFryrfA7GMbNvBbF8mZ8Nh0Ov1L9BEHJ1dk9UpiyQME6AAMcHD+Pxr2YVjym4s4zXllDVVw0pi0HDelMf8tgucOWSvvEMyBQ3A8jjWNTRsqdfRibbJKRk7adKzoDF8H/KcOmrh8wF+vgV1S9MSLznFjrAz+HH0FbwsWjczuhGxtdtuvKOmx5H8mGvY9GPy5xFcUsWQSqUOgg786Aa8cvvZyh+DkTcfI/uvUy4aN9jsFqoPqojq17DZedMB/8bC15DtTVxWd4XPAT6aulVIK+oorcEvgB1gpdPRXskqh4XZaOgAO2xcNWJ/yvwHbbzmspjOqLXMIrp66mty/7wR5/Yi1ZeEn1pVnMEP+8Z4T5IJtVpFjmxplpwm1srpBLyRSWVQmlU1lVFlVZpVddVBdVKdjmxqEA7411fUkTBzmwhH4oDUSU9CSCdABKBmZHReg4W6vDRjSnoDIYCmBunQgH8A98iM3rJcvf2CctOy2ujw6bU15d/o68taRa8u8/deU63deTc7FuVM3Gyu6ovDRDeplv7XrZOqEGtl81RpZtyEtq9QU39Q1rV6j12oempfmqXlrGVqWlqllqwwqi8qksqmMKqvKrLJbip1iDxDYG6uGc3t6eo4a+OjGf2rxPoHie4X3r+Ge4QTQYD8JEeci7onI4CiBiQ3p7t0n1v5r5kaNC87fZpWXrtxx1adwO+Ghn+61xv1z91vj9semTWz98yETv9txxFqX/XP62l9b8sl1znz5sLXOePDDa5x2/a7jTzt3q3Gna9T9ufuOPw3nTu8+dv0vIu1Xcc2luPY7yKPlF/tO+AnyvO/G3cb/FmU8ibJeaN54TMcea9X9HTIsdhQv1QIBrB6uAyfgJ+hTvoqPDI4RoAPgmEHRUM9Hg70NaunXe7BhsJ0AOuFXYdOfYXsJdDkecWpNTc2Y2traBsQ16urqJmG7FeJOiPvg3CHYHo04C/FzOH8O4kWN9fVXbD6h8eoDN1jl2pM2X/Xab+404RqNuv+RSatei3PX1NfUXIm030D8Mq79POJs7H8CeR6GuB8+74L4AcQp+LwWtmMRA8i2Je4dfwxbHSi0/j0LmbshK4MDBGDLC9G33PqPf/xjFbvVofSDCdABGEzD8v3e3t6r0VC/brkavorfB8X/jPgTDKLnYzA9CtsPYJDNYADeDNsjsD0Xg+0tiE/DzkuQ1pgA2f6SyWTuwvYbkO8YxO0hc0Mul9sIuhwCeb8EYVsQf4/4X0QGywjAhsesttpq+i2BTS0TneIWIEAHoAAYmw5joAgw+LdB5tMQGcwn8BxEvAkd6jkYIA9H3BQDpoYP4t8nMIhegMH0p9i+gDT9SGttqK+vb4cu98MZ+DZ0m424K+Jq+LwedPswFPs84vcRH0K0WlfI73xAX/MhOHRzu7q6rPx5YecNVKKCdABKBGZa8v/+97/j+/r6fgW5ZiAymEngDxDrCnSchy1atGg1DIDbIc7EIHgZBsh7EV/Dea8CBv+3of9vwOE7iCcj7oOYwfHdEc/BQHM/gPwPkcE8AlPg1P0StwQ+YZ5olKgUAnQASqFlWFp0klMaGxtfhFj7ITKYQaALYjyEQewyzOwPxiCn98h3xuB2JjrN+8aPH8/lbwAqFMDrccTLsPqhzzGsinRTwfFz2P4ETN/GlsEAAuh7amGPH2Hl8QwDxClSBCYbSoAOwFAilnxGw9sBM/830BDXtkRkJ8VEJ/hP2OAXiOdjoDoQg9fqGOz1QbxzMLP/Bc7zKfkKLA+WT4Pjd7HVBxHXQ1bbIX4W8SZE71ZOoLNp4UqsBFxumlCUpzgCdACK42RUqmw2+3EI9DQiQ/IE/ofB/g4M7F9C3Auz+rUxWz0Y8QIMVL/EsZ7kRfKnRDgCzyH+AHEm4qawxTbQ/tOINyK2IzIkTAB1/kuYkNyScLElF8cLViZAB2BlJkYfgbetM82fGi2km8LpcxanYIa/BQb76dh+G/ERdH58cK2K9oYtnocjMAfxBNhjCzgERyP+CHYx6lsSVUSUVNHHwgn4dVKFsZxoCNABiIZjIrlg8L8UHRu/5pcI7Xwhz4P3RdjbAQPMAYjfw2fehwYQEwNs0wuH4HbET2FlZgvIqN+KmYctQzIE9oMT8EQyRZVaCtMPR4AOwHBUDDyGhnUNOrizDRTNKZHA+B9Q6Abcz9eH0LbBrPJrGPj/iGMMFhGAHRfAbtci7guxd8FnfYnSX7DPEC+BXdBXPRtvEcw9KgJ0AKIiGWM+aFDXI3v9vjQ2DHEQwLLxz5HvCTpzxKBxIu7n69fQcIjBdgKw55Nw5PQlSlvCzh+FPvrOjP9gyxAPgW3RZ70cT9bl5cqrhidAB2B4LsYcRUO6GcKciMgQPQF9o955GBy2xrLxoRgobsRM8V/RF8McTSEAO98DOzfD5ptDps/AIXgAW4boCWyGW5bzo8+WOUZJgA5AlDQjzgsNSB/2Oy7ibH3PTh/aux5L/PtjINB36l+MQV/fpeA7F6/0h83fhf2vh0PwESi+HRyBCxDfwj5DRATAeMO+vr53I8qugmx4aSECdAAKkanycTSc+9CA9Ot+VZbEmeKXgOe16OS3R8f/GSzx84llZ0xbmSKoD8/BETgf2+1RP85Fbm8gMkRAADwnYhWTb3SMgGUcWdABiINqhXmiwfwaDeeQCrPh5QME/g2W+pU9/XGa09DR6w/uDJzhfxIYRAAO4j9QPy5ZtGjRDtj/Ik69hMhQOYFV0Kfpj11VnlMZOfCSwgToABRmU5UzaCi/RMF8tS8gVBLQgb+Dgf/i/v7+HdCp60t7XqkkP17rDwF9XXNNTc2ViDtA61MR+VQ7IFQYMujb6ARUCDHqy+kARE20gvyw7H8PLt8fkaF8AvMx8H8NnY0O/Oc1NDR0lJ8Vr/SZAJzIbtwWuG6pI6BvG9SfMvYZSaW6qxOQ8O2ASkV2+3o6AIbYt6en5ycYuA4zRBwbxXgVHfbZ3d3dOvBfNGbMGL6wx0YrGigz6lUIR0DfNrgrxDse8RFEhvIIrNLHBwPLIxfDVXQAYoBaapaYrbahkzmq1OuYXgRO0wvgcLrO0hAvHzduHL/GByAM8RCAI3AL4l6pVOpolKCvh8aGoRQCaLMTMeFJ5CuCpcjlY1o6AFW2Ogb/70OEGYgMpRHQ+7KfRWesT/XrWxIXlXY5U5NA+QQymcztqHsHYDA7AlFfIlV+Zh5eiQnPhuj7+LKgKtueDkAVDYAGcBWK/wwiQ/EEetB5XIjZ/h7ogH+AfT5YVDw7poyYQF1d3c8QD0W2+owAf54YIEoIm6EPVEe+hEtKScq0oxGgAzAaoZjOYwnsm8j6dESGIglgsL8DSffA4P917PPX3gCDwQwCcEbnYDDbE/XySjMkskYKfW0wf0CoSuaiA1AF8H19fV9GR/HlKhRta5H6fewZGPino6N92lYlKLfbBMaOHfsu6ugX+/v790X75iuGize3/oCQfv25+CuKSMkkoxOgAzA6o0hTYJYwE/cMdfYfab6uZoaO9DJ0qrrcr7+J4Kqa1MshAg0NDfNQZz+Sy+X0HQILHFItTlX2R9+ot0TjLIN5DyFAB2AIkDg/YuZ/IPJvRWQYhQAGfn0Vsi73n4P9f4+SnKdJwDgC9fX112Wz2T1TqdR1xglnpkCnwwmYHY1ozKUYAnQAiqEUQRrc898GM38uC47OUt/DfiJmUIchPjZ6cqYgAXMJNDY2LshkMqdiNeAjcGTnmSupMZLNgdN0kDHSOC4IHYAEDLxw4cI10fj5neHRWV+NQV+X+28YPSlTkIA9BLAa8ADq9r5wBL6IvoC/kDeC6cDo/iVLluw2QpJRTzFBcQToABTHqaJUdXV1OvOfWFEmDl+MlZFfolPcr7a29gxs33FYVarmOQE4Alf29/fvffPmwgAAEABJREFUCQxzEBkKEICz9Gusmm5R4DQPR0SADkBEIAtlg0qs7/ffvtB5349jwP8SHKQD0eB/6zsL6u8HATgBr8HZ/XQqlToSGrcjMgwhgElBA/qGmxcvXrzOkFNFfGSSYgnQASiWVBnpent7r0Ml5vv9h2f3PJb6pmHg//bwp3mUBNwmkMlk7kYbOBCDnU4S3Fa2PO12BKNW8Kkv73JeNRoBOgCjESrzPGb+Z+HSkxEZViZwGwb+AzETenDlUzxCAv4QQBt4HStgH8VE4SJ/tC5eU3A5EBOpkm6XFJ87U9IBiKEOYPA/HBX3shiytj5LePNfxvLnMeDzN+uVoQIkEBEBOMRfQ9vQHwTjj+QMYYq+4hj0qV8dcpgfIyBAByACiIOzQEXdHBX26sHHuJ8n8Bfc8zwYs51L85/4jwRIYAUCaBs/hSNwIPoP/rjQCmREwORC9K3qIMnIfzxbCgE6AKXQGiUtPPgAg5wO/pNHSerVaXC5PZvNHoj7eb/wSnEqSwIlEsBA9wqcgEPRZi4p8VLnk2vfitsBH3Re0QQVpAMQIey+vr5r0HD1bX8R5mp3VujQzsPM5ujGxsY37daE0pNAcgTQZs5FX/JJxL8mV6rZJYGFfiPgamwLPhRotgbmSUcHICKbwDM9BVl9DpFhgMCruVzucMxmLh74yP8kQAKlEIAT8GOk128J6HtEsMsAAntjoqWrrNhlqJQAHYBKCeJ6VMgPY8NKCQgaMOu/EwO/PuV/r35mJAESKI8AnIAXET+CWe/l5eXg5FUndXd3f2FlzXikVAJ0AEolNiQ9GuYGiDr4Z4ac8vIjWJyPwf/jcAI6vQRApUkgBgJwAs5G2zoO7YpvygTfVCp1BZyAg7HLUAEBOgAVwNNLs9msDv5b6b7ncREa5cfRUV3gOQeqTwKxEEDbuhW31fQZo2djKcCyTNHfXN3V1dW0TGxuSydAB6B0ZsuvwNL/F+GV6+s8lx/zdOdNzEwOy2Qyd3qqP9UmgUQIwAn4c39//8dQ2KOIvoeN0+n0hb5DqER/OgBl0uvt7d0Fl7LyiTwPDodi2Z8/dQoQDCQQN4GGhoYOtLdpcLr5Jk2RY9EXnyQSN3U386cDUL5dL8Tsv7H8y+2/Eh3QI+iIDqqtrf2T/dpQAxKwhwDa3mK0vWnog+62R+p4JAUL7Yt5G7YMvHQAyoCGpf+v4bL9Eb0N6HjuxZL/R9D43vIWAhUngSoTwC0BvQV5a5XFqGrx6IsmYhWAv6VQhhXoAJQIDYP/vqhwvj/odhM6Hv29gyUl4mNyEiCBiAlgBe44ZHk9orcBE5Ej0Dfzq4El1gA6ACUAw8Bfh+i7p3kNOpyZJWBjUhIggZgJoE1+BkVcgehhGFAZffOFWAnYaeAT/xdDgA5AMZSWpkHl0of+dlv60bsNGtgF6GhO905xKkwCFhBA2zwTYp6B6GsYg5UA7aN91b9kvekAFIksm80eisp1VpHJXUx2Opb9z3dRMepEAq4QgBOg78qf7oo+xegxOA0mKQf29PR8dfAx7hcmQAegMJvlZ1CpVs3lcj57ljPRsVyzHAh3SIAEjCUAR/0OCLcropcBE7UL+/r69vJS+RKVpgNQBDBUJn3qf9sikjqXJJVKHY7B/ybnFKNCJOAwAbTZ32PVcgOHVVyq2vAbTNq0zx7+JI8uJ0AHYDmK4XfQiPR9014+XQpP+sOZTIY/6DN81eBREjCaQGNj41twBAKjhYxPuH0xcftKfNm7kTMdgBHs+Pbbbzdi6f/rIyRx+dTMmpqa37isIHUjAR8IoB1PcFXPkfTCKsDXlyxZ4u1D2yOxWXaODsAyEsNsJ0yYoMtIU4c55fQhzPzPw8yBy/5OW5nK+UIA7fk9TGQ29UXfQXrWpNNp7cMHHeLuYAJ0AAbTGLSP5aMD0HDOHnTIl90fYMZwsS/KUk8S8IFAfX39a9BTf78EG1fC6HqgDz8QfbnP394aERIdgGHwYOkog+id5wid78bM/7PDIOEhEiABywmgbT+ZSqUOslyNksVHv/a13t7eHUu+0IML6AAMY+RsNquD/+7DnHL2EDzlB+vq6vS94s7qSMVIwHcCmUxmLgZEfXWw9ShKUEBfEKR9egmX+JGUDsAQO2O5aG80EN9eJPEolv2nDUHBjyRAAg4SgKOvPx50moOqFVQJffqhWAXgW0yHEKIDMARILpc7Z8gh1z8+i6XBPV1XkvqRAAm8TwBt/lqs+ln8o2bv61LC3rnd3d0blZDe+aR0AAaZGB7iLDSKAwcdcn33Vc78XTcx9SOB4Qmg7eurvb87/Fknj66ZSqV8/q2ElYxKB2ApEiwRjcWuN5UD+v4V+n4SDs/fsWUgARLwkABWAj4HtW9DtCpUIOwpuM37oQqud+pSOgBLzYnZvw7+Wy/96PrmP/CEj0Pj/6PrilI/EiCBkQlgJUBXPh8YOZVTZ/kswFJz0gEACNwX2gwzYXUA8Mn50JfL5Y5Do5/nvKZUkARIYFQC6Pt6MAGajYRPIVoQKhMRq59H9PT0fLKyXNy4mg4A7IjZsA7+q2PXhzC7vr7+5z4oSh1JgASKIzBmzJi3MTCeAGfgneKusDsV9Dwd+qbt1qJy6b13ALq6uvYFxpMQnQ+o8N/Csv8tzitKBUmABEomUFdX92esDn6p5AsTviCi4nbKZrPe3wrw3gHIZDJeVAJ4vA+ggfOVmBH1HsyGBFwkgD7iVkwULndRt2F0OmPJkiUbDnPcm0NeOwC473UcKvuhrlsbOr7tkWfvujmpHwnESgBOwNnoMwx9KDA61aHjer5MAAtR89YBgPH1/o8Xs38Y/0w06hewZSABEiCBYgiciT5SvypcTFqb05yBiaB3v/i6zGDeOgB9fX0nA8L2iE4HLP1fgsH/R04rSeVIgAQiJYA+40VkeCaiUSEmYXQsiClrs7P10gGAZ7sKzOK80aHn/TU1NedCVwYSIAESKIkAnIAfow+5pKSL7Ew8s6ura287Ra9Mai8dACz5nAJsmyO6HBZAOV88eKjKQAIkEDUBOAHnYhXRkK8NR63d+/llMhnnJ4Tva/v+nncOwKJFi9aG+s4bG577l9B4X4auDCRAAiRQNgEMjjqRmF92BhZciP5yejabPcgCUSMV0TsHAIPiyfBoN4iUomGZoTJ/A3rebphYFIcESMBCAugvX0GfUvX3A8SNrr+/X1eG4y7GqPy9cgC6B34K0unZPxrrPRj8v2pULaMwJEACVhNAn/JT9C0XWa3EKMJDv4N6enqmj5LMqdNeOQCpVOpkeLITnLLgIGWgWwe8WOc99UEqc5cESCAhAjU1NV9DH3NPQsUNKSaZj3ACnJ4gDqXojQMAz+4DUN51455ZX1//GvRkIAESIIHICcAB0OcB2iPP2JwM9+7t7Z1pjjjxSuKNA7DUs6uPF2f1cod+52OZ7q7qScCSSYAEXCeACcbrWElVJyBRVRMuzPWJ4nKcXjgAuPe/GTRuRnQ1PJPJZHx5f7erNqReJGAFAfQ1d0PQOYiuhqlYMT7GVeUG6+WFA5BOp9WYdYMVd2kfy3KXYwWgyyWdqAsJkIC5BHK5nPY57yYjYVVKObYqpSZcqPMOAAbHsYjqACSMNrHibsHSP7/ylxhuFkQCJIBbAa/19/c7u+qICdW0vr4+598O6LwDACPq4D/FxSaLSvofODfONkIXbUadSMAVAnACrkQfNC9ufaqVP/pW51cBnHcAUHmcNaIuw2H2z1/5g5EZSIAEkifg8ioAaB7T3d29KbbOBqcdgGw2ewgstweii+Hx2tray1xUjDqRAAnYQQCrAA+kUqnr4pO2qjnXY4VDV5CrKkSchTvtAMA7dXb2j+UpfQgnF2flYN4kQAIkMBqB3t5evQ2pPz42WlLrzqsDgL52jHWCFymwsw4AKuX2MN7RRXKwLdkcLP07/UYu2wxCeUnAVwKNjY0L9HZkHPobkOdGS58jM0CU6EVw1gEAKieXbuDUvOtwY4PZGEiABGwjgFsB16FvesA2uYuU18mxRHV30gHAks2aqIxOGg23NS5HY+PrfrX2MpIACRhDIJvN6q2ACOUxJqsPQbeDjJEmQkGcdACwZDMdTsBaEXIyIis4NfMw+F9phDAUggRIgAQGEWhoaJiHPsrJ/gmrrk7+SqCTDgDqpJPG0tk/dGMgARIgASMJ9PT06CpAJCuUJikIx2Z6V1fXZJNkikIW5xwAGEnf3qQxCj7G5KFftcHs39V7bMZwpiAkQALlExg7dqy+HlidgPIzMfBKrCiPyWQyzk0snXMA0um0c0aC9/m33oGv2hjYNCgSCZAACbxPoLa2dg4GzJ+/f6ScPfOugU7OjS1OOQAw0JqoNs4ZCfefbtSv2kA3BhIgARKwgcCNNghZooxTXXsY0CkHQB/+g0HVCcDGmfCeOgDOaENFSIAEnCdQV1f3Myj5K8SygqkXoS92aoLplAOASuOUcaCPYFXjxoaGhk7dZyQBEiABWwikUqk5tsharJy4HevUw4DOOACOPvy3WB2AYisn05EACZCAKQQymYz+TPkjpctj7hXoj516GNAZB8DFh//QDG6sr69/BVsGEiABErCRgHOrAHACnFlpdsIBgEEmoGU4YxTooiELvZxrPKoYIwmQgB8Eamtrb4Gmv0csOliQUB8G/IgFco4qohMOQF9f3yHQ1LWH//QHf56HXgwkQAIkYDMB574RkMvldMyx2SZ52Z1wAIIgcMIYeYu8/8+5RvO+atwjARLwhUBNTY32Zc8Wp681qQ7BCm29NdIWENR6B2DJkiUbwhCuOQCtWDp7uoDNeJgESIAErCGACVoIYdUJwMaZsGFvb6/14471DkAmk1EjWO+JDW4WaDCuNZbB6nGfBEjAMwJLVwFeGk1tm86jn9axxyaRV5LVegfAwdn/bWgsj61kKR4gARIgAUsJYLDsRnRtYqO3AfQBdEutImK1A9DT07MFKpUTT2Muq0HQx7VGskw1bkmABDwmsHDhQu3b3iiMwLozE5Y+gG6d4MsEttoBcG32j8H/Tsz+f7vMONySAAmQgCsExo8f/1/02eoEuKKSoM+2+jaA1Q5AKpWyGv7QVtDf3+9U4xiqHz+TAAn4TaB24JcC3xqOgo3H4NAcog+i2yi7ymytA9Db27sjFPgQohMBnuQv6uvr5zqhDJUgARIggWEIoJ/7Bw67NNGpX/ogOtSyL1jrAKAiHWwf7sISw5PUX88qnIBnSIAESMABAui7h+nr7FUMfbe1K9HWOgCAvre9VWYlyd/r6em5Z6WjPEACJEACjhHAbYDn0H8/4IpacGj2WbRo0do26mOlA9DV1TUZsF1yAH62yiqr/B06MZAACZCA8wQwaK6wCmC5wvU1NTVWjkdWOgDpdNpK2IUqeSqVcqkxFFKTx0mABEggTwADpvZ5/8l/cOAfHJq9bFQjZaPQkNlK2JB7uPBiJpO5b7gTPEYCJEACLhLAgPku9FInQESwZ5oQifQAABAASURBVH+wclJqqwNgJezh6jjuhfHe/3BgeIwESMBpAuj7XHIANu/t7d3FNoNZ5wB0dXXp4K/PANjGelh54Qm71AiG1ZEHSYAESGAogbq6Op38/GXocVs/w6HRsckq8a1zAHC/3DrIhWoEBv/f1NbWPlXoPI+TAAmQgMsE0Ac6MwHC2GTdrWnrHABUGOsgF2rA8BidqfyFdORxEiABEihEIAxDXQUodNqq4+jP97bt64BWOQBY/telf1dWABZns1lnKr9VLZXCkgAJGEEAK6BPQpB5iC4E674OaJUD4NjX/37W2Nj4pgu1njqQAAmQQDkEll7jzEqobSvUVjkAqCy7IToRsFzkTKV3wiBUggRIoCoE9J0AGDiXVKXwiAtFv75nxFnGmp1tDoD+AFCsQBLK/HUsfdEBSAg2iyEBEjCRwIBMGPwX5HI5J26HQpeturu7Nx3QzPz/1jgAS5Ys2QA4t0N0IdyDipJ1QRHqQAIkQAIREHBmQoS+facIeCSShTUOQDqddmX2L6ggzlT2RGopCyEBEnCOwGCFlq6Itg8+Zus+xio6ADEYzxUH4CXc83o0Bj7MkgRIgASsJIBJUS8EfwjR+oDbGTvbooQ1KwCoIK48APh7WyoH5SQBEiCBeAgMm+sfhj1q38GdwjAcZ4PYVjgAgFkPmFY9XQl5CwU6AIXI8DgJkIDPBPSdAE7on81mrZiwWuEAAKYu/6ddqBlY/qcD4IIhqQMJkEDZBIa7sLa29jlM9jqGO2fhMToAERrNCpij6YvK3Y5bGc+Plo7nSYAESMBHAugfXVkFsGLMsmIFAA3BieV/VG4+/AdjMpAACfhMYETdnXgOAJO9XUbU0pCTVjgAgOmEAwCbc/kfEBhIgARIoACBxwoct+3wmN7eXuPfW2O8A4DBfxIsvyqiC4EOgAtWpA4kQAJlExjpwtraWl0BeHekNBad28Z0WY13AHp6erY0HWIx8mH5/11U7meLScs0JEACJOArAUz61AmwXn30+VuYroTxDkA6nTYeYpFG/l2R6ZiMBEiABBwlUJRaTxSVyvBEuVzO+Mmr8Q4AvEHjIRZTD6EHHYBiQDENCZCA1wRSqdTDLgDgCkA0VnRlBeDxaHAwFxIgARKwk0AxUtfU1GhfubCYtIan2RgTv1qTZTR+BQDwXFgBWFxbW/s0dGEgARIgARIYhQBmz668D8DoCazRDgC8p3VQT1ZDtDpADy7/W21BCk8CJFA5geJzwP3zR4pPbW7K3t5eoyewRjsA3d3dRsMrodrRASgBFpOSAAn4TcCV5wCgB1cAyq3KrnwDAJWADkC5lYDXkQAJOEGgFCVqamp0BaC/lGsMTWv0JNboFQAY1Gh4kK+ogMpMB6AoUkxEAiRAAssJWN9v4vYvVwCWm7P0HaPhFanOX4pMx2QkQAIk4CiBstRyoe80ehJr+grARmVVG4MuCoLgJYPEoSgkQAIkYAsBFxwA6e7uNnYcM9YBwNKJfn9yA1tq6ghyOlGJR9CPp0iABEhgRALlnHRo8kQHoNQK0Nvbayy0UnTJ5XJ0AEoBxrQkQAIkAAKZTMaJvjOVSk2BOkYGY1cA0um0sdBKsSS8WCcqcSk6My0JkAAJvE+gvD30nW/jyv8iWh2wmm3sZNZYBwAzZ2OhlVIba2pq+AxAKcCYlgRIgATeJ+DCBMrYscxYBwD2NxYaZCs2tMOL7Sk2MdORAAmQgGsEKtTH+gkUxgBjxzJjHQCTl02KrdDQwQXvtVh1mY4ESIAEIiWAwdP6PhQ6GHs721gHwGRoJdRw6ytvCboyKQmQAAkMIVDZR4wD1vehmAiORVyrMhLxXG2sAwB1jV02gWxFhXQ6bf3yVVGKMhEJkAAJxEAgm81a7wAoFuhh5HhmpAOwZMkS/f6/vgdA2Vkbc/wKoLW2o+AkQAKVE6g0h/r6en2OqrvSfKp9PVYA6AAUawQs+xgJq1j5l6Wrqalxwntdpg+3JEACJJA0AQye1vej0MHIMc3IFQAMnKsnXcmiLg8GfxuOjPXfYY2aC/MjARLwhUBkelrvAGAsMHJMM9IBwNL5+MiqTpUySqVSvP9fJfYslgRIwB0CmExZ7wDAGnQAAKGoYKq3VJTwSxM5UmmXasMNCZAACZRGIKrULjxMjfHAyEmtkSsAqDhGekuQq5Tggtdair5MSwIkQAKRE+jv77e+LzV1UmukA2Cqt1RKzXah0paiL9OSAAmQwPsEoturq6uz3gEADSMntUY6AKbCglxFByxbLS46MROSAAmQAAmMRMD2/pS3AEay7uBzpi6XDJZxtH2sYtheYUdTkedJgARIYFgCMRy0vT/lCkCxlQKDp5HeUrHya7ra2tpFumUkARIgARKojADGBNsdgNq///3vYyujEP3VvAUQPdNlOdpeYZfpwS0JkAAJlEAg+qRYFba+Px07dqxxqwCmOgDWrwCgCVhfYaEDAwmQAAmYQMD6/jSdTtMBKLImGQeqSLmXJeuHx2r9+6uXKcMtCZAACRRLII506E+tv6Vq4gvujFsBwL0e638ECA3Aem8VOjCQAAmQgCkErO9TM5lMjSkwl8lhnAMAwYyDBJlKCvBWra+sJSnMxCRAAiSQJxDPP0wMre9TMS4YN7k10QEwDlKpVdqFylqqzkxPAiRAAjESsN4B6O/vN25sM84BWLx4sXGQyqjU1lfWMnTmJSRAAp4TiFF96/vUdDpt3Oq2cQ7AmDFjjINURqW2vrKWoTMvIQESIIFYCLiwqsoVgCKqRk9PD1cAiuDEJCRAAiRgFoH4pEmlUtZPqvgMQBH1w0RIRYi9QhIXvNUVFOIHEiABEqgiAUf6VONWt427BYA6ZhwkyFRqsN5bLVVhpicBEvCbQMzau9CnGre6bZwD4MIKAHSw/qUVMTdmZk8CJEACRRNwYQUgl8vRARjN4hg8jYM0msxDz0MHF7zVoWrxMwmQAAkUIBDvYRccAH4LoLg6wlsAxXFiKhIgARLwgoALDgAMZdzk1rhbAIDUh2h1QGW1/bcMrOZP4UmABJIlEHdpqVRqtbjLSCB/48a2VAJKl1QEBk/rf0QHtwDWKUlpJiYBEiABEihIwIU+tb+/37ixzTgHoKampqtgLbDkBJyYdS0RlWKSAAmQQIUE4r/chT4VqxjGjW3GOQDd+Iu/OsVeAlcAYkfMAkiABHwh4MIKAGzFFQBAGDHU19cb5yWNKPDwJ7kCMDwXHiUBEnCMQBLquLACAB2MG9uMWwFAZTLOS4JMpYba3t7e7Uu9iOlJgARIgARWJoAVgN1WPmrdEePGNhMdAOO8pHKqGSrsfuVcx2tIgARIwB4C8Uva19enfenY+EuKtwQ+A1AEXwycvUhm/Yt0crnch6EHAwmQAAmQQGUE9q/scjOuxi2Af5shyftSmLgCoNK9oP9sjnBk9lu0aNFaNutA2UmABEhgJAJJnMPAuUcS5cRdRk1NjXHjGh2A+Kyerq2tPSK+7JkzCZAACbhNoLe3dyo03B3R9vAGJoXG3d6mAxBjtYLnegpiQ4xFMGsSIAESqBKBRIo9JZFSYi4E44Bxs39V2UgHAJ6SkbAUWCkRemzd09PjRAUuRW+mJQESIIFKCfT19e2DPGYguhCMHNOMdAAymYyRsMqphalU6uSFCxeuWc61vIYESIAETCWQgFwuTZ6MHNOMdAAwc34H8Z8JVLAkimiqra11qSInwYxlkAAJeEwAK6dHYNn8Yw4hoANQijFhfCOBlaLDsrRwZr7e29t74rLP3JIACZCA3QTik37JkiXrIfdrEJ0JdXV1Ro5nRq4AqNUxaP5Wtw7F67u6uiY7pA9VIQESIIHICdTU1LSi/98g8oyrlCF0eaRKRY9arLEOACR/CNGpkMlkHnNKISpDAiTgJYG4lMZK6Xew+uvEi3+WMcrlcr9btm/a1lgHAIPlk4DVg+hMQMVeFxX8cWcUoiIkQAIkEBEB3Pf/EbI6FdGpkEqluAJQqkWxbNKLAdO12wCKYVc4Aa/gdkCTfmAkARIgAbsIRCst+vkNMPg/hz7/E9HmbERu3ZjMcgWgTFO4OlveNJ1OP9XX1zetTC68jARIgASsJ5DNZg9F/AMG/w9ar8zwCjwG3bqGP1X9o8beAlA08Az1NoDuuhgnQL+5WA34LrzfLV1UkDqRAAm4RyAKjbACOgl931W4P34v+sG1o8jTxDygm9GTWKMdgMWLF6sD8J6Jho1QplPgIT6J1YBLlyxZsmGE+TIrEiABEjCKAAbEWvR1Z2FZ/AkIdjqi0yGVShn94LfRDsCECRP+h9oxF9H1MBYN4+yampon4RV/F0tih7muMPUjARKwkUB5MqNf2xYD/3mIT6CvuwxxnfJysucq6Pg6+vQHTZbYaAdAwQGiDw6AqirQVZfCTsGy2D24LfBXNJr/w1LZ3t3d3ZvgXGM+Ef+RAAmQgMEE0FelETfEYL8r4nnox56BuM/i2EXYbo/oRcDKrvFjl/EOQG1trUJ0/TbASg0ClWddHPx0Op2eh2WkV9GQFiO+h8b0POI8xl4y6CUDtoNk68AovJ/B+XfQT2UR52PAfxzRq0EfffbygImcjl3LP5u4Y7wDgIFQB3/jQSZhXDSm1VHO1oh7MwoZCBkIGZjUDnR2vxZs4n1AX/16fX298eOW8Q6A1iTANB6kyslIAiRAAu4SoGbFEsDE1YoxywoHwNfbAMVWNqYjARIgARIwh4ANy/9KywoHAN6U3gb4qQrMSAIkQAIkkDwBllg0gadsWP5XbaxwAFRQxO8j9iIykAAJkAAJkICpBHSsMlW2FeSyxgHAbYA/QXJrwEJWBhIgARJwhADVKJLA7zBWtRaZturJrHEAlFRNTc33sNWXA2HDQAIkQAIkQALmEAjD0KpJqlUOQBAEr9oG2JyqSUlIgARIoDwCvGp0AhifflVXV/ej0VOak8IqB0Cx1dbW6irA33WfkQRIgARIgARMIJDL5aya/Ssz6xwAeFkLuAqgpmMkARIggSQIsIzRCGBMuhez/7tHS2faeescAAWIVYBvY/s8IgMJkAAJkAAJVJUAZv9XVFWAMgu30gHAKsAi6GslcMjNQAIkQALWEKCgoxK4pqGh4ZFRUxmYwEoHQDliFeAmXXbRfUYSIAESIAESqAKBN7PZrLWTUWsdADW0rcsuKjsjCZAACZhPgBKOQuCKxsbGN0dJY+xpqx2Apcsu1xhLl4KRAAmQAAk4SQC3oh/BSrTV44/VDoDWKl1+wa2Adt1nJAESIAESiI4AcypMAA6AtUv/y7Sy3gFYuvxy1jKFuCUBEiABEiCBOAlg0nlRJpO5N84yksjbegdAIdXV1d0Jg1ys+4wkQAIkQAJREGAewxHAzP8+jDlfG+6cbceccAAUOgxyHgxzv+4zkgAJkAAJkEDUBDDRfAszf2dWnJ1xANTQahgY6G3dZyQBEiABEiifAK8clsBZmGi+POwZCw865QDAMC/BBs54Z9CFgQTIeb95AAAFBElEQVRIgARIwAACmFx+CyvNVv3Yz2jYnHIAVFkY6Icw1CW6z0gCJEACJFAOAV4zmADGlLswtjg3uXTOAVCjwVDnYtuGyEACJEACJEACZRPA4P+L2traY8rOwOALnXQAlDcM1gzD/VL3GUmABEiABIonwJTLCbyCseQY3F7uXn7EoR1nHQC1EVYCDsSWvxoICAwkQAIkQAKlEejr69sHg/9/SrvKntROOwBqBnhv22D7L0QGEiABEiCBUQkwgRLo7++fMmbMmL/pvqvReQdADQcnYA1sexAZSIAESIAESGBEApj179HQ0NAxYiIHTnrhAKid4ATUY8vfDAAEBhIgARIoRMD345j571NTU/OYDxy8cQDUmHACNsL2UUQGEiABEiABEliBgA7+mPk/tMJBhz945QCoHeEE7InlnZ/qPiMJkAAJkMBgAn7uY0x4z7fBXy3tnQOgSmN55ygYnE6AwmAkARIgAb8JvJHNZo/waea/zNxeOgCqvDoB2H4fkYEESIAESEBEfIOAieCDYRh+FIP/I77prvp66wCo8rgdcDK2JyI6+z1P6MZAAiRAAiQwhAAG/sswEZxWV1f3wpBT3nz02gFQK8MJuAHbA+AJzsOWgQRIgAQ8JeCH2hj4FyB+AgP/OX5oXFhL7x0ARQMn4KlMJnMA9q9CZCABEiABEnCQACZ696C/3x+D/08cVK9klegALEWGipFFxfgCPh6P+BdEBhIgARLwhoDjii7CrP8CLPl/FH39q47rWrR6dACGoIITcAsqyW6oLBfjlJM/AAG9GEiABEjAFwI3oT/fDbP+831RuFg96QAMQwoe4n9QWc7DKXUEbsOWgQRIgAQcJuCeaujHH0mlUodjUjcT/Tl/FG4YE9MBGAbKskOoOM+i4hyDSvQxVKbHlx3nlgRIgARIwFgCb0Ky07GSu1cmk7kX+wwFCNABKABm8GFUortQmXbHMf3aID1JgGAgARJwh4AjmryHpf6L0VfvgsnbNY7oFKsadABKwItK9X1Urp1wyRdQ0V7HloEESIAESKC6BJag+CvQN0/Fiu15WK19G58ZiiBAB6AISIOToHJ1wxG4CnEq9s+FI/DW4PPcJwESIAG7CFgrbQ6SX6cDP/rjM9Eft+MzQwkE6ACUAGtwUlS2/6DiXYKKNzWXy30R57x8lST0ZiABEiCBJAm8hP73myhwJ/S/p2L/JewzlEGADkAZ0AZfgsr3Tn19/ZWoiHthf3fEy3Ge3zMFBAYSIAHzCVgi4XuQswWTLX2qfytMvr6CPvcZHGOogAAdgArgDb0UlfJxxLMRt8CtgY/h/M1wCHg/CiAYSIAESKBEAovQf/4C15zU09OzBQb82Zhs8al+AIkq0AGIiuSgfFBpc3V1dXehws6AM7Ce/s40jn0NSX6FbRe2DCRAAiRgAAHjRPgdJk8XYKY/TftOxIPRj/7fKqus8nfjJHVAIDoACRixoaHhIVTki1CRD8C2UR0CreSIt6L4JxBZuQGBgQRIwBsCC6Hpc5gQ3YF4WSqVOhR946roIz+EydP5mOk/iOP/QxqGGAnQAYgRbqGs1SHQSo54HCr8bohrofKPQ/rt4BRMR9RfqboCn1vQCO7G9iHEPyEuQNSGgw0DCZAACVRGIMqr0Vd1IeotzxexfRTxPuSvt0GvQZ92AQb543BsN/R1a6HPG4e4HfanI56TyWR+jnMc8AEsyfD/AAAA//80CaZTAAAABklEQVQDAF1f7SlBh8BRAAAAAElFTkSuQmCC",playlist:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAq0UlEQVR4nO3dCXxdZZ3/8c+ThJaCCAKKCJKbguyriIjI5jLiuM4gzkuxbcpSEFR01MFx9AWMfx0ZdRxhRK1AE4pr0XGdEUVkUdxQ9qUIJC2rMGxCBdrkPv/XKTcQapfc5J7z3HvO5/0iXdLknh+U9vnmOed8T4gxIkmSqqUr9QCSJKl4BgBJkirIACBJUgUZACRJqiADgCRJFWQAkCSpggwAkiRVkAFAkqQKMgBIklRBBgBJkirIACBJUgX1tPC1Ngf2B3YGtgdeAGwAzGjhMSRJqorHgGXA3cBi4EbgF8D97RAAasAs4O+B3d1RkCQpV3XgauA7wEJgyWRfKEzyaYAvBz4C/G32GpM9uCRJmlIY+B/gk8Cv8g4A2wJnAK9r9kCSJCk3PwROBG6b6CdMdMs++yr/Q8B1Lv6SJLWdNzTW6A9MdGd+IjsAmzXOM7jwS5LUGbsBs4EHpxIAsiv5/7dxgZ8kSeoMNwCHArdPJgD0ApcC2+Q2niRJykt2h8CBwNJmAkB2T/9lwI65jSVJkvJ2S6Oj596JXATYDZzv4i9JUsfbDvhGY21fZwA4BTiomLkkSVLODgE+tq5TANnFfr9vcUWwJElKaxR4CXDV6nYAsh/Pd/GXJKl0slMAXxjfETA+AGR9/vummUuSJOUsq/F/y+pOAVwB7J330SVJUjJXNtb6OLYDcICLvyRJpbdX47bAp04BzEk7jyRJKsis7JtQr9d7Qgj3AZsUdWRJkpTMA8DzukII2da/i78kSdWwaXYqIDsFYOmPJEnVcnAWAHZLPYUkSSrUrlkA2KHYY0qSpMR2yALAVqmnkCRJhXphFgA2KvaYkiQpsY2yJsCR1T0mUJIkldZotgPweOopJElSoR7LAsCjxR5TkiQl9ucsANydegpJklSoe7IAsLjYY0qSpMRuygLA9amnkCRJhbohCwCXFntMSZKU2CXZbYDTG08G2iD1NJIkKXfZxf+bZTsATwA/yP94kiSpDXwfWJ4FgMzCxMNIkqRirFzzs1MANJoAbwK2K+jgkiSpeH8EdhprAsyMAqclGESSJBXn3xpr/lM7AJlpwDU+HliSpFK6Ica4ZwhhRfaTsR2AzHLgWOCpRCBJkkrjPWOL/6oBIHMJcHbxM0mSpBx9Gbho/DvGnwIYsz7wa2CPPCeRJEmFuA54afYEwPHvXHUHgMbjgQ8D/lTMXJIkKSf3AG9edfFfUwDI3Aq8Dng4r4kkSVKuHm6s5bet7hfXFAAyVwKvAO7MbzZJkpTTV/6HAFet6QPWFgDGzhscBFzd+tkkSVIOskX/5Y0v5JlsABg7HbAf8CVvEZQkqW1la/SZjTV7aF0fvLq7ANbmgMaL7zqlESVJUistBk4AfjbRT5jIDsB4lzVuD3xb1ijU/HySJKmFsrV4Toxx12YW/8nsAKwaHg4GZgFvATaZ7AtJkqQJexD4buOpflmBX51JmEoAGC97muBewIHAzsD2wAuAZzWeMSBJkpqTVfQ/CtzV2OK/sbHgXzX2QJ+paFUAkCRJHaTZawAkSVIJGAAkSaogA4AkSRVkAJAkqYIMAJIkVZABQJKkCjIASJJUQQYASZIqyAAgSVIFGQAkSaogA4AkSRVkAJAkqYIMAJIkVZABQJKkCjIASJJUQQYASZIqyAAgSVIFGQAkSaogA4AkSRVkAJAkqYIMAJIkVZABQJKkCjIASJJUQQYASZIqyAAgSVIFGQAkSaogA4AkSRVkAJAkqYIMAJIkVZABQJKkCjIASJJUQQYASZIqyAAgSVIFGQAkSaogA4AkSRVkAJAkqYIMAJIkVZABQJKkCjIASJJUQQYASZIqyAAgSVIFGQAkSaogA4AkSRVkAJAkqYIMAJIkVZABQJKkCjIASJJUQQYASZIqyAAgSVIFGQAkSaogA4AkSRVkAJAkqYIMAJIkVZABQJKkCjIASJJUQQYASZIqyAAgSVIFGQAkSaogA4AkSRVkAJAkqYIMAJIkVZABQJKkCjIASJJUQQYASZIqyAAgSVIFGQAkSaogA4AkSRVkAJAkqYIMAJIkVZABQJKkCjIASJJUQQYASZIqqKeFr7ULcACwM7AD8FxgY2CjFh9HkqSyGwEeAR4G7gMWA9cDlwE3tOIAIcY4lc9/GTALOAzYohUDSZKktboH+DawEPgNBQaA7LTB64GPAi+d7IElSdKUXQ38B/BVYDTPAPBi4Exg36ZHlCRJebkSOB74dasvApzWSBi/c/GXJKnt7AX8EvhMjHG9Vu0AbAOcD+zTkhElSVKesusC3grcMZUAsBNwAfDClo8nSZLychdwKHDtZALArsDFwGa5jSdJkvJyP3BQ4/bBCQeA3sa5hK1yG0uSJOUtOw2wP7B0IgFgOnB544p/SZLU2a5pXMD/+LruAsiu9nfxlySpHHYH/n1dOwCvAC7N3l/oaJIkKU/ZYn8IcMlfBYDsvsEQwpWNTn9JklQu18YYXxxCGHnGKYAQwhEu/pIkldZuIYS3r7oD0NW4VzB7kp8kSSqnmxpf7NfHdgBe4+IvSVLp7Qi8KvvBWACYnXYeSZJUkFljpwCyB/08AGxY1JElSVIyj8QYN+tqlAO4+EuSVA0bhRD2yQLAgaknkSRJhTqoq/HQH0mSVB27ZAFgh9RTSJKkQu2QBYAtiz2mJElK7AVZANgo9RSSJKlQG2W3AWadwN3FHleSJCU0mu0APJZyAkmSVLhlWQB4pPjjSpKkhB7JAsBdKSeQJEmFuzMLAIuLP64kSUpo8dhjgCVJUnVclwWAS1JPIUmSCnVxqNfrPSGE+4FnF3tsSZKUwEPA5l0hhKwH4DspJpAkSYX79lgPQObc4o8vSZISWJh9kzUBrvweuArYPcUkkiSpEFcDewFxbAcgSwH/VsyxJUlSIp9orPlP7QDQeB7Ab4C9U00lSZJy8zvgZUA9+8nYDkBmFDhu7BckSVJpZGv7u8ev8eMDQOYK4DPFzyVJknJ0GvDb8e8YfwpgpRhj1gtwMbB/npNIkqRC/DrGeGAIYcVaA0DDc4FfANsXM5skScrBrcArgHtW/YVVTwGMuQ94PXB3HtNIkqTcZWv4a1e3+K8tAGRuAV4O3JzfbJIkKQe3AQc2dgBoNgBkhoEDgJ+3fjZJkpSDCxu3+2VfyDPZAJC5F3gNcDLwjAsIJElS21gOfKyx7Z+dyl+rNV0EuCY7A18ADp7SiJIkqZUuAk4AbproJ0xkB2C8G4BDGjsC2a2CkiQpnewU/asabxNe/CezA7CqnYBZwGHeMihJUiEWA+cD5zW76LcyAIy3VeOKw10aYWAL4FnAJq06gCRJFfIQ8Cjwp8aifz1wKXBXK168lQFAkiR1iGavAZAkSSVgAJAkqYIMAJIkVZABQJKkCjIASJJUQQYASZIqyAAgSVIFGQAkSaogA4AkSRVkAJAkqYIMAJIkVZABQJKkCjIASJJUQQYASZIqyAAgSVIFGQAkSaogA4AkSRVkAJAkqYIMAJIkVZABQJKkCjIASJJUQQYASZIqyAAgSVIF9aQeQJKaEc69YysY3Z7RuD3EFxHCZhA2JPAcYtwAWEEIK6jHRwg8Rox3E8LtxHgnXd1DxPr1sb/2eOp/Dym1EGNMPYMkrVbI/jn71l3o6jqYwMEQDgSeO8WXHQX+CFxN4HJGRi/iqG2vj+BfhqoUA4CkthMGhnckhCOI8Qigr4BD3gtcCOHbbNj9v/HwrR8r4JhSUgYASW0hnHpxD7W+fyDGE4F90g0SHiXGHxFZwNLaT+PJ1JPNIuXIACApqbDojhksG50L8YMFfbU/cSHcAnyJ9cI58R3bPJh6HKmVDACSkgkDQ2+EcDpQo51luwL1eA6j8ZPx6L4/pR5HagUDgKTChXOGdqArnAG8hs7yCDGeTlx+Wjxyh0dSDyNNhQFAUrFX9Q8MvRvCp4HpdK67IHyI/t6ve/eAOpUBQFIhwtl3bEr3yNnAWyiPS+kOx8VZvTemHkRqlgFAUu7CuUO7Uw8/ALahfJ6A+Ak2fOy0ePjOy1MPI02UAUBSrsLg0IHE8H1gY8oshOuI8ZjYX/t16lGkiTAASMpNGBx6EzF8A5hBNdSJnEV84oNeJKh2ZwCQlItw7pK/ox4XAd1UzzCR4+Lc2gWpB5HWxAAgqeXCguGDCPwYWJ9KC4uIK06Ic7e7L/Uk0qp8HLCklgoDt+1G4L9d/DPxcELPTWFweF7qSaRVuQMgqWXCuXduRhy5ihi3Tj1L+8meL1B/V5y77e2pJ5Ey7gBIal3JT33F2S7+axJeT+i+KQwMnxQWVfK6CLUZdwAktURYMPx+Av+Reo4OcTmx65g4d5sbUg+i6jIASJqyMLh0F2L9D8C01LN0XIHQ8gc+FeftvSL1MKoeTwFImrp6PXuwj4t/c6ZD+Femb/6HsGB439TDqHrcAZA0JWFgyTsgfjX1HB3OAiEVzgAgadLCmTc8iw02WAy8IPUsJTFMiMfGOX0/ST2Iys9TAJImb8MNj3Xxb6kaMVwQBpZ8K8y/efPUw6jc3AGQNClh/u/XY9pmtwIvTD1LST1A4J/jnNr81IOonNwBkDQ56206x8U/V5sS+XIYGP5RWHhbGR+jrMQMAJImJ4T3px6hIv6W0a5rw8CS48Op/p2t1vEUgKSmhcGlexPrV6Seo4IsEFLLmCYlTUL9iNQTVNTLCfWrwsDwp8IZt0xPPYw6mzsAkpqyssd+2fAdwPNTz1JpIVxHPR4d59Z+k3oUdSZ3ACQ157ElL3XxbwMx7krg8rBg+Msr+xikJhkAJDVnNB6cegQ9pYvAPDbY4NqwYPi1qYdRZzEASGpOwADQfmoEfmyBkJrhNQCSmiv/mb75A8TolnP7uhc4MfbXvpF6ELU3dwAkTdyMzbdz8W97zwO+boGQ1sUAIGniRuL2qUdQUwVCN4SB4ZMsENLq+D+FpIkLBoAOsyHwKXqHLwsLlu6cehi1FwOApCZ0vSj1BJp0gdAfwoKhj668jkMyAEhqSoxeYd65phPCx5m++R/CguF9Uw+j9AwAkiauK2yUegRNkQVCajAASJo47wAoX4HQ4NDfpB5GaRgAJE1cCAaAcqkRwwVhYHggnHvnZqmHUbEMAJImLsae1CMoF3Oor7ghDA7NTj2IimMAkCRlnkcMgxYIVYcBQJI0ngVCFeFvriRpzQVCC5fslHoY5cMAIElak5czGq8OA8OfCotumJZ6GLWWAUCStDZZc+BJLNvgCguEysUAIEmaiN0sECoXA4AkqdkCoWssEOp8IcbYqtfaATgE2Kvx4z4gqw3d2KChEnsMWAbcByxuvP0SuBR4mJIJA8M3AjumnkPtIixi+RPHx3nb/1/qSVR8AMj+IsiKI44AvG9UetoocDFwLvDtRkjoeAYArca9hPihOKcv+39dFQgALwM+Arwhe43WjyWVygPA6Y23B+lgBgCtxf/QXX9XnDVzaepBNDHNbs1v2fiK5nLgjS7+0oRsCpwC3AqcCHSnHkjKqUDo2jAwfKIFQp2hmd+ktwM3AbNc+KVJeQ7wn8BFwNaph6mkEB4Fbk89Rok9e+X/473DF4dzhrJrwdTJASDGmN0D+kXga43fXElTcyBwJfDq1INUTowPsnx6dgrjNKCeepwSO4CukO0GWCDUwQFgegjhG8BxBc0jVcXmwI8aO2sqUJy35V9if+3DxHAAcEPqeUrMAqEODgDrA/8L/H2B80hVkn1ldF7jtJoKFuf2Xs7y+/cEPgwsTz1PiVkg1GEBILtI6auN+/ol5ftn8GzgdakHqaI4b+8Vsb92GqOjewO/ST1PiVkg1EEB4GN+5S8VulX6TWD71INUVTxq2+tYUns5gWMbFwoqH33EcEEYWPKtMP/m7DSY2iwAHAx8NMEsUpVt1Nh184KpROLJ1OOc2nxi3A24IPU85RYPZ9q068LgUFYkpzYJANOBL3mfspTES4D3px6i6mJ/bTj21w6F+DZCsOI2P1sQw2AYGPphWHDrC1MPU0WrBoCTGj3+ktLITr/5l2EbiP19i+ga2QXCwtSzlFt4PaH7OguEijf+P3b20J5/TDCDpKdtCPxz6iH0pDhr23tjf+/slYsUWHGbe4HQ0KVh4ZKdUg9TxQDwnkYIkJTWkcALUg+hp8X+3v+he8bOFgjlLezPaLzaAqFiA0D2/byCjilp7bJrceamHkLPFGdtscwCoYILhM4demnqYaoQAF7leUeprczxmRvtyQKhwuxGPfzKAqH8A8BhOR5DUvNeBOySegitngVChbFAqIAA8Mo8DyJpUvxz2eYsECqMBUI5BYDnN77akNReDko9gJouEPpJ6nnKzQKhVgeA7MpWSe3H26E6r0DotRYI5c4CoRYGAPvHpfa0XYyxJ/UQao4FQkWxQKhVpwAktZ/1QgjPST2EmmeBUGEsEJpiAPD2Cqm9HxKkDmWBUKEFQn8IA8OnWCDUXADISkcktacZqQdQCwuEIjemnqfE1gdOtkCouQDwlyY+XlKxvLWsTAVCK+7fwwKh3Fkg1EQAeGSiHyypcAaAErFAKEGB0MDQa1IP084B4PbUQ0harWXAA6mHUOtZIFSYPgg/sUBozQFg8Rp+TVJa2Z/NmHoI5cMCoSJZILSmAJA91Wpktb8qKaVrUg+g/FkgVBgLhFYTAP4M/GHVX5CU3M9TD6DiWCBUFAuExoz9y1/41HsktYNs6/9nqYdQsSwQKsyzLRB6OgB8LfEckp7pMuDO1EMoDQuEihIqXSA0FgCuB65MPIukp7kNXHEWCBVm/aoWCI0///H5hHNIelp2Idg3Ug+h9mCBUGF2q1qB0FMBIMaYnQYYSjuOJOCzFgBptQVC1F9igVCuuqpUIPRUAAghrAA+knYcqfKyYq4zUg+h9hT7Z15rgVAh+qpQILTqLRDZtuOPE80iCd7baACU1l4g1MXuFgjlLZa6QGh190DOA+5PMItUdVkA/27qIdQZ4qzeIQuECrFFWQuEutawBXm0FaRSobKrvI9JPYQ6jwVChRYIXVumAqE1/Ut8t3HFqaT83Qe82Qv/NFkWCBVm46cKhAaGd6TDrS3F/HvjTVJ+sqf9vRb4Y+pBVJICofVGdiNyugVCeQr7Z905nV4gtK5tjJOA93k6QMrF3cAhlnCpleIR2/05zq2dSOg60AKhXK3f6QVCEzmPkRUEvQN4pIB5pKr4BbCPT/xTXuKcbX5pgVAhduvUAqGuJq5OzgoofpvzPFLZZX0b/y/GmH3lb9e/cmWBUGG6OrFAqJkrGW8G9gOOa1SVSmr+8b57Ah8LIYykHkbVYYFQggKhc+/cjDbX7K0M2UUlX37yX5IPAnflNJdUFtn1Mz8FDgZeCdyQeiBVkwVCRYqHU19xfbsXCIUYp3R9Xzfw6sY1Atm2x5atG03qWKONC/u+D5xXpmdshIHh7KKyTr796fbYX9sm9RDtIAwMHU7oOpMYS1t12xZC+CH1kePj3G2zjp1SBYBV7QTs1fgLYiawEbBBKw8gtaEHG7fz3dz4Cv/XwEOUkAGgXMJZQ1vQ0/XprEkg9Swl9/DKOwaW1M7IdmIoaQCQVGIGgHIKg0teT4xnAv63yVX8JYSjY3/tJtpAKeoMJUmTF+f0/sgCoeoVCBkAJEkWCBVfIPS71AVCBgBJ0lMsECrM7kR+GRYMfz5VgZABQJK0tgIhC+DyEkMPgfemKhAyAEiS1lYgtJ8FQuUsEDIASJLWyAKh8hYIGQAkSesUZ/UOxf7aayG+jRCsg8/PFsQwGAaX/CAsuPWFOR7HACBJmrjY37eIFfVdISxMPUupxfgGQve1YWD4xHBqPmu1AUCS1JR4dN+fYn/vbEJ8s0+1zNXGwH+yzfCF4eyh3la/uAFAkjQpcU7f91lvZGfgS40HXykPgUPoDteEBcNzWvmyBgBJ0tQKhPpr7yJ0HWCBUK6eTWAgDC5ZGObf3ZJn7BgAJEmtKRAKvJgYPwGsSD1PacX4TqY9cWk465atp/pSBgBJUkvE/trjcW7fR6G+twVCudqbnp7fhoHhPafyIgYASVLrC4Q2rL0cwgeAv6Sep6S2BH4ezrntFZN9AQOAJKnl4uGMxv7e/6A77GqBUG42oavrx2HB8EGT+WQDgCQp1wIh+muHAnOBB1LPU0IbEvh+WDC8b7OfaACQJOUqZpeu9dcGGIk7WyCU2x0CPwrn3rZ9M59kAJAkFcICoVxtRr3rh808TMgAIElKUyAUOR2op56nRF5Effk3wyK6J/LBBgBJUpoCobm1EwldB1og1ErhVSwb/thEPtIAIElKXyBE/KQFQi3zsTA4dOC6PsgAIElKXyDU3/cvFgi1TBcxDIRzFm+09g+SJKmdCoRC+KAFQlPWR9f6WS3zGhkAJEntVSA0p/ezFgi1Qjw+nDO0x5p+1QAgSWrLAqHYX3stxLcRwv+lnqdDddPFF0L2QOHVMABIktpW7O9bxIr6rkS+lXqWzhT2Z8Hwm1b3KwYASVL7FwjNrf0DIbwBuD31PB0n8PFw6l+v9wYASVJHiHN6f8Ty+m7Al55sGNYE7Ubfkqx98RkMAJKkjhHnzXw49tfeReg6wAKhJkT+cdV3GQAkSR1cIMSpwPLU87S9GF8RzrntJePfZQCQJHVwgVDtFOrxpYRwRep52l5X97xn/DTdJJIkTV08su9qhnv3JXAsITyaep72Fd8WFt0xY+xnBgBJUseLJ1OPc2rz6WJ34Kep52lTG7Ns9HVjPzEASJLKViD0NxYIrUk8bOxHBgBJUnkLhAgLU8/SZg4Np17ck/3AACBJKm+BUH/vbCJvAe5MPU+b2JTazH2zHxgAJEmlFufWvsd6IzsTOR2oU3UxHpR9ZwCQJJVePGK7P8e5tRMJXQdWvkAosF/2nQFAklTBAqH4SWAF1fSy7BsDgCSpggVCff8C9b2B31I1MW4ezhrawgAgSaqk2D/zWpbU9qtkgVBP2MkAIEmqrDhWIFQPe0D8GVUR2cEAIEmqvDh3m9tif9+rK1Qg9AIDgCRJVSsQCmFLA4AkSZUrEIrPMwBIkrSmAqHl9V1KWiC0gQFAkqQ1iPNmPryyQKheP6hkBULrGwAkSVqHeOTMX1AffRPwAOUwzQAgSdJahOySucGh2XR3/2blw3TK4YmVjwSUJEl/LQzevi1xdD6EV1IujxkAJElaRZj/+/WYvvk/EeNHs/PllM8yA4AkSeOEgeE9mbbZWcSYPSugpOI9BgBJkoCw6I4ZLBs5Gfgg0E2ZRe42AEiSKi8MDL0GwpeAmVRCuNMAIEmqrDAwvAmR0wjhmCcv+K+IwI0GAElSJYWBoTdC+CKBraiaaV2LDQCSpEoJZ92yNd09XyCErNinipbGd2zzoEVAkqRqFfr09FxNoKqLf+by7Bt3ACRJpVfiQp/mBX6VfWcAkCSVVgUKfZoX4sXZdwYASVIpVaPQp2m3x9l912Q/MABIkkolzL97A6Y9/nEIJ5a+0Kd5Pxr7gQFAklQaYXDoQKaFr0DYPvUsbakrfGvshwYASVLHq2yhT3PuYkbvpWM/MQBIkjpaGBx6G4TTCWyRepY2tzAezujYTwwAkqSOFM5bsiUj9TMgHJZ6lg4wSnf48vh3GAAkSR1X6MPg0Cxi+ByETVPP0yG+F2f1Do1/hwFAktQxwjlDO9C18iK/A1LP0lFi+Oyq7zIASJLaXjj14h56ax+gK5xioU/TfhLn9q6s/x3PACBJamth4LZ96K19Bdgj9SwdKDZC018xAEiS2lJYdMcMlo2cDF0ftNBn0r4ZZ/eu7P4vOgBMBzbI+RhSag+mHkAqZaFPzM71Y6HP5P2F0fjhNf1iTwsX+pcBhwB7ATsCfcB6LXp9qd09BCwGbmw8avMi4NbUQ0mdJpx9x6Z0j3wWwhwLfaYoxpPjUX1L8goABwL9wFuBjab4WlIn2wTYt/GW/ZnIXA+cm5VvAHcnnk9qe2Fg6I10hy8CW6WepeNFfsWz+j63tg/pmsTLZonszcBvgUuAuS7+0mrtApwGZPfengn0ph5Iakfh3Du2CguGvwfh+y7+LbGM7nr/+Na/VgSAFwE/Br4L7DO1+aTKyE6RvatxesBbmKRxhT5hcGg29ZFrCLwp9TylEeLxcfbMm9f1YT1NfNV/YuOrmWlTn06qpBnAyY1TZm8Dbkg9kJSKhT45CXwxzunLTj2u00R2ALKr+L8DZOcSXPyl1pwayE6h/UPqQaQUhT5hYPhEusIfABf/1rqUP4+8f6IfvK4dgOcAPwD2n/pcksbZEPg68ELgM6mHkYoQBob3pLd2FrB36llKJ3Ij07veEt+z3ROtCADPBi4EXtya6SSt5tTap1c+pevJHTaplML8uzdgvcf/lRDeZ6FPLoboqR8a31FrqpOkZy0XLWUX+rn4S/nLHtLxJ+BrqQeRcin0mbbyXL+FPvlYSux6dZxVW9rsJ64pAHy6UeojqZidgLMbdwlcmXoYqWWFPj0jnyGGrBfDQp98ZOVjh8a52wxP5pNXdxFgdo//u6c+l6QmrN+4JsDqbJWk0GfkGuLKnhgX/3z8ljhyQOyvTWrxX10AyAp9vuBvmJTEDsC/pB5CmiwLfQoS+DrLpx8S525331ReZtVTANk9yv6mSelkTz0bBNZZ4iG1U6EPg0OziOFzBDZNPU9phThCDB+Nc2pZJ8+UjQ8AWwDHt+JFJU1a1rXxUWB26kGkiQiDt29LHJ0P4ZWpZym526B7duzf5petesHxpwDe32gqk5TW24GZqYeQ1ibM//16YWDJR4ij1wEu/vmpE8J/sXz6bnFO6xb/p3YAYow9Iay8UlNSetmfyyMbOwFSexb6TN/8K8T4ktSzlFoItxCYF2f3/jyPl1+5AxBC+NvGKQBJ7eGdk3xap5SbsOiOGWFg+FPAFS7+OZ/rz569E+NueS3+468B+Lu8DiBpUrJHB+8F/D71INJThT4xK/TBQp98XUW966g4tzd7VkKuxgLAwXkfSFLTsvOqBgAlFQaGNyFyGiEc4y3iuXoMOJUNa5+Jh6+sB6eIALA1UCviYJKackCjlVNKV+hD+CLB28Nzdgld9Xlx9sxCb//NAsDORR5Q0oTtmHoAVVMYGH4+xP+CcFjqWUruIQInMaf2lZg9z69gWQDwfI7UnvoavQDLUw+ianiq0IfwOQgW+uQphB8Suo+Ls7e+k0SyAPDcVAeXtM4/n89pPClQypWFPoW5G8K745ze79AGf8E8K/UQktYoez6HAUC5Cade3ENv7QTgE8CGqecpsUjkK0wb+VA8Yrs/0wZ6GluMktrT9NQDqLzCOUN7UOs7y3v6O7vQZyoBYFnqISSt0SOpB1A5C31YNnIyXeGDxNidep6SP7zns8R4SpxTe5w2kwWAttiKkLRaBgDlUegzv/H4aeXnKug+OvZv07ZdHlkAWJJ6CEmr9TDwYOohVA4W+pS30GcqAWDxpD9bUp78s6mWsNCn3IU+UwkANzTuM/ZiQKm9XJV6AHU2C32qUegzWdnTxv4C/HbSryApLxelHkCdW+gTBodmA9e7+BdQ6NPVs2ucU5vfSYv/+IcB/RR4ReJZJD0tO3fYVrcMqZMKfUa+DOFVqWcpubvbpdBnssaeN/61lSUFktrFhcC9qYdQZxX6hIHhE4mjV7v45ypCWMhoz66xv3MX//E7ALcAlwP7J55H0pMWph5AncNCn8LcSgzz4tzeUpyeGwsAmc8ZAKS2cDuwKPUQan8W+hRc6AOnxLm9bVfo04oA8N+NOwJ8PLCU1mk+AVDrYqFPYa5q90KfVgSAOvB+4IKE80hVl90/fFbqIdS+LPQpzGOdUujTigCQ+QnwbcDbRqTiZRfiHgc8kXoQtScLfQpzKV31Yzql0KdVASBzPLAf8IIE80hV9nlv/dMaC31COAPCW1PPUnIPdWKhz1RvAxwvu/XoCGAkwTxSVf0GOCn1EGrjQp8YXfzzFDq30KeVOwCZi4G5wLmeY5JydxvwFi/803gW+hTmbkJ4T5zTm53+rpQ1BYDMecBzgezWB0OAlN8tf38D3JN6ELVPoQ+9tROAT0DYMPU8JS/0OY/R7vfFo7Z+gApaWwAY6wa4v3FV8noFzSRVxY3AocDS1IOoPVjoU5hby1Tok1cAoHEa4M7GjsDzC5hJqoKsQvSolRcdqfIahT4n0RU+Qox+sZWXkhb65BkAMj8D9gKy0ok3Tvpokv4M/DNwZupB1B4s9ClMaQt98g4ANM5RvqnxliWo7SZ9VKl6sqKtrwP/BNyVehilZ6FPYUpf6NPK2wDX5fvAjsA7n0xUktbi8cZptF0bf2Zc/NUo9OE6AvNc/HMv9Nkz9tdOc/Gf2g7AeNl/yK823nZv9Aa8BthjkqFCKts2/yXA94DzgYdTD6T2YKFPYSpV6FN0ABjvmsZbVmKyGbAnsD3QB2zceDMUqMzbi482CrSy2tDFMcZrQggWaekZhT4MDs2C8Dli3DT1PKUv9Andx8XZW2cXryvnADDe/Y0LBrM3qZJCcEdXT7PQpzCVLfRplwAgSbLQp0iVL/SZLAOAJLWYhT6FsdBnCgwAktQiFvoUWOhTD2eyYvo/x3lb/iX1OJ3KACBJLRAGhg6A8BULfQoq9Jlroc9UGQAkaQos9CmMhT4tZgCQpKkU+oSuMyFunXqWChT6HBNnz8xutVWLGAAkaSqFPtGemRxZ6JMjA4AkTZCFPgWy0Cd3BgBJmgALfQpjoU9BDACStBYW+hTGQp+CGQAkaQ0s9CmMhT4JGAAkaRUW+hRc6NMz4yNx1hbLUo9TNQYASRrHQp/CXM1oPDoe2XdF6kGqygAgSRb6FMlCnzZhAJBUeRb6FMZCnzZiAJBUWRb6FMZCnzZkAJBUORb6FMhCn7ZlAJBUKRb6FOYeQni3hT7tywAgqUqeRxy9FsKM1IOUWLbFP5/l9ZPivJkPpx5Ga2YAkFQl01MPUHK3ErqOjXO2+VnqQbRuXRP4GEmS1l7oEzmd7hl7uPh3DncAJElTYaFPhzIASJImw0KfDmcAkCQ161LqcV48sm9x6kE0eQYASdJEWehTIgYASdK6WehTOgYASdLa3EOM74n9tfNTD6LWMgBIklYnQjiP0e73xaO2fiD1MGo9A4AkaVUW+lSARUCSpCdZ6FMp7gBIkjIW+lSMOwCSmrEi9QDKqdBn+f37xCNnuvhXiDsAkprxSOoB1FKXUY/HPFnoU0s9iwpmAJDUDANAOVjoIwOApCaE8AjR9aLjC31WrHhXPHq7O1KPorQMAJImLtb/BCH1FJqcu4AT4pze76YeRO3BiwAlTVwIN6ceQZMq9FnIaM9usb/m4q+nuAMgaeLqLHYDoKNY6KM1cgdA0sQFfPxrJ7DQRxPgDoCkiVtSW0rv8IPAc1KPojX6PTEcHefWrko9iNqbOwCSJiyeTB24JPUcWmuhz36x38Vf6+YOgKTmBH5O5C2px9AzWOijphkAJDVnZPQiurtTT6EnWeijSQvRUg9JTQjZPwPDfwS2TT1LtcVvQ3h37K/dk3oSdSavAZDUlMZXmuelnqPC7iHGw2N/31td/DUVBgBJzesOg09mASUo9Nklzu07P/Uw6nyeApA0KWFwyWXE+IrUc1TEH4kcE+fWvANDLeMOgKTJ+s/UA1So0GcvF3+1mjsAkiZ/MeDgkmuIcdfUs5TU1dTrR8cjZ16RehCVkzsAkiZ/MWCs/3vqOUpc6LOPi7/y5A6ApEkLp17cwza1awjslHqWkriI0dFj41Hb3pJ6EJWfAUDSlITBoQOJ4eInzwpokh4GTmZJ7YxG3bKUOwOApCkLg8NfI/L21HN0pBB+yIoV74pHb3dH6lFULVYBS5q67vABRuLrgE1Sj9JB7qIrvDvO7v3v1IOomrwIUNKUxXf23g1xtuVATRT6dK23u4u/UvIUgKSWCQNLTof4ntRztLHbiPVj49yZF6YeRHIHQFLrPLLiQ8DvUo/RloU+cBob9uzq4q924Q6ApJYKC255LqHnl8CLUs/SJiz0UVtyB0BSS8W5291H6M4uCKz6k+os9FFbcwdAUi7C4NK9ifWfARtTNZGfUx+dZ6GP2pk7AJJyEeds83tGR7OnBd5JtQp93sfS2qtd/NXu3AGQlKswMFwDLgC2p8ws9FGHMQBIyl1YeOvzGO3+JnAw5XM3XeEE7+lXp/EUgKTcxVnb3suGtVdD+DiUput+FOKZwM4u/upE7gBIKlRYcNurCV0DwFZ0rsuA98b+2lWpB5EmywAgqXDhnMUb0TXtFALvJYZOeibJ9RBPpb/v/GjtsTqcAUBSMmHgtt2IXZ8ncAjt7XoiH2dpbZGP61VZGAAkJRcGl+4P8cPE+Prsp6nnaagTwkXE+un09/3Qr/hVNgYASe1VHkT9BCKHAc9OMkTkSmARoyMLvaVPZWYAkNR2wqI7ZrBs9O8gHgErTw/MyPFwj0G8HMKFjI6eb4GPqsIAIKmthTNumc5GPfsROYSwskdgF2CzSb7cKJGbCVxD5Grgch4d+XV8z3ZPtHhsqe0ZACR1nHDunZsxOrIDxBcRwmaE+CxieBYxjj134KHGI3gfIvAn6l13EOJdPDIy5GIvPckAIElSBdkEKElSBRkAJEmqIAOAJEkVZACQJKmCDACSJFWQAUCSpAoyAEiSVEEGAEmSKsgAIElSBRkAJEmqIAOAJElUz/8HKJrTsn8xeA4AAAAASUVORK5CYII=",radio:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAQAElEQVR4AeydB3wcxfXH35yaGziEngC+k40DCT1O6ATTQrOpIUCCrZNMCPCHUEINBBMChE7oYEsnmd5NTegEbCCht1ClkzEJBAIxAWzJkm7/v5HlYBtJ13Z3ZnZ/95mn29sy773v7O78dnbvlBC+SIAE3CQw9bVquWLOCjLtnTWkse070tS+iWTatpZMdmdpbt9HmtsmSXP2UEz/Whpbp0pT23nSlL0C1iKZttskk/0T7BHJtN0tmeyNkmmbjmV/hJ2FbX4jmexRkmk7WDLtB2LeHtIyZwdpad9cWuZuINPfHSNXt68u172zvNxyS4WbABk1CcSbAAVAvNuf2dtOYMaHw2V6+8bS3LafNLWdIs1ZdN7Zp9Ep/1tGDe+UoblPpbJyriTUm6K850XUEyLyJ/G828RTLeLJFZg+TxKJ00SpX4uSQ2GTRNQ+IrIzbDsRNUFE9hdRDVh2JOwkbPN7EblIRF0j4l2PeTMll3tIct5Tkut+WSoq3pFq75/SVfmZfPmDbsQ2FzFBTGSvwvsxEA4T5FqIkqkezzHCFwnYSECEB6ed7cKo4kRg6mOVMqN9XWnK7oGr+F+j87xGMtnHYP+QngVfSIX3gnjqZlHqDPEEnbdshk55RbHppdQaiAliQg7B+wUi6m7phigZ1d6D0YR3kNv9yOdiaW47XDJzdsR0UvgiARIwSoACwCh+Oo8dgaY530WH2CCZ9kvQCf4Z1iqjkl3S4/1dlMzEVfx5IupgEdlWRL4Fc7943hjktgsS+ZV46jKR3IOYziL3Tthr0py9AwLhHHDZp/e2AhaykAAJBEtA104BoCnQSCAIAnr4PtO2Izq336Kjw/329k9E5V7H8Pp0Ee8IuPwxrBYW11KNxL8nnuwlSo4Hl9t6bytksq0QSDPA7ZDe2x9YiYUESMB/AhQA/jNljXEl0NI6Fp3WZHRel6PD/1vv8L2oB9G5nQ4kuN/ufRPvLPkJQBR5B4HbVb23PzLZeWB6H26PnCKN7btI0wcr56+Ca5AACQxMYNESCoBFHPiXBIojkMkOkelt26BjOgad/Y2wdyWXeAudVjOu7g9DZT+AsfhDYCSY7irKO0MS3v2iOj4C779Kpu0yCK60ZOau748b1kIC8SJAARCv9ma25RDIZJPS3H44Op37RdQ/pEL9BR3TBSKyP2w0jCU8Aj8UUYdDcDWJdL8imWwWbXMt3veXS95ZXvgiARIYkMDiBRQAi0nwnQT6I3Bt++rS0j4FHcudWPw27lNfhk5nF3T8HM4HEItKEm3zc8RzoyxX+RbEwHTJtO4NMVCDeSwkQAL9EKAA6AcKZ8WcQMsbK0pmzkHo9G+SHnlbct40ENkTVgVjsZ/AahADDSKJ20WLAf3jR82tu9kfNiMkgTAIfOWDAuArFpyKM4HLXxuBof2fSnO2RXJD3xLJzQCOn6IjGYF3FncJjMKIzaHiJe6VTNvbksleJE2tO7ibDiMnAf8IUAD4x5I1uUbg6ueq0CHsKU1t02TYiLfQUdwkvT+049n1IzuucbU2XrU2QjtKVOIhtPmraPs/SOa9rTGPhQRiQ2DJRCkAlqTB6XgQaGnfRfQT5NUrvo2E7xSlpoh40fjRHSTEUgABpdbDWieI9DyBfeE5jPycLo3vjcM8FhKIDQEKgNg0dcwT1f+wJpOtk6bso7inr5/iPxxEkjCW2BNQ38fIz28l0fOs6H+KpH9rIPZMCCCaBJbOigJgaR78FDUCN7StKpm24+SLcS8htYwoGY93FhIYiMD+vb810Nz+kDS26f+7MNB6nE8CzhOgAHC+CZlAvwRmvLeeZNrPlQ71sog6VxYN+QpfJFAQAc/bQRJK/+fFl7AfHSNN7/DXBwsCx5VsJrBsbBQAyxLhZ7cJtLSPl0w2Iz05XPF7x4mSVd1OiNEbJrChiHeBqEoIgezZEALfNRwP3ZOAbwQoAHxDyYqMEmhu208ybffi/v6jiKMOJ+0KvLOQgF8E9EOiJ4qqgBBony7N723jV8WshwTCIfB1LxQAX2fCOa4QaHxzOWluO1wy2WfEUzeLKP7Yi/AVLAFVBXHZIF7PX6Qpe5c0t+8TrD/WTgLBEaAACI4taw6KwPVzVkCnf5okal5Cx38Z3GwKYyGBcAkomSiedxuEwFPS1DYlXOf0RgLFEehvbQqA/qhwnr0E9BX/wtwzCHAqrBbGQgJmCSjZXJSaJvorpk3ZPcwGQ+8kUDgBCoDCWXFNkwR67/G3z+q74h9rMhT6JoF+CeivmCqZCSFwszS/u6XwRQLWEOg/EAqA/rlwri0EFj3VPxMdP+7xezyp2tIujGNgAkr2E69ilmTaL5OWVorVgUlxiWECFACGG4DuByCQaV1fmtun9T3Vz2HVATBxts0EvMMll3im93kV/dyKzaEytkgTGCg5CoCByHC+GQKZ7GrSPOcsEZw4PY8PVplpBXr1j8AKqGqq6OdW9PMr+MBCArYQoACwpSXiHsctXoVkWo8BhmfEy52E92EwFhKICoGxuI11GW4LzBL9PEtUsmIeDhAYOEQKgIHZcElYBDJtB8n8Oc/gqv8CuBwFYyGBiBLwtoQQuBm3BWaKfr4lolkyLTcIUAC40U7RjLIp+yOcCP8komaI540TvkggPgT26H2+RT/n0tK6VnzSZqZhExjMHwXAYHS4LDgCTdnfipLH4GBnGAsJxJOAfs4ll3gUt78OjCcAZm2SAAWASfpx9N3YuhXugz6Mzv90pK9gLCQQdwKjRRLX47i4XFreXzHuMJi/nwQGr4sCYHA+XOongUz7yaIUrvq97f2slnWRQDQIeIdJrutR4a8JRqM5HciCAsCBRnI+xEx2M9zrf0DEOxMCoNL5fJgACQRHYANRMlOa286TC+cOFb5IoAwC+TalAMhHiMvLI5DJnoAKcNUvO+GdJTgCneJ5/xZRbSLyMqZn4f1+2M0iahrE14UiMlVEHYvpX4gn+2N6N1GJHURkLwxBT5Kc93+YPgnLzxJRl4pIs4jcgc8P4f0ZEfW6iLwHmwfrgbEERcBTv5YVuh+VTNuOQblgvSRAAcB9IBgCmdYf4J7mfaj8D7AhMJbyCOhO9yVUMRN2MexoGDpu2RjvK0g6NUTqa1eWdHK0pFMbYXprvO8G21/SyV9IuvZYSadOl3TyQkxPk/rUzZi+X+pGPSLp1ExJj7pWGmovx/QfsPw3kk4eKelUGrYPPu+E980lnVxP0qlRsBVgeiRndfjeHHYADMJBrsL7n2FvwjpgLOUR2ExEPSiZ7FThiwSKJpB/AwqA/Iy4RrEEmttxlZnAVb+3a7Gbxnz9LPIfqIPXne7G6Hj3gh0Nuxg2E/YSTIsDbBpySac+hO9nYDfB/gA7FLYLbF3YUESzOqw/gfAJ5rMUTuA0iOmHpal9i8I34ZokkJ8ABUB+RlyjUAIt7RtLpu1uDD+fj02Gw1gGJ/AyFl8lkvuZVFWtiU6zFmZPB4/gyioDC4SVUO+6otQUUZKBvY3PLIMS8LYX5T0qTdnjB12NC0mgj0AhbxQAhVDiOvkJZLJH4R4yrvrVhPwrx3KN+cj6L33iaC9JVK2Ezn4j2KGSHn2D/HyN9yVOr3TqTalLNkpdqh72HenxkiKJ/cRTFwDDMzCWrxOogVg6p1dkt7Rt8PXFnEMCxRGgACiOF9fuj0Cm7XLMvgg2EsbSS0D9A28Yzle/Qce2kwyv1B3+trg3fxw6/ZkyeQ0OgwPQ/8qU2jmSHnWr1Cd/DT6bS0XPqiLeRAimM2EPY73/wlh6CagJklN/ksycn/R+5B8S+BqBwmZQABTGiWv1R6Bl7rd7r0ZEHdbf4vjN8+aKUlfCdpd0cg1JpzCcnzwLHdtDst+aC+LHo4yMJ435SNK190AwnQLbURIdtRgCnyxKbhFP9GhKGZVHYtNvieRuwfF3aiSyYRJGCFAAGMEeAaf6u/25ngdEcDUisX59jOybcZWKqzE1VuqSh8H0tx8wm8U3ApPX/UTqamdIXeqnUlE5VlTiEBHvHtSfg8W4qN9Jpv26GANg6v0QKHQWBUChpLjeVwRa5uyLD0/jBPw9vMexfI6kb0Knf5AsSHwHV/ppXKXehvcOzGcJmsDkNf8hdaOuwQjBROnp+Q7cHQXTv1WAtzgW72cYCXhOMq1rxzF75lw6AQqA0tnFc8vm7NGSy90au+Q9rxtDz3dJQh0slUp3+geg079ODhv1n9ixsCnhKWPehfD6I2wniIH1EdqJsCdhMSvq+6IqXpDmOfvFLHGm+zUChc+gACicFdfMtE1HJ6h/US4+LJSajZGOI6UyMVbqU3vK5OR0OSj5QXwAOJTplDGvQQicA9tGKip+AKF6uij1rkMZlBeq540QL3ezZLJ/KK8ibh0XAhQAcWnpcvK8+q2VcJ/xNRHVIHF5KXWbJGRPqUtuhaHmS2VSMit8uUNg0lrPScPoqbJi9YbS+7yAxGlU4ARpatPPR7jTXozUNwLFVEQBUAytOK6byW4k1dUfi3jRv9+vBMP56lJJVG6Kjv8nMjl1VxybPFI5T/jW/EXPC6S2EUlMFCW3RCq/gZJRaneMBLwtj3n6J5sHWovzY06AAiDmO8Cg6Te36yv+FwddJxoL/46O4WTJ4WoxnTxSJq/5t2ikxSyWIpAedY/0fosAtwdE/iiiov5bDGtLe3uXZN77gfAVEwLFpUkBUByv+Kzde7/fmx7thNUjyC8tyeSGUpc6W+q/PRefWaJOQN8eSKeOkkTFhkj1RFEKt7cwFdnS8zdpyh4S2fSYWMkEKABKRhfhDTNZ/ZO++uo/mkkqdZ14srOkkztIOtUs41V3NBNlVoMS0F8nTKfOkfZRG/b+yJBIdL9KqOQqae4d0RsUCRe6TaDY6CkAiiUW9fUzbfpHRbaNaJo3I6/NpS55kNSnHsA0CwmITFU50T8ylE7tJJ73ExFvtkTx5WFEL9OG/KKYHHMqhQAFQCnUorpNY+tUEfUzid7rCcmpvXG1vz/smeilx4x8I1Bfe5uka7eCCDgSdbbBIlbULZKZMyFiSTGdXgLF/6EAKJ5ZNLe4du4YSSSOiFZy3jsiucPR6f9IGpJ3Ris3ZhMogXTtpVLRszluFZ0NP9H6Pw5ejxY3SIsl7gQoAOK+ByzOv7tLnxS+ufij0++e9wWGcn8vic7NJT36CqdzYfDmCOh/SFSfOlly3uYIohkWjaLUDpLJ1kUjGWaxmEAp7xQApVCL2jaNbRuKqGhc/Ss1XXK5zaW+9lTR/0BG+CKBMgk01L6MUaQ0atkF9meY+0Wpw91PghmUS4ACoFyCUdheqcnup6Huwy2MHaUuebDon4R1PyFmYBuBdOrPEAJaBGgx8LJt4RUVj+eNk0zrgUVtw5UtJlBaaBQApXGLzlbXvb+GKJnkcEIviSQmSTq5u0we9bDDeTB0Vwjor44Or9wcx83JCHkezNGC48bRyBm2PwQoAPzh6G4t3Z0Y/pcVHU3gYsQ9XtKjrsU7Htt5kAAAEABJREFUCwmER2C/NRdIXUo/IDgeTmfCXCw/luveWd7FwBnz0gRK/UQBUCq5qGynKldwMBVc9ctekk4dDXP4CsxB8gx5aQLp1EvYB/fCzKNh7u2LXZXRePAX8FmKJ0ABUDyzaG2Ry63kWEJ9V/0pV6+6HMPNcAsikE4t2i9F3NovPUUBIK6/So+fAqB0dtHYMpf7hiOJ8KrfkYaKbZgujgYoj7cAYrvDilAAxLjxHUp90dVVOuXW1ZVDgBmqjwRcHQ3wEQGrCo9AOZ4oAMqhx22DJsCr/qAJs/5gCLg4GhAMCdZqMQEKAIsbJ5TQKhKfhuKneCe86i+eGbewjYDtowEJ9ZltyBhPMQTKW5cCoDx+7m/tyROWJfEvEbWP8Al/4SsiBL4aDTjJqow8798yOfmiVTExmFAJUACEittCZ/rkJDLXksielYqK3SWdvMOSeBgGCfhHIJ36gyz6b5t2XHWrhG3iX/gqjkC5a1MAlEswEtt7DxpPQ6nbpWLo7jJpreeMx+JqAM3vjZam1h2kac6+0tI+RTJtx8HOhF0umfbrpSl7P+wpac7+XTLZD2AL+kxPv4Hpp2F/gt0IuxJ2NuxE2C9h+8N2lkzr+nLJOzWuIjIedzp5g+RyuyOOV2GGi/eQ4QDo3jABCgDDDWCH+8oWo3EodZHUJfeVSat9ZDQOF5xnsqtJ83vbLOrg289FpzxzUYfe3i1ez7uiEg+Jyt0qOW+aiDoXdjLsMBHvQFGyC0z/i9t1RWQ12JA+09PrYHoz2M6w/WG/hJ0I0792dyXeb4T9SSTxiixX2QG/7bAHJdN2GfwfKZnszhAetViHJR+BhtGzJKFFgHdfvlUDXP62DDd83AeYXDyqLj9LCoDyGbpfQ3qtJ5GEqa/YHY3O/xj4Z1mSwNTXqmV66/bS2Dq19+q9uf1ZdLR66PgDdPR/WdTBe8dhkz3EE3ToXgWmwyyj4GxHEXU4/P9RRP4E4dEqTW1dEAOvw+6Upuw5eN9TWt5w9aemJbDX5NHvSbp2dwgyLa4CczNgxcqbIfrnjAdcgQviQIACIA6tXEiOKnG+KLWgkFV9Wmfxw376aX+fqnS4mivmrCCNbROlqe08dPRPyajhnVKReFgSidNEX73r/97mif0/2qJUJVrhu7A9RcnxeL9TckP+DSHwIuwiaW7fR/Q/oMICFhCoS2F0RsJ+OPCv0rPwEnhncZiAH6FTAPhBMQp11I2aLaL0kK+E8HpW4v6w37R31pBM20+kKXthb4c/NPepJNRdotSvcUW9eQhtELaLjeDwKPG826Sra65ksi9CDFwqmbaDpOX9sVgW3xLmw4Ge1w3QJ0rDOp/jnSXmBCgAYr4DLJV+3ahLRMmMpeb5/SHOD/u1tG+MDu/U3g6/snKuiLoFvI+OaIcveV4bQQz8n4iaIbmutySTfQ12sbTM2UHi+Arr4cCEnCjp1ONxRBytnP3JhgLAH47RqaUuNVlE3SpBvOL4sF9j23ekue1YdG6P4b79CyLqdzHt8CXP63tY/ivJ5R6STNsrGBk5S5rat8C8+JSGgB8OzOVOl7raC+IDlJnmI0ABkI9QHJenk/uJvyLgQ1FqitQl4/GwX9O7a6IDO1Qy2fskod4UT50vItsKXwUSUOuLwn1x5c0Gw6elqe0UvOtbCAVu7/Bqix8O9NSZvmahO/+G0VN9rZOVGSPgl2MKAL9IRq2eXhGQOBLDtO+WmdpM8RLbo/NvLLMeuzdveX9FacpOlkw7hvUr3kIHdgUC3hXGUh6BzUSpM1DFi2D7iGRaj5GW1rH4HO1SnzxFvNwEEe/5MhN9XPQva7LzF76+ToAC4OtMOGcxgfSoSyVXtSmGZU8XT15cPLvA93skkZiA+417Sf2ovxe4jXur6SH+TPZs3Md+TZQ044T9ExEZCmPxnYC3nUjiAskl3sKIQAaC60e+u7CpwvrR90q6dpwo7xDsV8UKgXvEUwfj+Bsv/GVNm1rVh1j8q4ICwD+W0axpypqfir56qE9tguHsTXrFQO/tAfX6ooS9j0V6px8XTy6BHYaOf0dJpybK5FH3SlRfLW0/lObsFZJQWhjpb0/oH9OJarY25lUHwfU42uAOaW6baGOAvsVUV3tNrxAQ2UtE/QZ2rYg8BVHwDt7niagvReRZGASoHCqV6lu9x199cjrmsZDAgAQoAAZEwwVfIzA5+WKvGEgn95N0cj1JpxROTKvIounxUp/6FexKdPwPf23bqMzIzNkRQ9HXS079FWLnUKTFq31AMFY8dIqeugtt8ohk5hxkLI4wHKdTM3GsnQWbJOnUljj2xuJ9BUknR0g69UNYGnaVHJT8IIxw6MMMAT+9UgD4SZN1RZeA/s6+fqhPcg/iyuvA6Cbqamb69kBuBm4NPC+ZtiOk8c3lXM2EcZNAWAQoAMIiTT9uEmhqm4IOZZaIukVEdoWx2E1gExF1iSRqXhT97YEb/rmS8EUCkSHgbyIUAP7yZG1RIaD/uU2m7WFRapqI2lL4co3AaLTdGdLZORsC7mDXgme8JBAGAQqAMCjThzsEMq1rS1P2agT8JxG1vfDlOoGxIuoatOn90vTudsIXCThMwO/QKQD8Jsr63CTgeUoy7ceJqNmi5BfCV7QIKNlFVMUjaONLpKV1rWglx2xIoDQCFAClceNWUSKQad9bWtpni3jniqiVha8IE/COEK9itmSyv4pwkkwtkgT8Tyrhf5WskQQcIdDYtqE0t10r4t0unkTxP/A50hAhh+l5a8DjxRABj0tT6+6YZiGBWBKgAIhlszNpnPxPk4SaLZ76OWnElsCPRCXuwb7QKNPaVo0tBSbuBIEggqQACIIq67SXQPM7o6UpewcCnAobDmMhgXqplAelsW0noiCBOBGgAIhTa8c915b2vcSrekCU7BV3FMx/WQJqA4wIPSBNbb9edgk/k4B5AsFEQAEQDFfWahuBxtapkvNw5e+Nti00xmMRAaXOk0z7DN4SsKhNGEpgBCgAAkPLiq0gsHjIP5E4zYp4GIQDBLyDeEvAgWaKUYhBpUoBEBRZ1mueAIf8zbeBsxHwloCzTcfACyZAAVAwKq7oFAEO+TvVXNYGy1sC1jZNfAILLlMKgODYsmYTBDLZb0im7TbhkL8J+hH12XdLINO2dUQTZFoxJUABENOGj2Ta184dI+LdJaL2Eb5IwFcCuCUgch/E5UG+VsvKSCAPgSAXUwAESZd1h0egpX1z6e5+VERtI3yRQCAE1HIiagZEwKnCFwlEgAAFQAQaMfYpNLdNlJz3FDisCWMhgYAJqN9JJtsYsBNWTwIiEiwECoBg+bL2oAk0tzWIpzDsH7Qj1k8CSxGohwh4ZKk5/EACjhGgAHCswRjuEgQy2YvR+U9fYg4nSSBMAttJpv1dmfpYZZhO6Ss+BILOlAIgaMKsPxgCzdm/oOJfwViWJvAhPj4h4jWK5+FedeJI8aRORPYSr2d7UYlxUlm5tlT0rCqrdg+Rz2HekFVEVYwRr/v7WG+8KG8P8RIHiajDReQkEXWpiDwAa4OxLEXAGy2jUh0y/d0xS83mBxJwgAAFgAONxBCXIdDU9jk6tbg/7PeyKHUdOJwGOgeI6hknuc7lJZ1aHfYjSddOkfra30t61KVSn2rBvJlSP+ZRqRv1vBy05rsyacxHsuvanXIkrH71j6VurVapX/sFrPe41NXeLfWjrpN08gpJp/4g6eSRkk7tDBstc9qrpEJ9F373FE8dJ+JNg//HYTlYTItXIRUV78iM98bFFADTDoRA8JUmgndBDyTgI4FM+2vo+Eb4WKMrVb0gnlwpicRPJNGxEjrjjaQueRA6999h+iapG/O8NKzzuQT9mjq+WyYl34Dfu6Q+eT6Exi/gf7zMSVZJLrE1BMFvMPKA0QI1P+hQrKu/p+dZmfHuKtbFxYBIYAACFAADgOFsCwlk2qajg/mehZEFEJL3N1R6MewASSxcQ9Kp70t96jCZPOo2mbzuJ5hvV5mqctIwahYEwVkYedhZhlesJCqxA0TLaQgUggB/41B6KpvkMa8yDqkyx2AJhFF7Igwn9EECZRPItO8tohok2q+XRLyzxFNboiPdFJ3+0bCbZPJ3/uFc2vutuUDqRj0C0aJHKHaWnLeOiDpWRB6FRbh4u0k2OzXCCTK1CBGgAIhQY0Y7Fe+ISOan5A3c0jhfcj3bobPfGB3/b6Q+qX/TIFrpNtS+JenkhZJObS8Jb0Px5GTkPStaSfZlo9QRMqN93b5PfCOBEgiEswkFQDic6aUcAk3tU7D5trDoFE+ukQrZWepS35W65HHSMOax6CSXJ5PJta9Ifeps5L21SO6HksudLqL+KdF5LS+5iArW6LQRMwEBCgBAYLGcgPImWh5h4eHpjl9/Fa8+dYhMSsXn3vhAhNKjn5WG0VOlUsZJlISAJwfK1a0jB0qb80lgMAJhLaMACIs0/ZRG4Nr21bHhBJjbZcmOX38Vz+1s/I/+oOQHERMCI6VaRUe4+t/irNECAhQAFjQCQxiEQLe3xyBL7V/Ejr+4NoqWEHB73y2u5bi2bwTCq4gCIDzW9FQage+UtpnxrVpk8VA/r/iLb4wlhUDvNyO8L4qvxPQWarTpCOifBAYjQAEwGB0us4HAKjYEUUQM94snO0s6VSfs+IvANsCqWgika38jiYrNRMk1A6xl6Wy1sqWBMSyLCYQZGgVAmLTpqxQCjpxEvWdFqZ+j499N6vlwXykNPeg2daNel7rUIVhnvCi5E+8OlJxr4tUBpgzRTwIUAH7SZF1BEKgKolLf6lSSRV1Hy5zUZlKXvB7TLEESSKcel7rU3qJ/EtnzLP8dAWX3vhtkO7HuEgmEuxkFQLi86S1aBK6WxNDNJJ26WPRP4QpfoRHQP4lcX7u1iHd8aD7piAQiRoACIGINynRCIKBUt3jyK3T8v5RJq30Ugke6GIhAuvY8EbWbiLwFYyEBpwmEHTwFQNjE6a9IAt5DRW4Q9OqviKidcZ//EuHLDgLp5P0IZGfxxLJnA9RsxMVCAtYSoACwtmkYWC+BnNzX+27DH6VulIXo/PU/ubEhHsbwFYF0qh2ibG9R6vdfzTQ85Xl3G46A7p0iEH6wFADhM6fHYgg01L6M1f8KM1s871SpSx4ohyQ/MBsIvQ9KoC55qni5A0WJ+XbyvLsGjZULScAwgYRh/3RPAgUQ8Mw9Xa/kI1G5faW+1p4rywKIxXqV+tE3ivJ2FvHMDcF73gzR/wEx1g3B5IshYGJdCgAT1OmzOAJVPS3YQH/dDm+hlhfQkUyQutG3h+qVzsonoP/joKjdUdFNMAMlofdZA37pkgQKJ0ABUDgrrmmKwM/X/q/kcjNCdn+XVKIDmVz7t5D90p1fBNKpeZJOHSCizpMwX0rdJvXJR8N0SV+uEzATPwWAGe70WiyBhtFTsckDsOCLUpeh49hT9M/QBu+NHoImkE4eL/prm0H70fUreVt6htfrSRoJ2E6AAsD2FswWFrgAABAASURBVGJ8XxFIp3BfV/771YxApk6UuuQRgdTMSs0RqE9dIjm1N4TAvwINotvbSRpW/jxQH6w8cgRMJUQBYIo8/ZZGIJ0aKaJeF/9fn4qon+HK/xzhK5oEGpJ3ilehnwsI6lsl42VK7ZxowmNWUSRAARDFVo16TunkeiLqVvHv9VdcGe4q6eQN/lXJmqwk0LDWc9JTuauI5+c3S/6BXMeL/j8FmGAhgeIImFubAsAce3ouh0A6uZ943pmoorxbAp5c09sh1KeCuipEiCxWEZiy5qeSrv255HKni6h/SnmvZun2IB5Tj5dXDbcmgfAJUACEz5we/SJQX3uKVKjNRMmVqPIzWOFFd/wqMU7qU4eI7hAK35JrRoWAfrC0UsaVJgS8eySR2BFX/Wk5uPaVqCBhHuETMOmRAsAkffoun8Ck5BtSlzpMFuZGYVh3Ekx/Z/8lEYVhWa9LROZh3jsi8pQodT6G+veUXMW3ezv+ulHPYz5LnAnob3poIbCw57siud2wj+hRJVzNq9dFvI8XodHv+rM8LjlviiSwr6VrJ8rkUQ8LXyTgMAEKAIcbj6EvQeCQ0Z9hWPda2L64KttY0sk1MF0t6dQKeB+L9y2lLnkcOv67pGGtcod9l3DMyUgQ6N1/Rt+PfeQU7Cu4n59cD/vNKphWi97159R4aahtlMmj34tEzkzCAgJmQ6AAMMuf3kmABEiABEjACAEKACPY6ZQESIAESCDuBEznTwFgugXonwT8JnD1WytJpm1HacoeL5nsjZJpmyWZ7PP4/He8Z2Efwj6DLewzPf0Bptsk0/6aNLc/K5m2JzB9jTRnD5VMdjO5/50av8NkfSRAAmYJUACY5U/vJFA+gZb2jaWxdao0td0lmbb3pLr6YxH1oCjRP2q0P6a3FJFN8HldvCdhq8KWh1X1mZ5eDdMpEe974nnjRNTWmD5YPLlCRJ6Wf1V2QBC8DrsOdphc27465rOQAAmUTMD8hhQA5tuAEZBA8QT0FX6m7RJ0+u9IzntBEonTRKmJImpNCezlfVfE+xnscun2/imZ7GPSPOdIaZqD+YE5ZcUkQAIBEaAACAgsqyUB3wk0z9lSFnf6+gpf1BHo9Mf47qfwCrcVL/dHUbnXpbn9yd5RiGvnmoyn8Mi5JgkYJmCDewoAG1qBMZDAYASasj9Fx383OttZYr7Tl35fnrdV7yhEd/cr0tw2TTLZbftdjzNJgASsIUABYE1TMBASWILAtLZVca/9GHSkz4uSm0TUBHHjNVQ8NQWh4vZA9n6MDOCWAT6xkAAJLEHAjkkKADvagVGQwFcEmrJHSqV6FvfaL8DMTWBuFk92Ec+7DiJmtjS+u5ebSTBqEoguAQqA6LYtM3ONQKZ9V2nOPoor/j8i9AAf5kPt4ZYtJFFxhzRlWyTTun64rumNBOwjYEtEFAC2tATjiC+BltaxGO6/Blf894kn4yMLQskkETUbuZ4qt8wdKnyRAAkYJUABYBQ/nceeQHP74dKDTlG8g+PBQi0HofM7+aJbC4Fd45EzsySBJQnYM00BYE9bMJI4EWh569u9Q+Ked5kotVKcUu/NVcnGEAL3SWPr1N7P/EMCJBA6AQqA0JHTYewJ6AfictUPS++QeMxp6B8wymQhBNo2jDkJph8TAjalSQFgU2swlugTaM6e1ftAnMg60U+24Ax3hRh6WDJtMbkNUjAXrkgCgRKgAAgULysngSUI6H/M48lJS8zh5GICvbdB1DXS1P77xbP4TgLRI2BXRhQAdrUHo4kqgaZsE1LbH8YyGAHl/UaashcOtgqXkQAJ+EOAAsAfjqyFBAYmkMk2Y4g7PfAKXLIUASVHQwRctdQ8fiCBCBCwLQUKANtahPFEi0AmeycSmgxjKYaAkkMk065/CbGYrbguCZBAEQQoAIqAxVVJoCgCmfZHsP6eMJaSCHjH8GuCJYHjRlYSsC8oCgD72oQRRYFAc/s9It52UUjFaA76a4JNbfsajYHOSSCiBCgAItqwTMsggaa2FvG83Q1GEC3XSt0qTe0UU9Fq1dhlY2PCFAA2tgpjcpeA/hqbUpPcTcDSyJX3iDS2b25pdAyLBJwkQAHgZLMxaCsJZLK/FP01NiuDi0BQCblNMtmNIpAJU4gdATsTpgCws10YlWsEmrKbIuQrYSyBEfC+haob5ernqvDOQgIkUCYBCoAyAXJzEugloLwjet/5J2gCm0j1SmQdNGXW7ysBWyujALC1ZRiXOwQa23cRUT8TvkIiALE1rW3VkJzRDQlElgAFQGSblomFRkDl6kLzRUeaQFKqZIqeoJGA/QTsjZACwN62YWQuEMi0ri1K7edCqJGK0eM3LSLVnkzGCAEKACPY6TQ6BCp49W+mMcdK83sTzbimVxIonIDNa1IA2Nw6jM0BAt6ODgQZzRC93FbRTIxZkUA4BCgAwuFML9ElsHJ0U7M9M4/sbW+i2MdnNwAKALvbh9FZT0CxEzLXRquYc03PJOA+AQoA99uQGRgl4A036j7ezofFO31mbzsB2+OjALC9hRgfCZRNwHteRP1GPO9gyXl7SIVsJhWqViqGjpD5Xy4nqnuMeGpLSai9ReRQyeVOF1GtwhcJkECkCVAARLp5mVx8CXhzRanLRCXGSboWljxL6munS0Pt3TIp9VeZlMzKpNW+lMPX+0Lq1m6V+uRTMjl5p6RTV0nD6KmSTo4Bu/Gwq1DPF3hnIQESKIqA/StTANjfRozQbgL/sSy8xxHPAej015K65BFSNwpX/5hTSkmnHpd0CiMCNbUi6nARaRebXp73X5vCYSwk4BoBCgDXWozx2kbgQYsCwpV7ajw67Zt8jal+9Y8lnbwCdeoRgWa8W1LUbEsCYRgk8DUCLsygAHChlRijvQSUPGVBcPqqX3f8uHcfYDTpVLukU2l40GZ+NCDRQwGAxmAhgVIJUACUSo7bkYAm0JMzKwD0A3vplO78tQjQEQVv6ZQeBRgvntwZvLMBPbwsdWMoAAbEwwVmCbjhnQLAjXZilLYSaBj9nIi6QUy8dOevH9gz4VuPBtSn9halZplwL0pajPilUxKIEAEKgAg1JlMxRMDzZoTuWanf9z6tH7rjZRzWJbfGnLdh4RXPe19UVfjMw8uQnhwn4Er4FACutBTjtJdAfeoBEa8xtACVuk7qkqeG5i+fo3TqO1hlHiycUlFxkkxe45NwnNELCUSXAAVAdNuWmYVJIF07RUS9LkG/PHkanf9BQbspuv50aoWityltg6Nl8qjrStuUW5FAGATc8UEB4E5bMVLbCaST6yHEDlhABQKjPrVFQJWXX22u4tvlVzJIDZ43S9KpiwdZg4tIgASKIEABUAQsrkoCeQlUda8qSgK4J47OP1H5o7z+Ta7QsNY/pccLKsbHpb5WP29gMkP6JoG8BFxagQLApdZirPYT+Pna/xVPfoxAX4L5VNQNUiETnLjvPaX2CfHU9hBBT/uUPKrxbseVv/4RIkyzkAAJ+EWAAsAvkqyHBBYT0F+Ry43YBh/PgZVT5oh4R0o6+TPRv91fTk1hbluffFSGVW4vnlwEIbCgDNf/FMkdLunafcuog5uSQIgE3HJFAeBWezFaVwg0rPy5pFMnir4aFrkJYc+HFVoeFfF+IbkR66Pzu7TQjaxab781F0h96hiRivVFqVNgrxUeX+9/IvyjqIptJD1a/wRx4ZtyTRIggYIJUAAUjIorkkAJBPTVcDp1gCysWRlbH4COXXdoj+P9Y3yGKPDmiicviqjb0UlOES/xPQiH7SVdO020iBDHX3VrtUpd8kzY+shED+NPxfvj4nmvId8PMN0F0z8rfL+IOk9UYitJJ8dIOnWU6G2FLxJwh4BrkVIAuNZijNdNAod8az46tZvQsWNIOzUe76vg83C8r4Ur5U0kndwXnWSj1I/6u5sJFhB1OvW4pFOnw8ZLfe36yPdbmK6GpWC7STp5vNSN4s/7FoCSq5CAHwQSflTCOkiABEiABEgg3gTcy54CwL02Y8QkQAIkQAIkUDYBCoCyEbICEiABEiCBuBNwMX8KABdbjTGTAAmQAAmQQJkEKADKBMjNSYAESIAE4k7AzfwpANxsN0ZNAiRAAiRAAmURoAAoCx83JgESIAESiDsBV/OnAHC15Rg3CZAACZAACZRBgAKgDHjclARIgARIIO4E3M2fAsDdtmPkJEACJEACJFAyAQqAktFxQxIgARIggbgTcDl/CgCXW4+xkwAJkAAJkECJBCgASgTHzUiABEiABOJOwO38KQDcbj9GTwIkQAIkQAIlEaAAKAkbNyIBEiABEog7AdfzpwBwvQUZf6wJeJ439PPPP18Z78nOzs71Fi5cuFlHR8cO3d3de+Dzz/D5EHw+FtOndXV1nYvPV8Bm4PMd+PxAn92OeS2wyzH/HMw7BdNHwabg8/7YfvcFCxZsi8/jPM/7DuzbsJGwiljDZ/Ik4DgBCgDHG5DhR58AOtpqdMQbwPaD/RYd8fWw52FforOeX1NT8xHes0qpV0Hj6UQi8VAul5uJz9fh81X4fD6mp6Ke4/D5UNhB+LwXPu/UZ3tj3iTYYZh/POadgemLYNPw+UZsf09FRcVj+Pws/LwJex82D9YNm4s4HoVdjelf9wmP76KOKqzPQgIRJuB+ahQA7rchM4gIAVzJr4JOdBt0pr/A+wWw+zDdivdOdMQvw26GnY50D4RtAhsGM1rQ0a+BAMbDfoHp8/qEx+uIGaEvzOLPg7DLYUdBHOyG0YSxWE9hfRYSIAHDBCgADDcA3ceTADrEjdAZ6mH2RkzPhn2CK/l/oXP8C4hcjfdjYLtiuhbmakki8B1hh8Eugji4F6MJb0Ec5JDvO3i/s4/BRljOQgJOEYhCsBQAUWhF5mA9AXR443Rnpzs9TP8HAb+IzlAPs9djegvYN2FxKmMgcPbsY/CiZqLZaEaY/mGcQDBXEjBFgALAFHn6jSyB5557rmr+/PlboTM7Vndq6NB0h/+s7ux0p4fEvwFjWZrANzQbzQiz/6qZaXawX8O2xrJqzGchAUsIRCMMCoBotCOzMEgAndMIdFLbw06G3bXBBht8VFlZ+SQ6s/OxbE+Exg4fEIosvYIA/M6DPQGu/+rs7LwHdgqE1Y6ffPLJ8kXWx9VJgASWIUABsAwQfiSBQgigU1oZV6kHo2O6r7u7ey4+Pww7EzYR27PDBwSfyzeUUrvDzoCwenC55ZZrA/8MBMHeesTFZ1+sjgQGJRCVhRQAUWlJ5hEKAVx97o6OZzo6/jfg8Bp0+LvC2OEDRshlRfirgyC4HSMub6JNLkabbI95LCRAAgUSoAAoEBRXiy8BdC6boHP5Hd5fwdXnPSDRANMdEN5YLCCgvynxKwixh9FGL6CtTsf7OAviYgiRJBCdpCgAotOWzMRHAl9++eXq6EQOxRDzA6j2eXQup+J9fRiL3QQ2Rlv9FiE+i/Z7HCM2x8LG4jMLCZDAMgQoAJYBwo/xJoD7+Xug48j70iOPAAAQAElEQVRUVVXpIf4rMMS8U7yJOJ39jzBicz5M/3rhXWjXKV988cWqTmfE4I0TiFIAFABRak3mUhIBdAzfx5X+WXj/ey6Xm4lK6mAjYSzRIKAwKqAfzpxWU1Ojnxe4Bm29aTRSYxYkUDoBCoDS2XFLxwngXvGW6AiakMZzuNI/Ce/rwlgiTABCQD+weTBSfAZt34J9YBtMs5BAgQSitRoFQLTak9kUQAAn/e1w8r8encEsrJ6GscSTwCTsA3/B6M/NHR0dvNUTz30g1llTAMS6+eOVPO7v74LO/zac9B9B5vof6uCNJe4EMPqzXyKR0P8aeSb2kQlx58H8ByYQtSUUAFFrUebzNQK4wtsLdi/u79+Pzn+fr63AGSQAAtg39sA+cjdE4p8gBPbFLBYSiDQBCoBIN2+8k0Onvz+G+h/CFd4dsN3iTYPZF0oAQmBnCIFbse88hn3o54Vux/WiTiB6+VEARK9NY58Rrt4m4yruCXT6NwLGDjAWEiiFwLbYh66FEHgKpn/8qZQ6uA0JWEuAAsDapmFgxRLASboe9jdcvTXjKm7rYrfn+iQwAIHNMX869q3ZEJf6nzvhI0vcCEQxXwqAKLZqzHLC1f7mGKrV399vROo/gLGQQBAEtoC4vBNCoBn723pBOGCdJBAmAQqAMGnTl68E5s2btwJOxGfjan8Whmr38LVyVkYCAxOYnEgkZmHfOwX7Xs3Aq3FJdAhEMxMKgGi2a+SzwlXYpGHDhj2Jjv9EJMv9GBBYwiOAjn8k9r0zMPqkbwv8NDzP9EQC/hHgidM/lqwpBALo+H+IK6/b4KoF9j0YCwmYJPB93Ba4CfvkTdg3v28yEPoOjkBUa6YAiGrLRiwvXHEth6utM3DVpa/6+V3+iLWv6+lgv9SjALP1Pvrpp5/y/0i43qAxiZ8CICYN7XKauLr6GU6ssyAC9D3XapdzYeyRJlCj99ERI0bMwmjA5EhnGqvkopssBUB029b5zHAS3QR2E66urkMyG8BYSMAFAvobAvqbAndCuG7hQsCMMZ4EKADi2e7WZ40T52kIUv+zHj20ikkWEnCLAITrnhgRmN3R0XGcW5Ez2iUJRHmaAiDKretgbgsWLEhhyP92nDinIvyhMBYScJpAIpE4FyNZ12GfXt3pRBh85AhQAESuSd1NqLu7e2JFRcUDuHLa290sGDkJ9EtAP8fyIEYDdul3KWdaSiDaYVEARLt9nckOV/2n5HK5uxDw2jAWEogigfUwGnA/bm/p366IYn7MyTECFACONVjUwsWw6JoYHr0ZV/1nRC035kMC/RHAPn82BO9NeF+zv+WcZw+BqEdCARD1FrY4PwyH7oaroQcQ4n4wltIJdGPT1yCiHkKncjfsJnxugl2Geefi8+mwE/D5CFgDrkIPgO2BEZedtGGZfljtQCybAjsSn0+E/Q52Pj5fAdP/XOkWfL4X04/CsjCWMgigXX6Kff9B3PbavYxquCkJlEWAAqAsfNy4VAI4+Z2ITkh3KOuWWkfctkOn8Qlyng1rxPRx4Dehqqpq7erq6irY+pjeqaamZg/YAfjcADsC807A56mwc/H5MlhTZWXlTbC7hwwZ8pA2LLsLdiOWNcIuxfQ5sNNgx+Hz4bA0pn8Km4Dp7WG1qHcY4hiHGA6CMND/j0Hfvnkb81gKJ7AOBNg9GA04pfBNuGZ4BKLviQIg+m1sVYboLFbHkP/1eD/bqsDsCua/6ODvR0gXwn6B6W3Q4a4CWwmd71awKZg+H534vVj2LtYJvcDvAsTxPGK4DsLgZNie+PwdxFWFtt0Qtj/sd1jvVrxzxGCQFgIj/T8FbtXfgBlkNS4iAd8JUAD4jpQVDkQAQ/4/Ruf/IJbr4Wa8sfQR6EYn+SBMPxz2A3SkI9GR7ob3Y2HTMK1//vjjvnWtfkNn1g0x8ArsZthpiH0/vOsRgzWRn273K/H+utVJGAgOTPbFaIq+JbCnAfd02Q+BOMyiAIhDK1uQI4b8f40T3J/RQehfSbMgIuMh6J821v/bYCd0ksuhk/wx7Bx0+M8ZjyyAANDu7yM/fZvhMLyvh5y1INDPflwEd3+Dxb6A0RjcErgTtwT0b2DEngcBBE+AAiB4xrH3gKv+P+IK57yYg3gF+V8BDgd0d3evgY5+a3SEv0VH+BBO/B1YFquCnLUguBUcjoFtCg4UBH17ANichmNGP3zZN4dv4ROIh0cKgHi0s7EscSLTT6QfaSwAs47fRId/Ljp8fd9+Q3R0h6PTv2nYsGH/MBuWfd7R6S0lCPB5W5h+BsLIMw4WEDoUIwG3WxAHQ4gwAQqACDeuydTQ8S2Pzv8xxBCr3/JHp/URcp6OodyJ6PDXRYd/Ajp8/eQ+ZrMUSgAjAn+BHQtbB/uS/vfPLdj2P7DYFOxLe+PW2ZPI/5uxSdqSROMSBgVAXFo6xDw7OjrG4sT1DFxuC4tD6cHJ+g4kWldZWbkOOv6DhwwZcg8+s5RJAFx7IKLuANM6XBGvg+oOxrzYsEXnv5U+lpA7vy6LxmfxlwAFgL88Y18bTlZbJxIJ3fnH4YT1F1zpHwtbB1eq+6CTakHnFKur1DB3+OWWW+4jMJ4O1hPRMa4L1ifA4jC6sjbyfGbBggVxEdRh7lb9+IrPLAqA+LR14JniKmVfnJifgKMVYFEt85HY5bBN0Rltiyv9C2FxvU8NDGYKRgXehBA4F7YVOkf9D3ZuMRNJaF6Xr6ioeKy7u1t/cyI0p3QUbQIUANFu39Cyw/3+w3EivjU0hyE7grD5EPmdjav9jdHx/x+MX10LuQ0GcgcR8Ge0x0/ROW6FdabDemCRLNj/bsaxpn/SOZL52ZBUnGKgAIhTaweUK4b9f4eqL4NFsbyNzv9kdDAbo6M5GVf7/LlbS1tZP2yJdjoY7bUxxJr+BkFUb8dcgtG231vaDAzLIQIUAA41lo2h4mrkGpxwT7UxtjJj0j/I83/o9DfGcPPZ6FA+LLM+bh4SAbTXq2i3Y3t6ejbGvnk63M6BRapgf/yNPvYilZQVycQrCAqAeLW3r9niKkT/A5iDfa3UfGX6q4uTcCWpf5L3cpxo9T1/81ExgqIJDB06dA7EwFSIgY0xdH4sKngVFqVyMEbf9DEYpZyYS4gEKABChB0lV+j89T+imRihnB5JJBL6H9psh87/2gjlFftUIOL+g1s3F2ohABhHYFTgfbxHoiCXiRABd0ciGQuSiFsIFABxa3Ef8sXQ4xU4qe7mQ1XGq0AeH+urQ3T6O1RWVvJqyniLBBcA2roH7XwZ2ls/LBiZn9qFCJgAEaD/p0Jw8FhzJAlQAESyWYNLCica/R/rDg3OQ6g1t6DT31pfHYbqlc6MEtC3BiAEDocQ0F8f1Ld8jMbjh3OIgKMgzPntgLJgxm9jCoD4tXnJGWPY/0CcaM4uuQJ7NnwRefwUnUAdrgrfsicsRhImAQg//fXB7SAEjsF+EIWHPC/p7u6OxMhcmPtBnH1RAMS59YvIXZ9YcJK8vohNbFw1hxzOnDdv3jY1NTVR/+EYG/lbGROEwEUYCdK3BaZZGWARQUHM3ItROp1LEVtxVU0gjkYBEMdWLzJn/ROk+sRS5GZWrY6O/x7Y1lVVVaesssoqX1gVHIMxTgD7RitGhH6RSCQmIJhZMGcLRreexGjdBs4mwMBDI0ABEBpqNx3hvuI4/ROkbkYvgpPhe4j9UHT8E2FPYZqFBAYkgJGAeyEEtoYgOB7mrFBE7LMg3EcNmCgXLEMgnh8pAOLZ7gVljasI/Q99Hi5oZQtXQud/J0x/re8qC8NjSBYTgFg8D+H9GOaqaFwOwn0m9v9vIAcWEuiXAAVAv1g4c/78+WviKuJmkBgJc67gxHc67vPvjfu7rc4Fz4CtIAAR8NS8efO0CHBVQG6EEbxmHAvKCqAWBxHX0CgA4tryg+SNE8YKGAqdgVXWh7lWWnEfd290/lNdC5zx2kdAPy+CWwL6a6+HQhA7d0sAMe/R1dXVbB9ZRmQDAQoAG1rBohjQ+VfjqkH/Et62FoVVUCiI/c5cLvdjiJc7C9qAK5FAgQQgAvQogB4NcPGWwCQc05cUmGoMV4tvyhQA8W37fjPH1cJ0XDU4911idP4c8u+3RTnTLwKO3xI4Asf2GX6xYD3RIEABEI129CWLjo6OY1DRQTCXCof8XWotx2N1+ZYARPIpnZ2dBzjeBL6HH+cKKQDi3PpL5I6rg/G4d37OErOsn8QJjUP+1rdSNAN0+JbAHyD0x0azVZhVsQQoAIolFsH1582btwI603ORWiXMiYJ4OeTvREtFN8glbgk48wuZuL23VkVFRRR+ztunHSve1VAAxLv9e7MfNmyYvvIf1/vBgT84iZ3Ap/wdaKgYhNh3S+DnGD270pV0IZ73xojfya7EyziDI0ABEBxbJ2peuHDhYQj0YJgr5QhceenRClfiZZwxIFBZWXkYOlZn9kvEeiZuBehvNcSgdQZOMe5LKABivAfgKmALpO/MSQuxTsG918vwzkIC1hHAqNQJ6FhPsS6wAQLCqMXZiHfFARZzdgwIUADEoJH7SxEH/lDM10P/w/Fue8nhZLU7Ov9G2wNlfPEmABFwJggcAnOhbIyLgD+4EGgwMbJWCoCY7gM48M+FCNjKgfS/QJwbYYj1PgdiZYgkIBCq1yiltncExRTcBvylI7EyTJ8JUAD4DNSF6nDANyDO/4NZXXAS/Qj3+9fAVdWrVgfK4EhgGQLYbx/t6elJYh/+fJlF1n1EjGfjnODMQ8B+AWQ9IhQAMdsLcKBvggNeD/1bnTmu+ufgJLoqYv3M6kAZHAkMQGDo0KF6H14e+/I/B1jFitmIT//HwD/gXVkREIMIjQAFQGiozTvCAa7bWw/92/7gzyxc9SfNE2MEJFA+AezL30Yts2E2l+1xcRCj5wFsborwYtMdQnje6MkoAX3fHwHYfm/yedxD3RpxspBAZAhgn9bP2zxvc0IYbTu+u7v7JzbHyNj8JUAB4C9Pa2tD578jgjsWZm3BCMW7OFHyXqS1LcTAyiHQt2+/U04dQW+by+X0rYC1gvZjun76X0SAAmARh8j/Red6gs1J4urjI5wgv2tzjIyNBMolUFVVpffxf5VbT4Db1+Ji4aQA62fVFhGgALCoMYIKBff2jkTdNg/9dyLGjSACuhAnCwlElgD28W7s6xsiwQUwW8svOzo6JtoaXPlxsYbFBCgAFpOI6Duu/PVXkY63OT3EOG748OEf2BwjYyMBvwiMGDHiX3qf96u+IOpJJBInPffcc1VB1M067SFAAWBPWwQSCYbz9M+T6qeQA6m/3Ep7enrG19TUvFZuPdyeBFwigH3+7xgN2MbimDdbf/31I3krwGLmoYdGARA68vAcdnd37wJv1v7KF64y9h06dOjjiJGFBGJHoKqq6kmMBOxla+IQKCfhdgUfyrW1gXyIiwLAB4i2VpHL5Wwe+v9lZWXl7bayY1wkEAYBjATMhJ8pMBvLEC0CbAysZMv0KwAAEABJREFU9Ji45ZIEKACWpBGh6Y6OjmOQzrYw6wquek6prq6+2rrAGBAJGCCAY6ERHa2V39LBsbo3RgFsFSgGWitaLikAotWevdmg8x+D4XVbr/6bcdWj/2Nab6z8QwIkIILbAfrfcl9jKYuT5s+fb+1zRMUw47pLE0gs/ZGfokCgr/Nf1cJcnl2wYIHVP0ZkITOGFBMCEAF6FOA5C9Otxe06PhBoYcOUGxIFQLkELdseV/8TENLBMKsKhji/hB0zcuTIT60KjMGQgCUEcHzMg2kRkLMkpCXDOLy7u3vXJWe4N82IlyVAAbAsEcc/9139W5cF7iUeiyucWdYFxoBIwCICOEYe7RMBFkW1KBQcwyfB+B8DF+GIxF8KgEg046Ikurq6jsOU/qcjeLOqXFLNh/6sahAGYy8BiIDzEd2NMKsKOv+tMArg7K0Aq2BaEgwFgCUNUW4YODhXy+VyR5VbTwDbPzJ79mze9w8ALKuMLgF0tCciu7dgVhWcZ/RvA2xsVVAMpmQCFAAlo7Nrw4ULFx6MocNv2RQV4vkAJ4xjxo8f321TXIyFBGwnMGzYsPdw7GgRYFuoIxBQPcyxwnD7I0AB0B8Vx+bhRLESOlvrvquLEYlja2pqXnEMJ8MlASsI4NiZiWP7DCuCWSIInGsmdXR01C4xi5OOEqAAcLThlgwbw4X6qf+1lpxnehonrt/jBGbdfUzTXOifBIohgGPotziW7itmm6DXRTzLV1RUTAraj5/1s67+CVAA9M/Fmbnz5s1bAQekVVf/iOdunLhOdQYiAyUBuwmcgGPKqv+WiXgmw0bajY3R5SNAAZCPkOXLhw8frjt/q4bjEonEBZZjY3gk4AwBiOnXMex+imUBJ7u6uiZbFtMA4XD2QAQoAAYi48B8KPDlcJ9dD//bFO0lVVVVT9gUEGMhAdcJVFdXN0EE6H8cZFMqFAA2tUYJsVAAlADNlk06Ozv1k/9r2xIPTlDvd3d38+rflgZhHFEjoP9fQM6ipDbBOejnFsXTbyicOTABCoCB2Vi9BFf/QzHUrof/rYmzp6fnQv31JWsCYiAkECECGFl7GiL7HJtSQjwcBbCpQYqMhQKgSGC2rI77b3rof11b4kEcs4YMGXIR3llIgAQCIlBZWalHAV4PqPpSqt2ho6PD4v8RUEpK8dmGAsDBtn7ttdeqEbZVV/8YjeDQPxqFhQSCJIAr7nk41qwaBUA8/EpgkI0eYN0UAAHCDarqsWPH6s5//aDqL6He63BlYtsDSiWkwU1IwH4CONauxS3A2yyK9Kfz58/fzKJ4/hcKJwYnQAEwOB/rluLA122mh/9tiW0BAuHVPyCwkEBYBDASoEcBOsPyl88PRAlHAfJBsnC57kwsDIshDUQA9/711f9GAy0Pez4EyQXV1dUvhe2X/kggzgRwzD2HY08/D2ALBv3DQNZ8I2kRFP7NR4ACIB8hy5ZD+e9jS0g4Ab2BExGv/m1pEMYRKwI49vQogC3ie9jChQv5jQDH9kAKAIcarLOzcwN0ujvZEjLEyMWwebbEwzhIIE4EcOx9ifOBTaMAByCeKlvagHHkJ0ABkJ+RNWskEokJ1gQj8jyuQK6xKB6GQgKxI1BTU3MjOt0/25A4BEktRgEm2hALYyiMAAVAYZysWAsHuk0CgJ2/FXsFgyABydjCACLAEgFgCxG746AAsLt9/hfdggULtsaHTWE2FF7929AKjIEEQACjALeg452NSRvKRFyorGpDIIwhPwEKgPyMrFjDsuF/Xv1bsVcwCBJYRACdbvOiKeN/v9HV1WV8FMA4BUcCoABwpKEQpi3D/7z6R2OwkIBNBKqqqvRtgFdtiAliZA8b4mAM+QlQAORnZHyN7u7u3TDEt47xQBYFwKv/RRz4lwSsIYDzQ08ul7NiFACx7NbZ2fldc3DouVACFACFkjK4Hg5sXv0b5E/XJOACgZqaGj0KMMeGWHHLkrcBbGiIPDFQAOQBZHoxhtOWg6K2RQDw6t/0DkH/JDAAAZwn/gPTImCANcKbjfOWMQEQXpbue6IAsLwNFy5cOAEH07csCJP3/i1oBIZAAoMRwO1CfRvgP4OtE9Kyzbu6urYKyRfdlEiAAqBEcGFtBkXPq/+wYNMPCThOYOjQoXNwzrBiFAC3Lg08DOh4A4YcPgVAyMCLcTd//vw1sL4NAuAt/uofWoKFBBwggI5XjwL0mA4VQkT/JoAyHQf9D0yAAmBgNsaXVFZW6s5/uOlAcAvibtMx0D8JkEBhBGpqavTXAW8obO1A1xrb09MT6rMAgWYTwcopACxuVHS8WgAYjzCRSFAAGG8FBkAChRPAucOKYxajERQAhTdb6GtSAISOvDCHOIBXwBCa/vnfwjYIbq2nq6qqZgVXPWsmARLwmwBu2d2Nc0jW73qLrQ/nMH0bYGSx25W2PrcqlgAFQLHEQlq/s7NTP0E7IiR3A7rBAXzXgAu5gARIwEoCOG4XwoyPAkCErITbAPpcZiWnuAdFAWDpHoCDd0sbQqusrDR+ErGBA2MgAdcI4BxihXgPSwC41j42xEsBYEMr9BMDDl7jAgAx3At7o5/wOIsESMByArh19xhCfA5mtOAcwhEAoy0wsHMKgIHZGFuCYbOV4dy4AEAcvPpHQ7CQgKsE0PnacAxv9eWXX64eLEPWXgoBCoBSqAW8zcKFC8fDhenvz87DFYQNJw+gYCEBEiiFgC0iHrcS9TmtlBS4TYAEKAAChFtq1VDtNjz9fzfi+FepOXA7EiAB8wSqq6tfhgh40HQkOJcEehvAdH6u+qcAsLPlOPxvZ7swKhJwjgA6XxtG8igALNxzKAAsaxSodX2vbGOTYSGGNlw52HDSMImBvkkgEgS6u7v1sTzfcDLrL1iwIBVMDKy1VAIUAKWSC2i7vvv/AdVeWLW4YngU1lXY2lyLBEjAZgLDhg2bC1GvRYDRMCsqKrYzGgCdf40ABcDXkJidgY7XhodlZpulQO8kQAJ+EsB55RE/6yulLoiQQARAKbFwm0UEKAAWcbDp7zamg8nlcvzpX9ONQP8k4CMBdL7P+FhdSVVBhPA5gJLIBbcRBUBwbIuuGQfpmthoLMxkeX7IkCHvmgyAvkmABPwlUFNT8xrOL2/5W2vRta3V2dm5btFbDboBF5ZDgAKgHHo+b9vV1WXD8P9TPqfF6kiABCwggCtwG0YBeBvAgn1hcQgUAItJ2PFuXADgKuEJO1AwChIgAZ8JGBcAOL/4KgB85hO76igA7GrycYbD8b788suHDMdA9yRAAgEQQOf7lwCqLapKjEJQABRFLNiVKQCC5Vts7abvj83+5je/+VmxQXN9EiAB+wnU1NTof+zVajjSb8yfP38Nf2JgLeUSoAAol6BP20Odr42qKmDGCtT548ac0zEJkEDgBHCe+WvgTvI4qKqq0ue6PGtxcRgEKADCoFyAD0uejuXwfwFtxVVIwFUCEPn6XwQbDR8ixBcBYDSJiDinALCkISsqKtYxHMp8KHM+AGi4EeieBIIkgGOcAiBIwI7VTQFgSYNBFRu9/48rg0ctQcEwSIAEAiKA47wV55r3Aqq+0Gp9GAEo1BXXG4wABcBgdMJdZnQEgL/+F25j0xsJmCIAEWB0FAD+KQBMNf4yfikAlgFi8KPREQDkbfrpYITAQgIkEAKBZ0PwMZiLsgXAYJVzWeEEKAAKZxXYmhiSWx2Vj4QZK1DlFADG6NMxCYRHAMe6/jpgeA6/7qlqwYIFya/P5pywCVAAhE28H38dHR2mr/7l888/pwDop204iwSiRqCystK0ABDEUMYoQNRaxFw+FADm2P/PswXfAPh4xRVX/O//AuIECZBAZAlgBOADJGf0B78w6kkBgEYwXSgATLfAIv+mRwB49b+oHfiXBOJCwPQoQMkCIC4NFEaeFABhUM7jA4rc6DcAEB4FACCwkECMCBgVABwBsGNPowCwoB1yuZzREQAcjBQAFuwHDIEEwiKAiw6jAgD+SxwBCItQPPxQABhuZ3S+y+Fg+LbJMOCfAsBkA9A3CYRMAMe8UQGAdCkAAMF0oQAw3AJdXV1Gr/51+jgZUABoEDQSiAmB7u7uNw2nqjo6OsYUGwPX95cABYC/PIuuDZ3vN4veyOcNOjs7KQB8ZsrqSMBmAkOGDHkX8XXBjBWMfo4y5pyOewlQAPRiMPcnl8uNMOe91/OXI0aM+LB3in9IgATiRMDobYBEIlHkuS9OTRNOrhQA4XAe0AtGAEwfBLz6H7B1uIAEIk3AqAAAWdPnPoQQ70IBYL79h5sMAcNw+kdBTIZA3yRAAgYI4Ng3+hxAsRc/BhBF3iUFgOEmxkFoWgXzFwAN7wN0TwImCGAI/ksTfhf7tOD25+JQYvtOAWC46XEQGh0BgAo3+pOghvHTPQnElgAuPuabTB7nniIufkxGGl3fFACG2xYHoemDgCMAhvcBuicBEwRw8WFUAMC/0YsfE8xt80kBYL5FjAoAqHCOAJjfBxgBCZggYFQAFHPxYwJOHHxSAJhvZaMqGAchRwDM7wOMgARMEDAqAJCw0Ysf+I99oQAwvAugAzZ6EGAYjiMAhvcBuicBEwRw7jEqADD6WOC5zwSdePikADDczuiAjY4A9PT0cATA8D5A9yRgiIBRAYCcKQAAwWShADBJH76hwo0eBPBPAYB2YCGBuBGorKw0KgBw7ino3Be3dgkzXwqAMGn348v0QYARCN4C6KddOIsEYkDAqAAAXwoAQDBZKABM0odv3AczegsAAoQjAGgHFhKIIQEHBEAMWyXElCkAQoQ9gCujKri6upojAAM0DGeTQMQJUABEvIHzpUcBkI9Q8MuNjgAgPY4AAAILCcSQgPUCIIZtEmrKFACh4u7X2dB+54Y0E7cgjP4eeEhp0g0JkMAyBHDsdy4zK+yPRs99YSdroz8KABtbhTGRAAmQQOwJEEDQBCgAgibM+kmABEiABEjAQgIUABY2CkMiARIggbgTYP7BE6AACJ4xPZAACZAACZCAdQQoAKxrEgZEAiRAAnEnwPzDIEABEAZl+iABEiABEiABywhQAFjWIAyHBEiABOJOgPmHQ4ACIBzO9EICJEACJEACVhGgALCqORgMCZAACcSdAPMPiwAFQFik6YcESIAESIAELCJAAWBRYzAUEiABEog7AeYfHgEKgPBY0xMJkAAJkAAJWEOAAsCapmAgJEACJBB3Asw/TAIUAGHSpi8SIAESIAESsIQABYAlDcEwSIAESCDuBJh/uAQoAMLlTW8kQAIkQAIkYAUBCgArmoFBkAAJkEDcCTD/sAlQAIRNnP5IgARIgARIwAICFAAWNAJDIAESIIG4E2D+4ROgAAifOT2SAAmQAAmQgHECFADGm4ABkAAJkEDcCTB/EwQoAExQp08SIAESIAESMEyAAsBwA9A9CZAACcSdAPM3Q4ACwAx3eiUBEiABEiABowQoAIzip3MSIAESiDsB5m+KAAWAKfL0SwIkQEhRhrAAABAASURBVAIkQAIGCVAAGIRP1yRAAiQQdwLM3xwBCgBz7OmZBEiABEiABIwRoAAwhp6OSYAESCDuBJi/SQIUACbp0zcJkAAJkAAJGCJAAWAIPN2SAAmQQNwJMH+zBCgAzPKndxIgARIgARIwQoACwAh2OiUBEiCBuBNg/qYJUACYbgH6JwESIAESIAEDBCgADECnSxIgARKIOwHmb54ABYD5NmAEJEACJEACJBA6AQqA0JHTIQmQAAnEnQDzt4EABYANrcAYSIAESIAESCBkAhQAIQOnOxIgARKIOwHmbwcBCgA72oFRkAAJkAAJkECoBCgAQsVNZyRAAiQQdwLM3xYCFAC2tATjIAESIAESIIEQCVAAhAibrkiABEgg7gSYvz0EKADsaQtGQgIkQAIkQAKhEaAACA01HZEACZBA3Akwf5sIUADY1BqMhQRIgARIgARCIkABEBJouiEBEiCBuBNg/nYRoACwqz0YDQmQAAmQAAmEQoACIBTMdEICJEACcSfA/G0jQAFgW4swHhIgARIgARIIgQAFQAiQ6YIESIAE4k6A+dtHgALAvjZhRCRAAiRAAiQQOAEKgMAR0wEJkAAJxJ0A87eRAAWAja3CmEiABEiABEggYAIUAAEDZvUkQAIkEHcCzN9OAhQAdrYLoyIBEiABEiCBQAlQAASKl5WTAAmQQNwJMH9bCVAA2NoyjIsESIAESIAEAiRAARAgXFZNAiRAAnEnwPztJUABYG/bMDISIAESIAESCIwABUBgaFkxCZAACcSdAPO3mQAFgM2tw9hIgARIgARIICACFAABgWW1JEACJBB3AszfbgIUAHa3D6MjARIgARIggUAIUAAEgpWVkgAJkEDcCTB/2wlQANjeQoyPBEiABEiABAIgQAEQAFRWSQIkQAJxJ8D87SdAAWB/GzFCEiABEiABEvCdAAWA70hZIQmQAAnEnQDzd4EABYALrcQYSYAESIAESMBnAhQAPgNldSRAAiQQdwLM3w0CFAButBOjDJiA53kjOjs7D1i4cOEVsKcw/QHeu2FeHuvuW/cprHcFpg/QdQUc7terv+WjEdLUeoA0Z6+QpuxTksl+AOuGeWWaruOD3jp764YP7evrEQQ6RzPVbDVjmHvtEygdVk4CpRGgACiNG7eKCAF0JhvCGru6uj5TSt2AtA6FbY7p1fBeActXKvrW3RwrHorpG3Rduk7YhpgXbGls2xAdfKN88eVnohI3iCeHihIdS6Hx54tPM1itt87euuFD+8pkG0X7zrd1mcs1Q5i77VNm/m5uzqhdIUAB4EpLMU7fCaBjuRCVvgSrh/l5LOi6dJ0v9flA9QGUpuyFklCL4leifUooL9Xrq160bx2DBPPqY7coPxE/89N1Bd8+wWBhrSTgGwF9IPhWGSsiARcIYCh5fXQuzyPWo2FBl6O1L+3TN0eZ1vVx1f88rsrDiH/wsJUc3RuLjmnwNQteqllpZtggjPz8bx8EHufC3N0hQAHgTlsxUh8IYHh+K6XUk6hqE1hYZRPtU/su22Fj61a4GA47/nxhg2XiSemNLd+qgy/XjDQrrIU68Tec4l/7hBMvvZCALwQoAHzByEpcIKCvLD3PuxexjoSFXUZq3zqGkh3rq+xEwlT8+cIeKTo2HWO+NQdYrtloRljsZvsgcBYScIkABYBLrcVYyyKAK8tmVGCic4Hb3jKyL4beD8X/SZiOP1/IYNsbY771+l3exwZ19Ls4jJlltk8YIdIHCfhHIOFfVayJBOwlgHvK+oG/MIeVB4KxSV8sAy3vf/6ih+1siL//+L6au4ksivWrOQVM9TGxIb/S2qeAHOOwCnN0iwAFgFvtxWhLIIDORX8dL4wHygqNTj94pmMqbH39dTv9sF1ha5tfS8eqYy4wEufbp8A8uRoJ2EaAAsC2FmE8QRA4MohKy6yz8JgSqvB1ywzKt82Li9nG/GyMybfmCaYi1uoaAQoA11qM8RZFwPO8EdigDmZbqeuLbfC49K/ueWJj/DLoS8esYx90JZE+BjbmV1j75MmPi0nAZgIUADa3DmMrmwCGlyegEhv380RfbAhvkPLF5xNE+fojOBLKSyFmHbsM/upj4G77DJ5erJYyWfcI2HjguUeREVtLQCm1ta3BFRRbImFt/Hm5FhB7QQzyOgpmBZtjCyZj1ho3AhQAcWvx+OW7kcUp548tJ/nXEUtfhcVuc342x2ZZozMcFwlQALjYaoy5YAK4x5wqeOWQVywoNiXWxp8XVwGxF8Qgr6NgVrA5tmAyZq1xI0ABELcWj1m+GMZd2daUC4zN2vgL4Jo39gIZFODK/1Vsjs3/bMurkVu7SYACwM12Y9QkQAIkQAIkUBYBCoCy8HFj2wlgGPdjW2MsMDZr4y+Aa97YC2RQgCv/V7E5Nv+zLadGbusqAQoAV1uOcRdEAMO42YJWNLBSQbF5Ym38eZEVEHtBDPI6CmYFm2MLJmPWGjcCFABxa/H45fuSxSnnjy0h+dcRS1+FxW5zfjbHZk2jMxB3CVAAuNt2jLwAAhjGfbKA1YysUlBsuZy18eeFVkDsBTHI6yiYFWyOLZiMWWvcCFAAxK3FY5ZvdXX1PUg5B7Ot5PpiGzyuEcvdI57YGP/gceuYdeyDryV9DGzMr7D2yZNf9BczQ5cJUAC43HqMPS8B3Mf9Ais1w2wrzX2xDR7Xfqt8IUpsjF8GfemYdeyDriTSx8DG/AprH+GLBNwlQAHgbtsx8sIJXFL4qqGtWXhMOa/wdUMLP4+j4mK2MT8bY8oDPfzF9Og2AQoAt9uP0RdAAMPML2O1i2C2lIv6Yiosnobal3EbwKb4B4/bk4tExzz4Wv9b2sfCpvyKa5//ZcIJEnCLAAWAW+3FaEskgE7mGGz6Asx0eaEvluLiqE/ZEn++uF+QRbHmW2+p5X1M3G2fpbKJywfm6ToBCgDXW5DxF0zA87w6rPwZzFT5rC+GEv3nTMefL26w7Y0x33r9Lu9jgzr6XRzGzDLbJ4wQ6YME/CNAAeAfS9ZkOYGamppXlVK7I0wTncxn2reOAf5LK+nRr0ouZyr+fDF/1hubjjHfmgMs12w0Iyx2s30QeJwKc3WfAAWA+23IDIogUFVVNQtXmltjkzCHm1/QPrVv+C2vNIyeJZILO/58MYMlYuqNLd+qgy/XjDQrrIU68Tec4l/7hBMvvZCALwQoAHzByEpcIqCvNHHP+fuIOYwHz/QDZd/XPuHPn6KvstOp74t+2M6fGkuvRcegY9ExlV7LUltqVk63z1LZRPUD84oCAQqAKLQicyiJADoZ/WDdRti4CZaD+VV0XbrOjfp8+FXv0vXoh+1y3qL49Q/vLL00uE+LfDWJ9q1jCMhTH7tF+WHYw0c34bSPjwGzKhIIggAFQBBUWaczBNDJvAxrwNDzSAw9H4jAr4Q9jekP8d4Dy1d6+tZ9GiteiekDdV26Tpj++iFmB1j01+3SqQYZMXykeLkDRcmVGBnQsXwIr4XEj9UGLbqOD3vr7K0bPrQv7VP7HnTT8hdqhjB326d8BFbWwKCiQYACIBrtyCzKJKCU+gJDzzeiszkMtgWmV8d7JUzlscq+dbfAeodh+kZdV5nhFL+5/tW9+tE3Sl3qMKlPbSHp1OqwSpgq03Qdq/fW2Vs3fGhfxUdY1haaqWarGcPca5+ysufGJBAMAQqAYLiyVhIgARKIKAGmFRUCFABRaUnmQQIkQAIkQAJFEKAAKAIWVyUBEiCBuBNg/tEhQAEQnbZkJiRAAiRAAiRQMAEKgIJRcUUSIAESiDsB5h8lAhQAUWpN5kICJEACJEACBRKgACgQFFcjARIggbgTYP7RIkABYL499Q+tGIvC87wqY87pmARIwBgBC459o+c+Y+AtckwBYLgxlFL/NRnC/PnzVzLpn75JgATMECj+2Pc3TtPnPn+zcbM2CgDD7ZbL5T43GUJlZeWKJv3TNwmQgBkCpo990+c+M9Tt8koBYLg9TKtgHIQcATC8D9A9CZggUOyx73eMps99fufjYn0UAOZbzegIQEVFxUTzCBgBCZBA2AQsOPaNnvvC5m2jPwoAw60CFfwPkyF4nreHSf/0TQIkYIZAcce+/zGaPvf5n5F7NVIAGG4zDMO9aTIEHIS13d3dHAUw2Qj0TQIhE9DHvD72Q3a7lDvT576lgonpBwoA8w1vVADo9HEgHq/faSRAAvEgUOwxHxAV4+e+gPJyploKAMNNBRX+huEQtPstOzs7KQI0CRoJRJxA37G+pek0LTn3mcZg1D8FgFH8IlVVVVaoYByMZ3Z0dOxmGAfdkwAJBEhAH+P6WC/ORTBr23LuCyY7N2pNuBFmdKPEwTgf2T0LM10qE4lEk+kg6J8ESCA4An3HeGVwHgqu+dm+c1/BG3BF/wlQAPjPtOgaPc97oOiNgtlgla6urr8FUzVrJQESMEmg79hepdgYgljfonNeEOk5UycFgAVNhYNhlgVh9IaAWH6wcOHCx/A+sncG/5AACThNQB/Lfcf0D2xJBDFZc86zhYmJOCgATFBfxmdNTc3TGA77cpnZJj9ui6uFP+N+4S4mg6BvEiCB8gjoY1gfy6hlW1gJxf9N9LlOn/P8r5k1FkuAAqBYYgGsjwPiv7lc7okAqi6nys1wv/B+XDlcB9u0nIq4LQmQQLgE9DELu04fw/C8Gcyaos91+pxnTUAxDoQCwJLGxwFxjyWhLBvGzzDjGZxM/tbd3X05bC8M39ViHgsJkIAlBPQxqY9N2OX6WEVYz8D0sYu30ksQW1p8rgsiXavrpACwpHlw4N6LA0N/I8CSiL4Wxg+g3A+D3YEhxVacZHR5FX8eoy0kg4VkYOg40MfgQn1M6mMTdhiOXGvu9SOWpYo+x+lz3VIz+cEYAQoAY+iXdjxs2LC5UPH3Lj3X6k9ViG49mL63SBMhAzIwsQ/oY1Afi+L/y/8a9TlOn+v8r5k1lkKAAqAUagFtg/t1tt4GCChjVksCJBAnAjzH2dXaFAAWtUdFRcWNCOcVGAsJkAAJGCUQgPNX+s5xAVTNKkshQAFQCrWAtsH9sR5UnYGxkAAJkEDUCGT6znFRy8vZfCgALGu6qqqqDO6TZS0Li+GQAAnEioC/yepzmj63+VsrayuXAAVAuQR93h4K+TPcJ+Nv8vvMldWRAAmYI6DPafrcZi4Ceu6PAAVAf1QMz6usrLwCIbwOYyEBEiCB0An47PD1vnOaz9WyunIJUACUSzCA7aGUP8WQ2dkBVM0qSYAESCBUAvpcps9poTqls4IIUAAUhCn8lWpqaq6HV214YyEBEiCBsAj46uf6vnOZr5WyMn8IUAD4wzGQWqqqqs5CxZ/CWEiABEjANQKf9p3DXIs7NvFSAFjc1Bg2+zvCOxXGQgIkQAKhEPDRyal95zAfq2RVfhKgAPCTZgB1VVdX6wcCpwdQNaskARIggaAITO87dwVVP+v1gQAFgA8Qg66io6PjRPh4AcZCAiRAAgG38uyWAAADIElEQVQS8KXqF/rOWb5UxkqCI0ABEBxb32pefvnlP8FQ2gm+VciKSIAESCAgAvpcpc9ZAVXPan0kQAHgI8wgq6qqqnoY9f8SxkICJEACgRDwodJf9p2rfKiKVQRNgAIgaMI+1o97ald7nne6j1WyKhIgARLwhYA+N+lzlC+VsZJQCFAAhILZPyc1NTVT9YHmX42siQRIgAQ0gdJNn5P0uan0GrilCQIUACaol+mz70A7osxquDkJkAAJ+EHgiL5zkh91sY4QCVAAhAjbT1cYarsMqns/P+tkXSRAAvElUErm+hykz0WlbMttzBOgADDfBiVHANV9qz4AS66AG5IACZBAiQT0uUefg0rcnJtZQIACwIJGKCcEfQDiQNwb9k459XBbEiCBOBMoPHd9roHtrc89hW/FNW0kQAFgY6sUGRMOxDtzudyO2OxmGAsJkAAJBEXgZn2u0eecoByw3vAIUACExzpQT0OHDp2De3H76x/hCNQRKycBEogcgUIS0ucWfY7R55pC1uc69hOgALC/jYqKsKqq6lwcqFthiO7uojbkyiRAAiTQDwF9LtHnFH1u6WcxZzlMgALA4cYbKHQcqLMxRLcHljfA3oKxkAAJkMAABAacrc8dDfpcos8pA67FBc4SoABwtunyB47huqaOjo6toN7PgH2afwuuQQIkEHcC+lwBO0OfO/Q5JO48opw/BUCUWxe5Lb/88v+Gev9tT0/PpjioL8KshTAWEiABEuglsMSfhfococ8V+pyhzx1LLONkBAlQAESwUftLaciQIe/ioD4G9kMsvxT39d7FOwsJkEDMCfSdCy7V5wbYMfpcEXMksUmfAiA2Tb0oUSj8lzGsdyTu662dy+V2xVyKAUBgIYE4EVjc6edyuV31uUCfE/S5IU4MmKsIBUCM9wIo/T/pA1+fAHDwb4eTwu+BYzaMhQRIIHoEZutjXB/r+pjXx74+B0QvTWZUKAEKgEJJRXw9DP09hpPCqTgpbIXp5TE6sBtOFMci7WmwWbB/w1hIgATsJ6CPVX3MTtPHsD6W9TGtj219jGP6scUp8D3eBP4fAAD//2BfV+4AAAAGSURBVAMAazqguBgE/H0AAAAASUVORK5CYII="},Zt={book:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAACXBIWXMAALP6AACz+gFmujCYAAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAIABJREFUeJzt3X2UXXV97/HPb59MyJBQmAQI4CRzHgYSCVI1VS9KaUToVYuibQEtIklqoaJiqUpdXtsbW/vg5XoV1FIRebBia9WFWm1FUVJ86r00CmhoieecfYaEQEQyAfMwyczs7/0jSRs1hJnM2ft7zvm9X2uxlrpqfh9cXez32Wefc4KAfYaHh4/LsqxsZuUkSU4wswUhhAVmtkDSAjM7TtLRkhRCmCepT1KQdIzjbADdKZP0xL5/vV3S45K2SvpxCOFhSSNZlrWyLKtXKpUfrV27dsJraK8K3gNQrMHBwf7Zs2cvk3S6pNMknSypLKkiaa7jNAB4KnskPSDphyGEe8zsuwMDA/euW7du3HtYNyMAetjg4GB/X1/f80IILwohPMfMTpc0LKnkvQ0AZminpH+V9NUsy+5otVr3STLnTV2FAOgh+27h/6qkMyW9UNJztfc2PQD0ukclfUHSZ5vN5l2SJp33dDwCoLuVhoeHnz85OfmyEMJLJS2XlHiPAgBnP5H0D0mSfLxer3/Pe0ynIgC6zMKFC+fOmzfvPDN7lZmdG0JY4L0JADrYvZI+1t/f/4n169dv9x7TSQiALlAul+eEEM5NkuQCM3u1pHnemwCgyzxpZreEEN7fbDYf8h7TCQiAzhWq1erZklZLeqW46ANAO4yHEG6dnJz881ar1fIe44kA6DDlcvmEJElWSnqDpJrzHADoVeNmdnNfX9+fbtiw4WHvMR4IgA5RrVbPkfRGSa8QT+4DQFF2SLpmbGzsms2bN+/0HlMkAsDR8uXL+7Zu3XpRCOFtkp7tvQcAIrbJzP4wTdPPeA8pCgHgYMmSJUeNj4+vlvQ2SYu89wAA/tM/mdkVaZqOeA/JGwFQoGq1erSkqyT9gfZ9pz4AoONsDyG8vdFofNR7SJ4IgAIsXLhw7ty5c98s6WpJ8733AACeXgjhjomJiVUjIyOPeG/JAwGQo32f339TCOGPJB3nvQcAMG1bJL2u2Wze6T2k3fhRmJxUKpVXhBD+MYRwkfiVPQDoVvMkXTwwMJCMjo7erR76wSHuALRZuVx+dgjhAyGEFd5bAABt9fn+/v5LeuUrhQmANlm6dOmC8fHxvzSz1eLOCgD0JDP7/sTExHkbN27c7L1lpgiANqhWq6+V9EFJx3tvAQDkbqOZnZem6f3eQ2aCAJiBRYsWndTX1/dhSa/23gIAKNQTIYSXNxqN73gPOVz8dvzhCZVK5U19fX3/IS7+ABCjo83sjuHh4RXeQw4XdwCmad+r/lsknes8BQDgb5eZnZ+m6de8h0wXATANtVrtVWb2MUnHem8BAHSMnVmWvbzVav2L95DpIACmYHBwsL+vr++vQghXem8BAHSkJyWd02w27/EeMlUEwNMYHh4+Ncuyz0la6r0FANDRfhJCOKPRaNS9h0wFDwEewvDw8PlZln1HXPwBAE/vWDP7yvDwcFd89TtfWHMQK1asmFUqld5nZtdKmuO9BwDQNeab2RkLFiz41NatWye9xxwKAfBzhoeHj9u2bdsXJV0s3iIBAEzfYjM7bnR09EveQw6FADhArVYbNrNvSFruvQUA0NV+ZWBgYOPo6Oj3vYc8FV7h7lOpVM4KIdwuab73FgBATxjLsuyMVqt1r/eQg+EhQEmVSuWCEMId4uIPAGifOaVS6VMnnXTSkd5DDib6AKhUKu8KIXxaPOwHAGgzM3tmf3//+7x3HEzMzwCEWq12jaQ/Fm+FAADy87yjjz76X7dt29bwHnKgWC98oVKpfJBv9gMAFOSh/v7+ZevXr9/uPWS/GO8AlKrV6o0hhN/3HgIAiMbRk5OTR4yOjn7Ve8h+Ud0BWL58ed+2bdtuM7MLvLcAAKIzmSTJ8+r1ekd8NDCmhwCT0dHRW7j4AwCclLIs+7A65MV3LG8BhEql8jchhJXeQwAAUVs0MDBw/+jo6L97D+mICslbpVK5LoTwFu8dAABIavT395+6fv36PZ4jev4tgGq1+hdc/AEAHaQ2Nja2yntET98BqNVql5vZ33jvAADg5zyUJMkp9Xp9t9eAnr0DMDw8fL6ZfcR7BwAAB7E4y7LVngN6MgBqtdryLMtuUzwPOQIAus/VcrxO9dwFslwul0MI3xA/7AMA6GzHDAwM3Of1iYCeugOwZMmSo5Ik+ZKkE7y3AAAwBVd5HdxLARDGx8dvkrTMewgAAFN0ZrlcfrbHwT0TALVa7R2Sftt7BwAA0xFCcPlIYE98DLBWq51tZndImuW9BQCAadqaZdkzWq3WWJGHdv0Fs1arLTKzv1cP/L3gkLZI+oH3iJnYc1xlyeS8gUXeO2biiEc2/N9kbPtPvXd0st0nnPysrP+ohd47ZmLOxvV3h4ndeX5L3RGS5prZMSGEkyTNyfGsbjA/hPAKSZ8p8tBuvwNQqlarayWd6T0E+QohfKbRaFzovWNGbkqvVdCV3jNmJAnP1aXljvgls451c+sfpK7/0bETtaryaEFnhUqlsjiEcFoIYYWZnS3puQWd3Uk+22w2C/3/m65+1Vyr1d5lZlz8AaB7WZqmI5JGJH1ZkqrV6ilm9roQwuWSjnddV5yXL1y4cO6WLVt2FHVg1z4EWC6XX2Bmf+K9AwDQXs1mc0Oapn+yZ8+espm9RVJRdyM8HXnkkUe+vMgDuzIA9n3e/5Pq8jsYBcq8BwDAdG3atGlXmqYflrTUzK6TNOm9KWfnFXlYVwbA+Pj4tZKGvXd0OjNrSnpXlmXLvbcAwOFqNptPpGn61hDCuZIe8d6Tl31/f4U9m9d1AVCr1V4qyf1nFDvYnhDCP0g6N03Tk5vN5l8qjttnAHpco9G4y8yeI+ke7y05ObFSqZxe1GFdFQDLli2bZ2bXe+/oULvM7LpZs2ZVG43GRc1m805x6x9Aj0nTdEt/f//Zku703pKHEMJLijqrqwJg165d75VU9t7RYXaY2XXj4+PDaZq+dcOGDQ97DwKAPK1fv377nj17Xinpbu8tOXhhUQd1TQCUy+UXSHqz944OsieE8P4kSSppmr5148aNm70HAUBRNm3atEvSK9XlXxB2EATAgZYvX96XJMnH1IM/X3w4zOwrZnZ6o9F4e71ef8x7DwB4aDabT0j6LUm99O2UJw4NDVWKOKgrAmB0dPQKSc/y3uHNzJpmdn6api9L0/RB7z0A4K3ZbP5I0hu9d7RTqVR6ThHndHwAnHLKKcdK+p/eO5xNSvpLM1uWpukXvccAQCdpNpu3Sfqa9442Oq2IQzr+i3QmJibeI2nAe4cXM2smSfL6RqPxbe8tANCpzOwtIYQfSOrz3jJTIYRCAqCj7wDUarXTJF3mvcPRTbNnz342F38AOLQ0TR80s7/z3tEOZnZqEed09B0AM/uAOnxjTp4MIaxsNBq3ew8BgG6RZdlflUqlS9T9v3RbLuKQjr0DUK1Wz5F0jvcOB/UkSV7IxR8ApmdkZOTfJX3Le0cbzN33/FuuOjYAzOxPvTcUzcy+kmXZ8+r1+nrvLQDQjUIIn/Te0A4TExO5fxSwIwOgWq2+PIRwhveOIpnZNWmantdqtbZ5bwGAbpVl2RckmfeOmTKzE/I+oxMDICiuj/2ZpKvSNL1avf9TlwCQqzRNt4QQ/sN7x0wlSbIg9zPyPmC6arXa+ZKe772jIJMhhNXNZvOD3kMAoId0/XMAZjY/7zM67gl7M3u394aC7DGzi5vN5me9hwBALzGzrr8DEELIPQA66g7A8PDwCknLvXcUYEzSq9M05eIPAG1mZj/y3tAGc/I+oKMCIMuyt3tvKMCkmV3SbDb/yXsIAPSiJEke994wU1mWzc77jI4JgEqlskTSy7x35C2EcBWv/AEgP2bWC78OeETeB3RMACRJ8jZ10J6crGk0Gh/yHgEAPW7Me8BMhRByf0avIy64p5xyyrFmdon3jpxd32w23+M9AgAAqUMCYHx8/FIV8MCDFzNbu3jx4iu9dwAAsF9HBEAIYbX3hhw9OjExcfHatWsnvIcAALCfewBUKpWzJBXy04cOxs3swo0bN272HgIAwIHcAyCE8HveG3L0jjRNv+k9AgCAn+caAIsXLx6Q9FueG/ISQvhis9m81nsHAAAH4xoAfX19F0jq99yQk22lUukK7xEAADwV1wAws4s8z8/Rmzds2PCw9wgAAJ6KWwAMDw8fJ+ksr/Nz9KVms3mb9wgAAA7FLQCyLPttdeCvEc7Q6OTk5GXeIwAAeDqebwG8xvHsXIQQ1oyMjDzivQMAgKfjEgBDQ0MnSjrT4+wc/eiYY4653nsEAABT4RIApVLpZV5n5yWEcPW6devGvXcAADAVXhfhXvvZ37sbjcbnvUcAADBVhQfAihUrZkk6p+hzc2SS3u49AgCA6Sg8AEZGRs6QdEzR5+boK81m8x7vEQAATEfhAZAkyUuLPjNPSZL8L+8NAABMV+EBYGa/XvSZObqnXq+v9R4BAMB0FRoAy5Ytmyfp2UWembP3eQ8AAOBwFBoAu3bteoF659v/6s1mkyf/AQBdqei3AHrpy39ulDTpPQIAgMNRdAC8sODz8pKFED7lPQIAgMNVZAAkkl5Q4Hl5urPRaGz0HgEAwOEqLABqtdqpko4u6rycfcJ7AAAAM1FYAJjZLxd1Vs6eHBsbu917BAAAM1HkWwDPKvCsPH158+bNO71HAAAwE0UGwOkFnpUbM/tn7w0AAMwUATA9WZIkd3iPAABgpgoJgMHBwfmSnlHEWTlb12g0fuw9AgCAmSokAGbPnn1qEecUgNv/AICeUEgAhBCqRZyTtxDCV703AADQDoUEgJlVijgnZ+O7d+/+nvcIAADaoaiHAIcKOidP6zdt2rTLewQAAO3AHYApCiH8m/cGAADapahnAMpFnJMnM1vnvQEAgHYpIgASSYMFnJMrM+P9fwBAz8g9AJYuXTogaVbe5+TMdu/e/UPvEQAAtEvuAbB79+5j8z6jAI/x/f8AgF6SewAkSbIg7zMKMOI9AACAdso9ALIsIwAAAOgwuQdACKEX3gJ4yHsAAADtVMSnAAYKOCNvBAAAoKcUcQfgyLzPKMBj3gMAAGinIp4BmJ33GXkLIfAJAABATyniDkDXB0CWZQQAAKCnFPEMQNcHAHcAAAC9pogAOKKAM3KVJAkBAADoKbwFMAXj4+P8DDAAoKfkHgBmVsgvDuapVCpNeG8AAKCduv7iDAAApo8AAAAgQgQAAAARIgAAAIgQAQAAQIQIAAAAIkQAAAAQIQIAAIAIEQAAAESIAAAAIEIEAAAAEZrlPQAAntatmxZocvxMBXu+lJws2WJJ8yXNkTQuaYdkP5ZCXUEPKIRvqn/ofl0YJn2HA52LAADQmW5OT5B0kaTXKht/voKCFCTZU/wXgiS9RCbJTNrRGtXN6e2S/b1GKl/XmpAVtBzoCgQAgM6xxhItbp6tULpMsldJ6pvBnzYgabUUVmuo9bBuTj+pSbteb6iOtGkt0NUIAAD+9r7av1RqXSYl1ad+lX/YniHpj1QK79AtrW/Ishs0MnK71ryYn/pGtAgAAD7a+2p/qhKZnSOFczRU3ntXoJT9tV5fe6iAs4GOQgAAKFb+r/anau9dgcmEuwKIEgEAIH8+r/anirsCiBIBACA/nfNqf6q4K4BoEAAA2quzX+1PFXcF0PMIAADt0X2v9qeKuwLoSQQAgMPXG6/2p4q7AugpBACA6evdV/tTxV0BdD0CAMDUZXqxbm7+D0mvVG+/2p+qA+8KjOim5o2SLfAeBUwFAQBgGuz9+75zH79oSCH8mfcIYKr4OWAAACJEAAAAECECAACACBEAAABEiAAAACBCBAAAABEiAAAAiBABAABAhAgAAAAiRAAAABAhAgAAgAgRAAAARIgAAAAgQgQAAAARIgAAAIgQAQAAQIQIAAAAIkQAAAAQIQIAAIAIEQAAAESIAAAAIEIEAAAAESIAAACIEAEAAECECAAAACJEAAAAECECAACACBEAAABEiAAAACBCBAAAABEiAAAAiBABAABAhAgAAAAiRAAAABAhAgAAgAgRAEBRgnZ6TwCmZOfO7d4TkD8CACjOE94Dek4IdUm7vGf0lGATuuLUHd4zkD8CACjONu8BPWJMIXxSsrO0snyyZifPUNBbJa33HtYTLDyhEMx7BvI3y3sAEA3L6go09wxskHST9uz5uC5f8pP//E8vHhqVdJ2k63TLyHJl2WUKuljSXKed3e5H3gNQDAIAKErpiO8rG/de0W12S+GLsskbtKr69ad9ZbpyaJ2ky/XRxtU6IrlIpisk/XIhS3vHvd4DUAxejgBFuXTwcUkPe8/oCqZ/l3SVJmedpFXlC7W6due0bktfXntCKys3aFXl2QrJmTJ9QjwrMFX3eQ9AMbgDABQp6KsyrfKe0aGm92p/qlYOfVvSt/XRxpXcFZgCS77qPQHF4A4AUCSz270ndKANkt6pPXsGD+vV/lT97F2BX5HpBkk87f6z7tXqoab3CBSDOwBAkeb23akdE09K+iXvKc7GFMJnZdkNWlX9ZuGn739W4LaRd2o8u0SmyyQtK3xHpzH7nPcEFIc7AECRLly0SyHc4D3D0f5X+4u0snyJy8X/QBcPjWpl5TqtqpzGXQHtVgg3eo9AcbgDABQtlD4om7hS0mzvKQXJ5739dov9EwSmW7W68qj3DBSHOwBA0S5d9LCkm7xn5G6mT/J7ifMTBGPKJq/xHoFicQcA8DA7eZf2ZL8p6XjvKW3WHa/2pyqeTxC8T28YrnuPQLG4AwB4uHhoVKarvWe0Tbe+2p+q3r4r8CNJf+U9AsUjAAAvqyu3Kuhm7xkzsFsKn5Fl52pVeZlWVT6oNyza6j0qdyuHvq3VlUu1JztRQZeru784Z0wWXqNVlTHvISgebwEAnvbeUj5d0nLvKdPwi9/Jv9p3kIvLa09IukHSDV38GwRv1Ory97xHwAd3AABPqypjmph4lTr/B1jGJLtNwX5NqypLtKryvp/5QZ7YrRxap9WVyzU7WdQ1v0wYwru1qnKL9wz4IQAAb7938iZJZ0l6wHvKQfzX5/ZXVV+nldW7vQd1tG75XgGzP9bK8p97z4AvAgDoBKsqj0p6iaROuMDyar8dOvOuwG7JLtPq6nu9h8AfAQB0ilWVRzXSeomk90jyeIJ+76t9m1jMq/026py7AhslrdCq6scczkYH4iFAoJOsefGEpDW6tfUvMl0ns9NyPnFMss8p6AYu+AU48DcI9mSvl3SZpFNzPnVc0ke0J1uz78FFQBIBAHSmS8t3ac1dz9HQ0BsVkqtlNtjWP3/v5/Y/plLfJ3Tp4ONt/bPx9C4eGpV0raRr9fHGmUpKl0l2gaQ5bTwlk/SPsuRdWj3Uic+XwBkBAHSqvXcDPqQ1d12vxeXfUtAVkl4kqXSYf+Ljkr6gYLdqFa/2O8bv1r4l6Vu6beSt+36Z8CJJ/02H/xbtjyX9nULpQ1q5uNG2neg5BADQ6faGwKclfVofffBYze57mRReIuk07b193P8U/83HJX1P0jpZ9nU99NDafX8WOtHeuwLXSbpOt258hiYnXqmgF0h6roI9Uxae6p/XGyU9IIX/J7Mv66HyPVoTssJ2o2sRAEA32fs0/t/u+0taY4kqm07U+O5+zeo7WsEyjWdbtXvX43rTsu2uW3H49v5g1PX7/pLW3DVL1UXzpVkLlIUjNTG+W0nfTtmux/S7S3/quhVdiwAAutneV3oPe89Azvbeufnxvr+AtuBjgAAARIgAAAAgQgQAAAARIgAAAIgQAQAAQIQIAAAAIkQAAAAQIQIAAIAIEQAAAESIAAAAIEIEAAAAESIAAACIEAEAAECECAAAACJEAAAAECECAACACBEAAABEiAAAACBCBAAAABEiAAAAiBABAABAhAgAAAAiRAAAABAhAgAAgAgRAAAARIgAAAAgQgQAAAARIgAAAIgQAQAAQIQIAAAAIkQAAAAQIQIAAIAIEQAAAESIAAAAIEIEAAAAESIAAACIEAEAAECECAAAACJEAAAAECECAACACBEAAABEiAAAACBCBAAAABEiAAAAiBABAABAhAgAAAAiRAAAABAhAgAAgAgRAAAARIgAAAAgQgQAAAARIgAAAIgQAQAAQIQIAAAAIkQAAAAQIQIAAIAIEQAAAESIAAAAIEIEAAAAESIAAACIEAEAAECECAAAACJEAAAAECECAACACBEAAABEiAAAACBCBAAAABEiAAAAiBABAABAhAgAAAAiRAAAABAhAgAAgAgRAAAARIgAAAAgQgQAAAARIgAAAIgQAQAAQIQIAAAAIkQAAAAQIQIAAIAIEQAAAESIAAAAIEIEAAAAESIAAACIEAEAAECECAAAACJEAAAAECECAACACBEAAABEiAAAACBCBAAAABEiAAAAiBABAABAhAgAAAAiRAAAABAhAgAAgAgRAAAARIgAAAAgQgQAAAARIgAAAIgQAQAAQIQIAAAAIkQAAAAQIQIAAIAIEQAAAESIAAAAIEIEAAAAESIAAACIEAEAAECECAAAACJEAAAAECECAACACBEAAABEiAAAACBCBAAAABEiAAAAiBABAABAhAgAAAAiRAAAABAhAgAAgAgRAAAARIgAAAAgQgQAAAARIgAAAIgQAQAAQIQIAAAAIkQAAAAQIQIAAIAIEQAAAESIAAAAIEIEAAAAESIAAACIEAEAAECECAAAACJEAAAAECECAACACBEAAABEiAAAACBCBAAAABEiAAAAiBABAABAhAgAAAAiRAAAABAhAgAAgAgRAAAARIgAAAAgQgQAAAARIgAAAIgQAQAAQIQIAAAAIkQAAAAQIQIAAIAIEQAAAESIAAAAIEIEAAAAESIAAACIEAEAAECECAAAACJEAAAAECECAACACBEAAABEiAAAACBCBAAAABEiAAAAiBABAABAhAgAAAAiRAAAABAhAgAAgAgRAAAARIgAAAAgQgQAAAARIgAAAIgQAQAAQIQIAAAAIkQAAAAQIQIAAIAIEQAAAESIAAAAIEIEAAAAESIAAACIEAEAAECECAAAACJEAAAAECECAACACBEAAABEiAAAACBCBAAAABEiAAAAiBABAABAhAgAAAAiRAAAABAhAgAAgAgRAAAARIgAAAAgQgQAAAARIgAAAIgQAQAAQIQIAAAAIkQAAAAQIQIAAIAIEQAAAESIAAAAIEIEAAAAESIAAACIEAEAAECECAAAACJEAAAAECECAACACBEAAABEiAAAACBCBAAAABEiAAAAiBABAABAhAgAAAAiRAAAABAhAgAAgAgRAAAARIgAAAAgQgQAAAARIgAAAIgQAQAAQIQIAAAAIkQAAAAQIQIAAIAIEQAAAESIAAAAIEIEAAAAESIAAACIEAEAAECECAAAACKUewCEECbzPiNvIYQjvDcAAKZsjveAmTKzibzPyD0AzGxP3mfkLYRwlPcGAMDU9Mg/s3fnfUARbwHk/jeRt8nJyWO9NwAApibLsq7/Z3aSJLm/eCYApiCEcLL3BgDAlPXCP7PH8j6giLcAtuZ9Rt7MbIn3BgDA1CRJ0vX/zC7i2lnEQ4CP531G3kIIL/TeAACYGjP7Ve8NMxVC+EneZ+QeAEmSdP0dAEnLarXa8d4jAACHVi6XT5DU9XcAsiwbzfuM3ANgcnLykbzPKEDIsux87xEAgEMrlUrnSwreO2YqhJD7tbOIhwBHCjgjd0mSXOy9AQBwaGb2Ou8N7TBr1qxW3mfkHgBpmv5Y0q68z8mbmZ01NDT0TO8dAICDGx4ePlXSi7x3tMH2DRs2dP8zAJIshNAq4Jy8hSRJ/sh7BADg4MzsneqB2/+SWkUcUshvAZjZA0Wck7cQwu9Uq9VTvHcAAH5WuVxeamav9d7RDiGEQq6ZRf0Y0A8LOidvfZI+7D0CAPCzQggfkDTLe0ebFHLNLOoOQK8EgCSdW61WeSAQADpEpVK5JITwUu8dbdQ7AVAqlb5fxDkFur5arfbCV00CQFerVCpLQgh/7b2jnSYnJwu5ZhYSAPV6vSFpSxFnFeQoSZ+rVqtHew8BgFiVy+VjQgiflTTPe0sbPdJqtVpFHFTUMwCS9N0CzyrCs8zsnxcuXDjXewgAxGZwcLA/SZIvSjrNe0ubfbuogwoLgBDCd4o6qyghhDPmzp37+WXLlvVSfQJAR1uyZMlRs2fP/qKkrv/O/4Mo7FpZZADcWdRZBTtn165d36hUKgu9hwBArxsaGjpxfHz8LknneG/Jg5l9vaizCguAer1+r6Re+F2Ag3leCOH+crn8372HAECvqtVqLy6VSuskLffekpNH0zT9QVGHFfkMgPXwXQBJOj5Jki9XKpXreDgQANpn8eLFA9Vq9cNmdqekE7335MXM7pBkRZ1XZABI0pcLPq9opRDCWyQ9WKlU3jw4ONjvPQgAutVJJ510ZK1Wu3LWrFn/IelNKv6aVbQvFXlYof9jzpkz58vqgR8GmoKFIYQPzZ49u1WpVP6sXC4v9R4EAN1iaGjombVa7b1z5sxpmdm1ko733lSAHTt37vznIg8s9GsT169fv71arX5F0quLPNfR8SGEd4cQ3l2tVu+T9HUzW2tmP2i1Wg9JyrwHAoCzZGhoaChJktNCCC+W9BJJp5sVdie8I4QQ/mnLli07Cj2zyMMkqVarvcbM/q7oczvQbjN7WNITIYTtknbneNZsSWfl+OcXYYukwh6OAZCrI7T3C9WOlnTSvn8fNTO7IE3TzxZ5ZuEBUC6X5yRJslnSQNFnAwDQaczs8VKp9Ix6vZ7nC8FfUPgDFa1Wa0zSp4o+FwCAThRC+GTRF3/J6YnKJEk+7nEuAACdxsxu9jjXJQDq9fr3VeD3HQMA0KHuTtP0Po+DPT9T+QHHswEAcBdCcLsWFv4Q4AFKlUplQwih6rgBAAAvabPZPFnSpMfhnncAJkMI73c8HwAANyGE98np4i85f61if3//jZJGPDcAAODgoTlbfNYtAAAFQklEQVRz5rg8/LdfyfPwxx57bHJgYGC3pN/w3AEAQJHM7B0bNmy4x3OD+w8r9Pf3f9zMmt47AAAoSH3+/Pm3eI9wvQMg7b0LMH/+/IclXei9BQCAvCVJsnr9+vUPeO/w/BTAz6hWq/+i7v++egAAnpKZrU3T9MXeO6QOeAtgvyRJrpLj05AAAORswsyu8h6xn/tbAPtt3br1kYGBgWMkneG9BQCAdjOz97darb/13rFfx9wBkKSxsbF3S0q9dwAA0GYjRx555J96jzhQRwXA5s2bd4YQrpBk3lsAAGgTM7PL1q9fv917yIE65i2A/UZHR+sDAwPHSXq+9xYAAGbKzD6UpulHvHf8vI66A7BflmVvl/QD7x0AAMzQA+Pj4+/0HnEwHRkArVZrLMuy10va5b0FAIDDtNPMXrtp06aOvJZ1ZABIUqvVutfMLvPeAQDA4QghvClN0/u9dzyVjnsG4EDbtm27f2Bg4ERJv+K9BQCAafhIs9n8C+8Rh9KxdwD2S5LkrZK+5b0DAIApuru/v/8PvUc8nY75KuBDWbp06YI9e/Z8R9Ip3lsAADiERpIkZ9Tr9ce8hzydrggASarVasNm9l1Jx3pvAQDgIB7bd/FveA+Zio5/C2C/RqNRz7LsXEmj3lsAAPg5T0p6ebdc/KUuCgBp7ycDkiT5DUkd9W1KAICo7TSzVzSbzX/zHjIdXRUAklSv179rZr8pviMAAOBvl5m9Kk3Tu72HTFfXBYAkpWn6NTN7qaSfem8BAERrh6RXpmn6Ne8hh6MrA0CS9tXW2Wb2uPcWAEB0tiVJcm6z2bzTe8jh6toAkKR977ecLWmj9xYAQDQeCiH8ar1e/673kJnomo8BHsrQ0NCJpVLpHyUt994CAOhp9yVJcl69Xt/kPWSmuvoOwH4jIyOP9Pf3r5D0ee8tAICe9bkdO3a8qBcu/lKP3AE4QKhWq1dKukZSn/cYAEBPmJT03maz+R5J5j2mXXotACRJtVrtbDO7TdIJ3lsAAF3tkSRJfqder6/1HtJuPfEWwM9rNBrfSJLkdDP7gvcWAEB3MrOvZFn23F68+Es9egfgQLVa7XIzu0bSUd5bAABd4adm9odpmt7oPSRPJe8BeRsdHV03b968W0ulUlnSqd57AAAd7UuSzkvT9C7vIXnr+TsAB6pUKheEEP6PpEHvLQCAjvJQCOEPGo3G7d5DitLzdwAOtG3btgf6+/s/OmvWrJ9KeoGkI7w3AQBc7ZD0gf7+/tc8+OCD93uPKVJUdwAOtGjRopP6+vr+RNIqSbO99wAACrVH0scnJyf/bGRk5BHvMR6iDYD9qtXqYjN7WwjhcnFHAAB63XgI4e9DCO+p1+sN7zGeog+A/crl8glJkvy+mb05hLDAew8AoK2eNLNbkiT5341Gg9+PEQHwCxYuXDh37ty5l5rZG0IIz/HeAwCYke9JunHHjh2f2LJlyw7vMZ2EADiE4eHh55jZajO7UNLx3nsAAFOyxcw+LemmNE3v8x7TqQiAqSnVarVfM7PflvQqSSd6DwIA/JcQwmYz+3ySJJ+p1+vf1N7v78chEADTFyqVyulJkvy6mZ0r6QxJ87xHAUBktkv6jpl9TdJX0zSN6iN87UAAzNCKFStmbdq06fTJyckXSnpeCOE07f3GwTnO0wCgV4xJesDMfijpnlKp9O3BwcEfrF27dsJ7WDcjAPJRqlarNUnDkspmVg4hDEpaYGbHhRDmS/qlff+3R0ma5TUUAJxMSPrpvn/9pKTHJf1E0uNmtimE0JLUklRvNpsNcUu/7f4/0g9tzmiSZLYAAAAASUVORK5CYII=",cleft:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAACXBIWXMAALP6AACz+gFmujCYAAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAIABJREFUeJzt3Xl8XHW9//HX90ySNl3YWlbbZiZpKbSACggKgmyirIJIcYG2CUu9egW3K+5Wve7e63bRW6GZlMWrxY0LCq7w84Ko4AYWKSSZSYtIgbbQNmmzzPn8/kgLLTRtljPznXPO+/l48KBNJjPvNumc9+cs3+MQERGRipo2bVp9TU3N7EwmM9vMZgOHAA3AQcCBwDjgWWAL8Biwyjn3J+fc3T09PX94/PHHe8aawY31CURERGTnmpqappvZwcBsMzvEOTcbmA3MYPTb4G7g1iAIvtve3n4bUBrNk6gAiIiIjMEQ0/zBDG7oJ5X55Tucc19yzrW1t7f3juQLVQBERESGYcaMGXvX1NTMdc7NMbNGYK6ZzXHOZYHAbzranXPv6ujouGO4X6ACICIispXnaX7MzGxZT0/PO9esWdO9u8eqAIiISOqU6dh8tfgbcEFnZ+cju3pQ3P+QIiIiOzV37ty6/v7+af39/c/ttnfOzQWOACb7zldm68MwPLNYLP5uqAeoAIiISKwlfJofiw3AWZ2dnXfv7JNp/osREZGYSPk0PxbrgFft7HCACoCIiFQNTfNl8ejAwMCxq1atWr/9B2t8pRERkXTa1TRvZs9N885pex+RWTU1NV8HLtn+g/rbFRGRstA0X12CIDivvb39lm2/1zdARERGTcfmY6UrCILZ21YM1CEAERHZraFWwdu8eXMWCLbtrtdu+6rWUCqVLgf+C7QHQEREtor7KngyLP+YMWNG9q677hpQARARSZkqX9NeyszMzi0UCrfqEICISAINZ5o3s+cer1336eGcawFu1XdcRCTGNM3LKHQHQTBFBUBEpMrpTHuJmnPuFB0CEBGpEkNdN7958+YZgNOZ9hIVMztBBUBEpIK0Cp5UiUP1EyYiUgZaBU+q3F+1B0BEZJQ0zUuMTdVPpYjIbuhMe0mgjSoAIiJoFTxJHVMBEJFU0TQvMkgFQEQSR9fNi+yeCoCIxJameZHRUwEQkaqmaV6kPFQARKQqaJoXqSwVABGpGE3zItVDBUBEIqdpXqT6qQCIyKhomheJNxUAEdklTfMiyaQCICKa5kVSSAVAJEU0zYvINioAIgmjaV5EhkMFQCSmNM2LyFioAIhUMU3zIlIuKgAiVUDTvIhUmgqASIVomheRaqICIBIxTfMiEgcqACKjoGleROJOBUBkFzTNi0hSqQBI6mmaF5E0UgGQ1NA0LyLyPBUASRRN8yIiw6MCILGkaV5EZGxUAKRqaZoXESkfFQCpGjNnzmwys7OA483sSKAJ/YyKiJSF3lzFq2w2u1cmk7nEzC5jcLIXEZEKUAEQL7LZ7F7Oufc6564C9vCdR0QkbVQApOJyudzFzrkvA/v7ziIiMgpPAhOASb6DjIUKgFTMzJkz9zCz68zsQt9ZRER2o9/MVjvnOs3soSAIVphZp5k9WCgU1jQ2Nv4GOMF3yLGo8R1A0iGbzR4ShuFPgZzvLCIi23nSOfd34JEwDFc65x52zq3s6OgoACXf4cpJBUDKLpvNvtI5dxswxXcWEUmlPqAdeBhY6ZxbWSqVHg7D8JFVq1at95zNGxUAKatcLneEc+6nwN6+s4hI4q0HOp1zD5nZCjPrzGQyD02bNm3lXXfdNeA7XLVRAZCymTlz5rQwDH+ONv4iEp0RT/Pt7e0VDRgXKgBSFjNnzhwXhuEP0Jn+IjI6Oz02P3369KKm+WioAEhZhGG4GDjGdw4RqWo7PdM+DMO/FYvFJ3b2BR0dHZXOmFgqABK5mTNnvjwMw/f7ziEiVeNJ4GHn3EpN89VDBUAiF4bhl9HPlkjaaJqPGb1JS6RyudxrgVN85xCRstE0nxAqABK19/oOICJjpmk+BVQAJDIHH3xw48DAwOm+c4jIsGmaTzEVAIlMf3//m51zge8cIrIDTfOyUyoAEhnn3Hm+M4ik2Aun+ZXOuYc1zctQVAAkErNnz57c399/pO8cIgmnaV4iowIgkejv7z8GyPjOIZIQmual7FQAJBLOuTlm5juGSJxomhevVAAkEmbW6DuDSJXafpp/ZOuZ9prmxTsVAInKfr4DiHikaV5iRwVAImFmE51zvmOIlNuL7jcfBEGnc+5v7e3tvb7DiYyECoBEwjlX5zuDSES23W9+JTveb37lUPebF4kjFQARSStN85JqKgAikmQjPjYvkhYqACKSBJrmRUZIBUBE4kLTvEiEVABEpNpomhepABUAEfFB07yIZyoAIlJOmuZFqpQKgIiMlaZ5kRhSARCR4drpNF8qlVYUi8UtvsOJyMioAIjI9jTNi6SECoBIOmmaF0k5FQCR5NI0LyJDUgEQiT9N8yIyYioAIvGgaV5EIqUCIFJdNM2LSEWoAIhUnqZ5EfFOBUCkfDTNi0jVUgEQGRtN8yISSyoAIsOjaV5EEkUFQOR5muZFJDVUAESet2+hUHjWdwgRkUoIfAcQqRb19fUl3xlERCpFBUBERCSFVABERERSSAVAREQkhVQAREREUkgFQEREJIV0GaCIiMgQpk+fflBtbe0c51xjGIZznXNzzKwRyPnONlYqACIikmozZ84cB8wslUpznHONzrm5ZjYHOASYCGBmOOcAnvt/3KkAiIhIKgw1zYdhmAPctg27mfkNWiEqACIikhhpneZHQwVARERiR9P82KkAiIhIVdI0X14qACIi4pWmeT9UAEREpOw0zVcfFQAREYmMpvn4UAEQEZER0TSfDCoAIiKyU5rmk00FQEQkxTTNp5cKgIhICmialxdSARARSQhN8zISKgAiIjGjaV6ioAIgIlKFNM1LuakAiIh4pGlefFEBEBEpM03zUo1UAEREIqJpXuJEBUBEZAQ0zUtSqACIiOyEpnlJOhUAEUktTfOSZioAIpJ4muZFXkwFQEQSQdO8yMioAIhIrGiaF4mGCoCIVB1N8yLlpwIgIt5omhfxRwVARMpK07xIdVIBEJFIaJoXiRcVABEZNk3zIsmhAiAiL6JpXiT5VABEUkrTvEi6qQCIJJymeRHZGRUAkQTQNC8iI6UCIBIjmuZFJCoqACJVRtO8iFSCCoCIJ9tP82bWCMw1szma5kWkElQARMpouNP8NprmRaRSVABEIqBpXkTiRgVAZJg0zYtIkqgAiLyApnkRSQMVAJGtNm/e/LvGxsYmYDxomheRZFMBEHneXN8BREQqJfAdQERERCpPBUBERCSFVABERERSSAVAREQkhVQAREREUkgFQEREJIV0GaCIiMju/QNYue0/59wiMzvUc6YxUQEQEREZ1GdmjznnHgJWOOc6zeyhIAgeaG9v37D9AxsbGy/wlDEyKgAiIpI264GHzGzbRr4zk8k81N7e/jBQ8h2uUlQAREQkiYY9zaeVCoCIiMSZpvlRUgEQEZFqp2m+DFQARESkWmiaryAVABERqSRN81VCBUBERMpB03yVUwEQEZHR0jQfYyoAIiKyO5rmE0gFQEREQNN86qgAiIiki6Z5AVQARESSSNO87JYKgIhIfGmal1FTARARqW6a5qUsVABERKrDeqDTOfeQma3QNC/lpgIgIlI5mualaqgAiIhET9O8VD0VABGR0dE0L7GmAiAismua5iWRVABERDTNSwqpAIhImmiaF9lKBUBEkkbTvMgwqACISFxpmhcZAxUAEalmmuZFykQFQESqgaZ5kQpTARCRStE0L1JFVABEJGqa5kViQAVAREZD07xIzKkAiMiuaJoXSSgVABHRNC+SQioAIumhaV5EnqMCIJIsmuZFZFhUAETiSdO8iIyJCoBI9dI0LyJlowIg4p+meRGpOBUAkcrQNC8iVUUFQCRamuZFJBZUAERGTtO8iMSeCoDI0DTNi0hiqQCIPO+LZvagc25lEAQrNc2LSJKpAIhsVV9f/+kVK1Zs8p1DRKQSAt8BREREpPJUAERERFJIBUBERCSFVABERERSSAVAREQkhVQAREREUkgFQEREJIVUAERERFJIBUBERCSFVABERERSSAVAREQkhVQAREREUkgFQEREJIVUAERERFJIBUBERCSFVABERERSSAVAREQkhVQAREREUkgFQEREJIVUAERERFJIBUBERCSFVABERERSSAVAREQkhVQAREREUkgFQEREJIVUAERERFJIBUBERCSFVABERERSSAVAREQkhVQAREREUkgFQEREJIVUAERERFJIBUBERCSFVABERERSSAVAREQkhVQAREREUkgFQEREJIVUAERERFJIBUBERCSFVABERERSSAVAREQkhVQAREREUkgFQEREJIVUAERERFJIBUBERCSFVABERERSSAVAREQkhVQAREREUkgFQEREJIVUAERERFJIBUBERCSFVABERERSSAVAREQkhVQAREREUkgFQEREJIVUAERERFJIBUBERCSFVABERERSSAVAREQkhVQAREREUkgFQEREJIVUAERERFJIBUBERCSFVABERERSSAVAREQkhVQAREREUkgFQEREJIVUAERERFJIBUBERCSFVABERERSSAVAREQkhVQAREREUkgFQEREJIVUAERERFJIBUBERCSFanwHEBGRGMoXxgPZ5/5z7EfIFBxTgSk4NwWzeqB+61dMAmq3/voZwIASsAHYBKwFnsLsaXBrca4Lo0iYKXLZ9HWV+4OlhwqAiIgM7ZoVk5gw4TAcR2B2BLjDgVnAgTs8zgC3/e9tV8+695CfcduexAafLzMA+cIGoBPn/gb2ICF/xTIPcumMx0fxJ5KtVABEROR5yzoOJgyOw7njMTsOOBRwGOy4ha+oPYCXYfYytsVwJcgX1gD34tzdOH5LffcfmTe3z1fIuFEBEBFJs9ZH9yWoPR0LzwD3WkL2A3Y3wVeL/YHzMDsPA7onbKGteDdwB6G7nZaGhzznq2oqACIiaZMvHAJ2IbizgaMxCzxO91Eaj9lpwGk4+zL5QhdwBxZ+n0mNdzLPlXwHrCYqACIiaXBdZwMZd97ghp/jE7LB350GYBEuWER3cR354k8gvJmurttZfPKA73C+qQCIiCTV1x8dx+TMubjgCsxOBVxKNvw7sw/YJeAuoSH7OPnCDcB/05wr+g7miwqAiEjStHXNBXs7ZhcDe8XkeH4lHQRcDbyffOcdmLuWVdlbWexC38EqSQVARCQplna8mkzmaiw8ixSP+iOQAXcWjrNoKHaSL3ydTP11zD+g23ewSlABEBGJs+WWYVPhLTj3fuClmvZHrRH4KuGWj5Ivfoug5mssmLbWd6hy0lLAIiJxtNgC8p0X0l1cgXM3AC/1HSkRzKaCfQwbKJIvfJ6buoZetCjmVABEROLEzLGseD7Zrr+CWw7M9h0pkcwmAVfTF3bS2vlRrlkxyXekqKkAiIjERWvxSNqKdxHaDzE7zHeclNgL5z7NhAmP0Fa4guWW8R0oKioAIiLVbsnKqbQWvoazPwAn+o6TUgdiLKG7+AfynSf4DhMFFQARkWo1eJz/XdTVdeK4EkjM9BljR4L7f0/M+/TsUv0evrOMiQqAiEg1ynfMoqH4K3BfByb7jiM7cD2zj9tv9TuvZ8ORZ/nOMmq6DFBEpJosub+WuikfBj4M1PmOI0ML6yfz9FnvpWf28Uy97T+p2fi070gjoj0AIiLV4vpijrp97gQWo41/bPTMPJbH/qWVTYed6jvKiKgAiIhUg7bO+YQ8AO5431Fk5MJxE3ny/A/z5Bs+SFhX7zvOsOgQgIiITzc+ugf9mVbMXQBaxS/uNh3xWnqnz2W/73+ScU+0+46zS9oDICLiy9LO2fTX3AvuAt9RJDr9ex/E483fYOPLz/QdZZdUAEREfGgtvIHA/R6Y4zuKRM9q6njq7Pfx9FnvxTLVubNdBUBEpJLMHPnC53D8CNjTdxwprw1HnsU/5/8npYl7+Y7yIioAIiKV8vVHx9FWvBH4ILpdb2psmTaXfzT/F/37NviOsgMVABGRSrhu9T5MrvkF8FbfUaTyBvY+kH8s+BqbG6rnpo0qACIi5XZ9MUdN6fdAItaQl9EJ6yfzxNu+QPfck3xHAVQARETKa2nnbEJ+g9lM31HEP8vUsua8D1fFFQIqACIi5dLaNYfA/Rqzab6jSBUJMjx11nt59li/V3+qAIiIlENb11G48DfAQb6jSBVyjrWnv4NnjrvIWwQVABGRqOU7DsfCnwFTfEeR6rbu1Ct49lXzvLy2CoCISJTyHbMg0MZfhm3tqVew4cizK/66KgAiIlG5vmMGBL8ADvQdRWLEOZ4+86qK301QBUBEJArLHptCKfg5UF2rvUg8uICn3nA1m5uOrthLqgCIiIzV8hV1lPpvBmb7jiLxZUGGNW9aTN/+TRV5PRUAEZGxMHP0TFyK42TfUST+wrp6nnjLZxmYPLXsr6UCICIyFsu6PoXZxb5jSHIMTJ7Kmjf/O1Y7vqyvowIgIjJarYU3YPYR3zEkeXoPmMVT57yvrK+hAiAiMhrLOg7GsQzd1U/KZNPcU3j2FeeV7flVAERERuqaFZMIgx8Be/qOIsm27vR3sKXhiLI8twqAiMhITZzwbWCO7xiSfBZkWHP+RyjV7xH5c6sAiIiMRFvnfIy3+I4h6VGaPJWnz/23yJ9XBUBEZLiuL+Yw9w3fMSR9ug8+jg1HnhXpc6oAiIgMx2ILKFkeiH5frMgwrD39HfRPnRHZ86kAiIgMR0Px34DX+I4h6WW143ny3A9AkInk+VQARER2J98xC/iE7xgivS85lGePfkMkz6UCICKyK2YO3LeAet9RRADWnXIp/XuN/YaTKgAiIruyrHg5uMrep1VkF6x2PGvPvGrMz6MCICIylOtW74PxWd8xRF6op+kVdB964pieoyaiLLI7y1fX0x+Op7evBuomA1Bj4xhwvYMP6O9nXO0m+kKjOfeMx6Qisk2m/1PgpviOEXMGPANsAvoYXDp5L2AiMM5jrthbe+oVTHj0d7iBvlF9vQrAWC2+s4YZjTPAsgTkgCxGA9j+GPvimApMoXtgAgCuBggHv7YEONv6RBno2/rxfKEErMVYi+Pprb9ehaMAFIEifWGBRU3PVuzPKZI2bV1zobQI2/1DhSeAvwIPY6wEt5JS/yOEE9ex6KCeIb9q8Z01zJi2Ny7IYm42cAguOBhsLnAous/CLg3sfSDPvvJC9rr7plF9vQrASFy3eh8y/UdhvBTc4cDhOOZCWAfwojeK0f/oZoD9cOw35HPVBZAvrAJ7ENyDwF/JuL9yScPDOKe3LJGxsvA/tjZ2ebGNOPd7zH6JC37Jghl/GtX7zuKTB4Cntv533w6fa310X1zmleCOB04DjkSF4EWeefVbmfzXn5HZ+PSIv1Z/mbtyXftMgszxOHc82PHEo5Guxbl7MbsH7B42lv7AlbN6y/2ijY2NPwXOKPfrlFN9ff3kFStWbPKdQ6pAW+fpmPuZ7xhVxblNhPZDguB6ijPuZLELK/r6+Y5ZkLkE7GIgV9HXrnKT//QT9v3Jf47466p9Y1ZZy1fXs6nveFxwGsa5OA71HSkCm3HuHsx+Scb9L/Ozfy/Hi6gASKLkC78HjvEdo0r8H9i1ZCb8kPkHdPsOg5ljWeEEzC0A3obOI8CFJaZ9cyG16x8f2deVKU985At7AecBFwEnk/wfppVgPyDgeyxofCCqJ1UBkMRo6zwXc7f4juGf3YPLfIKFDb/ynWRI17fvRynzDuA9pHyJ5skP/Jx9b/nCiL4mnQXg+icmMtBzPkFwEWanA3W+I3nyMPA9gvA7LGh6ZCxPpAIgiWDmaCv+CXiZ7yge3YILPs3Chj/6DjJsg+cLvBvcu4EJvuN4EZaYvuQyap9eNewvSVcBaO2agwvnA5cD+/iOU2X+iOPb9I67cZdn7Q5BBUASIV84D/iR7xheONdOaP9KSy6+5z5c19lAxn0NiGat3JiZ9OAv2e/Hnxv245O/ENDXHx1HvthCW/E+XLgCuBpt/HfmKIwl1PU+Rr7wVdpWNfkOJOJB9Dddr35bgE9idnisN/4AlzV20Zw7DwvPAQq+41Ra92EnM7Dnfrt/4FbJLQBLOvYkX7iKyTUdYEsxO9p3pJjYG7gKKz1CW/FW2rqO9x1IpCLyhVcCx/mOUVHGnwnCl9KcW0xzbovvOJFpabqNiTVzgSW+o1SSuQzPvuL8YT8+eQVg2eqX0Fb8BnXB48BXgZf4jhRTAWZnY+Hd5DvvZlkx1rv3RXbP3u87QWW5G+gf9+qxnv9TteZN30xz7u3gLmBwJcJU2HjUOYTjJw3rsckpAEtWTiVf+DzhwKOY/StpPRGkLNzxhPZT8oV7yXee4zuNSOSuL+bAnec7RoVsAJtHc3b+aM73iZ3m7A8hPAbjz76jVEJYV8/Gl585rMfGvwAM7ur/PHV1RQaP7+uWneXzSnD/S75w59bdpSLJENrlDK7AmXT/JLQTaW682XeQimpuepRNA68Cfug7SiVsOOoccLs/xz++BWCxBbR1zqcuWMnghn+i70gpchLwW/LF5VzX2eA7jMiYLL6zBmOB7xgV0InLnMCljX/1HcSLK2f1MjE7D+eu8x2l3Pr3PogtM47Y7ePiWQCWFU+mofgnzC0D9vcdJ6Uc2IVk3AraCh8P6+rTMD1JEuVy5wAH+Y5RVs7dT6b0KhbO6PAdxat5rsSChiuAT/qOUm4bhnEYIF4F4KauvWktLCG0XwEv9R1HAJiI8cnV71h2wubGo3xnERm50C7zHaHM/khpyynMn/mk7yBVwTmjObcYs8/4jlJO3YeeSFi/68UR41MA8p0X0hc+jOMK0raAUQyUJk+p/+fbvsiaCz5OaTc/dCJVI184AHid7xhl9CiZ0plceshG30GqTnPuY+Cu9R2jXKymjk1zXrPLx1R/AcgXDqCteCu45cDwVzgQL7rnvIbH3r6U7tlaPkBiwOxNJPfkv8fJuNdp8h+Cc8bEhn8B+4HvKOXSPffkXX6+ugtAa+F1wJ8wO9t3FBm+0qR9WDPvUzz5hg8S1o73HUdkaM5d6DtCWTi3icDOYH42davhjcg8VwJ3MfBb31HKYfP0wyhNnjLk56uzACxfXU9r4Ws4bgcO9B1HRmfTEa/lsUXXsWXaXN9RRF7shuKBwKt9xygLC98R5d0+E605t4WBgYtw7mnfUSIXZOg+5IShP13BKMOTLxzCpoE/4rgSHeuPvYG9D+SfC77Cs8e80XcUkR2V7EKq8T1wrJy7jubGG3zHiJXLZz229VJQ8x0lapvmnDTk56rrh39wlbnf4TjUdxSJjgUZ1r7unTz5xo9idVqnSaqEkcRDiyvorbvKd4hYas7+FONLvmNEbcu0OUNeDVAdBWC5ZcgXFoP7MbCn7zhSHpvmnsxjl36T/n21dpB4tuTxCcDQ+0bjqQ8XXJSK5X3LZVXxI8AffceIVJBhc+ORO/9UhaO82NKHJ7OpeCvwCaohj5RV/9QZ/GPB19jcoGUcxKNxfScDSTtD9T9Z2LDCd4hYW3zyAGH4diD0HSVKPU2v2OnH/W5wl646iGDcXTh0p7kUCesn88TbvsjGI17rO4qklYVJe89ZTU9Pohe2qZhLm+4HErU+QE/TMTu9N4C/ApDvOJygdC+w830TkmiWqeGpc69m3amXD+umFSLRcqf5ThCpwF3FO+du8h0jMUo1Hwae8h0jKqVJ+9C3b/ZFH/dTAFoLr4HgHmCGl9eX6uAczxz3Zp46673gdPRHKqT10X2Bg33HiI79igXZH/lOkSiXTV8HfNx3jChtmX7Yiz5W+XfdZcWTCdxtwOSKv7ZUpY0vP5Mnz/8wFiR1QTapLjXHkaRLjM192neEROpbuxRY5TtGVPwXgNaOswntp5hNqujrStXbNPdk1sz7FFZT5zuKJJ1zSVqn+ne05P6f7xCJtOjofuArvmNEZWcLslWuALR2vgkX/JDknXkrEemZ9crBEpCp9R1FEi08zneCyATuU74jJFrfuG8DibiXwsDeB1KaPHWHj1WmALQWXodzNwJ6Z5dd6ml6BU++6eM6HCDlsdgCcC/3HSMif2F+wx2+QyTaooN6wH3Nd4yo9B6046kv5S8AbV2n4vgxMK7sryWJ0H3wcTz5xo+CSoBEbXphFjDBd4xoWCvOJW7p2qoTBm1AyXeMKPTt17jD78tbANq6jsfCW9Bufxmh7kNP5Kkz361LBCVaAUf4jhCRfqz0Xd8hUuHSGY8Dv/YdIwp9++V2+H35CkDbqiYs/BEwsWyvIYm28eVnsv7E+b5jSKIEh/tOEJGf0DIrMdepVz9LxM2VevetRAFYsnIqVrod2Lcszy+psf6ES9j40tf5jiFJYfbia6FiySVigxQbmQk/xLnYL7Q0MHXaDldaRV8A8oXx1NXdAsyK/LklfZzj6bPfx+acFoyUCDhm+o4QgS1MzNzuO0SqzD+gGwt/5jvGWJnLMLDXAc/9PtoCYOaANiA5l9mIdxZkWPOmT9A/ZZrvKBJ/Wd8Bxsy4l3nTN/uOkTouuNN3hCj077n/c7+OtgDkC+8DLor0OUWAcPwknrjo3wnHJeQEbqm8JSunkoQVSJ0lYkMUO0EyTgQszx6AZcWTCfhcZM8n8gL9U6bz1LlX68oAGZ2amqzvCJFwmURsiGJnfvbvwD98xxirgb0OfO7X0RSA1vbphPZdzNVE8nwiQ+g+5NU8e+ybfMeQOMpkGnxHiEAPEzbd5ztEisV+2eVoDwEstgCXuR7Yb8zPJTIM6067nN5pc3zHkLgx9t/9g6re35k3t893iBR7wHeAsQon7f3cr8deAGYUPgycNObnERkmcxmePP/DhHX1vqNInDibuvsHVTt72HeClFvpO8BYler3eO7XYysAbV1H4Vyi7pks8dC/14Gsfd07fceQOAmZ4jtCBGK/AYq52BewaArANSsmYeH/oBv8iCcbX3YG3Yee6DuGxIWz+BcApwLgVd/aDqDfd4yxCCfs+dyJ1KMvAPUTPoMW+xHPnj7rPZQm7Ok7hsQVafgAAAAfrElEQVSBuX18RxizMGj3HSHVFh3dj3NdvmOMhWVqCGsHb88zugLQWjgWh/a/inel+j1Y99p/8R1D4iH+NyVzts53hNQzW+87wlhZZnDH/cgLwPIVdTiWArpXq1SFjUe8ls1Nr/AdQ6qdS8AtyYPajb4jCLH/Hmy7H8DIC0D3hA8BcyPOIzImT535bkxXBciuOFe3+wdVufpnY7/xSYDYfw9GtwegtX068IEy5BEZk4G9DuCZ497sO4ZUM7O4F4B+rQFQBZyLfQGgZrAAjGzlPlfzH2BajH3kQmA18DSwEawbc93AM8B4nE3EBXtiNhnnJmLWCOjveYSeeeWFTP7zT6l5do3vKFKNjFrivYp0t+8AApjF/vtgmRoAG34ByHeeAHZh2RIlxzrgN5j9EcdKQh5hcu0jI7p7l5njhs7plNxsXHAw2FyME4E5EPO3sDKy2nGsPfUK9v/hp31HkWrkGPAdYYzifxJjEhj1cX8XdmEJoGd4BWCxBVD8alkTxVcv8CtwvyLgTgoNf2WxC8f0jM4ZsGrrf7947uPXdu5Pxp2E42TgDGDGmF4ngbrnvIYt9/+Y8ase9B1Fqk/cd5+PZ8n9tSw6OtbXoSdA/O8oOdAPsHF4BWBG8SLgyHLmiaE/AjdgA9+hZdZTFXnFyxvXAN8DvsdiC5jeeRwuuATHm4E9dvPV6eAc6069nIPyV/pOItXG6Iv75MakfScBsb8MLdYCNxkz3ynGxA30ATy1+wKw3DJ0Fz9R9kTxsBHcf0PpWpqbHvWaZHAvw93A3Sx5/D3Ubnkjzr0PeJnXXFVgy7S59Mw8hgntf/AdRaqJo9d3hDErDUxGBcAvs9jvAXClfoCVuy8A3cVLgNnlDlTlNgDfolTzRS6bXn0LcSw6qAe4EbiR1o7TIPgUjlf5juXT+pOamdBxH3Fv6hKp+BcAc3sxeGhQ/In90qOu1I+Z/X3XlwEuub8W+FhlIlWlbnAfIeydRnPug1W58X+hlqZf0pI7DhecBvzJdxxfeg88mO6Dj/MdQ6qJo/r//e5O6Bp9R0i1xRYAWd8xxsKFJYK+zTjnfrPrAlA75a1AWn/gfoiVDqU5+1kuPSR+130ubPgVE7PHYPYuBi83TJ1nTrjYdwSpKm6t7wQRSPveWL9mrMoS86sxgs0bwKx3y5Ytvx26AJg5HO+rYK5q0UHgzqQ5dwEtM1f7DjMm81yJlsb/YsAOwbkbfceptN4DD2Zzw0t9x5BqYRb/AuBUALxydojvCGOV6XkW4PbHH3+8Z+gCkC+eDhxeqVBVwbkb6el5GQuyt/uOEqnLG9ewMHsJxnmk7ASiZ181z3cEqRZmT/uOMGYhsd8AxZpZ7AtY0LMB4AbY1VLA6Zr+twDvZmH2Et45d5PvMGXTkruFTPgyjHt9R6mUnpnH0je1wXcMqQquMpfrlpNjztbj0OKDs9jfByfo69kcBMFPYKgC0NY1FzitkqE8ehgXHE1z7mu+g1TE/KZVTOo5Cdw3fEepCOfYcOwFvlNINci4JJw9vye5Lh3X8sad5DvBWFntuN+3t7f3wlAFIAyvIB1Lzt6HDZzIwoYVvoNU1Ly5fTRnrwS7ksH7FCTapsNPJdSdAiWg6DtCJIxTfEdIpes7ZgBNvmOMVe9Bs2/b9usXF4B8YTyOFJw+bb8i7D21Yqv4VaPmxm+AuwRI9NKiYe14uuee7DuG+HZxwxNAj+8YY2ahfph9GAhO9R0hCmFd/SPbfv3iAuDcBcA+lQxUeXYTfevOiOXlfVFrzn4H4xwSfqexDS8/03cE8e35e2zEnDtx6xotUknOJaN4lcLCtl++uACYXV7RMJXm3PeZmFugG2pspyX3M5y9kfjfLGVIvS85lL7907qkhTzPOnwniMBk6vY5yXeIVFlyfy3Y633HiIBRN2mIAtDaPh04sdKJKsa4kw39FzPPlXxHqToLG38OLCDB5wRsOiwt57XK0FwybhNpLgWHaavIuH3OAPb1HSMCncw/4Lm9vS/YAxBcRHJP/nsAxxu5clb81wMvl+bcd8G9y3eMctk092RwSf3xluFJSAFwXMA1Kyb5jpEewSW+E0TCeGD73+5YAJy7sKJhKucfDNjpNOdSuSTuiDRnvwl81XeMchjYcz96D9I6KulWSkYBgIlMrH+j7xCpsKRjT8zO8h0jIjv8/D9fAK4v5oBXVDpNBZQwN5/LG9f4DhIbfWs/APzWd4xy2DTnNb4jiE996x8mKee6mGv2HSEVaoO3Asm4jtjZ37b/7fMFYCC8gETu/ncfpyX7a98pYmXwBMm3kcBlg7sPTe4pLjIMgz/bSdkLcBKthWN9h0i0xXfWJGpVXFezwx1itzsE4JJ4ndSvmdjwBd8hYqk5V8TC+YD5jhKlgT3319LAqeeStHfrw74DJFpDw1tIwOI/Wz3Bwhk7XAUzWACWPjwZx/FeIpXPBmqczvgfi5am23C0+Y4Rtc2zNDSlmtk9viNExnEOrcUjfcdIpMUW4IIP+I4RGefufuGHBgtAMO5UoK7SecrK8TEuyf7Td4zYc7X/hnPxv4vadnqakniqiwxbaSA5BQAc2NW+QyRSQ+ECzA7zHSMyob1oz9e2QwBJWOBgew9SLH7Td4hEWDBtLWYf8x0jSltmHEFYO953DPHl8lmPAV2+Y0TGcSFLO17tO0aiLF9dD+7zvmNEyoVD7AEgUTeXMAK3iMUnD/gOkhhd2W8Dv/MdIyqWqaF3xuG+Y4hPjiSdGOzIZL6l5YEj1F36EJCkpUPX07Xqzy/8YEDro/sCMz0EKg/jZhZkU3O/+4pY7EKw5BwLA7ZMT86ePRkNu8N3gkiZHUbdlHf6jpEI17XPBPs33zEiZfxiZ0NxgKs5nuRc/mfgdNZ/OTQ3/h/wG98xorJl+lzfEcSn2swvcJa0vYSfYtnql/gOEXuZzH8ByTpG6Lh9Zx8OcC5JZ//fRkv2T7t/mIyKs8/4jhCVLQcdggUZ3zHEl7c1rMf4ve8YEZtMOHAjy00/2KOV73wX8DrfMSJmhJmf7+wTARa+qtJpyuizvgMk2uANg+7zHSMKVldP3/5JubxXRsXcT3xHKIOT6C5+1HeIWGrrOgrcl3zHKIM/c+mMx3f2iQAXvLTSacrk/2jOJeZEteplifkH0ndAck59kVEIMst9RyiTj5PvfK3vELGy9OHJWPgdYJzvKGVw81CfCDBLyB2lXJvvBKkwcfMtwFrfMaKgPQApt3BGB8aLzoxOgADc9TofYJgWW0Awrg042HeUsnCZXRSAZNhMX+kHvkOkwry5feyiUcZJ33453xHEN8f3fEcokwMIB37Gdav38R2k6mWLXwaSemfF+164/O/2klIAfsSipmd9h0gNczf4jhCFXhUAybjlJOx+F9uZS2bgp1z/xETfQapWa+FDGO/xHaNsnNtlwU1KAUjEBik2mhvuxbl23zHGKqzfg9LkKb5jiE/zswWcS9LSwC90LAObv8PiO2t8B6k6rYVmHIm5smknSvT3J74A9LBx4E7fIVLFOcMsEWdQ9+91oO8I4lto1/mOUFaOc2nIfo98IVnXto9FvthCYN8mOWvgvJhzt29d9npISSgA93DlrF7fIVLHSETpGtjrAN8RxLdJNcuB9b5jlNkbgTtY0rGn7yDe5QtXgV2HuYTvFQmv3d0j4l8AErIhip3+8C4g9rda7t9zf98RxLd50zeD/Y/vGBXwGsZl7k7t1QFmjtbOLwNfJcmT/6An6F2309X/thf/AuBUALwYPOky9qsuag+AABCwxHeEijA7jHDgbpZ1HuM7SkXd1LU3+eKPce59vqNUhNlSFh3dv7uHxb0A9NBVvN93iNQyi/29AVQABIAFjQ+A/cp3jArJYtxDvnA1ZkmfhGFpx9H0hffjONd3lArppTa4ZjgPjHcBMFbqtr8+uRW+E4xVqX4P3xGkWgTBf/iOUDGDx78/T77448SuFWDmyBeuIgjuIVm39t0Nu5FLsv8cziPjXQAcK31HSDcX+7//cOJeviNItViQvR34q+8YFeU4l8zACto65ydqb8CyjoNpK/6MweP9db7jVJDhMl8Z7oPjXQBQAfAqzDzsO8JYaQ+A7MD4mu8IHhyAuWW0FX9JvnCI7zBjcs2KSbQVv0QY/A1I4/0Qbmdhw7D3zMa7AJgKgFeXTV+Hc0/7jjEWVlOH1dX7jiHVon/tjUCn7xienAL8lbbil7i2M16Xxyy5v5Z8YSETJ/4ds/cDtb4jefLpkTw43gXAUfAdIfXMYv9mWRqnlVJlq8Ezp0f0JpowdZi9nxrXRWthCa3t030H2qXlK+po65zPuKkPAXnMpvmO5I1zt430jrjxLgAZp/X/fXNug+8IY2WZtA4LslMTszcAj/iO4dk4HFfgMu20Fa+ltXCs70A7WLrqIPKFq+meUMDcMszSfm9vI+QTI/2ieK+E1Nu/0XeE1AttY+yX1KhN0zlCslvzXIl88ZNgN/mOUgXqMLsMx2XkCyuB7+IyN+zqDnNlky+MBzsHF8yHgdcnfyW/EfkRLdkRr8sS77/AMFAB8C/23wML4v3PQMqgq+G7NBTfCxzlO0oVmQ18Ait9jHzhfuDXYL+mb/w9LDqoJ/JXW2wB0wuH49wpBO4UzE4GNxEzkr+Q34j0Ax8ZzRfG+53vn6u6fUdIPWcb4/6P0Wp0CEBeYLELWdrxboLgN8T9Bzx6AXDM4H/ug9T19pEv/B7jz8DDBMEj9Pet3N2NaHawpGNP6jgYc7OBQ8DNIeg6AXNTAQY3+jKEa2jOjeqKrPgWAGcDWgSoChhb4v72aC4DwPr160PPUaSaXNp0N62Fm3HM8x2lytUBJ+A4AQALoaYG8oUe4CmgG9iEcxuw8FlwE3FuEmaTgD2AvYDBxYi2fy/RRn/3nHsas0+O9svjWwDM1fD1R8fpToCeOTfJd4SxcqV+gNLjjz++2XcWqTal90PmbGCC7yQxNAFoeO532++618Y9GqF9lJbcM6P98nhfBbBnfew3Pgkw2XeAsdpaADYBeleSHbXMXI3Z53zHEHkR5+5nUva6sTxFvAtA2B/7jU8CxP57sLUA/MN3DqlSq7o+D/zFdwyR5zgbwHEF89yYbske7wJAGPuNTwLE/nvgSgOgZaVlKItPHiCwRcCY3mxFouO+xILsn8f6LDEvAMEU3wmE2H8PXH8vZvY33zmkii1o/APwDd8xRIBHmVATyWqVMS8ANst3glRbbAHQ5DvGmJgRbN5AEAR3+o4iVS5T/1G0p0j8KuGCZuZNj+SE5XgXAGO27wip1lCcQczPjg56u3FhqadUKt3rO4tUufkHdGPurUCf7yiSWv/OwoZ7onqyeBcAR7xvXRl3CShgmc0bAG4pFotbfGeRGBhcbnXEa66LROA++tZ+JsonjHkBCGK/AYq1IP4FIOh5FuBG3zkkRrqyX8TQISOppA1Y8Oatd6uMTLwLgFmOJR17+o6RYi/zHWCsgt6e7s7Ozp/5ziExstiFlOwt6NJRqQwDu4yWhshvvR7vAgAZ6tyJvkOklnGy7whjZeMn/RZd3iUjdXnjGgJ3ITofQMrvizQ33lyOJ457AQDnYr8RiqW2VU1A1neMseo74GBN/zI6C7L3gr3fdwxJMONOuoofLdfTx78AGKf4jpBKNpCIv/ewJoh8t5qkSHPjN8Dd4DuGJFIXDFxUzpvexb8AwOEsWTnVd4jUSc6el6LvABJzE7svA37tO4YkygYCO5eWWU+V80WSUAACausu8B0iVZavrsc4y3eMCBgDW9p9h5CYmze3j1LNhWiRIIlGP9ibWND4QLlfKAkFAJxd4jtCqmwaOI/B+3jHXYFLD9noO4QkwGXT15FxZwBrfEeRmDPeRXPjLyrxUskoALjjWdZxsO8UKZKUwlX2hi0pMj9bgPAcYIPvKBJX7iO05JZU6tUSUgCAMHir7wipcG3n/gT2Wt8xIuGcbgAk0Wpuug9zZ+DcJt9RJGYcX6E5+9lKvmQA/LOSL1hGC1lyf63vEIlX45oxV+M7RjTCB30nkARqyf6WsHQ+oOWlZZjsGhbm3lvpVw2A+yv9omXSQO0U7QUop3xhPHCl7xiRMfcH3xEkoVqafomzi9BCQbJbtpSFuXf5eOUAiOzOQt4F7qMst4zvGAm2CDjQd4iIPE5zrug7hCTYwsb/JXCv1+EAGZLjW3TlrsA58/HyAWGYnAJgNpOegi4JLIfBwysV30VVNsbdviNICizI3omFZ6ITA+XFvsDC3DtY7EJfAQKC4H6g11eAyJn2ApRF7ZTLgBm+Y0TG8VvfESQlmhv/D+N0YJ3vKFIVDPgQzbkP+g4S0JzbAvzRd5AIHU5P19t9h0iUZY9NwfFp3zEiZe7/fEeQFGnJ/Z5S6VjgEd9RxKs+nC2kOfd530Hg+csAK7LoQMWYfZYbikk5Vu2fDXwemOI7RmSce5pVDX/xHUNS5rKZ7QS1x+GcDj+l03oC93oWNl7vO8g2gwXAuN1zjqjtQb9VRcOKvXzHKzBr8R0jYnf4PO4mKbZg2lomZE4H+4HvKFJRBSx4NQuyd/oOsr3BArAqex/OPe05S7Qcl7CsmJQb1vixfEUdFiwhSQtGDbrDdwBJsXnTN7MwdyHwQaDkO46UmXEnmdIraWl4yHeUFxp8Y1/sQrBkHQYAR2jfIV84wHeQ2OqZ8HkcL/cdI2IhwUDSftYlbpwzmnNfAE4DnvQdR8rCgC8wKfta5s+syu/x85NdyK0ec5TLAUCexZa0Cbb82jrPxXi37xiRM35frf8YJYWac3cBx5KsE7EFnsE4n+bcB5nnqnYvz/Mbxs09twKb/UUpm9fTUPyA7xCx0to+HXOtgPMdJXKO7/mOILKD5lyRruIrgU+iQwLxZ9yLBUfRkrvFd5Td2fENPt/5fXDJW0jH2QDGmZW6xWKsXf/EREqb7wRe4TtKGYQENTNYMP0fvoOI7NSy4skY12M2zXcUGSFnA5j7DBOzn67mqX97O+4adyz3lKO8zNWA+zHLiq/yHaWqLbm/loHNN5PMjT/A3dr4S1VbkL2TgcxLwW7yHUVGZAVmx9GcWxyXjT+8sAD0jr8N6PYTpewmENotLOs42HeQqmTmqJu6FMcZvqOUjdnNviOI7NZl09fR3HgxgTsT6PIdR3apH/gCGweOornpPt9hRmrHArDooB4gyW+S+xIGP2PZ6pf4DlJ18oUvgV3iO0YZ9ZKp+x/fIUSGbUH2dnp6DsP4OqB1K6qO3UPGvZTm3Ae5clYsl9N/8dnx5q71kKOSsoQDd2tPwFZmjnznf+Dc+3xHKbMfsWDaWt8hREbknXM30ZK7isAdDfzGdxwB4J84FtGVO5H52b/7DjMWOz/LO1/4GzC3slEqbi1wNs253/kO4s3yFXV0T1gGvNl3lLIzdyot2V/7jiEyJvnOc8B9Dcj5jpJCfRj/Td3Ax7h4ViLu7jjU9fFJ3wsAg2vb/5zWjtN8B/Hixkf3oHvC7aRh4w8dNDdU1RKcIqPS3HgrE2vmMriKoPZoVUYJ3A1k3CG05K5KysYfhioApZobSO7JgNubTOBup63wAcySd837UJZ1HkF/zR+AU3xHqQjHt3HOfMcQicS86Ztpzn2Bnp4sg0XgGc+Jkspw7jZCO4rm7HzmZwu+A0Vt6I1eW/EbmP1rBbP45dwv6Q8v5vLGNb6jlFVb53zMfQuY4DtKhWwEZtCc05ukJNNNXXvTZ+8BewdJumunPyXg+xB+huamB32HKaddFIBVTVhpJZCpXBzPnHsMwrexsDF5J9ss6diTccG3MN7iO0pFOb7Cwtx7fccQKbuvPzqOPTIXYe5DwCG+48SOc5sI7Ttkwv9gQdMjvuNUwq53eyd1ZcBdM3A3khl4f2LWjM93noMLvpm61cWcDRBYE/ObVvmOIlIxiy0g23U+8HbMTiF5d/OMlnPtYNdSG1zL2xrW+45TSbspAIVXAvdWJkrVWYfjQxSz18X23vGtXXNw4TXASb6j+GE30dx4se8UIt5c++g0amreBvwL0OA7ThXpBfe/WOnbNDf+Kq3nCO3+xLfWwk8TvTrc7v0J+DQLs7fE5ockX8gCVwOXArV+w3hTIrS5XNq40ncQEe8W31lDQ+50sHnAG4C9fEfyoAR2F/A9SrU/4LLp63wH8m33BaCt6ygsvG9Yj022FTj7IsWu77D45AHfYXaqtasRwqtxNJPeDf82y2jOLfQdQqTqDJ4r8DoILsTsDJJ94mAfcDe4H5AZ+H5iDutGZHgb9Xzhxwy2RnGuHbOlWOkmWmau9h1n62I+ZwILgHPR8T6Afiw4hJaGTt9BRKraYgvIrno5Fp6Gc6dBeNLgzdNi7Qlwv4DwVvrs5yxqetZ3oGo1vAKwtPOlBO5PaOOyvRDsTszdQN3Ajyq6OMRiC2goHgN2Mbg3k+wGP3LGt2nJLfIdQyR2lj48GVd7LC54Nc4dj9nxQL3vWLvRCe4enN0NwT0smPFQbA7Xejb83fr5Qh5YWLYk8VYC/gL8Euwewr67uPSQjZG+QmtXI0F4GuZeDXYqcFCkz58cG6lxs7kk+0/fQURib8n9tdROPRxs8D/njgCOAPb3kKYbWIFzD4A9iHMPUuP+krYz96M0/AJwQ/FABmwlMLl8cRKjF/g7sBJjJfAwQfAIIesZx3o2PbWJRUf37/AVSzr2pKZ2IgxMpiZopGSH4JiNcTCOOfj5BxdHH6I593nfIUQSbenDkwlqsziXA5fFyAH7Mbg3ciowFeemYDZpGM/WC6zDubWYrQV7GliDuceAIo4CUKQ590SZ/jSpNbIT+1oLH8Lx2TJlSZteoIfBhZb28JwlKTrZODAnrrfmFEmsa1ZMYq9JO56YrMndu5EVgHxhPLACaCxLGpGxCNwbWZD9ke8YIiJxMLKT+ppzW4B3lieKyJj8VBt/EZHhG/lZ/c25O8BuKkMWkdHaiJXe7juEiEicjO6yvqDuKkALKkh1MPtwVazJICISI6MrAAumrcU53WFNqsFvWZX7pu8QIiJxM7blffOF7wIXRRNFZMS6CcIj03LrThGRKI11Zb+3A7rVqvhhvEsbfxGR0RlbAWjOPYOzSxhcCU+kkn5ISy7vO4SISFyNfW3/hY2/Ab409igiw7aauuAy3yFEROIsmpv7TMx+FPh5JM8lsmu9EF6gVcRERMYmmgIwz5UIat8KFCN5PpEh2btobrrPdwoRkbiL7va+C6atJbCLGFzjXqQM3A00N17rO4WISBJEVwAAFjT+Aee0VLCUw+/ArvAdQkQkKaItAAALs0txfC7y55U0KzBg5229F4WIiERgbAsBDcXMsazreswuLsvzS5qsI7TjuLRxpe8gIiJJEv0eAADnDLPLce7usjy/pEUvzs7Xxl9EJHrlKQAweOvg3tLZwB/L9hqSZCWwS7auMyEiIhErXwEAWNT0LDZwBvBQWV9HksbAXUFz482+g4iIJFV5CwBAy6ynGLBTAO3GleEw4B00Z1t9BxERSbLyFwCAyxvXAK8HOivyehJXBnYVzbn/9h1ERCTpynMVwFDyhQNw7heYHVbR15U4KOHcIhZml/oOIiKSBpUtAADXrd6HzMAdwCsq/tpSnZwNYLTQ3HiD7ygiImlR+QIAcFPX3vSVbgV3vJfXl2rSg4UX0dJ0m+8gIiJpUplzAF7obQ3r2Vg6FfiOl9eXavEEhCdp4y8iUnl+9gBsY+ZoK34C+ITXHOLDQ8BZNOeKvoOIiKSR3wKwTb7zcnD/BdT5jiIV4NwvMbuQ5twzvqOIiKSVn0MAL9TceC1heDzQ5TuKlJVhfJ1i4Qxt/EVE/KqOPQDbtD66Ly7zP+BO9R1FIrcRsxZaGr/vO4iIiFTLHoBtWmY9RVfX63HuywyuCCfJ8ABwjDb+IiLVo7r2AGyvtXgKzq4HXuI7ioyaYVxL/7j3sOigHt9hRETkedVbAADyhb2AbwFv9h1FRuxJnGthYfYnvoOIiMiLVXcB2Ka1sADHfwL7+I4iw/IdbODdtMx6yncQERHZuXgUAIDr2/ejVPNlsEt8R5EhPU7g/pUF2R/5DiIiIrsWnwKwTWvH2bjgGmCG7yiylbMBzF1DT89HeefcTb7jiIjI7sWvAAAsX11P98CVwEeAyb7jpNyvCew9LGh8wHcQEREZvngWgG2WrjqIIPw82MXE/c8SN861Y+GHaW682XcUEREZuWRsNPMdr4DgU8DrfUdJgccx+xyTNn+beXP7fIcREZHRSUYB2GZZ8VUYn8LsNN9REse5pzH7MhNrvs686Zt9xxERkbFJVgHYprXwGhwfAM4gqX/GyunC+Bo19d9m/gHdvsOIiEg0kr1xvK59JkHmXTguB+p9x4mZv+DsK/Su+x8WHd3vO4yIiEQr2QVgm3zhAIxmHJcCTb7jVLEtYD/A3LW05P6f7zAiIlI+6SgA25g5lq06BQsvB84DxvmOVCUeALuOusyNvK1hve8wIiJSfukqANtb0rEn49wbILgQs9OBOt+RKqyI8b9YeDOXNt3tO4yIiFRWegvA9q5bvQ81pfMxOxs4lWQuLmTAnzG7nUzwAxZk/+w7kIiI+KMC8EJL7q9l/NRXU7LX4zgdOBzI+I41Sk8Ad2HcQcnu4PLGNb4DiYhIdVAB2J0bH92DvppXAcfheDVwNLCH51Q7UwJW4txvCe1uwtI9XDaz3XcoERGpTioAo3F9MUcYHg7B4YR2BDALRxbYuwKv3odzqzAr4PgbIQ8SBA8wIXhIC/SIiMhwqQBEKV/YC8hiNOA4EOemYDYV3BSwKThXh9lkoAYjwLEnRi+OHgCMDQSuhLEeZ0+DW4vZ05itJWAVYVhgVdM/WOxCr39OERGJvf8P7lr/bsX9GQAAAAAASUVORK5CYII=",disc:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAACXBIWXMAALP6AACz+gFmujCYAAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAIABJREFUeJzs3XucXPP9x/H35zszm2zitgmisZudc85IwhYlbi2tpbR1q1ulv7qEjUu0lJ/e9PZrU9RPKb+iVIgkoheCatGiqLSlKFGXLknMnJlNlgpiE7LZZHfm+/n9kaVEErs7Z+ZzzpnP8/Hw0MZm5pXM7pzvfM853y9BKRVqra2tyVwut20ymdwGwLYAtjLGNADYipm3ArAVgK2IaCQzj2DmkURUB2BLAMn+f7/XZgBS6/1aH4BV6/3aCgAlACuZuZeIuoloNTN39/+3FUS0AsAKa21X/6+9Zq19zXGc1+fPn18M7m9BKRU0kg5QqpaNHz9+697e3kYiagLQTESNALZn5kYieueAv41s5ZC9BuD1/n+/DKCTmTsBLGHmpXV1dZ2LFy9+Q7RQqRqmAwClKsuk0+lxxpgMEXkAMsycAeAByACol80TtxpADkCWmbPGmBwzZ5k5m8/nlwKwwn1KxZYOAJQKSFNT09hUKrUTgBZm3omIWgB8DMBI4bSo6gWQJaJ2Zn6BmdsTicQL2Wx2IdadmlBKlUEHAEoN0qRJk1IrV64cz8yTrLWTiGgS9EBfTe8MDBYw8wIAC3p7exd0dnb2SIcpFSU6AFBq00wmk5lord2bmfchor0AtOCDF9EpWX0A2gE8QUSPF4vFJzo6OhYCYOEupUJLBwBKvUdLS8tm3d3d+xLRvkS0D4C98MGr6FU0rATwBIDHmfmRESNGPNbe3r7+nQ5K1SwdAKia1tLSsllPT88+AA4CsB+APQHUyVapCikBeIaZHwXwSF9f30OdnZ1vSkcpJUUHAKqmZDKZYcz8CWY+GMDBAHYHYISzlIwSgKeJ6AEiemDYsGF/b29v75WOUqpadACgYq+5uXnHRCLxOaw74O8PYIRwkgqnbgB/AfAAM9+bz+cXSQcpVUk6AFBxlHBd9+MADieizzPzjtJBKpLyzPwAgHtGjBhxv84OqLjRAYCKBdd1t8S6A/6RzPxZAFtIN6lYWUlE9zPz740x92Sz2bekg5Qqlw4AVGQ1NjaOGjZs2OHMfBzWTe8Pk25SNWEtgL8BuIeIfpPL5V6TDlJqKHQAoCKl/6D/BWaejHXn85PSTaqmFQE8zMy3lkql3y5ZsqRLOkipgdIBgAq9dDo9nIgONsacxMxHQm/TU+G0FsADRHTbqlWr7li2bFm3dJBSm6IDABVWxnXdA4loCjMfBWBz6SClBuEtZr7TGDM3l8vNh25qpEJIBwAqVDKZTKO19gRmPoOIXOkepQLQCeBXxpgbstlsTjpGqXfoAECJa2xsrE+lUl8gojYArdDvSxVPFsB8Zp7NzLcXCoU10kGqtukbrRLjuu4OAE7t/2dr4RylqmklM9+aSCSuymaz7dIxqjbpAEBVW8J13QMAnAvgMOj3oFKPMvOVo0aN+t2CBQv6pGNU7dA3X1UV48eP37qvr2+aMeYrzDxWukepEHqZma9NpVLXL168+A3pGBV/OgBQFeW67nhmPouIToOuwa/UQKwlonnMfJnv+89Lx6j40gGAqgRyXfcQAF8DcCD0+0ypoWAADxLRFblc7v7+/69UYPSNWQXJOI5zGBH9AMAe0jFKxcjzRPTTpqamX8+fP78oHaPiQQcAqmyZTGYYM3+Rmb8PYAfpHqVirADgZ2vWrLnhlVdeWS0do6JNBwBqyCZMmLB5X1/f2QDOA7CNdI9SNeQ1AFfU19df097evko6RkWTDgDUoLW0tGzW09NzKoDvABgj3aNUrWLm5UT0cwD/5/v+SukeFS06AFAD1n/gPwvAtwCMku5RSq3zzkDAWvuzQqGwQrpHRYMOANSHGjt27Ijhw4efDuC7ALaV7lFKbdSbAC7t7e29qrOzs0c6RoWbDgDURk2aNCm1YsWKNgA/1MV7lIqUlwFcVl9f/4v29vZe6RgVTjoAUBtiXNf9IoALAGSkY5RSQ/YSEf1PLpebB11HQK1HBwDqfdLp9D7GmMsBfEK6RSkVmAXW2q8XCoW/SIeo8NABgAKwbsleIrqImY+TblFKVcw9RHReLpfLSocoeToAqHH9m/T8gIjOBJCS7lFKVVwvgGt7e3sv7OzsfFM6RslJSAcoMcbzvJOstXcR0QHQ7wWlakUCwD6JROKMhoaGNV1dXU9Brw+oSToDUINc190TwM8B7CXdopQS9wyAr/q+/4h0iKouHQDUkObm5o8kk8mfMPOJ0NdeKfUfTES3A/h6LpdbKh2jqkOnfWuDcRznK8aYO7HuU78e/JVS70UAWgBMbWhoWNnV1bVAOkhVnh4IYs7zvAwzXw/gAOkWpVRkPFoqlU7v6Oh4UTpEVY7OAMTUpEmTUvX19d8EcBt0MR+l1OCMM8ac0dDQMHLs2LF/ff3110vSQSp4OgMQQ5lMZjdr7UwAu0u3KKUi71/W2tMKhcIT0iEqWDoAiJH+TXt+AOAb0NkdpVRwLDPPrKur+8aiRYvelo5RwdABQEx4nvc5Zr4OQLN0i1IqtgrW2jMLhcL90iGqfDoAiLiJEyeO7u3tvRLACdItSqnaQEQ3p1Kp8xYuXLhcukUNnQ4AIsx13U8DuAnA9tItSqmas4yI2nK53L3SIWpo9DxxBPVf4f8DADMBbCndo5SqSZsBOH6rrbYatfXWWz/85ptv6p0CEaMzABHT3Ny8ozHmV0S0m3SLUkr1+xczn5DP55+TDlEDpzMAEeJ53hQi+j0RjZNuUUqp99iWiNoaGhpWdXV1/UM6Rg2MzgBEgOd52zLzLACHSbeoSCkCeBsAiKjHWrum/9dXEpEF8M6UbYKZDfpPJxljhjNzff9/2xxAsorNKvruNsacms1mX5cOUZumA4CQc133UACzAIyRblFi+ph5KdZddLUcwBtEtJyZlzPz68aY5dba5YlEYnmxWFyeTqffmD9/fjHIgEmTJqWWL18+OplMji6VSqONMaOttaOJaBsiGm2t3ZqIRjPzaCLaDkATdOBQy17tv0DwPukQtXE6AAipxsbG+mHDhl3KzGdBX6e4KwF4BUCemQtElCeiQqlUyhNRIZ/Pd+I/n9YjobW1NdnR0bF9IpFwmDnd/49DRA6ANNbduWJkK1WFMTNfzcznFwqFNR/+5ara9MASQul0Om2MuQO6lG/cWAA5AM8CeJ6Ingfw/PDhw5e0t7f3yqZVV0tLS11PT08zEX2UmXcGsEv/Px50YBA3TwE41vf9JdIh6v10ABAynucdwMy3ANhWukWVZSXWXRndTkQvAFjQ3d39z2XLlnVLh4VZS0tL3dq1a3dg5knMvBPWbVG7J/QUWKQx83IAx+fz+T9Jt6j/0AFAeJDrut8C8GPo3RmRw8y+MeZRAI8Q0aPZbPYFACzdFRdNTU1jk8nkvgD2I6J9AewGnSmImhKAi3zfvwDrZsOUMB0AhMCECRM27+vrmw3gWOkWNSB9AJ5j5kcBPJJKpR5evHjxG9JRtSSTyWxhrd0LwH4A9u3/p37Tv0uFxN3W2imFQmGFdEit0wGAsEwm02Kt/S2A8dItaqNKAJ4gontLpdKDo0ePXrBgwYI+6Sj1H/2nDiYx80HW2kOIaC/oTFqYLSyVSsd0dHS8KB1Sy3QAICiTyRxprb0JupxvGL1ORPMB3LN27dp7Ojs735QOUgPX2Ng4KpVKfRrAQUR0GHS/jDBaxcxT8/n8bdIhtUoHADISruv+GMC3oK9BWJQAPAPgQQD3+L7/d+h5ytjon2k7HMBBAPYHkBJOUuswM189atSob+isWvXpwafKGhsbR9XV1d0O4ADpFoU+Zn6IiOYVi8XfLVmypEs6SFVe/8/gUUQ0mZk/DV2wKAweLBaLk/VnsLp0AFBF48ePd4vF4h8ATJRuqWEWwGMAbmPmW/L5/DLpICVn3LhxDalU6ghmPg7AZ6EzA5KyAA71ff8l6ZBaoQOAKkmn03sbY+6C3t8v4d2DvrX21kKh8Kp0kAqfiRMnju7r6zusfzDwOejMQNUx83JjzJG5XO5R6ZZaoAOAKnAc5wtENBd6m1K1vQBgZqlUuqWjo+Pf0jEqOpqamsamUqn/IqLTmHlH6Z4as5qITszlcndKh8SdDgAqzHXdcwFcAV20pFrWENHdzHy97/sPQRfjUWXyPG+StfYMIjoBwEjpnhrBAC7wfX+6dEic6QCgchKu614J4CzpkBrxAoC5dXV1MxcuXLhcOkbFj+u6WxLRF621ZxLRbtI9tYCIbmhqavpK0LtbqnV0AFABY8aMGTly5MjfADhCuiXmeojonv5P+w9Kx6ja8Z5ZgS8B2Fy6J86I6P5kMnncokWL3pZuiRsdAASsf83ye/QTQkV1ALgylUrN1DcFJal/SeLTAJwLYJx0T4w9Za09Qi/gDZYOAAKUyWR2stbeB6BJuiWmniKiy5uamm7XKUEVJq2trcklS5YcB+Ab0G28K6XDWvu5QqGwUDokLnQAEJBMJrObtfZ+ANtIt8QMA3iIma/K5/N3S8co9WFc192PiM5h5mOg+xEE7TVr7WcLhcIz0iFxoAOAALiuuyeA+wCMkm6JkbVENI+ILunfWlepSPE8L2Ot/SoRnQ69BThIK4wxh2az2cekQ6JOBwBl8jzvAGa+C8Bm0i0xsZqIrgVwWS6Xe006RqlyOY4zhojOB3AmdCAQlLf7rwn4i3RIlOkAoAye5x3CzHdAf6iD0MvMc4rF4o+WLl36inSMUkHzPG9bZv4a1l0wOFy6JwbWMvPkfD5/l3RIVOkAYIgcxzmCiG4DMEy6JeL6iOiWRCIxffHixb50jFKV5nlek7X2G0Q0Dfr+Ua5eAMf7vn+HdEgU6QBgCFzXPR7ATdC1wsthiegOAN/N5XJZ6Rilqs1xnGYA3yWiqdD3knKUiOi0XC43RzokanQAMEie501j5muhS/sOFQO4BcB03/cXS8coJS2dTk8koulENBn6njxUloi+nMvlrpcOiRL9ZhsEx3HOIqKroX9vQ/UkEf13Lpf7u3SIUmHjuu4eAH4GYF/plohiZv5mPp+/XDokKvRANkCe553DzFdKd0QREb0C4Ee5XG4m1m3Nq5TaMOrfPfQyAM3SMVFERN/K5XKXSXdEgS5SMQCu604FcC10wDRYPQCuSKVSX3zppZceg+7Mp9SHWrFixQv19fXXJ5PJIoC9AaSkmyLmoIaGhmVdXV1PSYeEnR7QPoTjOCcS0U3Qc/6DdY+19quFQqEgHaJUVGUymUZmvpiZT4S+Xw+GBTDF9/1fSYeEmX5DbYLrusdi3QVreoXuwD0N4Fzf9x+RDlEqLhzH+RQRXQngY9ItEVIkosm5XO5O6ZCw0lMAG+E4zmeI6HYAddItEdED4H9832/r6urqkI5RKk5WrFjRseuuu964cuXKNwF8Evq+NBAGwNENDQ3/7Orqekk6Jox0BmADPM/bl5nvBzBSuiUi/grgdL2tT6nKGz9+vFssFmcAOEi6JSJ6+vcOmC8dEjY6AFhPOp3exxjzJwCbS7dEwAoiOj+Xy90AvcBPqWoiz/NOstZeQUSjpWMioBvA5/TU5PvpAOA9HMfZlYj+DN3VbyDuSSaTZy5evPhl6RClapXjOGOMMZcx80nSLRGw0hhzYDabfVo6JCx0ANAvk8nsZK2dD2Ab6ZaQ62Tms3QDDqXCw/O8owBcw8xjpVtC7jVr7f6FQmGhdEgY6AAAQFNT09hUKvU4gCbpljAjopuJ6OxsNvuWdItS6v1c190SwDUATpBuCbkOa+0+hULhVekQaTU/ABg7duyI4cOHPwxgL+mWEHur/1P/L6VDlFKb5jjOcUQ0A0CDdEuILeju7t5/2bJl3dIhkmp9cZvEsGHDfg09+G8UMz+WTCZ304O/UtGQz+dvw7r1Av4q3RJik0aOHHkravxW+Jr+w3uedxWAKdIdIVUEcGE+nz9l+fLlb0rHKKUGrqura2VXV9fchoaGLgAHosbf6zdifENDw5iurq57pEOk1Ow3hed532Tm70l3hFSeiD7v+/7N0Nv7lIoq7urqeqKhoeF+AK0A9HbBD9qjoaFhZVdX1+PSIRJqcgDgOM4XAMyAXgPxAUQ0s7u7+8ilS5f60i1KqfJ1dXW9su22286x1n4EupTwhnxm1KhRz3V1ddXcnQE1dwB0XXdPAPMBjBBOCZs1AL7i+/5s6RClVGW4rnsCgOuh73/r67HWHlgoFGpqJqCmBgDNzc1OIpF4DMAY6ZaQWQLgWN/3dftMpWIunU5/jIjuICJXuiVk3iCij+dyuax0SLXUzF0AjY2NoxKJxL3Qg//67i0Wix/Tg79StaFQKDzT19e3JxHdL90SMlsDuGvcuHE1c/tkTVwD0Nramly1atXdAPaQbgkRBnCh7/vTVq5c2SMdo5Sqnrfeequnq6vrN6NGjUpg3e6CNTUbvAnbGGMmdXV1/Ro1cAF0TQwAjDGXATheuiNE3iKi433f/wVq4JtcKbVB3NXV9eeGhoanABwKYLh0UEi4DQ0Nw7q6uh6UDqm02I/6PM87mpnvQA38WQdoYalUOqajo+NF6RClVDi4rrsDgDsA7CzdEhLMzF/sX1QptmJ9UMxkMi3W2scBbCbdEgZEdNeqVauOr/XlL5VSH9TS0rJZT0/PLQAOk24JibettXvFeeOg2A4AJkyYsHmxWHyCmXeUbgkDZr6+ubn5rPnz5xelW5SQGU+lkBzlIoEJsNgWhkaAUQ9GLwz6B4XUDba9AADmLiQSJcAuRzH5BrrXLsc5O6wV/BOoykt4nvczZj5bOiQkFhlj9orrBmhxHQCQ67q3AThWOiQEGMAFvu9Plw5RAuZ0TALzkSAcAOa9AaTKejyiVWBeDuANAG+A6HVY2wFj8gAVACpg7WtLMG2PvgDqlRDXdc8FcAVq6E6xjWHm3+fz+aMRw+ulYjkA8Dzv+8x8oXRHCKwholNyudyt0iGqima8MgLD1p4GxhkAWgQKSgBeBpAHkAPjXzDmOdje5zB1h9cFetQQ9F8/9UvookEgovNzudyl0h1Bi90AwHXdgwDchxq5w2FjmHm5MebIXC73qHSLqpIZT6UwbOtzwHw+gG2kczbiVQDPg+hZwD6Pon0and4LmE5WOkx9UDqd3tsYcxeAbaVbhFlr7aGFQiFWayfEagDgOE4zET2FdQs61LIsgEN9339JOkRVyY25/WDMdZD5xF+uFQD+DqK/w/Ij6Bv2JKaNXS0dpdbpX0H1jwAmSrcIe7NUKu3R0dGRlw4JSmwGAI2NjfV1dXWPANhdukXYX4vF4lFLlizpkg5RVTCdDdId3wHsdDAlpXMC0gfgnwD+DtAD6K2brwMCWY2NjaPq6uruArCvdIuwJ40xn8xms7G4GDY2AwDP866u9StXmfm+vr6+Yzo7O3Vlv1owOz8cwG8AHCWdUmFrAPwFwH2wfC9OdRdJB9WisWPHjqivr/8tM39WukXYFb7vf106IgixGACk0+nPGmPuRUz+PEN0t7V2cqFQWCMdoqrgmvbNMGLEPQD2l04RkAf4XhhzD+q7H8Lkll7poFrR0tJS19PT8xsAx0i3CGIAh/u+/0fpkHJF/oCZyWS2sdY+B2A76RZBtzQ0NExZsGCB3npVC2Y8lULd6LsB1PonMQBYAdDdgL0NvW/ep7cfVkXCcZwbiehk6RBBy5h513w+v0w6pBxRHwCQ67q/B3CEdIgUIrohl8udCUCvoq4Vcwo3g/lE6YzQIXoDzHeAaR42a/4LJlNJOinGjOd5M5j5NOkQKf3rA0T69FukBwCO45xNRFdLdwi6xvf9ryKGC1SojZjtnw7Q9dIZEfAqGHNBdibaPL0bpjLIdd3LAZwnHSKFiKblcrnI/jxGdgCQyWR2stY+BaBeukXIT3zf/7Z0hKqi2bkdAPMsavd7figYwF8AugHg36LN0WtkAua67vkALpHuELLaWjspqvsFRHIAkMlkhllrnwCwq3SLBGb+Xj6fv1i6Q1XZ7PwfsG7bVjU0K8G4FczX4lT3WemYOKnx1VcX1NfXf6K9vT1yF6NGcp1na+3FqN2D/0V68K9Bs3KHQw/+5doShDNg6BnM9h/ETYVDwBzJD0Fhk8vlLiKiWn1fmtTT03OBdMRQRO6b33Gcg4noPkR08FIOZr46n8+fI92hBMzOPwrgE9IZMfQSgGswMnk9Jjfp+hll8jzvMmb+hnSHAEtEB+dyuT9LhwxGpAYAEydOHN3X1/ccM4+Vbqm2/qv9p0Ev+Ks9c/xPgekv0hkx9ypAV6OUuA6nNb0pHRNh5Hne9TV6d0BnsVjcJUqrsEbqU3Rvb++VtXjwB3B7Lpf7MvTgX5uY2qQTasB2AP8YieISzC5cihmLan0/kaHi/g8qv5YOEdCYSqWulI4YjMjMAHiedwgzR37lpSH43bhx446bP39+UTpECZi3tB7dxWUANpdOqTFvg+hKpOgKnNAcmU90IZLwPO83zHycdEi1EdHRuVzud9IdAxGJAcCYMWNGjhw58nkAjnRLlT1gjDkiLhtPqCGYlTsIZB6QzqhhbwO4FsAlaHNWSMdESf+ywXei9i5e/XexWGyJwqmASJwCGDFixMWovYP/X3t7e4/Ug3+NIzpAOqHGbQ7gfABZzM6fj3lLdQ2GAWpvb+9ds2bNcQAekW6pso8kk8nLpCMGIvQDAMdx9iKis6Q7qmxhsVg8Snf1UwDtIV2gAACjAVyC1aXFmONP0dsHB+aVV15Z3dvbeySAWtvB8dR0Oh36vTpCPQBoaWmpI6IbASSkW6poWalUOjQK00eqKiZKB6j3YG4E002YU3gMs/P7SOdEQWdn55vGmMMAvC7dUk3GmOvGjh07QrpjU0I9AOjp6fkOgI9Kd1RRjzHm6I6Ojrx0iAqBGU+lADRKZ6gN2hvAo5hTuAE3+GOkY8Ium83mABwGYLV0SxWlhw8f/gPpiE0J7TSW4zgTiOgZAMOlW6rEAjjO9/3fSoeokJi5dBQSxeXSGepDvQXQjzCy+UrdgXDTXNc9FsA8hPzDZ4CK1to9C4XCM9IhGxLWF8EQ0UzUzsEfAL6uB3/1fn166180bAHw5Vjd8Thu9GtyifKB8n3/DmY+X7qjipLGmBkI6bE2lFGO43wFwH7SHdXCzNf7vv8z6Q4VMsZa6QQ1CMx7IIGnMCt/Jea+OlI6J6zy+fxPiejn0h1VtJfrumdIR2xI6E4BNDU1jU2lUgtROwuf3O37/tEAdOpQvd+vOhrQa3VZ2mjKgcw0nNL8kHRISCVc1/091l0XUAtWENGEXC73mnTIe4VuBiCVSl2K2jn4P9/d3f0l6MFfbUhq3Fsg1hUgo8kD2wcwKz8DNy6slfezwSjV19f/F4B26ZAq2YqZL5GOWF+oZgA8z9uXmf+GkHVVyAoi2jOXy2WlQ1SIzc4vBrCDdIYqSwHWnoRTvVpbEOdDua67A4AnAWwp3VIFbK39RKFQeFw65B1hmgFIMPPPURsHfyaiqXrwVwOwUDpAlS2NBD2M2f7/YB7X0pomH8r3/ZeY+STUxkZnZIz5OUJ03A1NiOM4XwbwMemOKrkgl8vdKR2hooBC82lBlYEpCdAF6C48ipnZjHROmOTz+buJ6H+lO6pkkuM4U6Uj3hGKT9vjx4/fulgsLgbQIN1SBX/0ff8IrLvvX6lNW7fa3GPSGSpQb4HwTZziXC8dEiIJ13X/COAz0iFV8Lq1dnyhUBDfXCoUMwClUumHqI2Df6Gurm4K9OCvBqqj8BSAZdIZKlBbgDEDs/M3Yna+ltY62ZRSb2/vl5jZlw6pgm0SicT3pSOAEMwA9K/49zyAlHRLha0xxuybzWaflg5RETMnfwUY50lnqApg/BNJOhZT0rr8NwDHcXYlor8DCPUa+gHoJaIW6evAxGcAjDGXIv4HfxDRl/Xgr4akWJqF2rhIqvYQdoPFPzArd5B0Shjk8/lnmXmadEcV1AG4WDpCdAYgnU7vb4yZL9lQDUQ0M5fLnS7doSJsTuFuMB8unaEqpgTgInSkL8B0qvlThI7jzCGik6U7quCTvu+L3R4qOQNAxpifCj5/teSSyeTXpCNUxHHpAugsQJwlAPwQzYXbcE37ZtIx0kaMGHE2gJekO6rgcgh+EBcbALiu+yUAe0g9f5UUrbUnLFq06G3pEBVxbd6TAGZLZ6iKOwYjRvwds7JN0iGS2tvbVwE4AUCfdEuF7eU4zheknlxkADBp0qQUgB9JPHc1MfMPC4XCE9IdKiZ6e88HEKq1xFVF7AxKPIqb/F2kQyT5vv8kgB9Ld1QaEV3U2tqalHhukQFAV1fXaQDivhjGI/l8/ifSESpGpk14A4b+C7p3RC1oAptHMadQK5vlbJDv+xcS0V+kOypsfEdHh8j1DlUfADQ2NtYD+G61n7fKVjLzidA3ahW0k9MPAxz72TMFgHkzwP4Os/zTpFMEWQAnAeiSDqkkIvpR/7Gxqqo+AKirqzsXQGO1n7fKvpzP5zukI1RMtbkXApghnaGqgCkJohsw2/8xmMXXbZGQy+WWMvM50h0Vtn1dXd2Z1X7Sqn5Dua67JQAfwKhqPm81EdHNuVxuinSHirl5nMDqjuvAXMufDmvNdehIn1Wrtwm6rvsrAMdLd1TQ6/X19W7/BZBVUdUZACI6BzE++APoJKKzpSNUDZhMJZzcfAaILoLeHlgrzkRzx5xa3VHQWnsWEb0i3VFB2/T09JxVzSes2gxAJpPZwlqbR4wHAER0dC6X+510h6oxs/0jAJqDGP9sqfe5G8BktDlrpEOqzXXdw7Huzx9LzLy8rq7Oqdat41WbAeg/hxPbNyhmvlUP/kpEm3s3isVdAb5DOkVVxREA7sC8pVW/aEya7/v3APitdEelENHoYrH45ao9XzWepKWlZbOenp48gK2r8XwC3mTmnfL5vO7apmTN8T8Dph8B2Ec6RVUY42H0rP48zmqp2jnjMEin09sZY15AfHeQfaO+vt6pxrUAVZkBWL169TmI78EfRPR1PfirUDjF/RPGQOAZAAAgAElEQVTanI+D6dMAbgHQI52kKoRwAEaMuAczXon7znnvUygUXmXm86U7KmjrNWvWVGUWoOIzAGPHjh0xfPjwAoBtKv1cQh70ff8z0AuxVBjNyG2JOvoMQAcC2BfAeADDhKtUsO7H28Ujcc4Oa6VDqogcx/kzEbVKh1TIMmttulAoVPQ6j4oPADzPO4eZr6z08whZbYzZJZvN5qRDlBqQeZzA6qVpcN8oMLYEJbYAbAIwKRCv24SGMQKELWAxGsSjARoNYDSA7UD8ETCJLFuqNoFxJ5YUJmP6AUXplGpxXXcHAM8CiOu1EF/xff8XlXyCig4AWltbk0uWLMkCaK7k80hh5m/k8/nLpTuUqprpDyfRnG4EkAbDAZAGMBGEXQDsgHW72ikR/Ct0OFNqaZ0A13W/A+Bi6Y4KyY8bN278/PnzKzaoq+gAwHGcE4no5ko+h6Cnfd/fC7rcr1LrzFtaj9V2J1i7C4h2A/gTIN5VZwyqiW7AKc3TQFQTpyT7P2QuABDLjZOI6Eu5XO6Wij1+pR4YALmu+zSAj1XwOcQw86fy+fzfpDuUCrW5r45Ecc3eILsvQPsB+CTiO2UbDsyXY6r7DemManFddz8Af0WVV7atkmd9398NFbrGrGJ/Ya7rHgrgD5V6fGG3+L7/JekIpSJndn442O4HMgcBOAjAJOmkeOJz0OZeLV1RLa7r3g7gWOmOSmDmz+bz+T9V4rErOQB4EMCnK/X4gnqYeUfd7EepAMzqcIHSMSCaDGBP6ZwYKQF8NNrc2K6a917Nzc1OIpF4AcBw6ZagEdH9uVzucxV57Eo8qOd5H2Xm5yr1+MJ+5Pv+dOkIpWJnVocLspPBmAzCbtI5MdANMvvjlOYF0iHV4LruxQC+I91RIbv4vv980A9akYWAmPm/Ec+D/8vd3d2XSUcoFUtTm320OZdgqrM7ErQTgJ+A6A3prAgbCbb3YKYfy7uw1ldfX39xjDcLqsgmQYEfpDOZzDbW2g7E80KfE3zf/7V0hFI1Y97SenT3fQGg0wB8SjonotrRa/fFNG+ldEileZ53MjPPke6ogJ66urqmhQsXLg/yQQOfAWDmaYjhwZ+IHvd9/zfSHUrVlMlNPWhzb0absz+A3QC6GUCfdFbEtKDO3FoL2wjncrm5AP4h3VEB9b29vWcE/aCBDgBaW1uTzHxmkI8ZEmytPRe63K9SctqcZ9CWngJgHIAfAXhTuChKPovu/AXSEVXARHQe4vle/ZXW1tZA19QI9BSA67rHArg9yMcMid/4vn+8dIRS6j1uXLg5qO5cEH0dwFbSORHAYByNqc7vpUMqzfO8ecx8nHRH0IjomFwud2dQjxf0KYCq7WNcRSVrbS2MnJWKllMnvo2p7kWwa8cB+DaA2J/jLhOBcDPmFnaUDqk0Zv4+4rlK67QgHyywGQDP8zLMvDjIxwyJ2b7vT5WOUEp9iBmLtkYq9W0QnQ3d8XBT2rF69T44q6Xi+81Lcl33lwBOkO4IGAOY4Pv+S0E8WGAzAMz8FcTv4N+XTCYvko5QSg3AtAlvYKr7DZRKHwXoNumcEGtB/Yi5YI7b+/X7ENF0AHHbHZEAnBbkg5WtsbGxvq6urhPAqCAeL0Rm+L4fx4salYq/OR2fBtv/A7CzdEo4xX+5YNd1bwQQtxncN6y1TYVCYU25DxTIDEAqlfoC4nfwX0tEP5aOUEoN0SnND6GjsDuA8wB0S+eED12KmdmPSldUkrX2QgC90h0B2zqRSBwVxAMFdQogbiMsMPOMXC63VLpDKVWG6QcU0eb8DMBHAdwvnRMyw5FI3IJ5S2O3bss7CoVCAcAs6Y6gMXNbEI9T9gAgnU6niShuK3StSaVSl0pHKKUC0uYU0OZ8DuDJAF6XzgmRFnQXL5aOqKS+vr4LAfRIdwTsINd1x5X7IGUPAIwxbUE8TpgQ0c8XL178snSHUipgbe5tKPLOAP4onRIi52JW/rPSEZWydOnSV5j5BumOgBkimlL2gwTw+08uNyJk1gDQDX+UiqvT3WU4JX04CNMArJbOCQECYS5u8MdIh1SKtfYSAGulO4JkrW1DmRfylzUAcF33QABx22nqplwu95p0hFKqgogYpzjXg8xeAJ6TzgmBbZGk66QjKqWjo+PfAGK1kRsRuel0uqzT72UNAIKYgggZLpVKV0pHKKWq5JTmdgB7g2imdEoIHIXZfuyWz32HtfZSxGyPAGNMWcfgIU8fpNPp4caYZQC2KCcgTIjorlwud6R0h1JKwBx/CpiuQwx3Mx2EV1FKtuC0plhutOS67h8BHCLdEaC3ent7t+vs7BzSRY5DngFIJBJHIkYHfwCw1l4u3aCUEnKKOxeG9gWQl04RtB0SxThfAxW39/gt6urqhjygKecUQNx2x3sqn8//VTpCKSXo5PQ/0du7F4C/SacIasOcjk9LR1SC7/sPAXhauiNgQz4WD2kAMG7cuAZmjtVtI0T0U+kGpVQITJvwBkauPghEv5ROEUJgOxNzXx0pHVIhV0gHBOywdDo9pO2whzQASKVSxyFeu211NDU13SEdoZQKicktvTi5eQqYa3U58DRKa34oHVEJDQ0N8wDEaZXX4caYY4byG4c0AGDmLw7l94XYz+bPnx+3XaOUUuUgYkx1vw/QqSCuwfcH/m/MLewoXRG0BQsW9DFzrO72IqLJQ/l9gx4ATJw4cTSAOC39+3YqlbpROkIpFVJt6VmwfDTWLRJWS1KwuEo6ohISicQNAFZJdwSFmQ8cN25cw2B/36AHAGvXrj0KQHKwvy+smPk3ixYtelu6QykVYlO9ewAcAqLYHDQGhPkgzC4cKp0RtGw2+xaAedIdAUqlUqkjBvubBj0AIKJjB/t7woyI4rZGtFKqEtqc+SiVDgHwlnRKVRGuxLz2OumMoFlr4/beP+hj86AGAK7rbgkgTreHPOf7/lPSEUqpiDjVewSGDwawUjqlapgzWDXiLOmMoBUKhccBPCvdERRm/mwmkxnU2jyDnQE4HECcRoIzpAOUUhFzsvsPGKqt0wGEH2DWS9tIZwSNiGZJNwRoGDMP6nTNYAcARw3y68Osp1gs/kY6QikVQSenH4Mt1dKFgVuBEtOlI4JWKpXmIkY7QjLz5wfz9QMeAEyaNCkF4OBBF4XXrUuWLOmSjlBKRdRU70EwjkLMtpndODodszpc6YogFQqFFQDulO4I0KH9x+oBGfDV/F1dXfsD2HJISSGkF/+pWtba2pr0fX9zAEgmk5snk8l33gveWrNmTalYLK595ZVXYvPJqGKmOvdjTuFUMN+MMvdmj4AUyH4PwKnSIUEyxsy01p4g3RGQLZcvX/4JAH8ZyBcP+BvWdd2fATh3qFUhs9D3/Z0Qs60hlXqH53lNAD5qrfWMMWlmTgNoBDAawNYABrJ0aA+A5QCWM/O/iagAoEBEBWZ+oaGhYeGCBQv6KvRHiJZZ/vdBdKF0RhWUYLkFp7qLpEOC5LruiwAmSncEgZkvy+fz3xrI1w7mfv7Dh9gTRtdDD/4qJtLp9HbGmE8A2I+IdmfmXZi5AQCICMxD/lavx7pBQyMR7frOL77zeF1dXb2u677IzM8S0WNE9Egul3sBgC3rDxRFU92LMDu/PYAzpVMqLIGE+T6Ak6RDgkREs5n5J9IdQSCiIwAMaAAwoBmA5ubmHROJxAtlVYWHLZVKjR0dHf+WDlFqKMaMGTNyxIgRBxLRIVh3XU5Guuk9VgCYT0T3MvN9vu8vkQ6qmhlPpVA3+g+I17VSG1JCgnbGlPSL0iFB8TyviZk7EJPTOMaYTDabzX3Y1w3oD+u67tcQn32UH/Z9/0DpCKUGI51Ob5VIJI5i5skADkR0NuN6HsDt1tp5hUJhoXRMxc3IbYk68w8A46VTKotuQ1t6SOvPh5Xruo8A2Fe6IwjMfHY+n7/mw75uQHcBMHOcRrRxWv5RxVhra2vScZzPu657lzFmGTPPBnAIonPwB4CdAfzIGPOi67rPuq57Xv9+IvE0zVsJMsfEf40APhZzOlqkK4JERHE6NgzomP2hMwAtLS11PT09bwKIw97QJSIam8vlXpMOUWpjmpqaxiaTyTOJaCqA7aV7KmAtgN8y8y/y+fzfpGMqYnb+KAC/RUymlDeIMBunOFOlM4LSfy1NJ4CEdEsA3m5oaBj9YRfpfug3p+d5BzLzQ8F1iXrA9/3PSEcotSGO4+wC4CwimgJguHRPlTxNRFc2NTX9OnZbcs/yfwqir0tnVFAvbMLBqeNekQ4Jiud585l5f+mOIBDRfrlc7tFNfc2HngKI0/Q/M8dpikfFRCaT2d113buJ6FkiOgO1c/AHgN2Z+aYlS5Ys9DxvCuLx6WudJR3fBhDPGY516pAonS0dESRmvlW6ISgDOXYP5BqAuAwA+oYNGxanFZ9UxGUymZ1c173DWvsU4nWb7VB4zHyT67r/chxnMuIwdT79gCKKxeMBxHfFUcaZuKZ9M+mMoBhjbgcQi5koZv7Q2e5NDgDS6fRWAHYLrEgQMz+0cOHC5dIdSo0bN67Bdd1LrLX/BHAM4nCwC85EIrrVdd0nPM/7hHRM2U7foRPMZ0hnVFADRo6IzXUA2Wz2dQxwFb2wI6I9J0yYsPmmvmaTAwAi+uSHfU1UGGNiM7WjIsu4rvvlZDKZBXA+4rWzZtD2ZOa/ua47e/z48VtLx5Rlqns7iH4pnVExjPMw/eHBLCoXajE6DZBcu3btJgfRmzy4G2M+FWyPmGJfX9/vpSNU7fI8L+O67oMArgUwSronIgyAU4rF4mLP86L9KTrZdxaAgnRGhaSRdo6UjghKKpW6E0BJuiMIxphNXtC4yQFAXK6GBPCY7vynhCRc1/02M/8LwAHSMRHVwMwzXNf9Qzqd3k46ZkhO3OEtMJ2KuC5Bzny6dEJQFi9e/AYRPSndEZBNfojf6ACgpaVlM8Tn/P990g2q9nie1+Q4zoMA/hfRWrwnrA41xjznOM6g9jwPjanpP4Nxs3RGhRyM2fm0dERQYnTM2HPs2LEjNvYfNzoA6O7u3heD2ywotBKJxL3SDaq2uK57DDM/R0St0i0xsw0R/d513WtaWlqidw1FIvU1AHFciMyA0SYdERRmjssxo66+vn7vjf3HjQ4AiGi/yvRU3avZbPYZ6QhVMxKu604HcBsGtuWuGpqv9PT0/N1xnGbpkEE5uXE5QOdJZ1SEoamYx7FYxyGfzz8F4HXpjiAw8yc39t82NQDYpzI5VXcf4nreTYVK/+199wL4IWJy90zITSKiJxzH2egbXCi1pX8N4AHpjMAxN2KVf4h0RkAsgD9JRwRko8fyjb1JEYA9KtNSXTGaylEh1tzc7KRSqUcRn4WzomIMET3oOM6J0iGDkqBzAWxynfZIInOadEJQYnQdwN7YyFojGxwAZDKZnRCP6ctSX1/fg9IRKt7S6fTeiUTicWbeUbqlRtUR0VzHcb4nHTJgU9IvAny9dEbgiA/D7Hw079RYTyqVug/rZgKibpTjOBvcnnqDA4BSqRSX6f/HOzs735SOUPGVTqf3N8Y8AGBb6ZYaR0R0keu61yIqp1/qEv8DIF6rkzIlAT5OOiMIixcvfgPAAumOIBhjNnhM3+APijFmo1cNRgkRxWUKR4WQ67qHGmPuBbDJ5TZVVX3Zdd2bWltbw38H0wnNXSBcIJ0RODKTpRMCFItTyMy8wWP6BgcAzLxnZXOqo1Qq6fS/qohMJnMkgDsB1Eu3qA84ccmSJbMRhZmAtct/ASAvnREo5n0xNzdOOiMIzByXY8jABgCZTGYYgJaK51Rez8iRI5+WjlDx47ruQdbaW6Br+YfZia7r3oiwb7Q0bY8+MF8snREwQtEcKx0RhEQi8Q8Aa6U7AvDRDa2b8YEBgLV2ZwCpqiRVEBH9o729vVe6Q8VLOp3eH8DvAQyXblEf6hTXdS+XjvhQmzmzASySzggU4YvSCUHIZrNrEY/rAOq6u7t3Wv8XPzAAIKLdq9NTcY9KB6h4yWQyOxljfgdgo0trqtA5z3Gcb0hHbNJkKgH8Y+mMgO0Vl6WBmTkWxxJjzAeW9v/AAICZ47L+fyxeNBUO6XR6O2vtHxGP22NrChFd6rru8dIdmzTS+TWAxdIZAaK43A2QSCRicSzZ0LF9QxfJxGEAwL29vY9LR6h4aGxsrDfG3A0gWsvOqncQgJnpdDq8dzdNphIYV0hnBIpMNDdtWo8x5lHEYDVZIvrQAUACwM7VyamoF/X+fxWUurq6axCTlTFrWL0x5s7m5uaPSIds1KriHACvSmcEhvnjmLl0lHRGufrXA4jD7MyuWO+i2PcNAFzXdRGD85tEFIspGyXP87yvAvHZ5azGfSSRSNw2adKkcF7kfM4OawFcJ50RoAQSfZ+WjghIHI4pmzuO877bM983ACCiONz+B8TjxVLCHMfZi5nDfxW5Gox9u7q6LpSO2KhS8moA3dIZwaHPSRcEJBbHlPWP8e8bAFhrP3CbQETF4sVScsaMGTOSiG5GDG6JVR/wTc/zDpSO2KDTmt4E6NfSGQH6HJjDvRbDAMTlonJmft8xfv0ZgMhvZsLMy3O5XE66Q0XbyJEjrwKwwQ00VOQZZp47ceLE0dIhG1a6QbogQGMxK7+LdES58vn8YgBd0h3l2uQMADNH/hQAET2HGFyxqeQ4jnMEgKnSHaqitu/t7b1aOmKD2rwnwfindEZgDB0inRAABvC8dEQANjoDYIhoQpVjKuE56QAVXZlMZgsiula6Q1XFlxzHCeetaoZulE4IDOMz0glB6P9wGXU74T13Arw7AEin0+MQgzsAmDkOozQlxFr7EwCN0h2qOojo6gkTJoRvN8e1pV8CWC2dEQjCPpjXHod9M+JwbNls/PjxY9/5P+8OAIwxGZmeYMVklKYE9C8Uc4Z0h6qqccVi8YfSER8wzVsJ8J3SGQGpx6oRkV9grlQqxeLY0tvb++6x/r2nAOIwACitWbOmXTpCRRIZYy5HFLaQVYFi5nMcxwnj6c9bpQMCQ7SvdEK5enp6ngdgpTvKRUQfHAAQkSeTE6jsK6+8Eo9pM1VVjuOcACDyb1JqSFJE9FPpiA8Y2XM/gJisaMqR/9latmxZN4C8dEe53nusf3cAwMyRnwHQ6X81FJlMZhgRxW1PdjU4h7uuG65V6ya39AK4SzojIJEfAPSL/DFmgzMAiMcpgDhcpKGqjJmnAWiS7lCymDl8KwQamiedEJAxmJmNwzEm8gMAa+0GBwCuQEvQdACgBiWdTg9n5m9Jdyh5RPRxz/PCdc/6mjceBLBCOiMQicR+0gkBiPwx5gMzAOPHj98a8bgFUC8AVINijPkygO2lO1Q4MPOPpBveZ9oefQA9IJ0RDN5TuqBc1to4HGM2T6fTWwH9AwBr7bhNf30klOrr6zukI1R0tLa2JgH8t3SHCpU90+n0/tIR67lPOiAYFIet5guIwZ0Axpgm4D+nAOJw/vPl9vb2XukIFR1LliyZDCAOg18VIGPM16Ub3ieJexGP5c13ifrGQIVCYQ0RvSrdEYBxQP8AoFQqxWEAUJAOUJFznnSACqXD0+n0ROmId52U/jdicO4ZwJa42Y/8sYaZI38rIPo/9BsAICJ9UVRNcV13DwB7SHeoUCJjzOnSEe/DMTkNUETkdwZEDD5svnPMf+cUQOQvgiKignSDig5mDtcbvAoVZj45k8kMk+54l6G/SicEghKRHwDE5MPmfwYAzKwDAFUzWlpaNiOi/5LuUOFFRKOZ+SjpjncxP4oYXHwGcFwuBIw0Zv4IACQBwBgzhjna15iUSqU4jMqC86uOBvTaCWBsCeItAABkVsPyKpSKOZy+Q6dwoZjVq1cfTURbSHeEQDeApf3/7mLmkUQ0EsCY/n9qGjOfhLCsx9/mrMDs/IsAWqRTyhT5AYAxJh/14yX6f76TAGCt3ZYo0hdn6gzArA4Xxh4OxoEAPo5euy2A/p2f+19b5nX/M5kE5hRWgflpAH8GcD9OST8Bosh/Vw8EER0n3SDkGSJ6iJkfJqLncrnc0o19oeu6W1prd0wkEp9k5gMAHABgePVSQ+HgxsbGUZ2dnWFZj/8RRH8AkMF0NphOkZ3NSCQShWKxKJ1RrjEAQK2trcklS5asRbR3Qevzfb8eQEk6pKpmPJVCavTxMHQamPfFu0f6ISDKwtqbkKj7BU5uXB5cZLik0+mtjDGvAgjP+d0KYublRDTTGDM3m82+MNTHSafTWyUSicn9yybvHmBiqDHzafl8/kbpDgDAHH8KmG6SziibSTbi5KaXpTOGqv+Y2YP+D9ARZceNGzeMmpqaxqZSqci+GP3yvu/HYSnjgZnHCawqnAbCdxH0fexEq8D4BcAXo82JxxKk7+E4zklENFe6o9KYeTmA/x0xYsSM9vb2VUE+tud5hzDzdAB7Bfm4IXWv7/uHSkcAAGZ17ASKwUp01n4Sp3qPSGeUw3XdAoBm6Y5yMPN2ZtiwYXE41/dv6YCquTG3B7oLT4BwHSqxiA3zZgB/E8BCzCmcEPjjCyOicK31HjwGcGMqlZqYz+cvD/rgDwC5XO5e3/c/zsxnIDbb1W5Ua2NjY710BABgib8YwFrpjLIZcqQTAhD5xYCIaFtTKpW2kQ4JQGynrN/FTJidPxfGPApgUhWecQyYf4nZ+TswO79VFZ6vGhLM/BnpiErp/9R/hO/7py1evPiNCj+dzefzNySTyV0A/K3CzyWpftiwYeFYGnj6AUUAL0pnBCAtHRCASv98VcO2xhjTIF0RgDi8GBt31UvDMCd/G4CfAair8rMfA8bfMdOP9HQXAKTT6T2JaLR0R4U8b4zZzff9P1TzSRcvXvzyuHHjDmTmq6v5vNVkrQ3PrBFHfztaUPRnAPoH21G3lQEQ+U93zBzfAcCNCzfHZsl7ATpWrIGwIxL0KOZ0RPoKZGNMq3RDhTxirf3Upq7qr6T58+cX8/n8Ocz8PYnnrzQiapVu+A+O/pLANvozAEQU+WMOMzcYZo78AICI4jAa+6CrXhoGU3cnCAdIpwDYHmwfwNxClEfvcdiPfH1PpVKpQwuFgvgFm/l8/mIAP5TuqICPvrN9qriEif5FgBT9AYDOAIRITF6M92MmbJ68CaBPS6e8x0dQ4vvxq44onjYiZt5HOiJgOWPMoYsWLXpbOuQdvu9fAOA66Y6AmUQiEY7vHRuLZWi3kw4olzEmDsecLWMxADDGRH465gNuKnwVwBelMzZgB/Tx3Kht6+k4zviYnf9fa4yZnM1mX5cOWV99ff25AJ6U7ggSM39cuqFfAdHfGrgec18dKR1RjjicdiaiBgNgS+mQcllr43Ur0uzczmBcKp2xUcyHY05hmnTGIEV+E5L1fDubzT4tHbEh7e3tvclk8r8ABH4LohRm3lW6AQDQ5qxBDG5BA7ojPRiPyQzAVgbAZtIV5UokEpEfjb2LmQBzFcK/Ut1PcHPhI9IRA2WMCccbeDAW+L4f6qvuFy9e7BPRhdIdAQrPGvYc/c1oUExsLZ1QDmttHAYAIw2AEdIV5YrDdMy75nR8CUCrdMYAbIGijdIbfHjewMtkrT0bEVj2equttvo/AIukO4JARM6ECRM2l+4AABCifx0A2UjPAJRKpTgcc0YYAOFY5aoMRLRSuiEQzATCd6QzBo6mYHY+LV0xEMw8UbohCMx8X6FQeFy6YyAWLFjQR0T/K90RECqVSjtIR6zD0T8FwBTpGYBSqSR+100ARsRhBoCz2Wz0l8cEgNmFz4P5o9IZg5AC6GvSEQNAqMSyyQKY+RLphsFoamr6FWKwfzoAlEqlkOw3EofzzxzpGYDOzs44HHPq4zAA6JUOCNBU6YDB4xNw1Uuhvl6hqanpI4jHVrYvFQqFv0pHDMb8+fOLAKK/g906aekAAADF4JRn9O/IsQAivScwEcXiFEA8BgAzFm0NQniWHB24UdgyFY7d0jZi2LBhkV/GGAD6dzGM3C1gxpibEcHu9RFRWrphnRgsfEYU+YvPEfGNmZi53iD6n4wi/SK8K1V3MICUdMaQ2HAPXJg58guPAIC19m7phqHIZrM5xGATGyLaVroBABCHhc8sV3tPk0qI+rGn3gBISleUg4jiMQNAFIblfoeIw7Ra4QdYG+0rjoF1q13m8/nIrgNPRH+WbigXM4fjwjXLXdIJZaPQ3+Y8EJE+9jBzMvIDAGaO+iisH+8tXVAGF7NeCu220saYUdIN5SKix7DuvGNUPSodEICwDCTXSAeUjaq+q2klRPrYQ0QJAyAhHVKmSI/CAADT2QAIyS1GQ8RmgnTCxjBzFPcueB8iWijdUA4iisN6AOH4PkqZ6L/ncSxOAUT9dUjqACAMxuW2R9QvxiQT5gFMHKYbX5IOKMfbb7+9WLohAOG4XqrPRPqTZ79w/F2WJ+qvQyxmAKL+IgBEkd+QCeHeVCryA4Co73i5bNmybkT/ZzUcn1qTcRgAUDj+LssT9Q+fOgMQCpwIxxKj5TAI7Z+BKPpvNtbaOGysE5pti4coHAPJ4qrov+eFZTBVhhhcf5Yw0gUKANmoD8IADu+CUswc+e9zY0ykFx3p1ycdUKZw/Jwu/XePdELZONIXtMaGQQQ2FfkQkR9JgmNwK2O4r+qN/N+vMSYOC6eEdpZogMLxiW/6AUUA0R4EEN6STigXEYVjRmjoSnEYAET9RQAoJG8s5WAO7evAzJEfAJRKpS2kG8rR2tqaBDBSuqMcIZvyjfpmNFHvB6L/4bMYhwFA1F8EgGNwWw+ZML8OYXrjHhIicqQbyrF06dI01m3KFFnGhOjiO6KcdEJZmLPSCQEI7YeeAYrFDECYDzwDYyg8byxDxeH9YTDGRP3iMwAI7ToLA8HMke7vF6ZtxyO9LgQIcVgXIurHnqJB9Hc0Cu2BZ8Bsb/RnAMJ9CiD6u6cBu0sHlIOIIt0PAMz8pnTDu9j+QzqhDAzQk9IRAQjte95AMHMp8gMAa22kXwQAQCkOp0Tqth8AACAASURBVABCskraBkT9Hvp+E8ePH7+9dMRQWWsPlG4oV6gGkiX7sHTCkBG1o815VTojAJGeASCiokHE15WOwz3eSMbgFEB41kn/AGNMeN64y1AqlQ6WbhiKTCazBRF9XLqjXEQh2ob3tEwW0V0d8j7pgIBE/cNnjwGwWrqiTNEfAIxcHfXXAAjxAICZl0o3BIGZj5duGApr7bGI/pslAHRIB7wf3yxdMCQl+0vphIBE/Xt6tUHU7yeNwwBgcksvEPH7YolCOwCor6/vQLR30nvHpz3Pa5KOGCxmniLdEAQiKkg3vB/djOhdxP00TnWflY4IQOR30kVMZgAok8lEfSQGAOGZXhwK5s0wOx/KDT7a29t7Abwi3REAw8znSUcMRiaT2Z2I9pfuCIK1Ni/d8D5tTgHArdIZg8OXSBcEobGxMQ7HnJ44zACgVCqFeSOagYr+eeoSj5FO2BiOx33HADDN87xtpSMGylo7HRG///8dxWIxfPfek7kY0ZkFeAEdzh3SEUEgotBe9DwIq+MwA4BEIrG1dEMAoj0DAABJNEsnbMLz0gEBGQHgx9IRA+G67kEAjpDuCAIzL1+6dGn4ZpFOaW4H6FrpjAEhcw6mUxxOxSGZTMbhmLPaAIj8LmOlUim0558HjCj6MwA21KvVPScdEBRmPtXzvE9Id2xK/2m5n0t3BCi8A8je0v8g9Ke4+Fc4pfkh6YqgJBKJUdINAeg2ALqkK8pFRNEfjcXhXnVCWjphY5g5vG/gg0fMPNd13S2lQzamVCpdhoivXrie8A4gp3krwTge4T0V0IFS6hzpiCCVSqVtpBvKxcxvGiKK/KYMzBz9GYAwLTIydGGeAXgWMdgT4D08ADMRwvPrjuN8gYi+Kt0RsHCvXDfV+QuA70tnbMBqkDkWpzWFZxXFAFCI73oahBUG4VrfekhiMQNAWCadEIDQDgAKhcIaZn5auiNgX/A87yrpiPdKp9N7E9Ec6Y4K+Jt0wIdqcy4BODzXAxAXQTQZpzQvkE4JWiyOOcBKgxhsyxiT0VhBOqBsRDtJJ2yKMeZR6YagMfPZnueF4pOf53mTjDF/RMS3/d2Al/P5fMgWAdqIDuerAN8onQGgF5ZOxCnpP0iHVEIcZp2JqMtYayM/AIjDi4FSyO4xHgrmrXHjkrHSGRtjrQ3/p7ghYOYLXdf9PwieDnBd9yBmfhhAHC6OWl90vm+mk8Upzukg/K9gxdsAH46pTsTWKBi4mHzoXBGLiwABRH86Zou1SxCH1epMaRfphI2pq6t7GED0N17asP92XfdPjuNUey0Gcl33XAB/ALB5lZ+7KojofumGQSFinOJ8F8DRqP77+wsg83G0uQ9U+XmrKg4fOolohWHm16VDyhWHFwOTW3pBFPJbeQaCd5Yu2JhFixa9DSB2pwHe4yAietLzvM9V48k8z2tyXfduAD9DHJbk3jAuFovRGgC8o835HRI0CcAfq/BsvQBfDGDSurUJYi/6HzqB1wwzR/7iMyLaTrohEMzRPw1AJrQzAABARPdKN1RYEzPf67ruHZ7nZSrxBGPGjBnpuu63mflFAIdV4jlC5NmOjo5/S0cM2ZR0Hm3OYTB0DIj+VYFnYDDuBLAr2tzvoc2J9O6ygxDaVU//v707j4+qvvc//v58JwlZsBJQo5QkM+cMAY1a27hrW7Rq9ap1x1oVBLfb2qq9dvG29ne1i9Yu9lq1Fhc27SLWuuBttVKNdbdSrTYKcc45E0hRVAwqkG3mfH5/JCoqS5Yz8znnzOf5ePgASTLzgsCc73zPOd/vUPm+/7pJpVKvI/pTz/XTpk2L+sYMAMK22cgI+NwinbAlzHy3dEORHM/MyyzLutW27UC+J7Zt72BZ1n/X1NR4AK5A/C7225S7pAMCMTN5J2Y27o6B0wL3Y/RrBrwFopuQz++O2anjMSu1bPSR0dDS0lIOYJJ0xyjlPc97gwDAsqzXEfEpDWZORuZK3c2Z610Gwv+TzhglRr5suzDf92tZ1rMA9pDuKLI2Ivp9Pp9fkkwmn2ltbc0N5YuSyWTSGHMwBg4chyP6O6ANi+/7O2ez2fgd3G5eMRGUPwaGDgbzp7H1d7Q+gHYQHgLTEoD/VELv9j+gqanJCuW+EMOz2nXdHd/9x7waMRgAIHT7dQ8XvxzCdV2Gi2D69gdwr3TIFtyG0hsANDPzD4wxP1ixYsU7lmW9yMzLAKwwxqwDsJaZq4loLIA6Zm4CsDOAyG0/HKDnY3nwB4AzG1YBuH7wP2BB5wQg1wRgR/j+WBBVgfE22F+HBK2AT+2lesD/sFwuF9r1ToZhNfD+aH41gGa5ltFLJBIpAA9Ld4wK44XoH/8BkDkAIR4A5PP52xKJxI8wsKd3KdoGwD5EtA8AMPN7H9j45wq/lQ4ompmT1gB4QjojCpg5SRT5F+rVwPsvgNG9yGUQM0d/VLZN90uIx21qB0gHbElHR4cH4EHpDhVquf7+/lukI1QoJaUDRouIXgXeHwCsFGwJBDOHeSvaoZne3AdguXRGAPbCPK9SOmJLmPlG6QYVaotDuf2vEkcU6l1Ph2oFEKMBQEy+KUCYtx0dukoQf0Y6Ykuqq6vvAvCadIcKrZukA1RoxeFYsxIYHAAwc+QHAIjBtMygOAwAAKYjpBO2pK2trQ9AeDZOUWGy3HXd+6QjVDgRUVK6IQDvzwDEZADw8ebm5hisRkbh3Xd8eEI9AACAioqKawGsl+5Q4cLMP0f010ZRBZBMJiuZOQ4Lz70/A1BZWRmHAUCiu7s7+tcB5PrjMgCYgoXZUE+VLVu2bA2AW6U7VKisZma9+E9tThIxuHson893AoO/kcEXwsi/EyKiXaUbRu3syZ2IwV0ZAAAf/yGdsDXMfAXiceeFCgAz/yybzer97mqTYnGMAd7OZrNrgQ+OZFyhmMAwc6jXoR86fly6IBDMJ0onbM3g6pHzpDtUKLza29ur14WoLYnDMSbz7k/Mpn4xwkK7E92wMMVlx7rP4OYVE6Ujtqa/v//7ALqlO5QsIrp81apVG6Q7VKhFfgBARB8dABBR1Nc2BmLwzQEAJDguAwADyh0vHbE1K1euXEVE10l3KFEOEd0gHaFCL/JvMpn5vWO92dQvRphdV1cX/R3Ket58FkA83okYc7J0wlCUlZV9H8Cr0h1KhjHmokwm0yvdocJrypQp28RhvZlNDgAQj1MAprq6OtJ7GgAAzt2zH8DfpTMCwbw/bnw59FtnLl++/B1mjvpOjGpkHsxkMqWyTbQaoVwutxtisFsbM3/0FAAzvyyTE7h4nAZAjE4DlJfPlI4YCs/z5gJ4WrpDFVWfMeZr0hEqEuJwBwAqKio+OgDwPG8lYnArIGJwjgYAYMyj0gmBYT4Tl3IU7p3NAzgLQL90iCqaKzKZzIvSESr8YnKX2br29vb39rjY+EXZRzw2oonDNwmgyr8BiMv9yCk0ep+TjhgK13VfIKKfSHeoolju+/6PpSNUZMTh2NIG4L09vz/8rizyI2Ei2h0xOE+DGTuuB/CIdEZwzNnSBUNFRD8AEJcVGdWm9fu+P1MX/VFDRIjH7PIHjvGxGwAAGG9ZVlo6IhCMP0snBIePwY1unXTFUGQymV5jzCnQtQFii5kvy2azT0l3qGhobGycCmCcdMdoMfPmBwDGmDgMAEBEB0g3BILiNABABcroy9IRQ5XJZF4kooulO1RBPOp5nk79qyEzxsTimGKMafvA/2/8P8zchniIxTcLs1LLEIMlmjfyVSx8NTLrNDiOcw0R3S7doQL12uDsTl46REVHXN5UfvgY/4EBgOM4HuJxJ0AsvlkAAML90gkBmoB89+nSEcPAlZWVsxGPU2MKyDPzaZlMplM6REXO/tIBAXjbdd0P7Pz74WsA8swc+YufmHlqU1PTdtIdweD7pAsC9l8RuSUQANDW1rYun8+fCOBt6RY1Osz8bc/zHpDuUNGSTqe3BzBZuiMAz2GjOwCATexrTETPFi2ncCiXy+0rHRGI3soliMeszLsmozH7BemI4ejo6HjJ9/3pAHLSLWrE5nqe93PpCBU9zHwg4nBnGfCRY/tHBgDMHIcBABCX0wDnTtwA4F7pjIB9P0qzAACQzWbvZ+b/lO5QI/JQVVVVZC5AVaETi2PJpt7cf+RFOJFI/KM4OQUXi2/aAFokXRCw3dDghX6XwA/zPO9mIvqRdIcalueMMce2tbX1SYeoyIrFscT3/a0PAMaMGfMvAHH4x7J3Op0eIx0RDP4T4nYOmuiyqM0CAIDjOJcQkU4lR8PLvu8fkclk4vVvRxXNpEmTqpj5U9IdAegdP378Sx/+xY+8ALe1tfXF5HbAMQDi8I0DZqV6AF4snRGwXZDsOEU6YiQcx/kmM+ve8eG2gpkPzWazusWzGrHy8vK9AFRIdwTgX0uXLv3IHiebfAdGRLHYEY2ZD5FuCAwhbqcBAObLsKgtiv+42PO8/ySia6VD1CZ5ZWVlB3me1yEdoiLvUOmAgDy5qV/c3BRsLJbIZObDpRsCU919H4Au6YyA2VhfdYF0xAix4zjnA7hKOkS9j4he6u/vP7C9vT1OC2gpIUQUi2MIM2/ymL7JAUA+n9/kaCGC9pk6deoE6YhATG/uA+Eu6Yzg0SVR2SNgE9h13YsAXIoP3V+rio+ZnygvL//0ypUrV239s5XassH7/2NxGpmIhj4D0NHRsQzxeLeZ6O/vj89pAJibpQsK4GMoNz+UjhgN13UvI6JZiMfFs1H1x/7+/s8tW7ZsjXSIiod8Pn84Nj9LHhnMvMZ13cymPra53xwD+HvhkorH9/0jpBsCc0bjY4jjsrTMs7Eg+0npjNFwHGcBER2BeAycI4WZf+q67kmdnZ26e6MKTFym/wff/W9yhnJLo5tYnAYY/CbGYRWnAYybpBMKwMDnOVjECemQ0XAc50EAewB4RrqlRHQT0Rme530LgC8do2LFADhMOiIIRLTZa/o2OwBg5scKk1N0del0OtLvLj8gUb4QQI90RgHshfXZr0lHjJbruit6eno+C+BW6ZaYe5mI9nYcZ4F0iIqfZDK5F4BY7CdDRI9s7mObHQBUV1c/DuAj9w1GUT6fj89pgJmT1gBxvBgQAPAjzO2wpCNGa9WqVRtc1z2dmacDWCvdEzdEdLvv+3s7jvMv6RYVT8aYuBwz+jZs2LDZ2/o3OwBoa2tbByAWywLH5VzOe5hulE4okGqQfyOYY3HKxvO8240xeyImt9WGQBczn+w4zvRsNqsDK1VIcTlmPLVq1aoNm/vgFq9wZOa/Bd8jYt9JkyaNl44IzKzGhwC8LJ1RIAdjXvYM6YigZDIZp6Gh4UAAFwJYJ90TYfcS0Sc8z4vfglgqVAZv/9tTuiMIW5r+B7YyACCiuAwAyioqKo6VjggMEYP5l9IZBUO4BgucJumMoLS2tuZc173aGLMHgCXSPVFCRKuI6HjXdY92HGeldI+KP2Y+HkCkL0h+l+/7D2/p41scAPi+/yiAfKBFck6WDghUf+VcEL0hnVEgNeDEbzDnmXLpkCBlMhnHdd1DmfkLzKwr1W1ZHzP/koh2dhznTukYVToGr92Jg9zgtXybtcUBwOB5to9sIRhRB9u2vYN0RGDOnbgBvj9HOqNgmPdE+YRLpDMKwfO8xczcDOA70IsEP4yJaFE+n5/qed4FupOfKqZkMrkjgM9KdwTkqcFr+TZrq6scEdFfgusRVQYgPqcBAGBgM5pe6YyCIXwX89xPS2cUQjab7XFd94ry8vIGABcDeEu6KQSWENFejuOc3NHR4UnHqNJDRCciJtP/AB7Y2icMZQCw1QeJihhN7QyYlXoV4Djfb54A6HYsWPlx6ZBCWb58+Tuu615pjJnMzD8AENfTOpuTJ6LbAezluu6hjuMslQ5SpYuIYnOMGMqxe6u3WzU3N1d0d3evATA2kCpZfj6fn9TR0fGKdEhgbnanwNCLiMGa1ZvFeAJjN0zD9ObYr7U/ceLE6srKypkAzgcwVbqngN5m5gXl5eX/qzv3qTBobGzcKZFIdCIer6Vv19bWbrd06dItruWz1d9oW1tbH4C43A1gEonEcdIRgTrTWg7wn6UzCoqwH9ZV/1Q6oxgGFxG63nXdnYloT2a+AcB66a4ALSWic6uqqj7ued75evBXYZFIJE5GPA7+APDXrR38gaH/ZmNzGiBOUzzvMfg+4r4dLeF8zM+eKp1RTI7jLPU879yenp4dBk9f3Yto7jj4IoDLmHmq67p7Oo5zw9YuTlKq2GJ2inhIx+whrbiWSqWmENGy0fWEht/f318fuz3D53n3ADhaOqPAesD0OcxObvHWljhraGioLSsrO5yZDyeizwOok27ahF4AjzDzfcz8f9lsNi6vHSqmLMtqAJBFTDaOKysrs4cyuzbk36xlWe0AJo+qKjwucl33KumIQM1zdgPMc4jPFNbmrIHx98dMu106JARMMpncPZFIfJqZ9wdwIIBJAh3rMbDc8aPM/NiGDRseW716dZxOW6iYsyzr2wB+LN0RkBdd120eyicOZwBwFYCvjzgpXJa7rrsz4jZtPs/9A0AnSGcUgQPO7YfZk1+XDgkb27Z3YObdAewOoJmIbGZOYmBgMNrbm94AkCUij5lfYuYXiOh513UdxGfBMFV6yLKs5YjPG9wrXde9eCifOOQBgG3bBzPzX0feFDqfdl33UemIQM3vaAb7zyP+swAA8AiAwzArFcetkQPX0tJSvnbt2h3z+fwEItreGDMBwMcGPzyOBzdgYuZ1xph+AD3MvMb3/TXGmDVVVVWv6Hl7FUe2bR/EzA9KdwSFmT/jed4W9wB415AHAC0tLeVdXV2vARg34rIQYeaFnufNlO4I3Hzvt2CcIp1RJPfjndwxOH9yfBdDUkoVlGVZvwVi85r5ZkNDQ11ra2tuKJ885HeKS5cu7Y/RqoAgopMaGhpqpTsCR/6lALZ6+0dMfB5jyxZiEcdl5S6lVBEN7hIbp1vD/zzUgz8wzKliZr57+D2hVZVIJOJ3W9nAxXG/ks4oGsJ0rMvOxaVcCqc9lFIBqqioOB1ApXRHUIho8XA+f1gvmuXl5YsBxOacKxGdLd1QEBXmshjvFPhRhBlo9K7B4HlspZQaolnSAQHqKSsr+9NwvmBYA4Dly5e/g3jtZ767ZVl7SUcE7tTGLjD+RzqjuOgrWNCxEJc+VCZdopQKv3Q6vR+AT0h3BOi+wWP0kA172pSI7hju14RZbGcBahrnAHheOqOomE9DY/JWzHmmXDpFKRVuvu/H6rWfmYd9bB72AKC3t/cexOgiM2Y+JZ1Of2zrnxkx0ykPpris2zAcJ6Ni/J2Y58XmvJ5SKliWZW0LIE5L//Yx873D/aJhDwA6OzvfBNA63K8LsbG+758lHVEQs5MPAojThZtDREcCfC/mONtKlyilwoeIzgVQI90RoCXZbHbtcL9oRFdOM/OikXxdiF0wbdq0eJ47ZvNfADZIZxQffQ4V5jHc5DZKlyilwqOlpaWcmb8m3REkIrp9JF830gHAHzCw4UdcNKxYsSJO00Hvm93ogrnELgh8TzMS9CRudvaUDlFKhcPatWtPgcyeGYXSw8x3juQLRzQAGJxqiNse9BdJBxTM2NQvQPSMdIaQHWFMK+Z6x0iHKKXkMXOsro0iosWu6741kq8d8eIpzPy7kX5tSH3Ktu2DpCMKYjrlQf6ZiNHFm8NUA8KdmOf9WFcNVKp0pVKpwwDsId0RsBEfi0czALgHwIhGHWHFzPGdBZhpPQ/Cz6QzBBGAb2Nd9gEszOwgHaOUKj4iittr/Fv5fH7Es/EjHgBks9keZr5rpF8fUv+RTqd3kY4oGMb3AbRLZ4giHIR84knM8+L2LkAptQWWZe0G4FDpjiAR0e3ZbHbEq/OOav10IrplNF8fQhS380MfMCvVA+KzAfjSKcJSAJ7APO8CXT5YqdLAzN/AMHbAjQLf90d1DB7tH4axLMsBkBzl44RJj+/7qWw2+6p0SMHM9a4E4VvSGaFAtAR5MxNnNqySTlFKFUZTU9PHc7mcC6BCuiVAGdd1mwDwSB9gtDuo+QAWjPIxwqbSGPNN6YiC6l9zCYC/S2eEAvMhMPnnMN/9gnSKUqow8vn8xYjXwR/MPB+jOPgDAUyHJJPJpDHGwegHE2HSY4yZnMlkOqVDCuamTBplZc+Ceax0SnjQ7ejr/QrOnVI6OykqFXO2bdcz88sAxki3BMgnoqTjOCtH8yCjPmhns9ks4rU0MABU+r5/sXREQZ2VzsBnPQ3wAXwSKiqWY753jnSJUioYvu9fgngd/MHMfxntwR8I6F07M88L4nFC5izLshqkIwpqdup6MO6RzgiZ8WDMwTz3Xix04v39VyrmmpqaLCKaJd0RNGPM/EAeJ4gH6e/vv4OZ1wTxWCEyhogukY4ovNxZAF6RrggfOhJ58xLmef+DOauqpWuUUsPX39///wDEbXvwN4gokFvwAxkAdHZ2dhNR3C4GBDOfkU6nbemOgpo9+XUwnQigTzolhKoBXIqK3nbMd2foLYNKRYdlWZOJ6FTpjgK4KZPJBLIXT2AX7hljfoX43V9ens/n/590RMHNTj4O6G2BW/BxMC3AfO8RzO84QDpGKTUklwGI2y6vTEQ3B/Vggb6jsSzrAQCHBPmYIZDP5/O7dXR0vCQdUnDzvPkAZkpnhB7REpD/Xcy0npZOUUp9VDqdbvZ9/3nE6+40MPN9nucdEdTjBf2Hc33AjxcGCWNMaWynm6g6D8Dz0hmhx3wIfHoK87x7dElhpcLH9/3LELODPwAYY+YE+nhBPlhDQ8M9AP4d5GOGARFNTyaT+0p3FNyMHdcDOAZA3C7oLJSjATyLee6jmOcerdcIKCXPsqwDARwv3VEAK+vr6+8N8gEDHQC0trbmmPlXQT5mSJAx5lrEcET5EbNSWbB/BuJ3PUcB0QEA3YP52X9grnsa5jwTt6uOlYoKA+AqxGzN/0HXtba25oJ8wMAPaP39/b8GsCHoxw2BFtu2T5OOKIrZ9r0AxXs55MLYA0S3oGKCh3nZ72Oel5QOUqqUpFKpWQD2ku4ogA0VFRU3Bf2gBRkl2bZ9AzOfXYjHFrbaGNOUyWTelg4pivnZa8D8VemMCPNB9CDYvwE13XdjerPeaqlUgUyZMmWb/v7+5QB2km4pgOtd1/1K0A9akCltIroao9ykIKTqmEto+dzqxgtBFOg5pxJjwHwIQIuwoebfmOf9GguyB2ERJ6TDlIqb/v7+SxDPgz/n8/lrCvHABTtPYlnWXwAcWqjHF9Tj+/7Og3sgxN91bWNRXf0wgE9Jp8TIqwDfAcIiVKcew3TKSwcpFWVNTU1WLpd7ETFb83/Qn1zXPbIQD1ywi9qI6KpCPbawykQi8RPpiKI5r3kdyugoAB3SKTGyI0DngelhbOhYi/nZxZjvnYMbX54kHaZUFOVyuZ8jngd/APhFoR64oFdKplKpfxDRJwv5HFJ835+WzWYflu4ompsyuyKR+BuAWumUGGMA/wTwMJgfRbl5DKcndZ8GpbbAtu2Dmfmv0h0F8pzrup9CgU6pF3QAYFnWlwD8ppDPIei5hoaGvYK+LSPU5nn7AvgLgG2kU0qIC9BjYP9pgF7AGPM8Tm3sko5SKgxaWlrKu7q6/gFgV+mWQmDmkz3PW1Soxy/0vZIJy7KWA4jlhjpE9G3HcUrndAAAzPOmAfgTgCrhktJF1AmfXwDwAgAXhj0QZ/GW34HzJweySYhSUWDb9iXM/APpjkJgZtfzvCYABbtGqOCLJaRSqfOI6NpCP4+QbiLa3XGcjHRIUS3IHgGf7wJQIZ2iPoABrALQCWANQGsAXgPmgZ8T5wCsHfhM7gbQA0N9QGI9fHRh7LpOvVVRRYVlWU0YOGVWKd1SCER0ruM4NxT0OQr54AAwadKkqoqKiiyAHQr9XEIecl33c4jnbY+bNy97PMi/DUxx222rlOUBZEH0LBgPAfkHMMt+WTpKqU0gy7JaAXxGOqRAXvF938pmsz2FfJKiLJdoWdbFAK4oxnNJYOazPM8LbIvGyJjrngaiBSiFJZJL19MgWghTOX9wrwilxFmW9Z+I5+ZzAABm/obneT8v9PMUZQBQV1dXU1NT4wHYvhjPJ+CtsrKy5vb29ththLRV890ZYJoLQBe3iTOiN+D7V6Os+hc6EFCSGhsbd0okEi8CGCfdUiBvVFVVpdra2tYV+omK8s5t9erV61HAexlDYNtcLve/0hEizrAWAnwKAD13HGfM24HoB8h3v4h53rHSOap0JRKJ6xDfgz+Y+cpiHPyBIk7dVlVVXQPg9WI9n4ATbds+TjpCxCzrdhg6FkC3dIoquAYAd2JediEWvlojHaNKSyqVOhFAnF9n36iurv51sZ6saAOAtra2dcx8dbGeT8i1lmVtKx0hYmbyz2A6CkRFGbkqaXw6/J4nMTdTL12iSkNDQ0MtEf1SuqOQiOgnxXr3DxT54q1EInENM68p5nMWEzNPBHCddIeY2ckH4ePzePdWMxVvzLuCEo9hbscu0ikq/srKyn6FeG72867X1q1b96tiPmFRBwCD2+j+uJjPKeDUwRUQS9Ps5OMwdDAAXcK2NNSD/CWY22FJh6j4sm17BoAvSncUEhH9aPB6uaIp+u1bzHwtgJXFft4i+1UymUxKR4iZmXwWCX9fEP1LOkUVxU4wfD8WdE6QDlHx09jYmGLmgmyHGyIdRDSn2E9a9AFANpvtIaIfFvt5i2xbY8ytKOVb42bYK7B+/X4YWDZYxR1zGvn+W8BclFuLVWmYNm1amTHmNwA+Jt1SSER0aSaTKfoy3iILuDiOczOAZRLPXUQH2Lb9HekIUec1r0PfmmMBzJVOUUVAOALzsxdIZ6j4WLFixfeIaD/pjgJbXl9ff6vEE4uN1m3bPpmZfy/1/EWSM8Z8JpPJPCEdIm6edwGAq6CrBsbdBuR5F5xldUiHqGizbfsAZn4Yn9lVFAAAHMRJREFU8Z9JPcF13T9KPLHYi7HjOIsA/F3q+YukLJ/P35pOp2M9fTUks1JXg/ElALqKXLxVI0FXSkeoaLMsa1tmvgUxP/gz8xOu694p9fyS78aYmS8SfP6iICLL9/24r38wNLNTtwHYE4yXpFNUQU3HTZlY7s+uiuY6ACnpiALzieh8CG4kJzod63neIwBEpj6K7AzLsmZLR4TCrNQy9Pv7AVgsnaIKhmAS35SOUNGUSqXOBnCqdEcRzHdd9xnJAPErdpuamqxcLvcigDHSLQXWA+DT0t/w0GAmzM9+C8CPEPNpvhLVA2AnzErpolBqyNLp9Cd9338MQJV0S4G9k8/np3R0dIiulyJ+QVZ7e7uLGG/ruJFKAHc0NTVtJx0SCkSMWakrARwF4E3pHBW4SoCOl45Q0TFp0qTxvu/fgfgf/AHgR9IHfyAEAwAA6Ovr+0GclwjeSEM+ny/t9QE+bFbqPnB+DwAPS6eogDEfJZ2gIiNRUVGxCPE/7w9mdo0xodg9NhQDgM7OzjeJ6BLpjmJg5s/btn2ZdEeozE6vxBnJgwBcCN1WOD4IB2ER62BXbZVlWZcD+Jx0RzEYYy6SWPRnU8SvAdiIsSzrSQB7SYcUAQM4yXXdO6RDQmeesxdgfgNgsnSKCgCZXXFGY5t0hgqvdDp9jO/7dyJcx6NCedB13dAMdEIxAzDIJ6ILIXhLRBERgHmNjY07S4eEziz776gp+wQYsd72s3TwVOkCFV6WZTX5vr8ApXHwzzPz16UjNhamAQAcx3l8cPGHUrBNIpG4vbm5eax0SOhMr+/G7NQFAJ0A4FXpHDUKzDqTozZpypQp2xDRXQC2lW4pkhs9z3teOmJjoRoAAAAzfxvAW9IdRdLc3d39e+hFgZs2K/lHADuDcQNKY2Yohmi8dIEKn2nTppX19fUtYuZSmQXtKisr+550xIeFbgCQzWZfBfDf0h1FdKRt26VwG+TIzEqtxezUuSCeBmC5dI4aLtZlsNVHrFix4moiOly6o1iY+Zvt7e1vSHd8WOgGAADguu4cAI9IdxQLM5+dSqW+Id0RamdYf0PfmE8B9FMQ56Rz1BAR6eyW+gDLsi4G8BXpjmIhooc9zwvljqihHAAA8AGchYHVxEoCEf3EsqxTpDtC7dyJGzAr+S34Zh/EfyOpmOB3pAtUeKRSqZMwsPpnqejGwLEslKcwwzoAgOu67UR0uXRHERGAubZt7y8dEnqzk//AGcl9wDgDwCrpHLUFXDLX86itSKVSexPRfIT4uFMAlzmOk5GO2JxQfyPq6+uvAPCcdEcRVTLz3ZZl6ZXTW0PEmJ1agL4xkwFchhKaLYoUZkc6QclramqyiGgxgGrpliJ6vra29irpiC0J/b2Xg6PGx1FaV8o7xpj9MpnM69IhkXHjy5NQVn45wKchAn+vS4e/N2bZerqmhE2dOnVCX1/f4wCapFuKKE9E+ziOs1Q6ZEtCPQMAAJ7nPQ3gGumOIrN93//jxIkTS2m0PDpnT+7ErOQMMA4C8Lh0jgIA9KKm4l/SEUpOXV1dTW9v72KU1sEfRPSLsB/8gYi8U5o4cWL1mDFjXiAiS7qlyJb4vn90NpvV6e3hmuscAjKXozSWlg6rVsxKHSQdoWQ0NzdXbNiw4e5Sut1vUHb9+vW7rl69er10yNaEfgYAAFatWrXBGHOedIeAQxKJxG0tLS3l0iGRM9teMnih4LEAQrX6Vgm5XzpAyWhpaSnv7u7+Qwke/MHM50Th4A9EZAAAAI7j3AfgVumOYmPmL3R1df0OpXUNRDAGLhS8Gx3JTwI8HcCL0kklxEeefycdoUQkurq6FgA4WjpEwDzP8x6QjhiqyAwAAKCiouJCAP+W7hBwgmVZcxCRUzahcyn5mGXdjo7kbgB/AcDfpJNKQCvOsjqkI1TRkWVZNwAoxTVNVuZyuYukI4YjcgeUZDL5WWPMg4jY4CUIRHSt4zhfk+6IhQXZT8LH10H+KWAqk86JHcbhmJ3SUwAlxrbtnzFzpA6CAfGJ6FDHcR6UDhmOyA0AAMC27Z8yc0kunUtEP3Ic5xLpjthYmE0hzxeA6Eww686MwXgas1L7SEeo4rIs63KU1j4uG7vCdd3vSEcMVyTfRVdWVn6XmZ+V7pDAzN+1bVsHAEGZkfQwK3UhevOTADoPpbXwVCH4MHShdIQqLtu2v4fSPfg/U1tb+z/SESMRyRkAAGhsbNw5kUg8g9JaWWpjV7que7F0RCzd7OwJMmeD8EUAupvdsNCNmJU8R7pCFY9lWZcCiOQBMADrmbnF87xI7lQa2QEAAFiW9RUA10l3CLredd2vYmDzJBW069rGorpmOpjPAmE/6ZwIWI4NG/bEec3rpENUUZBlWVcBKNkZH2Y+2/O8m6Q7RirSAwAAsG37bmb+gnSHoFsbGhpmtba26ha5hTS3wwL8k0GYDmAP6ZwQWg+fD8CZ1j+lQ1RRJAbvTDpTOkTQXa7rHicdMRqRHwCk0+ntfd//J4CdpFukMPNt48ePP33p0qX90i0lYZ6XBHAMwCcBdIB0Tgj0w9AxmJn8s3SIKrxp06aVrVy5ci4zny7dIoWIVpWXl+++bNmyNdItoxH5AQAApFKpw4joPsTk9zNC9/q+f5IuG1xk8zuaAT4W7B8B0L4ovQWb+gHMwKzU76VDVOGl0+kxvu//DkCk3/mOkg/g867rLpEOGa3YHDBTqdTVRHS+dIckZm6trq4+uq2tTc/BSvhNRy3684cCdDgYRwDYUTqpoIjWwecT9X7/0jBx4sTqysrKuwAcKt0iiYh+5jjON6U7ghCbAUAymaw0xjwCYE/pFmGP9vX1HdPZ2fmmdEhJYyYs7NgDPn8ejM+AsD+AbaWzAtQGNtMxu1GXVy4BU6dOndDb27uYiEr6YlgierKysvKzbW1tfdItQYjNAAAAbNuuZ+alALaXbhHmAPgP13XbpUPUoEvZoNFtBpsDYWh/MB8IICmdNQJ5ANeib8x3cO7EDdIxqvCampqsXC73JwBTpFuEvWaMaclkMp3SIUGJ1QAAAGzbPpiZ7wdQ0su7MvMaAMd5nveIdIvajJtXTETC3w8+7w5gNxB2B5BCaBfo4r8C9A3MSuliSSUimUzua4y5G8AO0i3CcsaYQzOZTKt0SJBiNwAAAMuyvg3gx9IdIdBLRGc4jqMXaEXFdW1jUVXdDOLdQWZ3AFPBnAJQD6BCoKgX4HthzM8xM/mEwPMrIZZlnQDgFgBV0i0hcJHruldJRwQtlgMAAGTb9m3MfJJ0SAgwgO+7rnupdIgahUWcwDpnIoxJAUiCKYWB2YKJGDjlNWHwv9GvjEn0BoBWsP8X5MvvwFn1ej1JibEs6wIAVyG0s1FFdafruidg4LU0VuI6AEBzc/PY7u7upwDsIt0SBkR0U319/Zd1waCYW7SyCm/1TIBJTEAisR04P37gA1QDQgUYBu9fjFgFBoF4HRhdIHQgj3acmVoBoti92KkhSViW9UsAX5EOCYllxph9MpnM29IhhRDbAQDw3n4BTwHYRrolJP6vqqrqi3qboFLqw6ZMmbJNX1/fIiI6XLolJN4CsHecL6aO9fROR0fHS8aY0xHDqZsROrK7u/uZdDqtsyJKqfdYltXU39//hB7838MAzozzwR8ogVXL3nzzzeW1tbXVAHTJ1gHbMfOM2tra9q6urpekY5RSslKp1NFE9GcMXGiqABDR5a7rxn6judgPAACgq6vrodra2v0BWNItITEGwEnjx4+v6Orqehg6Q6JUKUpYlnUFEV0LoFI6JiyI6H7Hcc5GCbwuxvoagI1ZlrUtgEcB7CrdEibM3GqMOdlxnNekW5RSxTF16tQJfX19v0OJL+u7CS/mcrkDV6xY0SUdUgwlMwAAgGQymTTGPAmgTrolZFYy84me5z0tHaKUKqx0Ov0p3/fvQDRXoiykV5l5X8/zOqRDiiXWFwF+WDabzQI4CsB64ZSwqSeiv6VSqbOkQ5RShWPb9gzf9x+FHvw/rNv3/WNL6eAPlNgMwLts2z6Omf+AEhsADQUzL6ioqPja8uXL35FuUUoFY/AU6HUATpVuCaE8Mx/ned5i6ZBiK4mLAD+sq6trWW1t7TsAPi/dEjZEtIfv+1+qra19pqura4V0j1JqdJLJ5D5EdD+Az0q3hBERXei67i3SHRJKcgAAAF1dXU+OGzduPBHtI90SQuMAzKitra2xLOvhV155xZcOUkoNz7Rp08qMMd8kolsAbCfdE1JXua77A+kIKSV5CmAjxrKsOwAcKx0SYk8R0WmO42SkQ5RSQ5NKpRqJ6FYAB0q3hNi9rusei4EtrktSqZ8D9/v6+r4E4CnpkBDbh5mX2rZ9jnSIUmrrUqnUSUT0HPTgvyXPrF+//oso4YM/oDMAAIBkMrnj4O2BjdItIfdb3/fPy2aza6VDlFIflEwmxxljrgfwRemWkPOYeT/P81ZLh0gr9RkAAEA2m33V9/3DAehiOFv2pUQi0Wbb9nHSIUqp91mWdYIx5kXowX9rXgVwuB78B+gMwEYsy9oNQCuA8cIpUXCvMebLmUymUzpEqVI1OHt5DYATpVsiYK0x5uBMJvOsdEhY6AzARlzXfYGZjwCg98Bv3VG+7//LsqwLoH+PlCo2sm17hjGmDXrwH4q3ARymB/8P0hmATbBte39m/guAGumWiHjU9/2zs9nsMukQpeIunU7bvu/fAOBg6ZaI2OD7/n9ks9mHpUPCpmTXAdiSrq6ulePGjfs7EU0HUCbdEwENRHRWbW1t+cSJEx9//fXXS/rKWqUK4d37+pl5EYDJ0j0R0UdEx3uet0Q6JIx0BmALBpcMXgQdBAzH88aYCzKZTKt0iFJxYVnW5wD8L3Q30+HIGWNOzGQyd0uHhJUOALYilUqdSES/h86WDNe9ZWVlF7S3t7vSIUpFlWVZDUT0Q2Y+XbolYnwAp7uu+1vpkDDTAcAQWJY1C8DN0D+v4epj5l8nEonvZTKZt6VjlIqKurq6mpqamm8C+DaASumeiGEi+rLjOHOkQ8JO39UOQVdX13Pjx4/vAnCEdEvEJIhoH2Y+Y/z48e90dXU9B4Clo5QKMbJte0Z5efliDGxdrqcfh4mZv+W67jXSHVGg72iHIZVKnUdE10D/3EZqKTN/3fO8R6RDlAqbVCq1tzHmambeV7olohjAN1zXvUo6JCr0QDZMtm2fw8zXQ+99Hykmoj8Q0aWZTOZF6RilpKXT6Wbf9y8DcDz0NXmkfGY+1/O8m6RDokT/so2AbdtfZOaFAMqlWyLMJ6I7mPkS13XbpWOUKrbGxsaUMeZiIjoTejp2NPJEdKbjOAukQ6JGBwAjZFnWUQBuh16gM1o+Ed0B4Du65bAqBalUqhHAd4hoNvQc/2j1ATjFdd0/SodEkQ4ARsG27YOY+R4AY6VbYqCfiH6fy+X+p6Ojw5OOUSpotm3X+77/DSI6F8AY6Z4Y2MDMx3me9xfpkKjSAcAoJZPJzxpjFgPYRrolJnoAzMnn81d2dHS8Ih2j1Gg1NTV9vL+//9tEdA70wB+Ut5n5KL2geHR0ABAA27ZbfN+/n4gmSLfESB8R3QbgJ47j/Es6RqnhsixrN2b+KhHNgJ4qDFLX4Nr+T0qHRJ0OAAKSTqd38X1/CYCdpFti6DFmvtLzvHuh6wiokLMs60AMLOBzJPQ1Nmirmfkwz/Oelw6JA/3LGaBkMjnVGHMfgEbpljhi5meJ6Oe1tbWLli5d2i/do9S7Wlpayt98882TiegiAHtI98SUB+BwvWsoODoACFgymdxx8JqAPaVbYmwlM1+dSCRu1CWGlSTLsrZl5rOJ6AIAk6R7YuwpZj7G87zV0iFxogOAAqirq6uprq7+DREdI90Scz1EtJiZb3BdV7f7VEUzeN3POUT0JehdQIV2V09Pz6mrVq3aIB0SNzoAKJxEKpW6iojOlw4pEcsAzC8rK7u5vb39DekYFT/JZHJcIpGYzsxfAfAJ6Z5SwMy/9Dzv6xjY3U8FTAcABWZZ1gUAfg5d6atYeononsFZgb9CLxpUo7TRu/3TAFRL95SIPBF93XEc3dSngHQAUAS2bR/LzL+BvngUWzsR3Qzgd47jrJSOUdFhWVYDgFMAnAlgsnBOqVnPzKd4nrdYOiTudABQJJZl7QVgMYA66ZYStRTALf39/bevXLlylXSMCp+mpqbt8vn88cw8A8D+0NdHCa8CONp13WekQ0qB/gUvomQymUwkEn9i5p2lW0qYD+AJALf7vn9bNpt9VTpIyZk6deqE/v7+I5n5JACHQ9fml9TGzEd6ntchHVIqdABQZA0NDbVlZWWLABwi3aKQB9DKzLeVl5ffqRcPloaN3umfDOCz0OtzxBHR/cx8suu6b0m3lBIdAMhIWJb1PQDfA2CkYxSAgZmBZwEsAbCkoaGhtbW1NSfcpIJhbNv+JDMfgoGB9zToO/2wYAA/cV33uxgYkKsi0gGAoFQqdTQRLQQwTrpFfRAzrzHGPAhgSV9f37163UC0NDU1bdff338QgEOI6GjoEt1h9A6AWa7r3iEdUqp0ACAsmUxOTSQSf9TrAkLNx8BFhH8G8IDv+89ks9ke4Sa1kUmTJlWVl5fvCeBQIjoCwKegs2th1gbgeF3WV5YOAEKgubl5bE9Pz9zBC5FU+OUA/JOZHwPwqDHmYcdxXpOOKiWWZW0LYC8ABwI4YPBH3XEvApj57kQiMUOX8ZanA4DwIMuyzgfwUwDl0jFqeJjZNcY8xsxLiehRx3H+AV2EKDBNTU1WPp8/0Pf9A4joQAA7Q1+/oiYP4Luu6/4E+m8jFPQfUMikUqnPENEi6HoBUfcWgAwRvcjMSwEsraqqeq6trW2ddFiYNTc3V/T29k5m5hbf91uIaBcAuwPYQbpNjcobAE7RPTvCRQcAIWTbdj0z34GBKU4VHwzABfA8gBeY+QUALyQSiWwmk+mVTSuudDo9JpfLpYhoVyLaDcBuzPwJIkpBX5dihYieJKKTMplMp3SL+iD9hxZS6XR6jO/7VwC4EPp9ijsmoleY2QPgMXOWiDwiyuZyOW+77bbrXLp0ab905HC0tLSUv/POO/X5fD7p+34KQJKIkgBSRJRi5p2gf6/jzieiqyorK7/b1tbWJx2jPkr/AYZcKpU6jIjmQ29jKmU5AP8eHCSsYeY1RLRm8FbFN5j5Dd/330gkEmtyudya8vLyN4OeUUin02P6+/vHJxKJ7YwxE3zfnwBge2aeQEQT3v0RwHYAdgQwCbrATin7N4AzdMo/3HQAEAGD9zTfRETHSLeoyOka/LGXmTcAABG9g4FBxbsLryQAlDHzNoMfrwYwZvBjtUVsVfFwZ0VFxdnLli1bIx2itkwHABFi2/YMZr4OwFjpFqWU+pBuAP/tuu7V0iFqaHQAEDGpVGoKEf0GQIt0i1JKDXoGwKm6sE+06EpZEeN53vKGhoZ9AVwGXTtbKSWLmfmXVVVVB+jBP3p0BiDCbNs+iJkXYuCCK6WUKqaVxpgZmUymVTpEjYxepRthXV1d2W222WZ+IpGYCOAT0j1KqZLAABbkcrnjPM9bJh2jRk5nAGLCtu0jmHkOgHrpFqVUbHnMfK7neQ9Ih6jR02sAYsJxnD9jYDW1G6DrbCulgpUbPNe/ux7840NnAGJocPGgXwNISbcopaKNmZ9NJBJnZTKZf0i3qGDpNQAxtHbtWqempuaGRCKRA7A/9PuslBq+bgCXV1dXz1y+fLmu4x9DOgMQc5Zl7cbMc4hoP+kWpVRkPOL7/jnZbFYv8osxHQCUBmNZ1rkALgcwTjpGKRVaXcz8Tc/z5kKvJYo9nRouDdzV1fVMXV3dTblcrpKI9oIO/pRS7/OJ6FYi+oLruo9Kx6ji0INACbJtu8X3/Wv0tIBSCsBDzPx1z/P+KR2iiksHAKWLbNs+nZl/CmAH6RilVNGtJKJLHMdZKB2iZOgpgBLW1dX1z2233fYmY0wZBjYXKpNuUkoV3DsALjXGfMlxHL21r4TpDIACAFiW1UBEP2Tm06B/L5SKIyaiW/P5/Ley2eyr0jFKnr7Qqw9IpVJ7E9HPARwo3aKUCszfjTEXZDKZJ6RDVHjoAEBtCqVSqROJ6PsApkrHKKVGhoheYubvua77R+htfepDdACgtsSkUqkTAPyYiCzpGKXUkK0koh/W19fPbW1tzUnHqHDSAYDaqmQyWWmM+TKA/wawvXSPUmqzXgNwuTHm15lMplc6RoWbDgDUkNXV1dXU1NScBeBiADtK9yil3vMGgOuMMVdlMpm3pWNUNOgAQA3bRgOBbwPYSbpHqRKmB341YjoAUCNWV1dXM3bs2K8w80UA6qR7lCohrzLzz3p7e69ftWrVBukYFU06AFCj1tzcXNHT0/NFZv4OgCnSPUrFmAfg6r6+vhs6Ozu7pWNUtOkAQAXJpFKpI4noEgB7S8coFSP/JKKr6uvrf6tX9aug6ABAFUQqlTrMGPNfzHwY9O+ZUiPBAO5j5l94nveAdIyKH31hVgVlWdZkZv4qEZ0JoEa6R6kI6CWiRUR0ZSaTaZOOUfGlAwBVFFOnTp3Q19d3NoDzAEyS7lEqhFYC+NXg+f03pWNU/OkAQBWbsSzrYCI6h5mPh+5IqUqbD+BBZr6hsbHxTj2/r4pJBwBKTDqdtn3fPxvAbOgKg6q0dDHzLeXl5Ve3t7e70jGqNOkAQIlLp9NjmPk4Zp4F4BAARrpJqQLwiegBAPOI6C5dqldJ0wGACpWmpqaP53K50wCcBSAt3aNUAFYC+G0+n5/T0dHhScco9S4dAKiwonQ6/Vnf92cAOB7AttJBSg3DWgB3MPNCz/MegW7Fq0JIBwAq9NLp9Jh8Pn+YMeYkZj4BQLV0k1Kb0AvgASK6vbu7+w+6RK8KOx0AqEixLGtbACcQ0XRmPhhAuXSTKml9AP46eN/+H3VDHhUlOgBQkZVMJscR0aHGmKMHbynUhYZUMfQAWEJEi4nozkwm87p0kFIjoQMAFQtTpkzZJpfLHcnMxwD4PIBa6SYVK28CuJ+I7q6srPy/tra2ddJBSo2WDgBUHCVs296DmY8GcBSAFukgFT3M7AK4l4gW19bWPrx06dJ+6SalgqQDABV76XTazufzhxtjDmPmaQA+Jt2kQuktAA8BeKCsrOw+XaBHxZ0OAFRJmTZtWtmKFSv2BXAoMx9KRHsBKJPuUiJyAJ7GwJX7f6mvr39al+JVpUQHAKqk1dXV1dTU1OwH4EAABwz+WClbpQokB+CfAJYw82PM/Eg2m10rHaWUFB0AKLWRiRMnVldVVe3DzJ8GsA+AfQGMF85SI8DMa4joKSJ6koge6enpeaqzs7NbukupsNABgFJbRqlUqskYsw8z74uBQcGuACqEu9QH9QF4AcBTRPQUMz/pum67dJRSYaYDAKWGadq0aWWdnZ1TmLnF9/0WItqFmT9JRBOk20rEOwCeZ+Y2InoRwFLf95/JZrM90mFKRYkOAJQKSH19/cTy8vJdADQz8y5E1AxgdwDbCKdFVS8Ah4jamPlFZm5LJBIvZjKZlwD40nFKRZ0OAJQqLEqn0x8HkM7n82kisjGwy2EagA0dHLzNzI4xJsPMDjNnmDlTVlbmZDKZTuk4peJMBwBKCUomk+OMMfUAGgDUE1E9gHpmngigDsD2g/8ZwcyR8AG8DuA1AKuJ6BUAK5i5E8BKIupg5pWu674lWqlUCdMBgFLhZ5LJ5A7GmO2JaHtmrmXmWgDjjDHjmHkcgHEY2CVxGwBjBn9ew8wVALYloo0HEJUAqj70HN0YWOMeAMDMPoC3iKgPwHoAGzAwJf/24OeuJaK1vu93vftzIuoC8Jrv+697nvc6dJpeqVD7/2BQoU8SmqjhAAAAAElFTkSuQmCC",headphones:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAACXBIWXMAALP6AACz+gFmujCYAAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAIABJREFUeJzs3XmcHHWd//H3p7rnyj1JSEiYZPoiCQx3FISgBkFuREUOFUjCqYIoyqrrb9cFXVfdVRT8+UMQkiB4BTxWQU4FlXvNyhWF0F3dk8RACMlMQuburs/vjxkQyDUzXd2fqur38/FAc8x0vWCSqU/X8S0BEQVWW1vbuJ6enhkiMg3AHqraDGAigEkAJqnqJACTRGQsgPEA4qraLCLxoZ87Qx8/ElsBlAC8qqpFEekAUATwqoh0e57XCaBTRDoBvPHHL6vqxqampvWrVq3a5sO/PhFVkFgHENWihQsXxteuXTsDwGwAszzPawEwS0Rmi8ieqrongOkAmkxDR68HwMsi8iKAlz3Pa3ccZ62qrgOwFsCa2bNnr3/wwQeLtplEtYsDAFGFtLW11W/bti3tOM7eIpIGkBn6Jw2gFUDcNNBeSVXbRSQHIAsg6zhODkC2oaHhhVWrVvUb9xFFGgcAojK1tbXVd3d37+M4zj6e57WJyD4A2jC4s6/1nfxoFQG4AJ4Vkb+p6irP8/4Wj8f/ls1m+6zjiKKAAwDRCLS1tY3r7e2dC6DN87z5IjIfwHwAjcZptaIIYLWIrFTVVar614aGhkeee+65TdZhRGHDAYBoJxYuXBhft27dAZ7nvUNVDxORwwDsjcEL6yg4FIOnEB5X1cdF5PHm5uYnV65cOWAdRhRkHACIhrS0tEyuq6s70nGcd6nqYQAOATDGuotGpRfASgCPi8ifYrHYQ6tXr37FOoooSDgAUM1Kp9PTPM87TEQWADgGwMHgu/vIUlUXwP2O4zysqg+6rrvGuonIEgcAqhkzZ84c09jYeAQGd/bHYPAdPv8O1KjXBgIA94vIva7rbrFuIqomfvOjKJNMJnNwqVQ6HsB7ReQIAPXWURRIAwAeFZH7VPVu13VXYvDaAqLI4gBAkdLS0tJUX1+/QFVPEZEPAJhl3UShtFFE7vY87zexWOyebDa71TqIyG8cACj05syZM3VgYOD9InIqgKMR3tXzKJh6ATwgIv8N4Je5XO5l6yAiP3AAoFCaM2fO1FKpdKKqng7gOAB11k1UEzwAjwK4zXGcn2ez2XXWQUSjxQGAQiORSOwZi8XOUNUzABwOXrFPtlRVHxORFaVS6Wft7e0vWgcRjQQHAAq0lpaWprq6upNF5FzwnT4F1+tHBuLx+I+45gCFAQcACpyFCxfG16xZc7yInKuqJ4Pn9ClcegH81nGcH06cOPG3XJGQgooDAAVGMpmcKyIfBrAEg4/JJQq7zap6u6peVygUnrSOIXojDgBkqq2tbVx3d/eHASwRkcOte4gq6AkAyxzH+TFvK6Qg4ABAJhKJxDzHcRYDuAhAs3EOUTX1ishtIvLtbDb7F+sYql0cAKhq2tra6ru7u08VkYsweL8+//xRrVspIjf09PTcun79+m7rGKot/AZMFZdIJPYUkU+IyMUApln3EAWNqm4SkRvi8fj3Vq9e/XfrHqoNHACoYobW4f/Y0C18jdY9RCFQAnCXiHw9l8s9bB1D0cYBgPzmpFKp9wO4HMCR1jFEYaWqjwL4dj6f/zkG1xkg8hUHAPJFW1tbfW9v71kAvqCq+1j3EEWFqroicm1/f/8N69at67HuoejgAEBlaWtrG9fT03M+gM+CT94jqqSXAVxXLBavWbNmTYd1DIUfBwAalUQiMclxnE8B+BR4Gx9RNW1R1WsHBga+s27dus3WMRReHABoRObOnTt+YGDgEwA+D+74iSxtU9WlAP4jn89vsI6h8OEAQMPS0tIyua6u7nIRuQzABOseInrdqwD+bzwev5oPIaKR4ABAuzR9+vSxY8eOvRTAFwBMsu4hop3qAvB/AXzNdd0t1jEUfBwAaIfmz59f19nZuURVrwQww7qHiIZnaFGh//I875pCodBr3UPBxQGA3spJp9Nnq+pVABLWMUQ0amsAXOW67s0YXGCI6E04ANDr0un0e1T1WwAOsm4hIt88p6pfyufzt1mHULBwACAkk8m5juN8RVVPt24hooq5X1WvyOfzT1mHUDBwAKhh6XR62tCh/gsAxK17iKjiSiKytFQqfalQKLxkHUO2YtYBVH0LFy6Mx2KxCzzP+4WIvAuAY91ERFXhAJgvIh9vbm6unzlz5iMbN27k9QE1ikcAakwikXi34zjfBbC/dQsRmVstIp/K5XJ3W4dQ9XEAqBGzZs2aWV9f/3VVPRv8uhPRm93hed4nC4VCwTqEqoenAKJP0un0RY7j/BrA28GdPxFtb46IXNzc3Fzs6Oh4DIBaB1HlcWcQYZlMpk1Vb1TVd1i3EFFoPCkiF+RyuZXWIVRZPAIQQfPnz69ramr6J1X9CbiYDxGNzJ4Azps0adLUhoaGP3V1dQ1YB1Fl8AhAxKTT6SNU9QcA9rVuIaLQywG42HXd31mHkP84AETEzJkzxzQ2Nn4JwBXgkR0i8o+KyK19fX2fXrdu3WbrGPIPB4AISKVSJwK4DsBs6xYiiqyXVPWT+Xz+dusQ8gcHgBCbM2fO1GKxeC2AD1u3EFHN+LmqXpLP5zdYh1B5OACEVCqVOhrAzQD2sm4hopqzUVXPz+fzv7EOodHjABAymUymwfO8qwD8E7iELxHZUVX9QV9f3+Xr16/vto6hkeMAECKtra37OI7zIxE52LqFiAgARORvIvLRbDb7F+sWGhleLR4Okk6nLxKRX4gIL/QjoiDZQ1UXNzc3D3R0dDwKriIYGjwCEHDJZHK6iCwFcKJ1C4VCH4DXDsduU9UBEVEAnQCgqv0i0vWWzxkDoGHox5NUVUQkDmD8Dn6faFfuGxgYWLx27dr11iG0exwAAiyVSp0M4CYA06xbyMxWAAUReVFVN6nqJhHZpKqvOI6zSVVf8TzvlVgstqmnp2dTpc7FtrS0NDU2Nk4plUpTRGSqiOzhed4UEZmiqm/8/xkYXH1yYiU6KBReEZELc7ncr6xDaNc4AARQS0tLU319/TcBfBz8GkVdN4ACgDyAgqrmRaQgIoW+vr58WBdemT17dnN9fX3S87wEgISIJFU1ASCJwQFhrGEeVYGq3sALBIONO5eASSQSCcdxfg7gEOsW8lUvgL8CeBrAMwCe9jzv2UKh8JJtlo2hU1v7Adh/6J8DALQBaDINI7897TjOB7PZbM46hLbHASBAEonEcSLyIxGZYt1CZWkH8LSIPON53lOe5z2TTCZfePDBB4vWYQEXSyaTGQwOAwcA2F9EDsDgUQMKrw4A57iue6d1CL0ZB4BgkFQq9TkAXwXvzAibIoDVqvqQ4zgPe573h3w+324dFSXJZHI6gENFZD6ABQCOBNBoW0UjpAD+03XdLwLwrGNoEAcAY3Pnzh0/MDCwDMBp1i00LK8CeBzAw6q6UkT+6LruFuuoWjJ//vy6zs7OA1T1SBFZoKpHAZhq3UXDclexWPzomjVrOqxDiAOAqUwm0+Z53i8AzLFuoZ3qBfAnAHc5jnNvNpv9G/gOJmgkk8nso6rHeJ53goi8G7yWIMhyqnpaPp9/yjqk1nEAMJLJZE71PO9m8HapIMqr6n0A7o/FYvdks9mt1kE0fEN30SwAcMzQP/ONk2h7vQA+4bruMuuQWsYBoPpiqVTqqwA+B/73D4peAA8BuF9E7s/lciutg8g/c+bMSZVKpWMAHKOqx+MfCxyRMVW9YcyYMZ9ctWpVv3VLLeIOqIpmz57dHI/HbwfwHusWQi+A34rIim3btt2xYcOGt66ORxE0dHTgRBE5U1VPwuAqh2TroXg8/oHVq1e/Yh1SazgAVElra2syHo/fqar7WLfUsD4A94nIbSLyKx7ar20tLS1NdXV1xziOc7qqfhBcnMiMqrqqelKhUHjOuqWWcACogmQyeaiI/BrAdOuWGlQC8BiA2+Lx+I/4LoN2ZObMmWMaGhqOdhznHFV9H/jsAwubPc/7YKFQ+IN1SK3gAFBhqVTqgwBuBa9KrraVAG7s7+9fEdbldMlGIpGYJCIfEpELARxq3VNj+kRkcS6X+6l1SC3gAFBBqVTqUwCuBuBYt9SIrar6U8dxbuCFfOSH1tbWfWKx2CJVvYArdFaNAviy67pXWodEHQeAyoil0+nvqOql1iE1YqWI3NDY2PjjVatWbbOOoejJZDINpVLpfSJyEYCjwe+d1bCsubn54pUrVw5Yh0QV/xD7bPr06WPHjh37EwCnWLdE3BZV/ZmqXlcoFJ60jqHakUql5gA4D8AS8FHdlXY/gA9xtc3K4ADgo9bW1hmxWOw34MIjFaOqrohc29vb+wM+ZpQstbW11ff29p6lqp/D4JMMqTKeBXCS67prrEOihgOATxKJxDzHce4BMNu6JaIeFpFv5nK5X4NL8VKwSCqVOklVPysiC61jokhE1qvq8a7rPmPdEiUcAHwwtKb/fQBmWLdEjIfBxXq+lsvlHrGOIdqdRCJxUCwW+4yqngWgzronYjo8zzuxUCg8Zh0SFRwAypRKpd6mqnfzCmFfdanqjwBcnc/nn7eOIRqpodOBFwP4FIBJ1j0Rsk1ETs3lcr+3DokCDgBlSCQS73Yc5zfg2uJ+2SYi1/b19X2L9+5TFCQSiUmO43wawOUAJlj3RES3qr4/n8/fZx0SdhwARimdTh+lqr8GMM66JQL6VPVmVf23QqHwknUMkd9aWlom19fXXwYOAn7pB/Bh13V/YR0SZhwARiGVSp0M4DYAjdYtIdevqsuLxeJVa9euXW8dQ1Rpc+bMmVosFq8AcBm4Omi5SiJyXi6X+6F1SFhxABihdDp9lqr+ELzApxwDIvLTWCx25erVq13rGKJqy2Qye3ie91kMXiPANxKjV1LVj+Xz+RutQ8KIA8AIJJPJC0TkenBp39HyVPUWz/Ouam9vz1vHEFlLpVKzReRfVPU8ADHrnpBSEfl0Lpe71jokbDgADNPQuv7fBv+bjdYfHce5PJvN/q91CFHQpFKp/TH4/eVo65YQ+6Lrul+zjggT7syGIZlMXioi37XuCKl1IvJ/crncLRh8yAcR7UQymTxFRL4NIG3dElIcAkaAh5x2I51OLwLwfXBYGqluAP/R399/Vnt7O5/MRzQMnZ2dq1Op1HW9vb2bABwOXh8wUkdPmjRpW2dn56PWIWHAndoupFKp0wD8DByURkJF5HZVvYJrdxON3rx586b09fV9SUQuAb8HjYSq6sX5fP4H1iFBxwFgJzKZzKme590GXu0/Ek+o6ifz+fwT1iFEUZFOp+er6jUAFli3hEhJRD6ay+V+Zh0SZBwAdiCVSh0D4Dfg4bfh6gbwZdd1vwmgZB1DFEGSTqcvVNX/AhcSGq4BVT0tn8//xjokqDgAvEU6nT5CVe8BV/gbFlW9G8DH8vl8u3ULUdQNPWPguwBOs24JiX4ReX8ul7vLOiSIOAC8QSaTOdjzvN+DD+8Yjg4R+UIul7vBOoSo1gzdLXAdgL2sW0KgW1VPyOfzf7QOCRoOAENSqdT+qvoAn+q3eyJym4hcks1mN1q3ENWqRCIxSUS+ISIXgt/Ld2crgKNd1/2zdUiQ8A8NgGQyOVdE/gBgunVLwLWLyMd5OI0oOFKp1NEArgfXDtglVd3kOM7CXC73rHVLUNT8AJBMJqeLyKMAktYtAbesrq7uU88///yr1iFE9GYzZ84c09jY+C0AH7NuCbi18Xj88NWrV//dOiQIanoAaGlpaaqrq/udiBxu3RJgWwB8wnXdH1uHENGuJRKJ4xzHWQ5gT+uWAHsWwJGu626xDrFWyw+1cerr62/lzn+XHnAcZz/u/InCoVAo3CMiBwK407olwPYD8JOFCxfGrUOs1ezqUqlU6moAS6w7AqoI4Cuu616wefPmmp+SicKko6Ojq6Oj4yeTJ09ej8GHC3Exs+3tvXXr1pkdHR01vUZATQ4A6XT6IgBfte4IqOccxzkhl8v9BHx4D1FodXR0rJwyZcqvVPVI8JTAjhwyadKkrs7OzkesQ6zU3ACQTCZPAXALavv0x85c39vbe1p7ezvX8CeKgM2bN2+cOHHicgATRORQ1Ph1X28lIsdMmjTpr52dnX+1brFQU38YMpnMIZ7n/QFc5e+teodu71tuHUJElTG0eNAtACZatwRMr4gcncvlau5IQM0MAHPmzNmrWCw+BqDFuiVgskPrZT9tHUJElZVKpeYA+AWANuuWIFHVTSJyuOu6L1i3VFNNHAbPZDITisXib8Gd/1v9tlgsHsqdP1FtcF13dVNT0zsA3G7dEiRDK8Delclk9rBuqaZauAbAmThx4i9FhI/S/AcPwFWu635sy5YtPdYxRFQ9Gzdu7O/o6Li9ubm5F8BRqJE3gsMwWVXnH3jggT8uFAqedUw1RH4ASKfTXwFwnnVHgGwVkQ+7rns9eJU/Uc3q6Oh4aOLEiX8QkRPA66Jek9y6deuYjo6O+6xDqiHS1wAMXfTyK3DCfc3TjuN8MJvN5qxDiCgYMplMi+d5twM4zLolIFRVz8rn8yusQyotsgNAKpXaG8AT4KN9AQAick88Hj+da/kT0VtlMpkGz/OWAfiwdUtAbHMc5x3ZbHaVdUglRfKd8fTp08di8EpX7vwBqOoNs2bNOpk7fyLakWw22+e67kcBXGXdEhDjPM/7RSqVivQtk5G8BmDatGm3iMh7rDsCQAF8OZ/PX1ErF7UQ0eh1dHQ8OGnSpHVD1wVEcv8wAlNEZN+Ojo6fWYdUSuS+wMlk8rMi8hnrjgDoFZFzXNf9nnUIEYVHZ2fnXyZNmvSYiJwKoMG6x9jc5ubmvo6OjoesQyohUtcApNPpBar6AGr84RequslxnFNzudzD1i1EFE6pVGp/DD5VcJZ1izFPRE7O5XJ3WYf4LTIDQGtr64xYLLYSwAzrFmNZACfW2opWROS/WbNmzYzH43eIyMHWLcY2x+Pxt69evdq1DvFTJC4CbGtrq4/H478Ad/5/KhaLh3LnT0R+WLt27fpYLLYQwP3WLcYmF4vFFYlEotE6xE+RGAB6enq+oqrvsO4w9kBTU9OJa9as6bAOIaLoyGazW5uamk7C4J1VtWy+4zhfs47wU+hPASSTyXeJyO8RwQsaR+AOz/NOLxQKvdYhRBRZsWQyuVREzrUOMaQATnFd907rED+E+ghAIpGYNPR4y1re+f+0ubn5g9z5E1GFlfL5/HkAbrIOMSQAliaTyenWIX4I9QAgIt8HMNu6w4qI3DJ79uxzVq5cOWDdQkQ1oeS67oUAvm0dYmiaiCxDBI6gh/adcyqVOk9EvmjdYej/ua57caFQKFmHEFFt6ejouKe5uVkALLRuMbJ3c3Pzho6Ojj9bh5QjlAPAnDlzUp7n/Qq1u0jFN1zX/Qz4ND8iMtLR0fHg0COFj7FuMXJ0c3Pzrzs6Ol62Dhmt0J0CWLhwYbxYLP4YwHjrFiP/5rruF6wjiIhc1/0GgM9adxhpVNWb29ra6q1DRit0RwBE5CoR+Yh1h5Fvu65by6c9iChgOjo6Hp08ebIH4CjrlmoTkRkDAwONnZ2d91m3jEaoBoB0Or0Ag1eghu7IhQ++57rup6wjiIjeqqOj44/Nzc0NAN5p3VJtInJ4c3Pzwx0dHXnrlpEKzQAw9FjGewFMtm4xsNR13Y9bRxAR7UxHR8fvJk+ePBXAodYtVSYAjh47duzyrVu39ljHjESY3kl/A0DCOsLAz2fPnn0xeMEfEQVcLpe7TER+YN1hYK+6urqrrSNGKhT3MQ6t9vcgQtLrFxH59aRJkz7E+/yJKERiqVTqFgAftg6pNlU9Lp/P32vdMVyBPwKQyWQaHMf5Pmps5w/g/lKpdCZ3/kQUMqXm5uZFAH5jHVJtInJDW1vbOOuO4Qr8AKCqX1LVfaw7quzh3t7eU7m8LxGF0cqVKwc8zzsDwO+tW6qstaen58vWEcMV6HfVyWTyABH5M4A665YqyjmOc3g2m91oHUJEVI5MJjPB87w/ATjAuqWKPMdxjsxms49ah+xOkI8AOAC+jxra+avqJgAncudPRFGQzWa3xuPxEwGss26pIsfzvOvnz58f+H1XYAeAZDJ5uYgcbt1RRb2O47zPdd3V1iFERH5ZvXr13x3HORXANuuWKtp/8+bN/2QdsTuBPAWQSCQSjuM8AyA0F1OUSQGc47ruj6xDiIgqIZVKnQjgvwHErVuqpK9UKh3c3t7+N+uQnQnkEQDHca5H7ez8ISJf4M6fiKLMdd3fisgl1h1V1BCLxQJ9B1vgVgJMp9OLUUMPlxCRG3O5HB/uQ0SR19HRsbK5uXkigFo5vds6efLkFzs6OlZah+xIoI4AzJs3b4rned+07qiiu2bNmsUlfomoZriuewWAX1p3VIuqfj2dTk+z7tiRQA0A/f39XxWRKdYdVfJcXV3dmQ8++GDROoSIqIq83t7eswE8ZR1SJZM8z/uKdcSOBObcRCaTOdjzvP9BAE9LVMA2x3EOy2azf7UOISKykEwmWwGsrJE3fZ6IHJrL5QJ1KiAoRwDE87xrUBs7f1XV87jzJ6Jals/n2zH4vICSdUsVOKp6DQL0phsIyA43nU4vAlArz7r/Rj6fv9Y6gojIWmdnp9vc3CwAFlq3VMHs5ubmZzo6OgJzW6D5NDJ37tzxAwMDqwHsad1SBfe7rns8amPiJSIaDieVSv0awEnWIVWQ9zxv36A858X8FMDAwMA/ozZ2/mscx/kIuPMnInojz/O8swFkrUOqICkin7GOeI3pEYBMJtPied7zAMZYdlRBL4B3ua77P9YhRERBlEql9gfwKICx1i0Vtm1gYGDu2rVr11uHmB4B8Dzva4j+zh8ALuHOn4ho51zXfQbARdYdVTAuHo//h3UEYHgEYOi2vz8jAKchKuxW13XPsY4gIgqDVCp1I4DzrTsqTFX1Hfl8/gnLCLOdr6p+23L7VVIAcKl1BBFRWHR1dX0KQNSfiioAvgPj0/AmO+BkMnmKqr7bYttV5Hmet9h13S3WIUREYbFhw4YuEfkIgH7rlkoSkcNTqdQHLRssBgBHRL5ssN1q+/dCofAH6wgiorDJ5XIrVfUq644q+I+FCxeaPR656gNAMpn8CICDqr3dKvtzc3Pzv1tHEBGFVT6f/zqAB6w7KmzO2rVrz7baeFXPP8yfP79uaBWkdDW3W2VdAA5xXTfq57CIiCpq6FbxpwBMtm6poHbHceZms9m+am+4qkcANm/efBGivfOHiFzKnT8RUfmy2ew6RP/WwFZVvdhiw1U7AtDS0tJUX1+fAzCjWtusNhG5LZfLnWHdQUQUJclkcrmILLLuqKCXu7q6Uhs2bOiq5kardgSgvr7+IkR45w/g5bq6uo9bRxARRU0sFrsMwDrrjgqaNmbMmKrvP6pyBCCRSDQ6jpMFsFc1tmdBRM7K5XI/s+4gIoqiVCp1EoA7rDsq6JWmpqbkqlWrtlVrg1U5AhCLxS5EhHf+AH7LnT8RUeW4rnuniNxm3VFBU7u7u6t6LUDFB4BMJtOgqp+r9HYMvSoiH7OOICKKulKpdBmADuuOShGRf5o5c2bVno9T8QGgVCpdAKCl0tuxoqr/nMvl1lp3EBFFXaFQeAnAFdYdFTS9sbGxam8oK3oNwNB9/y8AaK3kdqyIyGO5XG4BAM+6hYioRkgqlboHwHutQypkg+d5iUKh0FvpDVX0CEBnZ+dHENGdP4B+ETkf3PkTEVWTep53EQYXXYui6SJSlSfIVnIAEFWN7KEaEfn3bDb7V+sOIqJaUygUClF+poyIfB5ArNLbqdgAkEwmTwawX6Ve39hfGxsbv2EdQURUq2bNmnU1gCetOyoknUwmP1DpjVRsABiaYCLJ87zPrFq1KtKPqiQiCrIHH3ywKCKXAlDrlkoQkf+DCl+nV5EBIJVKHQlgQSVeOwDuKBQK91hHEBHVulwu9zCAn1t3VMhBqVTqPZXcQKWOAFxeode11g/gs9YRREQ0SEQ+A6DbuqNCKrov9X0ASCaTrQBO9ft1g0BEvssn/RERBUcul1srIt+27qiQExOJxLxKvbjvA4DjOJ9EFa5eNLCxVCr9u3UEERG9WU9Pz38AiOKCbOI4zqWVenFfB4C2trZxqnq+n68ZFCLyL4VCodO6g4iI3mz9+vXdIvIv1h0VsqSlpWVyJV7Y1wGgu7t7MYBJfr5mQDyVy+Vuso4gIqIdy+VytwB4wrqjAsY0NDRU5I21nwOADN2SETkicjmAknUHERHtlDqO82lE8LZAVb0EFTi17tsAMHS7wly/Xi9A7sjlcg9YRxAR0a5ls9lHReR2644KaE2lUif4/aJ+HgH4uI+vFRTqOM6XrCOIiGh4VPVfEM0jtr4/JdCXAaC1tXUGgPf58VoB84tsNvsX6wgiIhqeoVu1f2rdUQEnJBKJhJ8v6MsAEIvFLgJQ58drBYinqpF92AQRUVSJyJUAitYdPnNisdiFvr5guS+wcOHCOIALfGgJmp/m8/mnrSOIiGhkcrlcFsAPrTv8pqoXZjKZBr9er+wBoL29/QQALT60BEkJwFXWEURENDqe530Fg8u3R8kepVLpFL9erOwBQESW+BESMLdwyV8iovAqFAoFAEutO/wmIov9eq2yBoB58+ZNAXCiTy1BMRCPx79iHUFEROUZGBj4CoAe6w6fHZ/JZHw56l7WANDf338uAN/ORwTE0tWrV7vWEUREVJ61a9euB3CDdYfPYp7nne3HC5V7CmCxHxEBUvQ87+vWEURE5I+BgYH/RPSuBVgMQMp9kVEPAOl0ej6AA8oNCBJV/fnQeSMiIoqAoaMAP7bu8NncdDp9RLkvMuoBQFXPKXfjQaOqUX2mNBFRzRKRbyFizwhQ1bJPA4x2AIgBOLPcjQeJiPyhUCg8bt1BRET+yuVyz6rqPdYdPjujra2tvpwXGNUAkEwmjwawZzkbDhrP875l3UBERJUxdBQgSib39PQcW84LjPYIwEfK2WgArc7n83daRxARUWW4rnu/qkbt2S5l7YtHPAAkEolGEXl/ORvEfRiVAAAgAElEQVQNmqHJ0LPuICKiirraOsBnp7a1tY0b7SePeAAQkVMATBztBgNoY19f3y3WEUREVFmTJ0/+GYC11h0+GtPd3T3qN+SjGQDOGO3GAup769ati9pKUURE9BYrV64cUNVrrTv85DjO6aP+3JF8cEtLSxOA40e7sQDqF5HrrCOIiKg6ROQHALqsO/yiqsfOnTt3/Gg+d0QDQENDw/EARn2+IWhE5Fe5XO5l6w4iIqoO13W3ALjNusNHjcVicVTP5BnRAKCqp41mI0Glqj+wbiAiouoaOgoQJaPaNw97LeH58+fXdXR0bADQPJoNBVDedd0MePU/EVHNSaVSzwJos+7wSXdXV9e0DRs2jOjUxrCPAHR2dh6D6Oz8oao3gjt/IqJadaN1gI/GjBs3bsSLAg17AFDVU0f64gFWLBaLy60jiIjIRn19/S0Aeq07/KKq7xvp5wx3ABAAJ430xQPsjqEnRBERUQ167rnnNgH4pXWHj07CCK/rG9YHZzKZgwC0jKYooKJ2AQgREY1QxC4G3CORSBw6kk8Y1gDged4po+sJpHWu60btqVBERDRCuVzuQQAvWHf4RURGdKR+uIcLonT4fymAknUEERGZUwzuEyJBRE4eycfvdgBIJpPTAbxt1EUBo6o/tm4gIqJgUNWfYHAQiIIDM5nMsE/XD+cIwLHD/LgweDKfzz9vHUFERMGQz+fbReRx6w6fSKlUOm64H7zbHbvjOO8trydQVlgHEBFRsKhqlPYNw95n724AEFU9psyYwBCRKK3/TEREPnAc5zZEZ2G4YzDMo/a7/KBUKrUfgBl+FAXAn3O5XNY6goiIgiWbza4D8Ih1hx9EZEo6nT54OB+7uykhMof/RSRKh3iIiMhHUdpHqOqwlgXe3QAQlcP/WiqVePifiIh2qFgs3o7onAYY1pv3nQ4ACxcujAM40rccQyLyeKFQKFh3EBFRMLW3t7+oqn+07vDJEYlEonF3H7TTAaBQKMwHMN7XJCMRu8KTiIgqIEKnARpEZLfLAu90AIjFYu/yt8eOqv7CuoGIiILN87xfIiKLAjmO8+7dfszOfkNVd/vJIfHXfD7fbh1BRETBVigUXgLwF+sOP6jqbt/E72wAcAAs8DfHhojcZd1AREThEKF9xhFtbW31u/qAHQ4AmUzmQACTKpJUZaoalS8mERFVXlT2GWO6uroO2dUH7HAAKJVKkXj3D2Cb4zgPWUcQEVE4zJo163EAHdYdfhCRXd7Jt8MBQETeUZmc6hKR32ez2T7rDiIiCocHH3ywKCL3W3f4YXf78p1dAxCJAYCH/4mIaKSisu8QkcN39fvbDQDz5s2bAiBVsaIqisfj91o3EBFRuHiedxcicDugqs7MZDItO/v97QaA/v7+wwFIRauq47nVq1e71hFERBQuQ7cDPmXd4YdSqbTTI/rbDQCqelhlc6omEodwiIjIxN3WAX5wHGen+/TtBgDHcd5e2Zyq+Z11ABERhVYkLgTc1Zv6HR0B2OV9gyGh/f39j1pHEBFROHV1dT0GoGjd4YMDsZML/t/0i+l0ehaAPapRVGF/Xbdu3WbrCCIiCqcNGzZ0IRrXAUxIp9M7vLD/TQOA53kHV6enslT1YesGIiIKt6jsS3a2b3/TACAiUTj8D8dxIvFFIyIiU5HYl4jIsAaASBwBEJFIfNGIiMhOsViMxFLyqrr7AUBVD6xOTkVtyGazOesIIiIKt7Vr164HULDuKJeIHLSjX399AMhkMhMAzK5aUeXw3T8REfklCvuUPefMmTP1rb/4+gBQLBb3RTRWAIzCF4uIiIIhEvuUgYGBfd/6a68PAI7jbPebYeR5XiS+WEREFAiRuA5ARHY+AOzoN0NoIB6PP2kdQURE0eC67ioAXdYd5RKRtrf+2usDgKpGYQB4PpvN9llHEBFRZHgAVllHlGtH+/g33gUQhQHgGesAIiKKFhF52rrBBzs+AtDS0tIEYFbVc/wXhS8SEREFSxTeXE5PpVIT3/gLDgA0NDSksZOHBYQMBwAiIvJVRI4AQEQyb/z5azv9zA4+NnQcx4nEF4mIiIKjt7c3KvuW7QcAz/OiMAB0ZLPZddYRREQULUNPl/27dUe53rqvdwBARNI2Of6JyiEaIiIKpNDvY966r3/tFEDoBwDP80L/xSEiosCKwoWAOxwAUgYhvnIc51nrBiIiiiZVjeQAIABabFp8FfqFGoiIKJhisVgU9jEz5s+fX/faT5xEIjEdQINhkC+KxaJr3UBERNHkeV4U9jHOpk2b9nr9J47jRGEBoN729vaXrCOIiCiaXNfdAqDTuqNcIvL6Pt9BNFYAbAeg1hFERBRdqpq3biiXiMx+7ceRGACi8EUhIqJgE5GCdYMP/nEEQERCfwFgRL4oREQUbFF4s/mPAUBVZ1iW+KRgHUBERNEWkTebe772AwfAdMMQX/AUABERVVpE9jWv7/MjMQCARwCIiKjCInIEIFoDQCwWi8JURkREAbZt27Yo7GumvfYDB8AUwxA/dGez2Y3WEUREFG0bNmzoAhD2/c2ElpaWJmBwAIgZx5Rrg3UAERHVjJetA8pVV1c3DfjHw4DCbJN1ABER1QYRecW6oVwisgcQgQFAVUP/xSAionBQ1Si86ZwERGAAiMI0RkRE4RCFN52q2gxEYAAATwEQEVGViEgU9jmROQIQhS8GERGFQBROATiOE40BIAqHY4iIKBwcx4nCPicyA0DopzEiIgqHKOxzVHUSAMStQ8oVkWmsPCvWNmFL7xTE6ifAQRMAQL3xUC8ORxx4mABoJwBApA8a24RSaRMmJl/BGVKyTCciQys0hi35qYjFpkBKU6DaMPgbMgkOtsJTD+IUIc6rAAAPPYg5W+AVN2FJstew3Iznea84TujfO48BIjAAeJ4X+mlsp658II7WRAuABIAEFEkACQhmQDEVgqkApqCrOAbxOAAP0Dd8vjiDPxe89j9Dv+4BcQG6Ch6WF9YDKMBTF4K/wpGngdjTWDTr71X6tySiSvvBCy2I1x0A6AGA7AtBEqpJdBVmIC4O4AEQQN7wfULxj5+rN/j/AsAb+vGyfBeATVBsgmAjFC9BkMfgs1kKKGke69r/jiuPKlbp37IqHMcJ/T5HRKIxAKjqFuuGsl2pDhJrk1DvQED3B3R/iHMg4CWgb/gaveHv5pt+PHoOVFsAtEBwJADAUwBFYHlhHVQfgurDiOm9WJRe7csWiajybnLnwsGxgCyAyILBv+evvTvQN79RGL2xAMZCMBvA9t+TYgIkWotYls9D5ClAn4HIM1DnaSya5ULEn4oqcxyn03ttCAopVR0DAJJKpUL5RXhNqVSa2d7e/qJ1x4hc//xUNNQdAZUjILIAwEFQHWedtRsuIHcC+mMsST5mHUNEb7BCY+gqvBPQDwFyIoCkddIuiWyD6l8APAzoI3DqH8GillC8s06lUhMBdFp3lOl3ruseE/oBoL6+fupzzz0X7D84P8xOQ9E5Fo68B4rDAcyzTirT81C9FR5uwQWpdusYopp1Y3Y/OLELITgDwJ7WOWVQKJ6D6CMQ5wF4A/fivL0D+dCdRCLR6DhOj3VHOVT10Xw+f0ToB4Cmpqbxq1at2mbd8SYrNIZt7YfBwQkAjofqIYjAHRc7oAD+CMV1WJO4DVdKuI+LEYXB4Lv906G4DILDrXMqxAOwEoq7ILgLYxP/E6ALlp1UKhWUltF60nXdg0M/ADiO05jNZvusO3D9n+vQOPUYeHomgFMATLZOqrLVAL6G/k0/wsVvG7COIYqcFavq0TX2bEC/AGBv65wq2wTBr6FYgf5Nv7P+HpNKpfoB1Fk2lOl513XnhX0AUNd1Y/DrkpaRWqExvOoeDnFOh+AsANNMOoJlDYCrMTZ+A86YFerDZESBcO0LDZgQOxMqXwKQts4JgA5A7gC829C/+W6LYSCVSm3D4EWQYZV1XXfvsA8A/a7rNlR9qzfn5sCLXQDoInCnvzNrALkcSxK/sA4hCq2l7ofgON8euluHtvcSgJtRKt2ICzLZam00lUptQriP8hZc102GfQB41XXdCVXZ0rUvNGB87H0Q5yKoHg2/bsSLvt8DuARLks9ZhxCFxvI1aXil70JwgnVKiKyE4Ab0NdyKi2d2V3JDqVTqRYT7osu1ruvODvUAoKqb8vn81Ipu5Oa1e6FUvAyCCxDuic9SL4CvA/hGra4eRjQsK9Y2YVvxCxB8DkCjdU5IbQJwI7zYtTh/9vpKbCCVShUAtFbitavkRdd1Z4b6ynTHcSp38d9N7oFYVvghvGJ+6C8jd/6j1wjgSij+F8ty+1vHEAXSTe6B6Cr+BYIvgTv/ckwB8Hk4pTyW5ZfjZveACmyjvwKvWU0xIOS3pqmq/1+EZe57sbxwHxx5EtBzEO4rPYNFsA/gPI6l7gXWKUSBsjR/MRx5DMBc65QIqQewCJ48iWX5e7C8/WgfX9v+zrPyxF//n7BSVf/uO78pdyTE+TKAo6ChPSsSBk0Q+QGWucejX8/HxenwL+VMNFo3PTceTsP3AXzEOiXCBMCxUO9YLMs/ApV/xXmJ35f5mmFfB0CAkB8B8MXy9gVYlv8dHOdPEBxlnVM75DTUO49jafu+1iVEJm7M7genYSW486+mIyD6Oywv3IebC1FdRGnYancAWN7ehqX530K9hwC8xzqnRs2FeH/iX0SqOTfljkQs9kfU3oI+waB6DDx9BMvcO2r5TUjtDQA3rp2MpflrgNKTvMUmECbD0/uxvHCSdQhRVSzNnQzHuQdAs3UKyUlwSk9haf56LH1hD+uaaqudAeDKB+JYnr8I8dLzEFwGlVBf/xAxY6D637w4kCJvmXsOxPkFgDHWKTREJQ7BRZD481iW/zxWrKq3TqqW2hgAlrvvwuzE01BcD9XKrhtAoxWDyA1Ylv+0dQhRRSzNXw7IzeCdRUHVDODr6Brzv7gpd6R1TDVEewC4PjcRS/PXQOWBwVvQKOAEwNVYXjjfOoTIV8vccyD4FriCaBi0wXH+iKX563HrC9VZadZIdAeA5YWTUO88A8FliPK/Z/QIVK/HzYUPWIcQ+WKZewoES8Gdf5gIBBdhIP4clhU+aB1TKdHbMV7//FQsK6yA6h0AZlnn0KjE4OmtWFo4wjqEqCw35Y4E5Ge85ii0ZgD6cyzL/xQ3r5tiHeO3aA0Ay9z3or7+KUBPt06hso2B6G9q+RYdCrlluf3hOL8B0GSdQmU7E97AUz6vJmguGgPAtS80YFn+64DcDWCmdQ75ZjIc/e+on4ejCPreqnGAcxuASdYp5Ju9oN59WJq/RuP1kTidE/4BYHl7G8bHnwDweUTh34feTDWDgfh11hlEI9I05iZwXf8oEgguW3fh9XsP7BHmhwEOCvUOc9tBJ4yDeo8DqMTTnig4PsI1Aig0luY/DsEZ1hlUOQNTZzetO/86vHrAsdYpZZFUKhW6J9+oOOh4z/noPOIs6xSqnl4Ah2NJ8knrEKKdWpbbH3AeB8/714wJ/3snptx1DcQL1fOBOlzXnRy6IwClcZPx4rlXc+dfexoB/ATL8nxOOgXT9evHAM7PwZ1/Tdl6yEl48ez/Qmls+FZ2DtUA0LfXPlh3wXXonb2/dQrZmAfgC9YRRDtU1/tF8OE+Nam39UD8/cLvo2/GHOuUEQnNANA170isP+ebKI3nSr417gu4OReuv2UUfctye0PkCusMslMcPxXrF30bXXPCs3xJKAaALYd+EBs+9G/QOh79JTTAc75rHUH0JupcA6DBOoNsaV0jNpx+JbYcGo6FTIM9ADgxbDr+k9h03CWABDuVqurYKC/PSSGzNH8mHy1Or3Ni2HTcpdh03KWAE7Ou2aXA7lU1Vjc4Sb39/dYpFEj6HaxYy4utyNb168cMPeSH6E22HPoBbDjtX6Gx4D78MZADgNY14qUz/z1U51Ko6mZh2wCfGki26vsuArCXdQYFU9e8d+Klj3wdXkBPXwduAPDqGvHSWV9FT/pt1ikUdCKfw4pV9dYZVKOu/3MdgMutMyjYehIHDQ4BDWOsU7YTqAHAaxqPF8/5JnoSB1mnUDjMQvfYc6wjqEY1TFkCYLZ1BgVf7+z98eI530KpKViPNQnMAFBqmoD151yNvr32sU6hcPkCVmiwr7Sh6LnygTgUn7fOoPDomzEHL57zzUANAYEYALyGsXjpo99A//SUdQqFjWoGXe1nWmdQjZndehYAfsOiEemfng7U6QDzAeC1C/7CtoISBYl+zLqAaozIx60TKJz6Zs7FSx/5RiAuDDQdADQWx4bTr0RvKx/mR2U5EsvXpK0jqEbcmM0AONw6g8Krt2VfbDjzK9C47TXMZgOAioMNp1+F7vTbrRIoOgRaOts6gmqEEzsHgFhnULj1JA/By6f9q+liQWYDwKbjL0X33u+w2jxFjcjZUOU3ZaosVYGAwyb5omvOEdh4wqfMtm8yAHQu+DC2vu1Ui01TVKlmsKydh2Wpsm7OvxO8+I989OohJ2HL4WeYbLvqA0BX20JsPuq8am+WaoF4H7VOoIhT+Yh1AkXPpqMvRNc+76r6dqs6APTtNQ8vn/JPfLAPVYicaF1AkceH/pD/xMHLp34BvS37VnWzVdsTFyfsgZfO/Cof6UuVlMCy/DzrCIqoG7P7gSv/UYVoXQM2nPFlFMdPrdo2qzIAaKwOGz50JUpjJ1Vjc1TbjrMOoIiKxY+1TqBoK41txssf+jdoLF6V7VVlAHjlhMvQtxffmFEViBxpnUBRpe+0LqDo623ZF5uO/URVtlXxAeDVA96LVw/mqVmqElUOAFQpvG+ZqmLr207FqwdV/nKTih5n6JsxB6+c9JlKboKAPgAFAC8B2ATFKxB0QHUbRAZe/xjFDDgyE6oLACStYqtgT9zotuKCVLt1CEXIDwtJlHRP64wKcwF5GND1GPx+0gAAUK2DyDhAJgM6BcAUADMAtL7+MeS7V47/JBpeegH1L2Urto2KDQBa34SXP/B/zJc6jJBOAE8B8jTgPQN1VkGdAs6b9SJEdESvdJN7IBxcCMhFAOoqUmsphgMAcAAg/xT1gIiu/dcPyPVwvBuxKPX0iD5TVbB07QzENAkt7QtxDoDq/gAOAjCxIrU1ROsasOH9X0TLTZ+ADPRWZBsVGwBeOfYTGJjSUqmXjz6RdfD093DwMOA8jMLsv+FK8bb7uPNH8drnp54CcCluzH4HMef7gBxddm+gOPsD+I11BUWI6AERXP33XqjzcZzX6o7qswffeKwf+ufh13/9SnXQktsXTmwBRBYA+h4Ae/kRXGsG9mjFpvd+DFN/+52KvH5FBoCueUfyvP/IeQD+BOidgN6NxelnKr7FCzJZXPnA8WhNXg3oJyu+varxqnszLdUAabMu8Nk1GJv4LM6Qku+vPPhG5dmhf64HANzsHgCV46E4GcACBOBJtGGx9ZCTMSb3BMY8/4jvr+37AFAaPxWvnPxZv182qhQiD0O9FYg7t+OcxItVL7jyqCKAy7A0rxBcVvXtV4RE+RoHshGlP1PfwZLk5VXd4uDphacB/CduWjMTsdKHoDgTg09VjNyhFV+JYOPJV6Bl/YWIvbrJ15f2dwAQwcunXIFS0wRfXzaCNkLkZkjpB1iUXm0dAwBYU/gsEsl9oXqMdYoPovTNmoIhYR3gk3sxNnGFacH5s9cDuBbAtbjJnQvBhRA5F8Aepl0BVhozERtPvgJ7/uSffX1dSaVSI7uAbBdePeBYbDz18369XPQo/gLo1RjXswJntPVb52xn+Zo0tPRXAGG/clMxtrsxkP+NKXyW5RsBdCP871T7EJN9cG4ibx2ynRWr6tHVdCYgn8HgRYS0A9N+9TWMe+Z+P16qw3Xdyb6dhymNbcbmYz/u18tFzT1QORrnJQ/BealbA7tjWjw7B8X3rTN8IHi1iutpUrQVi1MR/p0/AHw/kDt/ADijrR9LUrdgSfJgiHMMgPusk4Jo03GX+HqE3bcBYNPxl/LQ/3b0YTjyHixJHo/zEr+3rhkWx7nBOsEX8SIHAPJHfV00Dk3H5HrrhGFZ3Po7LEkeC0eOAPR31jlBUmqa4Osqgb4MAN1zDse2fRf68VJR8QzUey+WpI7EosQD1jEjsrh1FUQqt/JEtZSk2TqBIiMKDzFZjXMTf7OOGJFFiUexJHUMRI+DyLPWOUGx7YD3ojv9dl9eq+wBQOub8MoJn/KjJfxEXgHwcYxNHIzz0r6cqDGh+pB1QtkETdYJFBlReIRpeP9OL07di0L+YEAuAeDvZfAh9coJn4LWlb8IY9kDQOcRZ6E4IRpHyMojt6Gvbx8sSX6/IvfWVpPq360TyiYa9gsZKSg8Df9ytyLrrRPKcuVRRSxJ/D8AGShuAODbxethVGyegc7DPlT265Q1ABQnTkPnO04vOyLk3MHD/YkzcPHcV6xjfCHYYJ1QNi/0dzJQUKhW59msleR54f87DQBLkp04L3kxRI8HEMwLGqukc8GHUSzzWueyBoDNx1zsy2GI8JJb4PUdFOrD/Tv0+kOEwsvhSmPkkyj8WRIpWif4anHqXnh9Bw4dDahJWt+Eze+5oKzXGPUf7N5Z+2HbPu8ua+MhthkiH8KSxLk4f96r1jFERDXn/HmvDh0NOBNAh3WOhW37H4O+vfYZ9eePbgAQGbwVQaJwa+yIrURJD8HixM+tQ4iIat7i1ArEZP7gQms15rV98SiNagDomnME+mbOHfVGQ0vkVvQ3vIvPmiciCpBzE3kIjgD0JuuUautt2Rfde79jVJ878gFAHHS8e/GoNhZiJQCfxuLEObh4Zrd1DBERvcWSZC+WpC4A5LMYfLpqzehYuHhUR+RHPAB07fsu9E9PjXhDIdYFxWlYkrzGOoSIiHZjSeJqAKdh8PkNNaFvz73RNXfBiD9vZAOAE8Pmd5474o2E2CY4+h6cl/xv6xAiIhqmJclfATgawGbrlGrpePdiQEa4Sx/JB29rOwoDe7SOaAMh9hJKpYVYlHrCOoSIiEZoSfIxOHoUEIF1TYahf1oS2/Z514g+Z/gDgAg6jzhrpE3hJLIOjvduXJDh+tNERGG1KPU0PH03RNZZp1TDlgUfHtHHD3sA6Em9Df3TkiMOCqGXofpeLEqvtg4hIqIynZ96HsXiUQBetE6ptL49M+hJHjLsjx/2AFATS/6KvIJS6WgsST5nnUJERD65IJMFvONQAw8T2jKCffWwBoD+6akRTRWhJLINkON52J+IKIKWpJ+BoycC6LJOqaTu9NvRv0diWB87rAFgyzvOiPqqfyV4ejYWt660DiEiogpZlHoCImdicG2XaBLBlsOHdxRgtwNAacxEbGs7quymQFN8krf6ERHVgMWJOwG93DqjkrbtdzRKTRN2+3G7HQC2HXgcNBb+p2HunH4P5yWvs64gIqIqWZL6bpSfJKixOmw74NjdftxuB4CtBx7vS1BAPYaxPZ+xjiAioiob2HQpoA9bZ1TK1kNO2u2p+10OAL2tB0R54Z8N8GKn4Yy2fusQIiKqsovfNoBi6SwAL1unVMLA1NnobWnb5cfscgDYevBJvgYFiELkfJw/e711CBERGblw73UAFgFQ65RKePXgE3b5+zsdALym8ega4bKCoaH47uCFIEREVNOWJO8GNJLXgW3bdyG8hjE7/f2dDgBdcxZA4/UViTK2CoLPW0cQEVFAjK27Aoq/WWf4Tesa0b2LpwTudACI6K1/HlQuwpJkr3UIEREFxBmzegAsAeBZp/ht274Ld/p7OxwASk0T0Js6uFI9lq7FeYlHrCOIiChgzks+HsVTAT3pt8PbyZoAOxwAuvd5J1RiFY0ysAbd3f9qHUFERAFVV/oigL9bZ/hJnRi65hyxw9/b4QCwq0MG4aVX4JK2bdYVREQUUGfvvRUikbtGrKtt4Q5/fbsBoNQ0Ab2JAyvdU10iD2Fx8nbrDCIiCrhFrT+G4lHrDD/1JA+B1zhuu1/fbgDoSc2P2uF/BeTTEInkfZ5EROQjEUVMP40IrQ2gTmyHT/TdfgDIHFaVoOqR2/mUPyIiGrZFqScAROoBcd3pt2/3a28eAETQvYMpIcQ8oPQV6wgiIgqZUulfEaHbArszh233bIA3DQB90zMojZ9S1ajK0p9gSfoZ6woiIgqZCzLPArjNOsMvpfFT0D8t+aZfe9MA0LN3xA7/O/hP6wQiIgor76uI0LUAbz0N8OYBIHFQVWMq7G4sSj1tHUFERCE1eAT5fusMv/Qk3nyK//UBQMVB3177VD2oYsT5pnUCERGFnOJb1gl+6ZvVBjj/uMvv9QGgf88MvLpGkyjfKf6Gxa2/s84gIqKQW5K4F8Dz1hl+8Oqb0PeG6wBeHwB6Z+1nElQhP7AOICKiCBBRqN5oneGXvjfs66M4APQDxVutI4iIKCIGBpYD6LPO8EPvjgaAvlltJjEV8Euct/dG6wgiIoqIi+e+Augd1hl+2G4AKI2fiuL4qWZBPvupdQAREUXOz6wD/FCcsAdK4yY7wNAA0PeWxQFC7FWMjd9jHUFERBHT33gnRCLxRNm+aakYMDQADERmANBf44xZPdYVREQUMRfP7IbqndYZfhjYM/OPAaBvetq2xi8qv7FOICKiiNJoXAfQNy35jwGgf1rKtsYfJcTqIrNiExERBczAwN2IwAOC+qclBgcAdWIYmDrbuscPj2NRyybrCCIiiqiL574CIPSPlx+Y2hrDlQ/EneKkPaGxuHVP+TQ66zUTEVFQ6X3WBeXSWB0wOzXbKTbPsG7xh+hD1glERBRxjhORfY0mnIGJ060r/FBCvz5hHUFERBHXW3oEGvrLAAAHSac4aU/rDD88i4vTW6wjiIgo4i5Ob6nbvL7XOqNsnpd0ipMicQog9BdlEBFRONS/7HZbN5TNcVqjcgrgGesAIiKqDfUbC+E/AqBe0ilF4RkAKk9bJxARUW2o35AN/wAA2cspjZlgXVG+krfKOoGIiGpDw0tu+F++c1UAABfQSURBVAcAkamO1jVaZ5SrCxemNlhHEBFRbYhv3TAgxX7rjPKojnOsG3xQsA4gIqIa4nmIbwn/+84IDABasC4gIqLaUtf5knVC2SIwADjrrQuIiKi2xLZutE4oWwQGAOUDgIiIqKpiPa9aJ5QtAgOAhH8MIyKiUHG6O60TyhaBAUA3WxcQEVFt4RGAIBAN/5KMREQUKjIQ/qUAwj8AqIT8ZkwiIgobKRWtE8oW/gEAHACIiKi6pDRgnVC2CAwAXvi/CkREFCbKASAIVNU6gYiIako3IrDrCf8AQEREVEUiEv5bAMABgIiIaERU9UXrBj9wACAiIhqZ560D/MABgIiIaARUdZV1gx84ABAREY2Aqv4JIp51R7k4ABAREY1AoVDo1LrGrHVHuTgAEBERjVBx0p5/tG4oFwcAIiKiEdo67133WzeUiwMAERHRCPXP2neTdUO5OAAQERHVIA4ARERENYgDABERUQ3iAEBERFSDOAAQERHVIA4ARERENYgDABERUQ3iAEBERFSDOAAQERHVIA4ARERENYgDABERUQ3iAEBERFSDOAAQERHVIA4ARERENSgCA4ATsy4gIqIaI07cOqFc4R8AROutE4iIqMYoGqwTyhWBAcDhAEBERNUVgTef4R8AgEbrACIiqjmh3/eEfwDwvGbrBCIiqjUy2bqgXOEfAESmWCcQEVGNUXAAMBeBLwIREYWMaOjffIZ/AAD2tA4gIqIaI85064RyhX8AELRaJxARUY1RTVonlCv8AwCQsA4gIqKak7AOKJcD0aJ1RJmm4fr1Y6wjiIioRtz03HgAYb8GYMCBSod1RZkEDQP7WEcQEVGNiNdHYZ+z2QHwonVF2TxvP+sEIiKqEersb53gg787UBSsK8qnUfhiEBFRGKhG4U1nwQEiMACIHGydQERENeMg64CyCdodiLRbd/jgMFz5QOgfzUhERAF35QNxiLzNOsMHBQeCKAwAY9GaiMIhGSIiCrLW2QdDdZx1Rvm04MBD3jrDH3KEdQEREUWcOIdbJ/iihHYHPV2rAah1S/n0aOsCIiKKOMUx1gk+8FA3JuvgkrZtiMKFgMAxuP7PddYRREQUUStW1QNYaJ3hgxzO3bNrcClgxTPGMX6YgHjzYdYRREQUUT1jFwAYb53hg2eA158FoFEYAADHOdk6gYiIIqrknWSd4AvFs8BrA4DIs6Yx/jnDOoD+f3t3Hh5XXS5w/PuemaRLaFlKuYBtM5OURUCUK1zl4bogaJGtiFK8SJtM2mtYXFBQUR6uAa94Xa4sAlKkmaQtqAW0SEGgYNnasspaKJRkJkWQC6S0QNM2kznv/aMUUuiSZM6Z38yZ9/M8fR7SZOZ8S5bzzsk552eMMRGkKoh8xXVGIET7DwBeNI4AQJL2rN0UyBhjTLBmZw6BiCw/H/P6DQAjJywH3nLZExhf7SiAMcaYYOUjc4R5DZ21z8GmAWCK5BF50GlScKYyT2OuI4wxxkTExrv/neI6IyBLaREf3j0JEFCWOssJ1ofo6TrKdYQxxpiImJA4BtjDdUYg5L19/XsDgBeZAQB8ne46wRhjTGQ0uQ4IjOoWBgBflwK+i57ACcczO5t0nWGMMabMpTMJPD3adUZAfHr1oU1vvDcApJKrgWddFIUghs8ZriOMMcaUOeFbqERltdmnaK5fs+kN733vvLPIMeFR/TpzV4x2nWGMMaZMzV0xGo3Q4X+Rhf3f3HwA8OT2osaEazR9Vf/pOsIYY0yZysVPB3Z0nREY9e/o/+bmA8CI2N3AuiLmhO1crlgWgXWbjTHGFNXsV2qAs11nBGgdNVX39/+LzQeAKePXIbK4qElhUt2VkSNOd51hjDGmzPSt+xYw1nVGYJS7mTJ+sxf47z8HAHw/Sr8GAOR7zOyIziEcY4wx4UpndkIi9eofhDve/1cfHACI3VqMliIaS5X3I9cRxhhjyoWeD4xxXREoz//Avv2DA0BT7TPAM8XoKRrhLK55YaLrDGOMMSWubWU9yJmuMwL2JA31z7//L7dwBABQbgg9p7iqicV+7jrCGGNMifPzvwaGuc4Ilm5xn77lAUD8qA0AACfSmpnsOsIYY0yJSmdPRDjedUbgYt4gBoBU/VNoZO4K+B7hN8xaPsp1hjHGmBIzd8VohEtdZwRO5GmmJba4P9/yAADgyY2hBbkzntjwi1xHGGOMKTF98f9BdZzrjMDplg//w7YGgLw/F9AwepxSPZN0NioLOxhjjClUa2YSymmuM0Kg4F+3tXdufQCYXvccRGiJ4PcIaJrZL+zmOsQYY4xjrSvGIrQB4jolBPeSql+xtXdufQAAUK4JPKc07EY+djWqUfyEG2OMGQhVQWJpYHfXKaEQbd3Wu7c9AMRHzAPeDLKnhEymLft91xHGGGMcSWfOAznGdUZI3mTD8G1e0bftAWDa7msRmRdoUmm5iLbOL7iOMMYYU2St2c8h0uI6IzTKH2jes2dbH7LtAQDA16j+GgDAQ2UOs7NJ1yHGGGOKpG1lPR5/BGKuU0Ij/nb33dsfAJqSDwIPBNFTonYjr7dybdfOrkOMMcaE7JoXd0Hzt6C6q+uU8OhiUvUPb++jtj8AAIheXHBPaduXXn8+l62I2O0fjTHGvGvmI1XEcvOAfVynhEq8Ae2zBzYAjEzeCGQK6SkDn2ZU/DpaFsVdhxhjjAnYPI1RPWYOyBGuU0KWZWTt/IF84MAGgCmSR+SKgpLKw4lMSMyiRQf2/8UYY0zpUxV6uq4CTnadUgSXMkXyA/nAge/oNuSvAd4aalHZEKZRm/mN3SPAGGMiQFVoy1yO6gzXKUWwhqq+bV7739/AB4Dm+jUovx1SUtmRM2jvmm2/DjDGmDI2T2O0d10NcobrlKJQvZxT9xrwvXsGd6g7VvULKuEoAIDqqdQm5jLzkSrXKcYYYwapZVGct7OtFfLKH0TeJpe7ZDAPGdwA0DCuG6iEcwE2OZmqMTfZEsLGGFNG5q4YTW1iAcI01ylFdAnN+7w+mAcM/mQ3r+pXVMpRAADhi8SGL2F2xwTXKcYYY7Zj1so96Y3fDUxynVJEb9IXG/Tl+oMfABrGdSNcPujHlTPVA8h7S0h3HOI6xRhjzFa0Zj6Bl38Y4SDXKcUllzJj/KrBPmpol7v1xX8FvDGkx5avD4F3H62ZZtchxhhj3qc1czrCvcCerlOKrBv010N54NAGgBnjV6H8ZEiPLW/DEK4inWlj9is1rmOMMabiXbFsB9LZ2QhXAtWuc4pPLyCVXD2URw79hje57suB54f8+PLWQH7dU7R1HeY6xBhjKla64xBGjnwUdKrrFEeW07vqqqE+eOgDQPPBOZTvD/nx5S+J+otoy55n9wswxpgialkUJ915PiJLgL1d5zgjcg7NB+eG+vDCbnnblLwJWFjQc5S3KlT/m9rEo7RmPuE6Jjiyi+uCgok35G8KYzajXp/rhADs5DogMO3Zg0gkl4JciEolv/j6G42JWwp5gsLvee/r9xCNwjdIIQ5EWEw6cwkzO3Z0HVMwYQ/XCQVTel0nmIjQfPl/LWkEvqfTmZ1IZy/D10dQPdh1jmM58vlvF/okhQ8A0+ueAG9Qdx+KqBjwbaq9FaQzp5X1rwVUy3+pTD+/wXWCiQhPyn8AEPZ1nTBkLYvipLNnILIC9JsEsd8qf//LjIlPF/okwfyP3FD9Y6K/XPBAjQV+S23icVozk8tuUaG5K0YDn3GdUbCYDPh+2MZsk0bia+kz73xvlw9VoT37JWoTT4BegequrpNKRAc18QuDeKJgBoDmPXuAylhsYeD2R5hPW/YR2jqPL5tBIBebTBQupdF4t+sEExV+FL6WhtEbO951xICoCunMCbRl/46vfwL2c51UWvR0poxfF8QzBbtTSmeuBU4J9Dmj43ngSmriVwf1yQtcy6I4ExJPInzYdUrBqvp2HMyqWMZs1bVdO9PrD/ouayXoeXq7DyjkrPFQzVtWTc+Ir6JyDvAR1zmlSeaQSgS2vkGwv0uJ5b+DyKAWI6ggewOXsLYvQ2vmAq7prHUd9AGJxBmR2PnDWr42sXLWqzDhOmXCaqA0h/bB2Zthu37ddcQHpDMJ0tkLWTtyJSrt2M5/a15Dc2cH+YTBH5ZOZ04A/hz480aPD9yFkiY37KZ3fo3iTnv2UHxdBAxz2hGMZaSSB7iOMBGSzjwLZXwi3XvWA4eTSj7gtGL2KzXk108GvwnkcOzEvu0TnUxj3V8Cfcogn+xdbdnfVcwazMHoQeRW8K8n3/tXpu9b3Fev17xwALHYQmD3om43LCILaEwc5zrDREg681fgKNcZAXkF8Y6ksXZZUbc6a/koZNjRiJ4EcjQwoqjbL2fK1TQlA1+HJpxL1dau/Q41NZ9FdWIozx89I1H9CshX8IblSGeWoNyO+HfStfIxWg4P7z4LrZnJCHOAUaFto9jUr9RbVJuwKM8jkRkAdkf9JaQ7TyVVd3NoW2lZFCdZ+6/43pGgk4BDgaqwXndG2PPER3w3jCcO7zPRnj0U9e+t8Ds1BWEtykN4shjVR5HYU2THZ2gRv6Bnbe/YG18uAjmRqH1HKk00JdOuM0yEtHbOQOR3rjMCpiA3QP48UvUrCnqmFvUY11FHVfwj5P2PI3IYcAhgi6YVJgf+YaTqHw7jycP9wZ/uPB8kkOsVzWbWIvIsvnYCWSCL6D+Q2CrU70b7usl5vTTXr3n3EbNf2I2ctwfCp/C8yeB/NrLDme8fwvT6R1xnmAhp7/w3fHnQdUYoRPtQWYTITeT9+6ny/8m0ia+++/6ZHTsyQoeRj+2CeGPQ/C6ojAMSQAKhHvgwMNLNPyDClB/RlPxZWE8f7gDQoh612ZuBo0PdjjHv2QDsRCq53nWIiZB5L45gbd9qonCPDFMubqYxMRkRDWsD4Z552SI+1d6pQEeo2zHmXfqI7fxN4Dbeu+PvrjNMhRB5AZgW5s4finHpxddq38DTEwG3l7mZCiH3uy4wEaW62HWCqQjr8TmZVHJ12BsqzrWXDXVPonyjKNsyle5u1wEmojxvkesEUwFEm2lKFOVoU/FuvtCUTKNcVrTtmUq0jpr4Pa4jTER5w+9m4410jAmHcDGNdbOLtbni3n1ph8R3gfCuOzWV7p6SXWfBlL9pu68F7nOdYSJrPtnEOcXcYHEHgCmSpyZ+MvBQUbdrKoPIDa4TTMQpN7pOMJH0KLERpxZ8f5dBKv79l6eMX0dcTgBWFn3bJsrWo2o/nE24cv4fiMbCQKZ0vIQXn/zOEaaicrMAw9TEP8E/Fliz3Y81ZmBuKsZZs6bCNdevAVngOsNExmrEm0TD+JdcbNzdCkyp+qeAoxB521mDiRAp2okzpsKJP9d1gomEHtDji74oUz9ul2BMJR8AOQE7s9YU5lV6X1/oOsJUiGzXrcD/uc4wZa0X+DKpOqcnlbpfg7mx9i7QKUDOdYopU6pzaD7Yvn5McbQc3odwnesMU7ZyqP9lUsnbXIe4HwCAjUtSylcRDW/ZWxNVOeJq95cwxeXnL2bjqzhjBsNHaaCpviTOIymNAQAglfgT6jXYEGAGR9qYVm9XlJjiapr4Iugc1xmmjIj2gUylKfl71ymblM4AAJBKXIevX8LOCTADk4f8L11HmAol8Z/ZCxYzQL2odzKpREn96qi0BgCApvoFeHK0XR1gtk+uI1W/wnWFqVCNEzpArnedYUpeD6LHkUr8yXXI+5XeAADQkFiE+kcDb7pOMSXLJ8bPXEeYCteXvwgo6t3bTFlZg+9PorHuDtchW1KaAwBAqu4+xPsc8E/XKaYkXc20xLOuI0yFmzHxaURaXWeYkvQynhzO9PqSXaK8dAcAgMbaR/HihwCPu04xJaWb3t7zXUcYA0Bf7AeIvO46w5QQkaeJ+YfSkHjMdcq2lPYAANAw/iV6ej4F3Oo6xZSMc2jex37gmtIwY/wq1P+R6wxTMhayIf/v5XB1UukPAABn7v82XdnJCL91nWJc08U0JtpdVxizma7kLJSlrjOMazqL3u5jNq4ZUfrEdcCgpTNnAb8AqlynmCIT7UP4OA11T7pOMeYD2rMH4evDQMx1iim6HMI5NCbL6qZk5XEEoL9U8hJ8304OrEQq59vO35SshsRjoBe4zjBF9zLiHV5uO38oxwEAYHr9/WjfR0Hvcp1iiuY2uhK/cB1hzDZ1JX8KlOQlXyYU9xKXg2msXew6ZCjKcwAAaNrrNbq6jkK4GFDXOSZUL6F902gRu97alLYW8enTadgRyqhTRH5FV/YIpibK9nNdfucAbElb5xdQSQN7uk4xgcuj8gWaEn9zHWLMgLVmPoNwF3Y+QBS9ivrTS2VBn0KU7xGA/hrr7kD7PobyF9cpJnDn2c7flJ2m5D2I/Nh1hgncfHp794/Czh+icgSgv7bOaeBdgeoOrlNMwWaSSp7mOsKYIUtnLwP9pusMU7B1wA9JJS91HRKkaBwB6K+xbjZ9fQcBd7tOMYXQG6lJnOm6wpiC1NR+B+XPrjNMAZRF5PMHRm3nD1E8AtBfuvMkxLsS1V1dp5hBuRv4IqmkLQttyt+8ZdX01NyC6pGuU8ygvIFwLg2J3yESyRPNoz0AAMx+YTfysYuBU1ynmAF5nF7/s+VyJy1jBmRmx45Ue/cAH3WdYgZAZC5+7rs07fWa65QwRX8A2KQ1MwnhUmAf1ylmK5SlxKqOo2Fct+sUYwLX/o8x+LkFwCddp5itUJ5F9Nuk6ha6TimG6J0DsDVNydvpyh6A0Ay86jrHfMBCdMMk2/mbyGoY103vsCOwhc1K0SrgXHbo+Vil7Pyhko4A9Hdt1870+j8AzgKGuc4xMofe16fTfHDOdYkxoWtZFKe29iqQ6a5TDDmUNLne8ypxhdHKHAA2SXfsBd5PgJOopKMhpeXnNCZ+GNWTbIzZIlUhnfklIme7TqlQPsIf6cv/FzMmvuA6xpXKHgA2ae3aD9FzQU/B7txVLG+hNNOU/L3rEGOcSWdPBJ0F7OQ6pUL4iNyK6vmkko+7jnHNBoD+bBAoDuUx/PyUSp68jXlXe8fe+N4fgY+5TokwReQW2/FvzgaALdk4CJwFOhUY7jonWvQK3sqfzbf22uC6xJiSkc4MBy4G7M6XwVqHMgfhYlLJ5a5jSo0NANvSumIsEjsN5EzgX1znlLmXgG+QSs53HWJMydr4K4HfYAubFeoVVK8gl7uqEk/uGygbAAbishXDGBX/D6AZu4Z3sHKoXsa6dS2cuf/brmOMKXmzlo8iNuwC0G+iEnedU1aUpQhX81bf7+0o4/bZADBY6cy+QOM7f+yowLbdB/6ZpOqfch1iTNlp7zwQnytBDnOdUuLeQLke1SuZXveE65hyYgPAUM1bVs3ammNRbUCYhN1PoL/nEPkJDbXX2eV9xhRAVWjLnApyPrCX65wSsh64HU/aWf/6AruHyNDYABCEmS+PpHr9EeCdBHoiUOM6yQmRp8H/JSOT1zJF8q5zjImMFvWozRwD8mPg465zHFmPyJ3gX088P59T93rTdVC5swEgaLOWj0KGHYvHcSCfr5CVCB9C9Kc0JG+2V/zGhEhVaMtORuQ8VA92nVMErwELgZvp6Vlg5xEFywaAsLV17Y/6xyJyJKqfBqpdJwVkFcoNqD+H6fX3u44xpuJs/NkylWidj5QHHgfuxPcX8GLdElrEdx0VVTYAFNOs5aOIVR+KyqHApj+jHVcNxnqUv4A/h5Urb6Pl8D7XQcZUvJmPVFG9y1HgTQU9jvK6d8ka4AFgKegS/N4HmL7vW66jKoUNAC61qMe4jv3wvE/ieR/F1/0RDgTGuE7rpxO4A+U21vXcZYfgjClhs5aPIj78SPJ6FMLngaTrpH66UZ7Ek2X4/hP4/gP8o/4Ze4Xvjg0ApWhOdg/6/ANA9mPjN3DinT+1hHvP8FcReRL1n0R4kHz8fqZPeDnE7RljwtT+4ofQ3GEgn0T1QJADgbEhbnE1kAW6gCxCJ77/DOI9TSr5SojbNUNgA0C5SWd2An88eGMQGYPqWETGgI7BpwaRnTd+oFYjsvFqBNU4IpsO169G9U2U1/HkVfBfRDVDb1/G7phlTAWY+dyuDK+qQ0mANx5fd0PYFZHRbHqB0f9nhupakN53/vsNRN9GvFWodiPyGqrd4HfTy0qa69c4+leZIfh/Gb6xSWIc7b8AAAAASUVORK5CYII=",microphone:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAACXBIWXMAALP6AACz+gFmujCYAAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAIABJREFUeJzs3Xl8XHW9//H358wk6cbSlk1sm5kz0wUCiBThCigFgaKCiEBdgDZpgSJc4aoo6E8x4sUruHGrKAWapAUUC+KCgCBQUFlcUAQq2GaWtBVapbSXki5J5nx+fyRoKV2ynDmfs7yfjwcP4YE6ryYz53zmLN8jIKJoUhW0rHwLUpqFVvaHyl6AjoXIWCjGQHQsIGMBjAWQAjAMwPC+//UoADXb/D+u6/vPHgAb+v5+PYCXIVgL1VegshYO1gKyFpDV6OnuwO5bVmBGQ1eV/7RE5DOxDiCinWhekoabnYiKdxAUkyHIQJx6qNYDmACgzjoRgAfgJUDLAMoAOiBOEVp5BqmRf8XM/TpN64houzgAEIXFovZ9UEkdBsEhUDkIqgdBcCDCsZMfLA9ACcCzEHkO8J6F6NOY6S6HiFrHESUZBwAiC4s1hY0rpgCVqfDkaAiOAXAAkvOZfBUiv4fqY4A+Bchv0JRdbx1FlCRJ2dgQ2WpWB9nS4ajgJIgcB5EjoDrKOis0RHug8gwUv4XI/UgNe5SnDoiqiwMAUbUsat8HFedYqJwAwakA3mKdFBmiPVD8DpC7Ic6DmDXhTzxlQOQvDgBEfmotHQrVMyHyAQAHW+fEyGpA7wHkTnStfQhzD++2DiKKOg4AREPV1tEA9c4C8GEAU6xzEmA9IHcD3h3YUHkAl0zcYh1EFEUcAIgGY1H5AFR0FoCzALjWOQm2Hoqfw9HbUM4+iGbxrIOIooIDAFF/LV45HJ3dp0CcC6D6HvDzEzZ/B3Ar1LkRs+uL1jFEYccNGNGutHVMheddAMFHAexmnUO75AH6BEQWYUvdrZi7/0brIKIw4gBAtD2tpWFQPQeOcylUD7LOoUFbC+h8eOnrMWfCi9YxRGHCAYBoa72r8TUBuATA/tY55JtuQH4K6LfQlH3SOoYoDDgAEAHAguLbIHIRBOfi3w/MoXh6CqLzUO74AZqP67GOIbLCAYCSbWHxEHjOFwA9E/w8JE0RgmswIrMAM6RiHUMUNG7wKJm446fXKZ6Ho1/DiOxtHAQoSbjho2RpLRwMpL7IHT9tx18heg0HAUoKbgApGdpW5ADva1A9A3zf0849C9HL0Og+YB1CVE3cEFK8Xb90FEaMuAzA5QCGWedQhIg8CK18Ck25Z61TiKqBAwDFU7M6yJTOgcq1APa1zqGIEu2BJy1IV76Imfl/WOcQ+YkDAMVPS2k6BN8CcKB1CsXGekC+gq6Xv8MnEVJccACg+LipuC/SztcBPdc6hWLrWQAXcDEhigMOABR9qoKFpXMB55tQ3cs6h2JPobgJtT2fwTkTX7WOIRosDgAUbb1X998A1ROsUyhxXoLqJZjt3mkdQjQYHAAompqXpJHJXg7VL4BX95Otu5CqfJwXCVLUcACg6GktZQAsAvAu4xKi1/0Toueh0f25dQhRf3EAoGhpK86EyncB7GadQvRmcgs2dl6Eixtesy4h2hUOABQN8/+2F2prbwLwQesUol0oQZxz0Vj/mHUI0c5wAKDw672vvw3AftYpRP3UDdWrsCL7VTSLZx1DtD0cACi8VAVt5c8C+CoAxzqHaMAUS5CufIQXCFIYcQCgcJpf2AO1Tht4yJ+ibyUUZ2F29nfWIURb47cqCp/W0qGodf4E7vwpHsZD8ChaS5dahxBtjUcAKFxai+cCcgOAEdYpRP6TW9BVeyHm7r/RuoSIAwCFw2JNobPj24B+wjqFqMp+hx49Dee7a6xDKNk4AJC9RatHomfTDyD4gHUKUSBEVqHinYI57l+sUyi5OACQrVvKb0GP3g1gqnUKUcA2wJEPY1bmPusQSiZeBEh2bm4/CD36JLjzp2TaDer9HK2lC61DKJk4AJCNltJ0pFKPA5hgnUJkRiUN4PtoKf43VHlElgLFNxwFr6V0GgQ/AlBnnUIUHnITOuov5MqBFBQOABSstvLZgNfW982HiN7odnStnYm5h3dbh1D8cQCg4PSe67wePPVEtGMiv4DqWWjKbrZOoXjjhpiC0Vb6LIDvg+85op1TPQWKe3H90lHWKRRvPAJA1ddavgrQL1pnEEXMb1DTcwrOmfiqdQjFE7+NUXW1lr7EnT/RoLwL3en7eCSAqoVHAKh62kqXQPG/1hlEkSbyIFRP5TUB5DceAaDqaCk1QXGddQZR5KmeAOB2NC/hnTPkKx4BIP+1FM+ByEJwwCTyj8idGFH/EcyQinUKxQM30OSv1tIH4aAVfG8R+Uv1THSWb+aKgeQXvpHIP23Fd0PlAXCFvzBa2/fXht5/1M0QZ9O//q1qGsBuff80HMAYAGMB1AQZSf2gejVmu1+wzqDo4wBA/lhQnAxHHkfvjoOCtRqK5yHoAFCGotz396uhPWuxIr920MvL3rp8d3g1Y6HYDxWdAAf1UK0HUA9xJkPVBY/2BE8xG7OzrdYZFG0cAGjoWpbvDUk/ASBnnRJzCuB5AE8CeAYqz6J7yzOYO/lls6L5L45AetOBcFKHQPQgqB4ByFQAw8yakqEb4rwXjfUPWYdQdHEAoKFpLQ0D8BCAo6xTYqgbwOOA/BoOnoCnT6Apu946apcWL61F54jDoHgnBMcAOB7AntZZMbQe6hyN2fV/tQ6haOIAQIOnKmgt3w7BDOuUGCkAej9UHoBueRhzpmywDhqyxZrCax1HAjodgukA3gGeNvBLGT36HzjfXWMdQtHDAYAGr7V4NSCft86IgRcAuQOOdydmuc9Yx1Rda2k/QD4E1TMheDeAlHVSxP0ewLFcKIgGigMADU5r6YMA7gLfQ4P1d6i2wfNux3n556xjzNxU3Bdp5wxAG9F7ZIAGQ+RmNGbOt86gaOHGmwautTARcP4AYA/rlIipQGQJ1LsRHR0/QfNxPdZBobKofAAqOgvAbAB7W+dEjsh5aMwssM6g6OAAQAOzaPVIeJufhOpB1ikRsgbA99GjN/BcbT/MW16H3VMfhif/BcHbrXMiZDPEOQaN9U9Zh1A0cACggWkpLYRgpnVGRCwD8D2MTN+IGeM37fK/TW+2oHAMnNQlgH4IvFagP1agq2uq6a2hFBkcAKj/+HS//hH5I4BmNGbusU6JjdbSFAiuhOLD4B0Eu/JLdGTeP+jFnygxOABQ/7QW3gE4j4FLw+7MnwBtRmP2FxBR65hYauk4EOJdCeAscBDYCfl/aMp81bqCwo0DAO3aotUjUdn0FIDJ1ikhVYDI5ZhVfxd3/AFpLRwMON8AcJJ1Skh1w/OOwpzcH61DKLw4QdOuVTZ9E9z5b896AFcAOAiNmR9z5x+gptyzaMpOh3onAnjWOieEapBK/RDXLx1lHULhxQGAdq6t/H4AF1hnhIwH4AZ0dU1EU/YaLsBiaHbuQXSUD4PIf6J3IKPXqeYxcsS11hkUXjwFQDvW+5CfZwDsZ50SIssAzEVT9hHrENpG7wqD1wJ6rnVKuOgH0OTebV1B4cMjALRjkl4A7vxf1w3gGmzoOYQ7/5Bqyq5GU2YmRE4B0GGdEx6yoHc4InojDgC0fS2lWQBOtc4IiacAHIKm7BW4ZOIW6xjahcbMPfC2HAygxTolJPaGyHesIyh8eAqA3mzhqrHwup8Hl2P1oPguRm38DGY0dFnH0CAsLJ8OxY1Q3cs6xZzig5id/Zl1BoUHBwB6s7byLVA9xzrDWAninIvG+sesQ2iIbim/BT3aAuBk6xRjK+FtaYjFI6bJFzwFQG+0sHwcVM+2zjB2L2qdqdz5x8S5mZfQmHkfem/ZrFjnGBoPp+4q6wgKDx4BoH9bvHI4OnueBZCzTjGiAK5FR+bzXEY1plpL0wDcDmBf4xIrHhw5BrMyT1iHkD0eAaB/e62nGcnd+b8CxXvRlL2CO/8Ya8o+gooe2fe8hiRy4On30LwkbR1C9jgAUK9F5QPg6KesM0yItMPx3onZ2futUygA57kd2FJ7LIC7rFOMHIr6zMXWEWSPpwCoV0vpXgjea51h4EmkKqdhZv4f1iEUMFVBW/lLAL5knWJgHZyaiZg1bq11CNnhEQAC2oonJXTn/yMAx3Hnn1AiiqZsMxQXQbTHOidgo1HpvtI6gmzxCEDSLdYUOst/BnCwdUrAbkBH5mKe7ycAQGvxVEAWAxhmnRIY0R4gdSga65dap5ANHgFIus7y+Ujczl++jsbMRdz50780uXfDkfdB5DXrlMCopAH9mnUG2eERgCRb8MJucOqWIVnr/V+DpuwV1hEUUq3FdwHyCwC7W6cERnQ6Gt0HrDMoeDwCkGRO7RVI1s7/c9z50041ub8BMB1AclbLU7kGqvwymED8pSdV73r/JQC7WacEQ76CpgwveqL+aSkfBdEHAIy0TgmGnIGmTFJvi0wsHgFIKq/7M0jKzl8xjzt/GpDZmccBPR1AQp7+qFehWbk/SBj+wpOoZfneEEnGQiCKG9GU+S/rDIqgJvdXgHwMyXh+QAMmlD5kHUHB4gCQRFLzGaiOss4IwL1YUb4YImodQhHVlLkL0I9bZwRCpJlHAZKFv+ykmf+3vSBIwgbtT9i48cNoPi5pC7yQ35rcmyD4tnVGABpQXzrDOoKCwwEgaerqLk/At/+V8FKn4uKG5NzTTdVVzlwGxU+sM6pPvsSjAMnBX3SS3Lp8d6heYJ1RZZ1w9BTMmfCidQjFSLN46K47B8CfrFOqrAETiu+zjqBgcABIku6a8xD3BU5EL8Is9xnrDIqhuftvRMo7HSIvW6dUlTiftE6gYHAASIrFmgI07lf+X4dGd5F1BMXYzNwKeJWPIt53BhyP1tKh1hFUfRwAkqKz9CEArnVG1SiewMiNl1tnUALMzj0I4CvWGVXGW2cTgANAYkicP9BroakzMaOhyzqEEqIj8xVAH7LOqKKPoLWUpGXCE4kDQBIsKBwO4CjrjKoRvYgX/VGgmsWDUzMLwFrrlCqpS8xiYQnGASAJUqlLrROqRtCKRnexdQYl0Kzxf4/1IkGqc7F4aa11BlUPB4C4m1/YA6pxXeKzhHRPnE9tUNg1uXcAWGidUSV7Y+PIU60jqHo4AMRdbepsACOsM6pAoWjCORNftQ6hhKvpuQTA360zqsLTOdYJVD0cAOJO9TzrhKoQWYDZ2UetM4h6h1C5xDqjKgTT0dI+3jqDqoMDQJwtLB4CwdutM6pgDWrks9YRRP/SlLkLwE+tM6rAgZOeaR1B1cEBIM48xHPZX8WlOLt+nXUG0Ruk5SIA660zfKc6h88HiCf+UuNq8crhfc8yjxeRBzE7+yPrDKI3OTfzEhRXWWdUQRYTOqZZR5D/OADE1cbK+wCMts7wWQVa+ZR1BNEOda/9LoBl1hm+Ey9+XyaIA0BsqZ5pnVAFN6Mp96x1BNEOzT28G4oYXp8iH0TzkrR1BfmLA0ActZaGAYjbIz03AGi2jiDapdnZnwH4lXWGz8aivv446wjyFweAeDoZcXvsr+q1aMquts4g6heVKwCodYa/nLOsC8hfHADiKW4f1LWorcyzjiDqt9mZPwH4uXWGrwSn8zRAvHAAiJt5y+sAnGKd4SvFN7niH0WOI19GnI4CqO6FjHusdQb5hwNA3OyWOglxOvwv8jJ0y3etM4gGbFbmz9CYLQ6kXhwvLk4sDgCxI/G6+E/xbcyZssE6g2hQJHbrAsRr+5JwHADi5yTrAB9thJOebx1BNGhN2ach8qB1ho8moLU0xTqC/MEBIE4WFiYBcK0z/KOtmDVurXUF0ZAovm2d4LPp1gHkDw4AceJJnD6YCgjP/VP0NdbfB8Xz1hm+UQ4AccEBIE7Eic/hf5F70JR9wTqDaMhEFA6us87wjeDYvsXGKOI4AMTF4qW1AKZZZ/hG8X3rBCLfOMNvAxCXW1lHQL1jrCNo6DgAxMWmkUdDdZR1hi9EVmFk/f3WGUS+mblfJyDxeYqlpOJztDHBOADEhReribwNM6RiHUHkL22xLvCNapy2N4nFASAuVN5pneATBZw26wgi3zVlnwSw1DrDF4LDeB1A9HEAiANVgeA/rDN88ms0TihYRxBVhy60LvBJHcSZah1BQ8MBIA5aVxwAYLR1hj9ksXUBUfXIHYjL8wG0cpR1Ag0NB4BYiM0H0YPnxGvtdKKtNWXLEHnKOsMX8TntmFgcAOJAYvNB/A3mTHjROoKouvQO6wJfCI62TqCh4QAQD0daB/hC9U7rBKKq85y4vM/3waJy1jqCBo8DQNTNW14H0cnWGf5I3WtdQFR1s+uLsVkauEcPsU6gweMAEHV71BwIlbR1hg+WYXZ90TqCKBCCmCx0pQdbF9DgcQCIOvVi8gGUmGwQifolHu93kYOsE2jwOABEnhOPASA234iI+mFk+lEAm6wzfMABIMI4AESdahw+gN1whj1iHUEUmBnjN0HkMesMH0zCvOV11hE0OBwAoi8ORwCe7n1YClGCqMZhAKjBHqmYXIScPBwAoqy1tCeAt1pnDJ08aV1AFDjRx60TfOE5cTgKmUgcAKJMnJx1gj9isiEkGoh05UkA0X/qpXqudQINDgeASNOMdYEvUh4HAEqecya+CuCv1hlD5jj11gk0OBwAoszTCdYJPvgnZuZWWEcQGfmDdcCQqcfVACOKA0C0ZawDhk6fsS4gMqN4zjphyIRHAKKKA0C0ZawDhk6etS4gMiMa/QFAdQKalfuSCOIvLcqEAwBRtMXi/V+Lt7bvbx1BA8cBINqifw2A6lLrBCIzTdnVEHnZOmPIHCdjnUADxwEgqnpX39rTOmPIvPRy6wQiU6rt1glD5qT2sU6ggeMAEFUj68ZaJ/hgA84b/4p1BJGxsnXA0Hlx2B4lDgeAqHK64/CBK1sHEIVA2Tpg6CQO26PE4QAQWU70P3AiHdYJRCEQ/c+BcACIIg4AURWHD5x6XACIyInDIKzR3x4lEAeAqPJ0L+uEoZN/WBcQmdMYfA48cACIIA4AURWLIwC61jqByJx60f8cCGLwhSR5OABEljfSumDoJPobPqKh8rbE4XMQg+1R8nAAiCpxaq0ThszhEQAizJmyAUCXdcYQ1VkH0MBxAIgqT6M/AAjWWycQhUTUPwscACKIA0BUCaI/APRgi3UCUUhE/bMQ/e1RAnEAiCqJwcTtSNQ3ekR+ifopAA4AEcQBIKo0BqcA1In6Ro/IL1EfhqP/hSSBOABEVgwuAqx0cQAg6hX1z0L0t0cJxAEgqlTT1glDlk73WCcQhUTUB4Aa6wAaOA4ARERECcQBgIiIKIE4ABARESUQBwAiIqIE4gBARESUQBwAiIiIEogDABERUQJxACAiIkogDgBEREQJxAGAiIgogTgAEBERJRAHACIiogTiAEBERJRAHACIiIgSiAMAERFRAnEAICIiSiAOAERERAnEAYCIiCiBOAAQERElEAcAIiKiBOIAQERElEAcAIiIiBKIAwAREVECcQAgIiJKIA4ARERECcQBgIiIKIE4ABARESUQBwAiIqIE4gBARESUQBwAiIiIEogDABERUQJxACAiIkogDgBEREQJxAGAiIgogTgAEBERJRAHACIiogTiAEBERJRAHACIiIgSiAMAERFRAnEAICIiSiAOAERERAnEAYCIiCiBOAAQERElEAcAIiKiBOIAQERElEAcAIiIiBKIAwAREVECcQAgIiJKIA4ARERECcQBgIiIKIE4ABARESUQBwAiIqIE4gBARESUQBwAiIiIEogDABERUQJxACAiIkogDgBEREQJxAGAiIgogTgAEBERJRAHACIiogTiAEBERJRAHACIiIgSiAMAERFRAnEAICIiSiAOAERERAnEAYCIiCiBOAAQERElEAcAIiKiBOIAQERElEAcAIiIiBKIAwAREVECcQAgIiJKIA4ARERECcQBgIiIKIE4ABARESUQBwAiIqIE4gBARESUQBwAiIiIEogDABERUQJxACAiIkogDgBEREQJxAGAiIgogTgAEBERJRAHACIiogRKWwcM1LRp09IrV67MqGq9qo52HGckgM2q2ul53sue5/1txYoV66w7iYgoPsaNGzcmnU5PchxnLxEZCWCY53mdjuO8AmBFoVAoAagYZw5IFAaAVDabPR7AiSJy3IoVKw4BUAsAIgJV/dd/0XEcOI4D13XXAPitqi5JpVI/a29vX2WTTkREUZTL5cZ7nneaiBwH4GgA+77+717f72y9D3JdtwvAM6q6REQeKBaLSxDygSC0A0DfD/8TInIOgLcM8H++L4AzROQMz/Pmua77sKreWCqVfgzA87+WiIhiwMlms2eKyFxVnSYiAzlNXgvgcBE5HMBncrnci6p6q+M43wnrl9DQXQNQX1//llwud5OqtovIZzDwnf+2HAAniMhi13WX5nK5j/iQSURE8SGu657tuu7zIvIjAMdjiPtHVd0fwGc9zytks9n5mUxmP19KfRSmAcBxXffSVCr1gqqeh77D/D6boqo/dF334Ww2O7kK//9ERBQh9fX1B+RyuSUAbgUwqQovUSsiFziO80Iul/sEQrTfDUVIPp/fO5vN3gPgOgC7B/CSx4nIn3O53AUBvBYREYVQLpebmUql/qCqxwbwcnuo6jzXdX8VlqMB5gNANps9RFWfFpGTA37p4ao633Xd7yIEPwciIgpMynXd76vqQgAjA37t4x3H+UMulzso4Nd9E9MdXy6XO1pEHu07V2Ll4lwud/vUqVNrDBuIiCgADQ0Nta7r/gjAhYYZ41T117lc7mjDBrsBoO+b/y8A7GnV8DpVPWvdunWLwCMBRERx5mzcuHERgDOsQwCMVtV78/n8YVYBJju8bDZbLyIPIAQ7/618JJfLXWMdQURE1eG67jdE5MPWHVvZ3fO8e3K53HiLFw98AJg2bVpaRG7DVosqhIWqfjqXy51u3UFERP5yXfcMAJ+07tiO/VT1DovT0IEPACtXrmxG76pKYSSquqC+vn6oaw8QEVFITJo06a0Abrbu2Ikj161b94WgXzTQAcB13UmqelmQrzkIo1Op1DesI4iIyB+VSuVbCNcp5+25IpPJTAnyBQMdAERkHoC6IF9zkD7muu4x1hFERDQ0mUzmWFWdYd3RD7WO43wzyBcMbADIZrNHqOr0oF7PB1+0DiAioqFxHOdK64YBeJ/ruu8I6sUCGwBE5PKgXssnJ1nenkFEREPTtzM93rpjgALbVwYyAOTz+b0BnBrEa/lJVZusG4iIaNBmWwcMwgcmTZq0VxAvFMgAoKofBRC5lfZU9SNcIZCIKHoaGhpqAYTpnv/+qunu7g6kO5ABwPO89wbxOlWw1/r164+wjiAiooHp7Ox8J4DR1h2DISKB7DOrPgBMnTq1RkSifEV91M4fERElnuM4x1k3DMG7gzj6XPUBYO3atQ0ARlX7dapFVf/DuoGIiAZGVY+0bhiC3V555ZUDqv0iVR8AUqlUoAsbVMFk6wAiIhoYEeG+ZxeqPgB4nper9mtUWWbatGlp6wgiIuqfvsPnE6w7hkJE8tV+jaoPAI7jhH35xV1JlcvlyJ7CICJKms7Ozt0R/ce7V33fWfUfkKpGfufpOM7u1g1ERNQ/W7Zsifx+B8Bu1X6Bqg8AIpKq9mtUm+d5I6wb3sSRinXCkDnpyL83iHyh0VsnZRs91gFbU9Xh1g1DJSJVP/UcxBGArmq/RrWJSK11w5vE4OcKqYTv50pkQRD1z8IW64CtiUgUHjq3K1X/mQZxjiTyO6pQDgAx+Lmi2wvjz5UoeFHfYYmEbXsU7Z8ngvnyzAGgH0I6AIRq4h6UdPQ/pES+UI32Z0E1VNujkG6zByoWRwBC9cYYpBB+OEM3cQ+cF/GNHpF/or7DCtv2KA7blugfARCR7mq/RrVVKiE8V61e2D5wA6fYwzqBKCSifrt0qL7oxeEIAE8BhEQo30xODI4AwBlrXUBk7vqloxD9b6xh2x5F/ecJxOEUgIbs3NAghfDNJJ3WBUMmwgGAaLdhY6wTfLDROmBrnhf9C4wdx+ERgDAI5REA1bXWCUMmupd1ApG5nlT0PwciL1snbCOEX9oGLPpHABCyc0ODISIhXFUqBgOASvQ3fERDJV70j4R5+op1wtZEZKR1gw+ifwQgDgsBqWr4PqDqRH8AgI63LiAyp6i3Thgy0VAdARCJ/peLuFwEuDmA16gqCeO5avWiPwDEYcNHNFSOE4PPQbi+kKhqHK6rqPq+M4inAYbq0NBghPIIgFcJ1QduUAQZ6wSiEMhYBwxZyK5JisMRAM+r/pe8qg8AQfwhAhC+AWCPYXH4uY7G/ALXAqCky1gHDF24BoBQfmkboFQqFf0BIIg/RADC92aaMX4TRF6zzhiyYSnXOoHIlGrOOmHo5J/WBdsI3zZ7gHp6eqI/AGzevJkDQLWorrBOGDLPO8g6gcjMzSvHAHiLdcaQCTqsE7YRzm32ANTU1FT99HnVB4BVq1ZtArCp2q9TZWF9M5WtA4bOOdi6gMiM0xP9979oDzrKq6wzthHWbXZ/vdbe3h6LdQAAIOpHAUYjuJ/VAGjZumDoNPobQKJBi8H7X2UVmo/rsc7YSgqI/HNGAtlncgDon1Q2m93bOuJNRMJ22G0wor8BJBoskTicAitbB2ytvr5+H4TyC1v/qQazsBIHgP4L3726XujOuw3GW9Fa2s86gsiEyFTrBB+UrQO2VlNTk7FuGCoJaGnlQAYAEYnDAJCxDtiOsnWALxx5p3UCUeAWrxwO1bdZZ/ggVF9EPM/LWDf4ID6nADRki0QMhhPK1bp6itYFvvDAAYCS57WeIwDUWGcMmaJknbCNjHWAD+IzAMThCICqZqwb3mT2xH8C+Id1xtB5R1kXEAVO5GjrBF+ot9Q6YRsh/LI2MLG6BkBVXwzidaospG8qfda6YOhkKuYtj8PjO4n6T2Jx5MtDz/C/WkdsTUQy1g1D5TjO3wN5nSBeBPE4V52xDtg+ec66wAfDMKomHt+GiPpj/h9roPpu6wwfFDB3/43WEVsL5dHaAapUKuUgXieQAcBxnHKbcJtIAAAgAElEQVQQr1NlGeuA7VKNwwAAQKdbFxAFpmbsUQB2t87wQdiOQAqACdYRQyUi5SBeJ5ABYMOGDaG6SnSQRk6aNCmET5iSsH0AB0fAAYCSw4nJ+10Rqi8g9fX1+wEYbt0xRNrd3R3IMu+BDABr1qzpBBC2h0UMWKVSmWTd8Cbp4c8B8KwzfHAIbilHf010ov7QmAwAEq4jkCISvm30wK3uW0K/6oJcLakc4GtVS/hWrZu5XydE4nA7oKAH77WOIKq63kH3UOsMf4TrCKTEYGVF1eCWeA9yAIjDaYCwvrmetA7wheqZ1glEVdftnYGIL1XbZx06MsusI7YmIuH7kjZAQZ3/BwJ8Ewb5h6qicL65FE9YJ/hCcELf41GJ4kvkLOsEf+jjaJawnX4M65e0gQjsy3JgA4DneZE/AqAa0id3OTEZAIAapHo+YB1BVDU3FfcFEI9bXsUJ23ZHADRYR/ggfgNATI4AjBk/fvz+1hFvMrz+GYi8Zp3hD54GoBhLO2eg93G10eeF64uH67rjAexp3TFUPAUQYqlUKnxHAWZIBaq/t87whWA67wag+NKZ1gW+EO3Bps6wbXPicPg/sEWAgAAHgE2bNhURg9vVQnuRicjj1gm+UEmjoudaZxD5rq2jAcCR1hm+UPkLLm4I1VHHONwBAKCCAO+YC2wAePHFFzcCiMPtauEcAFQfs07wjWI2VMU6g8hXWpltneCf8H3hCO01WgOzvFwubw7qxYK+FSVUi0YMhogcbt2wXanhvwGwxTrDJ5PRUozHhVJEALB4aS0gMTqy5f3KumA73mEdMFQiwa6rEOgAoBqHJ9fhgHHjxoXvVrWZ+3UC+lvrDN84cqF1ApFvXhtxOoC9rTN80oWNm5ZYR2xtypQpYwFEfhVADfjZLjwCMHBSV1cXzvN4Ig9YJ/hHZuCm5eOsK4h8IfikdYKPHg/b+f8tW7Ychd7bACMt1kcAPM+LwxEAeJ4Xzud4V/R+6wQf1aAmfZF1BNGQLSgcg7hc/NcrdNsZEQnnNnmAYn0EIJvNLgcQ2AUO1SIiR1k3bNfs7DMAXrLO8I3iQixaPdI6g2hIHCdO3/4BR0I3AKhqHAaATcViMdAL5QMdAB555JEeAC8E+ZpVcgTCuJiHiAKI0WkAjEZl8yzrCKJBa1uRA3CadYaP1mBm/dPWEVubNm1aOrQXZw/MUvTeBhiYwB9IEfQ5jirZLZvNhvOeU8V91gn+0ssxb3mddQXR4FT+H8L4ZWGwFPf3fdEIjRUrVhwKYJR1hw8Cv0bO4olUcbgQMLynATZtvAdAIM+SDsgEjErH6P5pSoy2FTkgZotaid5pnbCt0G6LByjo8/+AzQAQhyMAABDON13v1bmhO0c3JILP8SgARY5WvgiVtHWGjzYAErr7/2Ny/j8ZA0BXV9dfgn7NKjkBob3tRO6wLvDZeOxec551BFG/3dyeh+jZ1hn+0p+jKRu2i7gdAO+xjvBJ4PvGwAeAlStXvghgRdCvWwX7ZbPZQ6wjtsvbfDdicLfFG6heifmFPawziPol5XwtZt/+AQ3fFwvXdQ9DDBZYUtViuVxeHfTrWpwCAIDQrSM9GI7jTLdu2K45UzZAY3U3AADsg1rnCusIol1qKR8FyIesM3y2AaPSodumqOpJ1g1+EKOHuZkMACISqudID5aqhnMAAABo6KZ1H3yq77YqonBqVgcO/hehPT04aHdjxvjQXVwsIiHeBg+IyT7RZABQ1VgcAQBwTENDQzhvP6mt/BxAp3WGz2qhlautI4h2aEL5XKjG4Z70bejt1gXbmjx58m4AYnEBoOM4yRkARo8e/RcAGy1e22e1mzZtOtY6YrvOmfgqFD+2zqiCD6OlcIJ1BNGbzC/sAcFXrTOqYDW6XvmldcS2KpXK8QBqrDt80Dlu3DiTu+NMBoCnnnqqG8AfLV7bb6E+DeDoAuuEqnBS38filcOtM4jeoDb1dQD7W2dUQRvmHt5tHbEtz/PCu+0dmCf7VskNnNVFgEBMLgQM9TmoRvfXiMfSy2+kmkdn9xesM4j+pbX4LkDjeqvqQuuAHYjFBYCqanZNnNkAYPmH9tkk13XD/BzqNuuAqhB8Fq2lQ60ziLB4aS0gNyB+F/4BwG/QlA3dl4j6+voDAMTigmDLi+LNBoCamprHAYRqTenBUtUzrRt2qEfbAITu8N2QqaShaOnd+BIZem3EVwAcaJ1RJS3WAduTSqXOsm7wiXZ1dT1p9eJmA8CyZcteBtBu9fo+C+8AcL67BsC91hlVIXg7Okd82TqDEqyldCwEl1lnVMkGpIaH9XbiuAwAz69ateoVqxe3vAYAAB4zfn1fiMjbc7lc3rpjx/R664Iq+ixaS9OsIyiBeq/6Xwj77Wi1tGDmfqG7lTibzU4GEM6nsQ6Q1QJAr7N+44buwRKDFerTAI3ZBxGfhzBtywHQxmWCKXB1zvcB1FtnVEkFkvqOdcT2OI4Tl2//8DzPdHVF0wEgnU4/AMCzbPBReAcAEQXkOuuMKqpHjbMIqnG8CIvCqKU0F4qPWmdU0c/QOKFgHbE9qhqXAaDS3d39kGWA6QDQdx3AnywbfDQ1n8+H96rUDd23AQj8YROBEXwAbeXPWmdQArSWDoXg29YZVeV5ofzz9d1xFc6HsA2QiPzB8vw/YH8KACISm2fXq+oZ1g07dMnELQBusM6osq+irRiLe4MppG5eOQbAXQDivBDVU5iT+611xPbE6Ns/VNV832c+AHieZ/5D8Evo35ypyvcRt8cEv5EDlVvQ0j7eOoRiaLGmkOr5IYCsdUpVKb5pnbAjIhLeU60DJCLmT1c0HwDq6+ufAPB/1h0+OTybzYb38NTM/D8AucU6o8r2gaR+gQUv7GYdQjGzseM6xGT1uZ3oQPfaO60jtsd13YMBxGXxr/Xjx4//vXWE+QDQtwbyEusOv4jILOuGnap4VwPoss6oskPg1N2B5iVp6xCKiZbSJ6H6n9YZ1adXh3HdfwBQjdVSyw9arf+/NfMBoE+cTgPMyufzddYdO3Se2wFIWNf29tN01NfH/ZoHCkJb+f0QfN06IwAdGLkplNuGhoaGWhH5mHWHX8Jw/h8IyQDgeV7oHjU5WCIy1vO8U6w7dioZRwEAyBy0lj9vXUER1lI+CqqLAaSsU6pO9b8xoyGU24XNmzefDmAv6w6/hOH8PxCSAaBcLpcBLLfu8NEc64CdOs/tANBqnREMvRpt5U9bV1AELSweAtG7AYywTglAB0ZtWmQdsSOqOtu6wS8i8nyxWFxh3QGEZADoE6f16k/K5/PjrCN2SitXA9hinREI1a+jrXSBdQZFyMLCJHjyAIAx1inBkKvC+u3fdd0JAE6w7vCLqt5n3fC6MA0AobzydJBSqtpoHbFTs/MrIeF80lcVCBTfQ2vpI9YhFAEtHS4852EA+1qnBKSIrpfDfHdQI8K1rxoSz/NC84Cl0PxQi8Xi4wD+bt3hl75DVqH5+W6XU2kG8Kp1RkBSAG5FS6nJOoRCbEFxMhx9FMBbrVOCo1eE9cp/AAJgpnWEj1aVy+XfWUe8Lkw7KE9V77KO8FE2l8tNt47Yqd51Aa6xzghQCoIFaCtdYh1CIdTW0QBHlkA13Kfv/KR4Ao3Z0B59dV33/QDCu8T6wN0BQK0jXhemAQCI12kAqOonrRt2Tb8FoGxdESCB4jq0Fj9jHUIh0lp4B9R7FMBbrFMCpEjpf/U+LCy0IrAN7T8RCdU+LlQDQKlU+q2IvGjd4aMTs9ns26wjdqopuxnA56wzAiaAXIuW0jV8giD13uefehjAWOuUQInchlmu+Wp0O5LL5Q4CcJx1h4/+XigUnrSO2FqoBgD0ngb4iXWEn0Qk/IebGzM/AvQx64zACT6LtvKdmP9iEm7zou1pLZ4PeD+F6ijrlIBtglP5f9YRO6Oqn0bvNQBxcScAzzpia2EbAOA4TqgOkfjg7Ewms591xE6JKFQ+jRCdmwrQh1C75WHcVEzKFd8EAKqC1lIzIDdCJYlLRl+LmblQ3Iu+Pblcbh8AcbtrJ3T7ttANAO3t7b8G8JJ1h4/qHMeZax2xS7Ozv0NiFgd6kyORlsexoBju0zXkj/mFPdBW/hmAL1mnGCmiq+5a64id8TzvPwEMs+7w0eq+O91CJXQDAHoPkfzUOsJnF2UymfC/mSvpzwBYY51hxIUjT6KtHO5VHGloFpUPQI3zBIBTrVPMiFyCuftvtM7YkXw+XycisVq4S1XvQMgO/wPhHABCd6WkD/ZxHCf8D7I4b/wrgHzKOsPQMKjejNbyIixeOdw6hnzWVj4bFf0DBAdYp9jR29CYuce6YmdUdRbitwhTKPdpoRwACoXCowBWWXf4SUQuQxQeKNKU+QGA2DycaXD0XHT2PILWwkTrEvLBotUj0VKaD9VbAYy0zjH0ClJe2Af8lKqGvXGgVpRKpd9aR2xPKAcAABURCe2DKQZDVQ9wXXeGdUe/VPRCiLxmnWHsCMD5C1pLl1qH0BAsKByOyqanIIjVIeVBUVzWu/hXeGWz2Y8BmGzd4bM2hPDwPxDeAQA9PT03I35XpX8ZUTgKcJ7bAc/7snVGCAwHcB1aS/fhlnKSFoiJvmZ10Fq6FI7zGOK3QxmMR9GUabOO2IWUiIT61sRBUMdxQvtlNrQDQEdHR0lVH7Xu8NlE13U/bB3RLys6roPiCeuMkDgZPfo0Wsvhv46DgAXFt6G+/ASA6wDUWueYE3kNkpoT8hX/kMvlzkb8hrWH2tvbC9YROxLaAaDPAuuAKmieNm1a+O87bj6uB2k5G8l5WNCu7APobWgtLcHCwiTrGNqOxSuHo7XUDEd+D+AI65zQUFyKxgmh3Qn1Sanq560jqiDUT1wN9QDQ3d39YwDrrTt8NrGjoyMaC1zMzJQAidVa3D6YBs/5M1pLl2Pe8jrrGOrTVn4/OnuWovfefn7r/7e70JQJ9U4IAHK53LmI37f/9V1dXaG+pT3UA8CqVas2AbjdusNvInJlJI4CAEBTpgWKxdYZITMCwNewW3oZ2ooz+TwBQ62lKWgt/gKqvwCQtc4JmX8gVfm4dUQ/pFQ1ds8jEZFb+/ZhoRXqAaBPHE8DTOzo6PiodUS/dXddjHitzuiXCVBZiLbyI2jrmGodkyiL2vdBa+kGAM8B8n7rnBBSKGaG/ap/AHBddyaA2J1WE5HQH3mJxDcX13WfBhCrZVpVtZhKpQ5sb2/fYt3SL62lkwHci4i8ZwwogJ/A0S9jlvuMdUxszf/bXqitvQwiFyfwAT79p5iH2dnQ38KayWSGOY7zPICMdYufVPXPpVLpMOuOXYnCEYBITFIDJSKuqob/SYGva8r+EsA11hkhJgA+BE+eRlv5brSUQ//hj5SFq8aitdSM2tp2AJdz579TT2NU+grriP5wHOeTiNnOv08kjlxH4tvclClTxnZ1da1CvB4OAQD/5zjOxPb29n9ah/TLYk2hs3Q/IO+xTokADyL3wsO3MTvzsHVMZLWtyEG9SyFo4k6/X9aiolNxntthHbIr2Wx2XxFZBmB36xafberp6XnrihUr1lmH7EokjgC88MILa0XkVuuOKtjD87xm64h+myEVVGpmAChbp0SAA9VTIPoQWktPo610AVpLcRtgq6etYypay4uAnhcA/QR3/v3iATgnCjt/AHAc5yuI384fABZFYecPROQIAADk8/kGz/OeRYSa+6kiIocWCoXnrEP6bWHxCHjyawC8DW5g1kFxB1S/hznuX6xjQqe1tCcEM+DhQgjebp0TOSJfQGPmauuM/sjn8wd6nvcXANG4G6r/tFKpNHR0dDxvHdIfkdqZuq57P4CTrDuq4L5isfg+64gBaSl9HILvWWdEluIJQFtQl/oxzq6PxLeFqpj/xxrU7nUigEZAPwAOlYMj8guU609Ds4RyzfltxXhbfm+xWIzMXSmRGgByudzJqnqfdUc1iMh7C4VCtJ7C11pqAzDLOiPiugE8BMgdcNI/w6xxa62Dqm7x0lp0jjwB0LMAnAZgtHVSpIm0o0aOiMogmc1mTxWRn1t3VMmJxWLxQeuI/orUAABAXNd9DsCB1iFVsHTChAmHPvLIIz3WIf02b3kddkvfD+BY65RYEO2B4lEA98PDA5idfSbs67f324IV+0Mq0yGYDmA6gD2tk2JiLRzvKMzKLbMO6Y+pU6fWrFu37hkAU6xbquDZYrH4NkToIXZRGwCQzWbPF5EbrTuqQVUvK5VK37TuGJCbV45BqudxxG8ZzzB4CcADUDwKwRNozPwtMgPBTcV9kZZ3AvouQE4EcLB1UgxtgehJaHR/bR3SX67rXgHgf6w7qkFEmgqFQpt1x0BEbgDI5/N1nud1ANjXuqUKNqbT6YOXLVtWtA4ZkLYVOWjlCQB7W6fE3FqIPAHgSaj3DFLOczi3vmw+FCxcNRboOQSedxDgvAPQowDkTJviTyFyLhozt1mH9Fcmk8k4jvMcgJHWLVXwD8/z6svl8mbrkIGI3AAAAK7rfhnAldYd1aCqvyyVSu+17hiwlvJREH0I8VurIew2AFgKwfNQdEC0BKCMHnRg900vYUZD15BfQVVwc2kfpHUCIBn0LtxSD8gkAAcBeMuQX4MGSK9Ek/sV64qBcF33AQAnWndUg4hcWSgUIvX7ACI6AORyuX1UtQMx3dmIyEcLhUL0HoLUVpwBldsR0fdVTG1A75GDl6G6FpC+xztrJxT/Hg5EBK+flxcMh+oYAGMhMhaqY8HfaZi0oTEz2/zIzwBks9lzRWSRdUeVbFbVTKlUWmMdMlCR/VC7rtsKoNG6o0rW9PT0HBCVxSTeoK10CRT/a51BFE96D7peOR1zD++2LumvvpVcn0dMTxGKyE2FQuEC647BiMRKgDvwVQAV64gq2bempuZa64hBaczOg8gXrDOIYkexBCNrzorSzh8Aurq6voGY7vwBVFT1G9YRgxXZAaBYLC4H8CPrjmpR1Tm5XO54645BacxcDYnnlb5ERn4H3XIaZowP9fPlt5XJZI5FvNcKuaVYLEbiFsztiewAAACqehXiexRAVPV748aNG24dMiiN2c9DNVq3NBKF0zOopN+HOVM2WIcMxP777z/CcZybEOFTzbvQ4zjOf1tHDEWkB4BSqfQ3AD+07qiiyXV1ddE8FQAATdnPAHKTdQZRhC0HMB3njX/FOmSghg0b9k0AE607qmhRe3t7wTpiKCI9AACAiHwZQHRWzxsgVb3Ydd3IrC39BiKKkfUfRzyf5EhUbX+Dkz4OTdnV1iEDlcvlTgYw17qjirrT6XQkHry0M5EfAAqFQruIxPkogABoyWaz0Vz4aIZUMKt+JhTzrFOIIuSv8FLHY9b4v1uHDFQ+n99bVVsR30P/ALAocgu2bUfkB4A+VyHGRwEA7ANgvnXEoIkomjL/BZHIXi1LFBiRP8KpeTfmTHjROmUwPM9bAGA/644q6k6n01+1jvBDLAaAQqHQrqqRWRJzMETktGw2O8e6Y9BEFI2ZzwC4wjqFKMR+jXT3e6L6VEjXdS8EcKp1RzWJSFscvv0DMTpEk8/nc57nvQAgbd1SRZ0ADovybScAgLbyxVD9DmL0/iPywb0YmT4zarf6va5vG/w0gFHWLVXUXalUJnd0dJSsQ/wQiyMAANB3NeYt1h1VNlJV26ZNmxbtIacxcz1EzgcQqQVNiKpG5FaM3Hh6VHf+U6dOrfE874eI984fqtoal50/EKMBAABU9csAIvU0poESkXeuXLnya9YdQ9aYWQBx3gtgvXUKkSnFPMyqn+nLg5uMrFu37usA3mHdUWUbU6lU5B74szOxGgBKpVKHiHzLuqPaVPVT2Wz2LOuOIWusfwjiHAOgwzqFyEAXRGdhdvbSKD3YZ1u5XO7DAC617gjAte3t7ausI/wUu3OwDQ0NozZt2rQM8X9E6WuO4xzZ3t7+V+uQIWst7Qfg54j/Nwii162DI2dgVmaJdchQZLPZySLyewC7W7dU2d87Ozsnr1mzptM6xE+xOgIAAEuXLn1NVb9o3RGAUZ7n3ZXP56P/wetd6OTdiPGzHYi2UkJKjo76zr+hoWGUiNyF+O/8oaqfi9vOH4jhAAAApVKpFcBT1h0BmOx53kLE4UhOU3YzOjIfA+QrADzrHKIqeQBdXUdgZuZ565Ahks2bN7cAONA6pNpU9c+lUimWt5nHcgAA4DmOc5l1REA+6LpuPM6/NYuHpsyVgJwKIHJrnxPthAK4BiMz78PcyS9bxwxVNpv9tKpG/zqk/rkUMf1SEv1vjjuRzWZ/KiKnWXcEoFtV31MqlX5jHeKbRYUJqDh3gtcFUPS9CkgTmjJ3WYf4IZPJHOs4zoOI95orr7uzWCzGdtCJ6xEAAEAqlfo0gC3WHQGoEZG7crlc3jrENzNzKwC8GyI3W6cQDcFfIKnD4rLzr6+vzzqOsxjJ2Pl3icjnrCOqKdYDQN/iQN+z7gjIXqp694QJE0Zbh/imKbsZjZnzAb0AwEbrHKKB0QUYmX4nGidE+pGxrxs3btyYVCp1H3qfTZIE3y4UCu3WEdUU61MAADBhwoTRqVRquYiMtW4JyJLhw4efvHTp0sguKrJdLR0upLIIkKOtU4h2YT0UF2F2NjZPKc3n83Wqer+qHmvdEpB/OI4zsb29/VXrkGqK9REAAFixYsU6AJdbdwTouE2bNrUhbsPd7PoiOjqmofdhQlxCmMLqV3DSB8Vp5w9AKpXKjQna+UNVL4v7zh+I205ix8R13V8BeI91SFBE5MpCoRCrZSv/paV0JBy5FarxueaBom4zgGZ0ZL6OZonVFeOu6zYD+JJ1R1BU9ZFSqXQ8eu/ciLWkDABwXXcigGcADLNuCYiq6qxSqRTPByQteGE3OLXfBmQ2EvQ+plD6A9RpxOz66K/KuY1cLvcRVf0BkvMZ2yQih8T93P/rkvJLBQDkcrkvqGo8vxVv3xZVPalUKv3aOqRqWovvgsp8CA6wTqHE2QjgKozMfAMzpGId47d8Pj/N87z7AdRatwToc8ViMfoPW+un2F8DsLVhw4ZdC2CpdUeA6kTkbtd1D7cOqZom9zfoXvs29F4bkIRbPikU9B5U9EA0Za+J484/k8kc6nneT5Csnf+zo0eP/qZ1RJASdQQAADKZzJGO4zyOZA0/LzuOM629vT3ew09rYSLUmQ/BcdYpFFurIXo5Gt1F1iHVksvlDvI875EE3TkF9K4ee0x7e/sT1iFBStJOEABQLpd/B2C+dUfA9vI87+FsNjvZOqSqmnLLsSJzAgRzAfzDOodipRuKeejypsR8559X1QcStvOHql6ftJ0/kMAjAACQz+d39zzvrwDeat0SsJWe5727XC6XrUOq7vqlozBixGXovQU0KRd+UjWIPIienk/ivPxz1inVlM/nx3me9xsAGeuWgL0E4IBisfh/1iFBS+QAAACu654B4E7rDgPtlUrl3R0dHS9ZhwSipX08JH01oOcgwe93GgTF8xC5DE2Ze61Tqi2Xy+2jqo8CmGLdEjQROb1QKPzUusNCojeIruveBeB06w4Dz3Z1dU1btWpVcp64t6BwDBznW+DDhWjX1kBwJUZkFsTxAr9tjRs3bkxtbe0jAA42TrEQ64f97EqiB4B8Pr+353nPANjPusXAU7W1tdNfeOGFtdYhgWopnABxvgZgqnUKhYzIy1C9HjU938I5E2O/ChwATJkyZWxXV9f9SODnQUReTKVSb1u2bFnkH888WIkeAAAgm82eJCK/RAJ/FiLyfFdX1wkrV6580bolUKqCttIpgHwJCdzw0ZusBfDdJO34ASCbze4rIg8AOMS6xYACOKVYLMb+9M7OJG6ntz2u634XwMXWHUZK6XT6hGXLlhWtQwL370GgGcBh1jkUuN4df5f3bczNJeoCMNd1JwB4EMBE6xYj1xWLxU9aR1jjAAAgk8kMcxznDwAOsm4xsgLAicVicZl1iAlVwcLSqVD5JIBp1jlUdUUA87Bx4wJc3PCadUzQ6uvrs47jPCgirnWLkb92dXUdvmrVqk3WIdY4APTJ5/Nv9zzvSSRr5autrVHV6aVS6S/WIaZaS4dC8XEIZoK3D8bNUxCdh3LHD9B8XI91jIV8Pn+gqv5KVfe3bjGyRVWPTPx2rg8HgK24rnsFgP+x7jC0zvO895XL5SetQ8zdVNwXafk4RC6G6l7WOTRoHkTuhYf/wezM49YxlnK53FRV/SWAxL6fVfWyUqmUqOV+d4YDwBs5uVzu4SQ993o7XhWRDxYKhSXWIaEwb3kddkt9AOJcANX3gJ+ZqFgO4AeoaCvOczusY6zlcrnjVfWnAHazbjH0cLFYPBFArB7XPBTcmG2jbzWsZwCMtm4x1CUi5xcKhdgueTooLe3jIamPAbgQyVstLQo2A3I3tHIjmtyHIBL757n3Ry6Xa1TV+Uju6U0AWA/gbcVicYV1SJhwANgO13U/BuA26w5jCuArxWKxue/v6XWLNYVNHSfB01kATgEw0jopwTwAv4XgNqR7bk/SbXz9INls9ioR+YJ1iDVVnVEqle6w7ggbDgA74LruDQDmWndYE5E7tmzZMotXzO5Aa2kYoCcCzlmAngZgd+ukBPAAfQKQO+Cl7sCcCclax6If8vl8ned5NwM4x7rFmoh8t1AofMK6I4w4AOzA1KlTa9atW/cIgKOsW6yp6hOpVOq09vb2f1q3hNrilcPR2TMd0DMBeT+APa2TYkO0Byq/huJOVPQunO+usU4Kq3Hjxo2pq6u7K+HXMgEAROTJYcOGHbt06dIu65Yw4gCwE7lcbryqPgVgb+uWECio6vtLpdLfrEMiYbGmsHHFoVDvBIicgN6NcY11VsQUoXgQog8C8is0ZddbB4VdPp/PeZ53D4B4P/q7f/7hOM7U9vb2VdYhYcUBYBey2eyJInIfgJR1Swi8LCIzeIfAINy8cgzS3SdAZTqAYwHkrJNCaC0Uj0HkflR6HsB5+XbroPhz8B4AABPoSURBVCjJ5XLHe563WETGWreEQI+InMRt1c5xAOiHbDb7eRG52rojJCoA/rtYLF4F3k4zeDcV90UaRwAyFSJHQ/VoAMOtswJWBOQxQJ+COL9FecKf0Sx8Tw2cuK57CYCvg0eZAAAi8tlCofB1646w4wDQP+K67p0APmQdEiJ3e543s1wu87CsHxYvrUXniMMAOQzQgyFyEFQPQjyuI+gC8DygzwHyLIC/AHiSh/SHbvLkybt1d3e3ADjTuiUsVPVnpVLpdPDupV3iANBPfR+03wOYYt0SIssBnFEsFp+1DomtlvbxSKUPgurBUJ0EIANx6qE6AeG6r1sBvASg3PuXFCDec/BSz2FFcVlSl96tpkwmMyWVSt2lqgdYt4TIcgDvKBaLiXq402BxABgA13UPBvAEeN/31jYBuLhYLLZahyRKszp4a/v+cJwMRDIQeStE9gJ0LDyMhSNj4OlYCMYCGIvBX8OyHiIvQ3UtFK/AkbVQXQvoWgCrAZThaAf+z+vAJRO3+PXHo53rW6vkRnBbtLVOx3GObG9vX2odEhUcAAbIdd2zAdxq3RE2qvqdMWPGfPqpp57qtm6hHVi8cji6vd4HHHV5e0Ad5w3/vnvzqxg1rALtqnBBnXBqaGio3bRp07eQ3MeX74gCOLtYLP7QOiRKOAAMQi6Xu1pVP2/dEUJ/VNVzeKsgkf8ymcwUx3FuBTDVuiWErioWi1+yjoga3to2COvWrVsyevToHIBDrFtCZn8RmTN69OjX1q1b93vrGKKYkFwud4GI/BhAvXVM2Kjqj0qlElf6GwQeARikvkNxvwRwnHVLSD3Q3d3dtHLlSi7TSjRIuVxuH1W9GcCp1i0h9RvHcU5sb2/n9SeDwAFgCKZMmTK2q6vrcQCTrFtC6p+O45zf3t7+M+sQoqjJ5XInq2oLgLdYt4RUwXGcd3KJ8sHjADBEkyZNcnt6ep4ElwveIRG5ZdiwYRctXbr0NesWorAbN27c8Jqamq+JyCXWLWGlqmtF5J3FYnG5dUuUcQDwgeu6xwB4EECddUuIFQBcWCwWH7QOIQqrbDZ7IoAbRMS1bgmxzSLynkKh8Lh1SNRxAPBJNpudISK3gz/TnRKRO0TkYh62I/q3cePGjampqfkfETkf3IbsjAI4t1gs3mYdEge8C8An69evXzpmzJgKgOOtW0KuQVXPGzNmzLp169b9yTqGyFo2mz0rnU7/UkTeBe78d+XzxWLx+9YRccE3m89yudyNqnq+dUdEPCQiFxYKBT71jRLHdd1JAG4A7yTqrxuKxeLHrSPihEcAfLZu3bp7R48ePRHAwdYtEeACOH/PPffUXC735EsvvcQnwVHsNTQ01O6+++6fA/ADABOteyLitmKxeD74gB9fcQDwn65bt+6nY8aMOQBAg3VMBNSIyHs2b978kT333HP1+vXr/2odRFQtruue0NPT81MAHwaQtu6JiJ9OmDDh7HK5XLEOiRueAqiSvoWCfgLgfdYtEfOw53mfLpfLT1uHEPkln88fWKlUvikiJ1u3RMyDjuOcwoV+qoMDQBWNGzdueF1d3X2qeqx1S8R4InJbpVL5bLlcXm0dQzRYkyZN2qu7u/uLInIxeMR1oB7v7Ow8ac2aNZ3WIXHFAaDK8v+/vbsPjqO+7zj++e5KJ9kGG8tQHiLpbvc2trFJKXhwwFAqEgc61E5pgdRQcIszJSXtpE3DQMqkdJgkTXiYpHSgDcQxaQgGYqDloUATUUwmpg0pDwZELHO7eyerxoFaEg8Bobv7ffuHBJQg27J8ut/u3ec147mxx6N7z9h3+73f7f42COYaY3oBnGC7JYV+CeC6sbGxqwcHB9+yHUM0VZ2dnbMymcznAFwBYK7tnhR6orW1dWV/f//rtkMaGQeAOujs7OzIZDKPgjcPmq4SgKu6u7tv3bx5c8V2DNGeLFu2rHVoaGitiFwJoNt2T0o9OzY2dtrg4OCQ7ZBGxwGgToIgOExVH1PVo223pFhRRL7W1dW1gYMAJYzjed7ZIvJV8Mz+A/GiMeZUfvVXHxwA6igIgk5jzI8BeLZbUq4gIl/u6urayEGAbOrp6WnZsWPHBar6JQB52z0pFzuOc2qhUBi0HdIsOADUWTabPdJ13V4AS2y3NACuCJAt73zi/wp4N9Ba2C4iK8Mw3GE7pJlwALAgl8sd4ThOL7hPQK1sV9XryuXy93myIM2kiSt71qrqpQAC2z0N4nljzCe47F9/HAAs6e7unt/S0vIwgOW2WxrIKwA2OI5zA5cRqZY8zztcRC4B8GcADrXd0yhU9enW1tbTt2/f/r+2W5oRBwCLfN+fB+BBACtstzSYMRG51xhzXRzHT9iOofTyPO9YAJ8VkQsBzLLd02B+NjY29ts8298eDgCWLVq06OBKpXI/NwuaMY8A+GYURQ8B4L0GaCoc3/fPBPB58O6eM0JVN8+ePXt1X1/fG7ZbmhkHgAQ46qijZs+aNeseVT3DdksDGwRwW7VavalUKsW2Yyh5Fi5c+KFKpXKBql4sIr7tnkalqg+Xy+Xf5/k69nEASIggCNqMMXcAOMt2S4MzIvIjY8wG13Xv5R7jzS0IgjZVPUtV1wFYCcCx3dTg7nEc53y+7pKBA0CyuL7vX4/xE41o5o2o6g9c1/1WoVB42nYM1U8QBEuMMWsBrANwmO2eZiAi67u6ui7hJbvJwQEggXzfvxzA18B/n7pR1adF5AciclcYhgXbPVR7vu9/GMA5AD4F4Dcs5zQTFZHLwzC81nYIvR8PMAnled45InIrgHbbLU3oBQCbjDF3FIvFbbZjaPqy2aznuu4nAZwL4GTbPU1oDMBFURRttB1CH8QBIMHy+fxpqnoPgENstzSxrSJylzFmUxzH/bZjaN9yudxi13XPVdVzwBtw2TRijDmrWCw+ZjuEJscBIOGCIFhqjHkQvLOYdaoaAegF0CsiP4yi6FXbTTR+FU17e/sKjJ/EtxrcZjsJ/kdVfyeO4622Q2jPOACkQDabPdJxnH8TkeNst9C7qgCewfhA8EAURY+D+wzUzcRgvArjB/3fBNBmOYne85zjOGdyN87k4wCQEkEQzDXG3AZgle0WmtTLAB5R1cdd193S2dn5HM92ro2enp6WwcHBX69WqytE5GQAHwfP3E8kEbmvpaXlgv7+/tdtt9C+cQBIF/F9/zIAfwder5x0vwTwjKo+CeAnra2tj3K/86mZGHaXAzgFwLKJR54Hk2wK4Jooiq4AV8JSgwNACvm+fzaA7wI4yHIKTZ0C6BeRnwF4HsBzAJ5v9tuf5vP5LgDHAPgIgGNU9QQAi8D3pjR5XUT+KAzDf7EdQvuHL7KUyufzx6jqvwLI226hAzKC8YHgeQDPqmqfqm5vtFuj5nK5I0RkoYi8e7Cf+MVP9ulWcBznrEKh0Gc7hPYfB4AU6+zs7MhkMrcDON12C9XcqIjExpiSiBQBlESkWK1Wi6paKpVKuzC+qpAEks1mj2htbc2palZVcwByqpoVkRyAHLifRcMRkX8vl8vnDQwMDNtuoenhAJB+bj6f/7qqXmo7hOpKAewGMKSqu0Vkt6oOTTzuFpHdAF5V1YqIGADvXLI4KiLv3ITlnT+bBwCqOgvvHajnqaojIi0ADlHVDhFZoKoLRKRj4vHd34PvJc1EAVw78X1/1XYMTR9ftA3C9/3zANwE4GDbLUTUsF4TkYvDMLzTdggdOA4ADSSXy+Ucx7kDwEdttxBRw3kKwJooil60HUK14doOoNoZGRkZWbBgwa3GmLkishwc8IioBlT1Ztd1zwnD8GXbLVQ7PEA0KM/zPikitwDosN1CRKn1qqr+SRzHm2yHUO1xAGhg+Xy+S1U3YnwjFSKi/fFEtVpdUyqVYtshNDO4m1wDC8NwR3d392kArgJ35yKiqVFV/Yf58+efwoN/Y+MKQJPwfX8lgA0Aumy3EFFiDQBYF0XRI7ZDaObxJMAmMTw8HC1YsOA7xpgFInI8OPwR0f8jIpsqlcqqYrH4gu0Wqg8eBJpQLpc7w3Gc9QA6bbcQkXW7VPUzcRzfZzuE6osrAE1oZGQknD9//oaJ3d2W2e4hIjtEZNPY2NiZAwMDz9huofrjCkCT833/TBH5tqoeZbuFiOrmFyJyCe/g19x4FUCTi6LoQdd1j1VVbu1J1Bw2ZjKZpTz4E1cA6F35fP5jqnojgMW2W4io5kIR+fMwDB+2HULJwHMA6F3Dw8PxnDlzNriuWwFwEoAW201EdMDKAK4zxnwqjuNttmMoObgCQJPK5/MBgBtU9QzbLUQ0Paq62Rjz2VKp9HPbLZQ8HABorzzPWy0i/wheMkiUJrtE5PIwDL9nO4SSi18B0F6NjIxsnzdv3i0iMhfA8eCJo0RJVlXVG0Xk7CiKnrAdQ8nGFQCasmw2e7TrutcAWGW7hYg+oFdVL43jeKvtEEoHDgC03ybuK3AdgGNttxA1OxH5uapeFkXRA7ZbKF04ANB0Ofl8/gJV/TqAI23HEDUbEdkJ4KowDL8DoGq7h9KH5wDQdOnw8PDWTCbzrUwm8xqAjwJosx1F1ATeBPANx3HWhGH4OAC1HUTpxBUAqomFCxd+qFKpfBnAWnCwJJoJFQD/XC6Xr9yxY8dO2zGUfhwAqKay2aznOM4XRWQduJEQUS0YEblbVb8URdF22zHUODgA0IzgIEB0wIyI3G2M+Zs4jvttx1Dj4QBAM2rhwoV+uVy+XEQ+DX41QDQVPPBTXXAAoLrIZrNHt7S0/LWqng8OAkSTMSJyd7VavbJYLHLPfppxHACorjzPWwTgr0RkLYB22z1ECfAWgO8B+Aa/46d64gBAVgRBcJgxZp2IfE5Vj7LdQ2TBKwA2VKvV60ul0ku2Y6j5cAAgq4IgaFPVP1DVywEssd1DVAcFADeMjo5+e+fOnW/ajqHmxQGAkkJ83/84gL8A7zVAjWmLql4fx/E94M59lAAcAChxgiA4zhhzMYA/BHCw7R6iA/AagO+r6s28SQ8lDQcASqxcLtcuIqtF5GIAK233EO2HJ0Xk5vb29o19fX1v2I4hmgwHAEqFIAiWVKvVz4jIReCqACXT66p6u+u6NxUKhadsxxDtCwcASpVFixYdXKlUzlfVTwM4wXYPEYAnVHX97Nmzb+enfUoTDgCUWp7nZUVkDYCLACyy3UNNpQjgTlW9hbv1UVpxAKCGEATBUmPMhRi/G+GRtnuo8YjITmPMXSKyKYqiLeBteCnlOABQo3F831+hqueKyPkADrUdRKk2IiL3G2M2ZbPZhzZv3lyxHURUKxwAqGH19PS0DAwMnDgxDPwegC7bTZQKA6r6MIAHXNf9YaFQeNt2ENFM4ABATWPia4JVAFYDWAH+/6f3vADgfgAPcHmfmgXfAKkp+b7fraqrReR3AZwKoM12E9XV2wAeA3CviNwfhuEO20FE9cYBgJpeZ2fnrEwmczKAUwCcDOC3ALTaraIaqwJ4BkCvqm7JZDKb+/v7X7cdRWQTBwCiX7F06dKD3nrrrRMxvvvgSgDHg6+V1FHVCEAvgN5qtdo7MDAwbLuJKEn4pka0D57nHe44To+qnqSqy0XkOADttrvofUYBPIXxTXn+03GczWEYvmw7iijJOAAQ7aeenp6WwcHBRaq6zBhzsoicAuBo8PVUTy+JyE9UdQuAJ40x/10sFkdtRxGlCd+wiGpg8eLFC8rl8nJjzPEAPiIiSzC+O2HGclrajQHoB9Cnqs85jvP022+//dPBwcEh22FEaccBgGiG9PT0tOzcubO7XC4vFZElIrJUVZdhfDBwbfclTFVVSyLyAoC+dx6r1WofP9kTzQwOAER1FgRBW7lc9l3X9VTVcxwnp6oegBwAD0CH3cIZMwQgBlAUkVhVYwDFarUat7a2Rtxwh6i+OAAQJUwQBHOr1aonIn8M4C9t9xygv1fV77quGxcKhddsxxDRe1psBxDR+00cKLf6vv+s7ZYaeDaO4622I4jogxzbAUQ0ORF503bDgVLVN2w3ENHkOAAQJVQjHDwdx+Fue0QJxQGAKKFEZJfthgMlIr+w3UBEk+MAQJRQLS0t25Huu9JpW1vbi7YjiGhyvAqAKMF83y8B6LbdMU3FKIo82xFENDmuABAl249tB0yXqj5mu4GI9owDAFGy/YftgAPwiO0AItozDgBECTY2NnYvgDTukDfW1tb2oO0IItozDgBECTZx05uHbHdMw33btm3bbTuCiPaMAwBR8t1oO2B/icg/2W4gor3jVQBEKeD7/hYAK2x3TIWI/FcYhifZ7iCiveMKAFE6/K3tgClSAFfYjiCifeMAQJQCURT1quqdtjumYGMYho/ajiCifeMAQJQSxpjPA3jZdsde7FLVL9iOIKKp4QBAlBKlUuklEVkDoGq7ZRJGVdfGccy9/4lSwrUdQERTNzw8XDzkkEPeFJHTbbf8ii/EcXyb7QgimjoOAEQpMzIy8nhHR8dBSM5VAVdHUfQV2xFEtH84ABCl0PDw8I/mz58/CmCl5ZSroyj6ouUGIpoGDgBEKTU8PLylo6NjF4BPAGip89OPquqfxnF8bZ2fl4hqhBsBEaVcEATHG2PuAPDhOj1lvzFmTbFYfKZOz0dEM4ArAEQpNzQ09NKcOXPWu65bAXAiZm41YBTAV40xFxSLxcEZeg4iqhOuABA1EM/zsiJyGYB1ANpr9GNHRWQ9gGvCMNxRo59JRJZxACBqQPl8/tdU9TwAFwJYNo0foQCeFJFbReT2QqHwSm0Licg2DgBEDc7zvMNF5GMAlqvqYhHxARwK4KCJv/IGgFdUNRaRbSLyU2PMo9zUh6ix/R9cpXQbr6wXdwAAAABJRU5ErkJggg==",microphone_magic:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAACXBIWXMAAHYcAAB2HAGnwnjqAAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAIABJREFUeJzs3XmYXHWV+P/3udXd2VjDphDSVbcqi0RFDYsCMgluCAIqiizZOoCZGUYcR78yzmac8acz+h1HcPlOhKQ7zWpwAwREgTAKwiBxw0ASuquqk8iiQMDs3V33/P7ogCydpJeqOvfeOq/n8RnT3bn1NtNd9/RdPldwVVUoFA6Jouho4A3AG4EZQBY4xLLLDds2oASsBR4GHhaR33R3dxeByLTMOTc0Vz42iebMKWhwEsLrUJ0CHPaKr9qOSDcarYXgl6B301N+iMWz+y2S60msA5KsUCiMUdVjgBOAk1T1OOA1xlmutrYCvwJ+rqr3NTc3/3zdunVPW0c553ZpLx2A6hxE5gLHjXArz4DeQKQdXJh/qJp5ceIDwPBkstnssUEQvBd4JzATGGPc5OytAf5HRH7U1NR019q1azdbBznXcJY9dgjS9Engr4D9qrjluwnk88zPrqziNmPBB4C9mDx58oHNzc1nqOp7VfVdInKQdZOLtV7gPhG5PYqim0ul0lrrIOdSTVVYXpoLwX+ienDNXkfkh/RHf8NFYU/NXqPOfAAYxOGHHz5+zJgxp4vIPODdQIt1k0usR4AbVfV6Hwacq7LOrkOpZK5m4H26HjYDH6Utd0OdXq+mfAD4s0wulzsNuFBETsUP7bvqWyUiy/v6+q5Zv379JusY5xJtefltRPp9Xn1RXz1cTk/271gsib4guOEHgKlTpx7R398/h4HzRq3WPa4h7BSRm1X1W8Vi8S5ArYOcS5Tl5fcS6XeA8WYNygq29M/j0ik7zRpGqWEHgHw+f4qq/h3wXiCw7nENa42IfHXnzp2dGzdu3G4d41zsLSufguhtxOEorXIz68tnJ/WWwYYaAGbOnNn87LPPvl9EPgkcb93j3Ev8EVjW19d3xYYNGx63jnEulpaV34LoPcC+1il/pt+kLbzEumIkGmIAKBQKYyqVysUichkwybrHuT3YDixramr64rp1635vHeNcbLSXDgBWAaF1yquIzmdB2GmdMVypHgBmzpzZ/Nxzz50XRdFnRSR+3zTO7V6vqnZEUbS4p6fnCesY58y1l24APmKdsRtbqVTexEWFLuuQ4UjrACC5XG4OsNh3/C7htgJfB75YLBaft45xzsSy0nsQfmSdsRc/oS1Xr9sRqyJ1A0AYhscCX2VgeV7n0uJZ4F+LxeLXgYp1jHN1s+ShZsYc/AiqBeuUIfgAbbkfWEcMVWqufp86deoR+Xy+E/hffOfv0mci8NV8Pv9wPp8/1TrGubppPuj8hOz8AT6LamJ+sU7DAJDJ5XKf7O/vX6eqc0nhUQ3nXqCqr1PV28MwvLZQKPgTJl26qQrCp60zhuFNdJTfYx0xVIkeAMIwfEMYhj8Xkf+L5YIQztXf+VEUrc3n8x/Fh16XVu09bwOOss4YHlloXTBUiRwACoXCmHw+//8xcEvISB/36FzSHaiqS8Iw/FE2m81axzhXdYHOsU4YPj1j1y2LsZe4AaC1tfV1lUrlflX9B6DZuse5GHh3EAS/2XU0wLn0UE6zThiBsSCnWEcMRZIGAMnn8x/NZDIPicibrWOci5n9VHVJPp9fMWnSpInWMc6NWsf6PEl9Posw2zphKBIxAOTz+UPDMLxVVZfg5/qd2y1V/XBLS8svwzA8ybrFuVHRyrHWCSOmmoil5mM/ABQKhbeo6oMMPLTHObd3rcDKMAwvsw5xbhSmWweMwjTrgKGI9QCQz+fnRVF0L0k9DOScnSbg38MwvP6www6bYB3j3PAlehXX/Vj2WOxv043lAFAoFMaEYbhUVZcD46x7nEuwcydMmHB/oVDIW4c4NzyaiCvpdyuS/a0T9iZ2A8CkSZMmquodQGLupXQu5t4QRdGDuVzuZOsQ54ZM2cc6YVSam2L0yOLBxWoAmDp1atjS0nKfqv6FdYtzKTNRRH4chuH51iHODUkgyb7Nu6It1gl7E5sBIJvNHt/f338/yb7ww7k4GwNcE4bhYusQ55y9WAwA+Xz+1CAIVgKHWrc4l3ICfDYMw//ClxB2rqGZDwC5XO4MVf0+frGfc/X0t/l8fjmQsQ5xztkwHQDy+fy5IvJdYKxlh3ONSFXnhmF4zcyZM5N9rtU5NyJmA0AYhm2qei2+nr9zls7dtGnTt30IcK7xmAwAuVzuQ8CVVq/vnHuZD2zatOn6WbNmNVmHOOfqp+474EKhcJaIXIefe3QuTs7u6em5Ch/KnWsYdf1hz+Vy74qi6Ab8sL9zsSMi8/P5/OXWHc65+qjbAJDL5Y4TkR/gF/w5F1uq+jf5fP6frTucc7VXlwEgm81mReRm/FG+zsWeqn4un8/Ps+5wztVWzQeAQqGwXxAEtwCH1fq1nHNVIap6VRiG77AOcc7VTk0HgBkzZrRUKpWbgNfX8nWcc1XXDNyYzWZ9aW7nUqqmA8D27dsvF5FZtXwN51zNHBgEwc1hGMb+sabOueGr2QCQy+XmAH9Zq+075+piioh04s8NcC51avJDncvljhaRn+MX/TmXFv9QLBa/aB3hEuLangNHvY3e6DbgraOPMaLRuxjTtGpU23imdxuXTtlZpaJXqfoAMGnSpIktLS2rgGy1t+2cM1MBTi0Wi3dah7gYuarYSkZmA28HjgKmAhNto1KnDygCj4L+Esnczc4/PsiiY/pGu+GqDwD5fP7bqnpOtbfrnDP3hyiKji6Xy09ahzhDV22YSFP/HJR5wEzrnAb1LMK3Ee1gfvjgSDdS1QEgl8tdJCJXVnObzrn4UNUflUql0wC1bnF11tl1KJWmT4H+JbCvdY570T1I8HkWtN413L9YtQGgUCjkoyj6Ff6N4VzaXVIsFr9pHeHqZLEGZEtzUPkKcJB1jtsNkR/SH/0NF4U9Q/4r1XjdmTNnNm/atOk+4NhqbM85F2vbgyA4pqur6xHrEFdjnV2HUslcDbzbOsUNyWaURSzMXT+UL67KbYDPPvvsp/Gdv3ONYlwURR34Ez3TbXn5bVQyD+M7/yTZF+E6lpUuZ7Hudf8+6iMAYRhOBX6DP+THuUbziWKx+FXrCFcD7eXTQG/Eb+VOMLmRzX1z93Qb4WgHgCAMw3sYuAXEDc+zqrpWRNYA60SkrKpPB0GwNYqiLU1NTVt37NixyToyDZqbm/epVCoTMpnMBFU9MAiCCZVKZVIQBNNVdSowDZiML3YzXFuiKHpDuVwuW4e4KlpWPgXR24Ax1ilu1G6ip/whFs/uH+yTTaPZchiGH8V3/kPRLyIPqepKVV3Z3Nz8q3Xr1j1tHdVA9jpITZo0adyYMWOOUtWTgVOAk4H9al6WbPuIyP8D3msd4qpkWfktiP4A3/mnxVm0tl4OXDLYJ0f8G08+nz9UVdcBvk744J4AVgA/aW5u/unatWs3Wwe5oZs1a1ZTuVyeGQTBbODDwFusm+JKVc8plUo3Wne4UVq6Zl+CMQ8xsJiPSxPR+SwIO1/14ZFuL5/Pf0tVLx5dVersAO5U1c6JEyf+YNWqVaNeqcnFQ2tr6+symcxHgHlAzronZjbs2LFj+uOPP77NOsSNQkfpOpTzrDNcDYhsgeBNLJjc/bIPj2Rbu9b6X4VfBfyCNar6n5lMZkVXV9efrGNcTQW5XO4dIvIx4H34dQMAiMg/d3d3f966w41QR/HdqNxhneFq6se05d7z0g+M6M0rDMMfA++qSlKy/VZE/rO7u/taBtZKdw0kn8+/Hvi0qp7HKK+nSYFtwOuKxeJ66xA3TItXNtGafQSYYp3iakz0LBaEN7/wx2GvA1AoFM6iwXf+qno/cHqxWHxTd3d3J77zb0jd3d2/6+7ungfMANpp7O+D8ar6r9YRbgRaW8/Dd/6NIZLFqL74i/9wjwBIGIa/Ao6ublViPAv8a7FY/BoQWce4eMlms28SkW+KyNusW4xUKpXKG3p6eh61DnHD0FF+GNXXW2e4OhF9DwvCH8MwjwDk8/lzaMydfyQiVzc1NU0rFouX4zt/N4hyufzrUql0oojMB/5o3WMgk8lk/sU6wg3DstLxvvNvMCptL/zX4QwAGVVdXP2a2PstcHx3d/c8v3ffDYF2d3d3NjU1HaWqr7rtpgGcE4bhG6wj3BCJzrVOcHV3Ftc8th8MYwDI5XLnA9NrlhRPS6IoOr5YLD5kHeKSZd26dU+XSqX5qjoP2GLdU0cB8DnrCDdUcpp1gau7cfQ2zYahDwAiIn9fw6C42QycXywW/7JcLu+wjnHJVSqVrlbVYxh4XkajeH+hUJhhHeH2orN7Mr6mRWMShj4AhGF4GnBUTYPi49fAzGKxOKTHKTq3N6VSaW1vb+/bgKXWLXUiURR9wjrC7UVFjrdOcEaU42CIA4Cqfqq2NbFxdxAEf1EsFh+zDnHpsnHjxu3FYvEi4G8Bte6pgzmtra2vtY5we6BMs05wRmTg//d7HQDy+fxMEZlV8yB734+i6HRfyc/VUrFYvFxEFgBpXyZ6TFNT06APIHExIZK3TnBmJnJtz4F7HQBUNfWH8kTk68Vi8UN+vt/VQ3d3d6eqng1st26pJVX9q0mTJo2z7nC7of4gt4bWG+2/xwFg+vTpBwFn1ynHhKp+vru7+2P4vf2ujkql0i2q+h5gq3VLDU0cM2bMh60j3G4I+1gnOEOB7rfHAaC3t3ceMLZOORb+u1Qq/bN1hGtMpVLpZ8D7gV7rllpR1YusG9xu+S89jayS6d/bKYAL6xJi4wfFYvFvrCNcYysWi3cCbaT3zfjthUKhUe4gShaRzdYJzlLf5t0OAGEYnsTAQ07SaGUQBOfS2A9vcTFRLBavU9WPW3fUiqoutG5wg4j0WesEZ0bZvnPTno4AtO3hc0n2u+bm5rO6urp2Woc494JSqfR1Vf2adUctqOrcWbNmNfrjkmNI/XbnxvUEl8zYMugAMHPmzGYGzk2mzdYgCD6ydu1aP/TlYmfixImf3PWo6bQ5tKenZ7Z1hHuFIPCnNjauNbCbdQA2bdr0HmBiXXPqQEQu6erqesS6w7nBrFq1qk9EzlXVZ6xbqi0IgnOsG9wr9GfuJ73Xnrg9Ue6F3QwAIpLGH9aO7u7u5dYRzu1JsVhcv2uhoFStFqiqZ8+YMaPFusO9xEVHPsvA005doxFWwiADQKFQGKOqZ9a/qKbWbN261a/4d4lQLBZ/mMLrAQ7csWPHO6wj3KvcZB3g6u4ZJmz7OQwyAKjqKZCqFaJUVRc99dRTaV5wxaXMtm3b/gFYb91RZR+wDnCv0kHKjja5vRC5nnNm9MIgA0AURe+tf1HtqGpnqVT6qXWHc8Oxa2BN1TLcqpqq95ZUaMuVEbnLOsPVjSLRlS/84VUDgIik6Yf0+SiKPmMd4dxIFIvF7wG3WndU0aRCoZDWtUWSK+KL1gmubm5mfvjidR8vGwCmTp0aAoW6J9XOZ3p6ep6wjnBupIIg+DiQmodUVSqVU60b3CsszN4N3GOd4WquQiCfe+kHXjYA9PX1nVbfnpp6uFgsfss6wrnR6Orq6gb+y7qjWlJ2hDE9NLiE9D+iusHpfzM/+6uXfuRlA4CIpOYqXRH5Ar7Ur0uBlpaW/wS2WHdUyUnZbDbNDxhLpoWtjwBfsM5wNdMD8k+v/OArrwF4a51iaq37yCOP/I51hHPVsGbNmmeAtBzNGpPJZN5iHeEG0ZP9V1C/IDBtRPuR4ALacs+98lMvDgBhGE4BXlPXsNr5wj333NNvHeFctURR9GVgu3VHlZxoHeAGsVgi+rkA6LZOcVWk/DULWu8b7FMvDgAikpYfyg3jxo27xjrCuWoql8tPMnDPduJFUZSW95r0uTh8Csm8B3jSOsVVgeo/0xZeubtPvzgARFH0tvoU1ZaIfG316tW91h3OVZuIfIUULNoiIicAYt3hdmPB5G40OBGRLusUN2IKfI6F4ef39EUvvQbg2Nr21EWlt7f3WusI52qhu7u7C/i5dUcVHNLa2pq1jnB7sLC1SIaTUdL4dMq02woyh7bc4r19YQAwa9asJhE5quZZNSYid27YsOFx6w7naigVp7eCIHiDdYPbi7nZJ+h75i9Avow/NTApHkaD42jLXjeULw4ANmzYMB0YU9OsOlDVq60bnKul/v7+bwM7rTtGKwiCN1o3uCFYdEwfbdlPE8gxwAPWOW63tgGfY3P/sbtu6RySAEBV0/DDuGXcuHH+ZCuXauvXr98E/NC6owr8CECSzM/+igXZE0DPBH5hneN2EdmCcgVNUqAtt5hLpwzrl4OmXf/39TVIq7ebVq9enZbFUpzbk+uBs60jRskHgKQRUeAW4BbaS28FnQvyQdJz+3hS9IL+DOQamvq+x5wpfxrphl4YAF5XpTBLvoCFawi9vb0rW1paIgZ5mFdSqOqUWbNmNfl6HQnVlnuAgVMCl7Cs5yiI3o7wOmAacAiwH5AZ5ascDiR51cjfM/rTdZtBt6DSjchaVFfRNO5e5r2mKo+3F4AwDH8NHF2NDVqJoihXLpfL1h3O1UMul/uliLzZumM0/GfW7VFH+WeonmSdMWLKW1mY+1/rjD154TeIrGVEFXT7G4lrJEEQ3G3dMFqZTCZn3eBcIwsmT558ILC/dchoiMhK6wbn6klVE/89r6o+ADhnKGhpaclaR4yWqt5j3eBcPTU3N/8USPT5cx8AnLMVAJOtI6rgt9YBztXT2rVrNwMl645RSsN7j3OJFVQqlUOsI0YpiqLoMesI5wyssw4YDRE52LrBuUYWpOCHsKdcLu+wjnDOwFrrgFE6yDrAuUYWiEiifwhVNelvgs6NiIgk/Xs/6b98OJdogaom+ocwBW+Czo1IpVJJ+vd+ot97nEu6QFUPtI4YpbJ1gHMWgiBI+kWA+82aNatp71/mnKuFQETGW0eM0ojXQXYuyaIoSvr3vvzxj39M8lKvziVaICIt1hGjoaqbrRucs5DNZhP/8Kvnn38+0e8/ziVZAIyxjhiNIAh8AHANadeDdLZbd4xGJpNJ9PuPc0kWqGrSJ3AfAFwjS/T3v4j4AOCckQBI9AAQRVHiD4M6Nwo+ADjnRiQQkdE+s9lUFEW91g3OGUr0IliZTMbvAnDOiP/wOedc3F352CSamk4COQrRg1E5GOFAVHtBnkH0aVSfAB4A+QVtuUQPhgBotBPEumLkMhr763N8AHDOuTha2n0SmWAhymwgO/BBBX3p/33pf39xZ9lLe/EXwE1opYOFU/5Yx+oqkkSf3kLif4G6DwDOORcX7aWxoBeDLAJm/HknPywtICcCJyJN/0Z76fvA5bTlHqhmau3pM4k+ArC98qx1wt4E1gHOOeeA9uIZwGqQK4AZVdrqGOBc4H46yrfQ2Z2gRzBLkp/y+hSL8s9bR+yNDwDOOWdp6frDaS/dDnIzENbsdVTfRyX4He3Fj9XsNapJ9FHrhFFYYx0wFD4AOOeclWXltxBU7gdOrdMr7gtyBe2l61nyeLyXgZeW+4DIOmNEVO+1ThgKHwCcc85CR3Eeoj8HLA7Ln0vLzntYuv5wg9cemvmTngF+Z50xIkFmpXXCUPgA4Jxz9basdB4q7dguxX4sQeUeOrsONWzYC7nJumAEnuVPvX4EwDnn3Ct09LwDoZ14vP9OoZK5hc4nJ1iHDKrS3wkjvBfCjN7ApVN2WlcMRRy+AZ1zrjG0d78B9AfE6yFsx1HZfi2q8bvn7qJCF5CIw+m7KMiV1hFD5QOAc87Vw+KVTUhmGar7WKcM4iw6etqsIwal0RetE4ZM5Fbacr+2zhgqHwCcc64eWls/g+ox1hm7p//Fsq4jrSteZWH+TuB/rDOGIAJZbB0xHD4AOOdcrS0tTgP5J+uMvdgPyXzNOmJQElwC9Fln7JGwhAWtq6wzhsMHAOecq7VAPk0yHr1+FsvLb7aOeJUFratR4nwqYD3NwT9aRwyXDwDOOVdLVxYPA863zhgy5e+sEwa1Pvs50LusM15FtB8JzueC1k3WKcPlA4BzztVSk/wtMNY6Y8hUPxLLZwYslghkDtBtnfIyyl+zoPU+64yR8AHAOedqZfHKJiCeV9fvXjOVYKF1xKDack8imfcAT1qnDNB/oS1MzG1/r+QDgHPO1Uq29TTgMOuMEZgfy3UBABZM7iYjJyDSZVihwOdoC//NsGHUfABwzrlaUZlvnTBCWZaX3m4dsVvzsiUynAz83ODVt4LMoS232OC1q8oHAOecq4WrNkwETrfOGLG4Dy9zs0/QU/4LlC8BlTq96m/JyLG0Za+r0+vVlA8AzjlXC02V84jXkr/D9aHYPzJ48ex+FuYuA45Bub+Gr7QN+BwTth3LvOyjNXyduvIBwDnnakF1nnXCKO1HS+/7rSOGpC33a9qyJ4KeCTxYte2KbEG5giYp0JZbzDkzequ27Rhosg5wzrnUWd49lYjjrDNGT+cDyTjcLaLALcAtLC8ehwZzUf0gcPgwt7QT+B9Er2Xrtu9xyYwtVW+NCR8AnHOu2qIgabf+7c47ufKxSVw8ZaN1yLDMDx9k4EjAx2gvTUf1JGA6QTAN1UOBfRg4PfMcsBkoAuvQaBX7tNzHOUduN2uvIx8AnHOumhZrAOULrDOqJKC56XzgS9YhI9aWWwOssc6II78GwDnnqmly8RQgfk/VGykl3ncDuBHzAcA556opyKRth3kUS7tj/BhjN1I+ADjnXLV0PjkBSMaV88MRZJJ+R4MbhA8AzjlXLZXtH0Z1H+uM6tPzueKxJK9p4AbhA4BzzlVP2g7/v+Ag9m16r3WEqy4fAJxzrhquKrYCJ1tn1IzipwFSJvG3AWYymUfCMLTO2JOdwFbgGaAHWCsiv1DVlcVicb1tmgOYNm3avn19fScDJwLTganAwcAEBu4Xdm7vMswjzb9UCaezZO3BLJr2tHWKq47EDwAJMGbXfyYCU4B3qioAYRiuBq5pamq6et26db+3S2w8kyZNGtfS0vIBEZnX19f3DvxnwY2apOXe/91pobn5XODr1iGuOtI7rSbDDOCL/f39pTAM28MwnGodlHaFQmG/MAz/vqWlpQxcq6rvwXf+brSWlU8Aplln1FwQpPUah4bkA0A8NAMLgNW5XO7yadOm7Wvck0q5XO6MKIpWA18EDrXucSkiiX/wz9CoHsNVXa+3znDV4QNAvDSJyKV9fX0PZ7PZt1rHpMXUqVMPDsPwFhG5GZhk3eNSpr00FjjHOqNuMpk51gmuOnwAiKfWIAh+ms/nP2YdknRhGB7T39//K+B91i0upUTPBA60zqijuazQjHWEGz0fAOKrWVWvyOVylwNiHZNE+Xx+NnAX/lu/qyWVRjsvfjjbSu+wjnCj5wNAzInIpfl8PrlP4jKSz+dnq+rtwH7WLS7FOrsORfTd1hl152sCpIIPAAmgqp/K5XKftO5IikKh8GZV/QEDt186VzuVpjmoNOBdJPJBlnTvb13hRscHgIQQkS+FYfhO6464C8Nw/0ql8h38N39XFw1y9f+rjaMlc7Z1hBsdHwCSIwA6p0+ffpB1SJyJyLdEJNZLQ7qUaC+9CTjaOsNOww4/qeEDQLK8tq+v79+tI+Iqn8+fqqqNczuWsyUNfx78ZJb1+LCdYD4AJIyqLszlcsdZd8TNjBkzWlT1m9YdrkEsXtmEcp51hjEhiHxNgATzASB5AhH5F+uIuNm2bdt8IGfd4RrE5MmnAq+xzjCnLEDVb1NOKB8Akum0bDb7JuuIGAlE5NPWEa6BSKbRD/+/IMfy9SdYR7iR8QEgmSSTyVxoHREXYRjOBgrWHa5BLOneH9RXlnyBaqMthJQaPgAklKqeO2PGjBbrjjhQ1bnWDa6BtATnAeOsM+JDP8KSx8dbV7jh8wEguQ7etm2bPzAIREROt45wDcV/4325/WjZeaZ1hBs+HwASTEROsW6wlsvl3ggcbN3hGkR79xTgeOuM2PGlgRPJB4AEE5GGPwIQBEHD/xu4Ohp48I9f9f5Kwru5uvxa6ww3PD4AJJiqTrdusOb/Bq5uVAWR860zYipDX3SBdYQbHh8Aku3IQqHQ6A+88av/XX2098zG15rYPZEF1glueHwASLZAVRv9iVwHWge4BiG+9v1ezGB5+c3WEW7ofABIOBHZ17rB2D7WAa4BdD45AfigdUbsRT4kJYkPAAmnvgxno//vd/UQbTsbaPRheyjOZ8lDzdYRbmh8AEi+P1kHGNtsHeAagN/mNlSH0jLxVOsINzQ+ACRbJCLPW0cY22Qd4FJu+YYjQGZZZySIL5SUED4AJNuGrq6undYRxrqsA1zKRZX5QMY6IznkDJZvPMi6wu2dDwDJttY6wJqIrLFucGnnz5oYphYqfedYR7i98wEg2e63DrBWqVT+17rBpdiy0vGALzY1XOKnAZLAB4AEU9W7rRuslcvl3wBPW3e4lAp8RzZCx9Ne8sEp5nwASChVfWb8+PEPWHfEgKrqbdYRLoVWrG5B8UPZI+anTuLOB4CECoLg+tWrV/dad8SBiFxt3eBSaMu4MwG/mG3EZD4r1C+ejDEfAJJJRWSZdURcFIvFu4Fu6w6XMiJ+7//oHMG29bOsI9zu+QCQTLd3dXX9yjoiRiIR+ZJ1hEuRzq5DAV/QZrSiyIeoGPMBIHkiVf2cdUTciMhyoGTd4VKikjkf8CVtR0s4m6VrfAnlmPIBIHnaS6XSg9YRcdPV1bVTRP7ausOlhC/9Wy0TkDH+EKWY8gEgWZ5oamr6e+uIuOru7v6RiNxo3eESrqNnBoI/1rZaxIepuPIBIDkiYN66dev8nvc9qFQqH8VPBbjRiCpt1gkpM5vOcs46wr2aDwAJoaqXFYvFO6074q5cLj8XBMHZ+FMC3Uis0Awi51tnpIwQ4f+mMeQDQDJ8o1Qq/V/riKTo6ur6lYicBTT6g5LccG3veTfwWuuM1FGdj6pYZ7iX8wEg5lT1imKxeKl1R9J0d3evFJHTgD9Zt7gEidSX/q2NKXT2vNU6wr2cDwDx1Scil5ZKpY8zcP7fDVN3d/fdwDuAjdYtLgHmihtXAAAgAElEQVSWdO8PnGmdkVqR+sWAMeMDQDz1RFF0cnd399esQ5KuWCw+1NTU9GbgVusWF3Njgo8A46wzUuw8Vmzwf98Y8QEgXvpV9YogCN5YLpf9QT9Vsm7duqeLxeL7VPVMYIN1j4sp9d9Qa2x/tva9zzrC/ZkPAPHQB3QAM0ql0se7urr8vHUNlEqlW5qbm2cAnwH+YN3jYuSqrgLICdYZqSeBD1kx4gOArUeAfxCRfLFYbCsWi+usg9Ju7dq1m4vF4r/39vZmVXWuiNwB9Ft3OWNBZi7gV6nXXHQq7aXXWFe4AU3WAQ2gn4F70p8BeoC1IvILVb27WCyut01rXBs3btwOXANcM23atH37+vr+AjgRmA5MBQ4G9gHG21W6ulAVOspzrDMagkoTynnAf1mnuBQMAJVK5aienp5HrTtccq1du3Yz8MNd/0mUMAx/B8yw7ki09vLJCKF1RsMYWBrYB4AY8FMAzrnGFuD3/tfXm1haPNo6wvkA4JxrZCs2jEPxp9XVW+APCIoDHwCcc41rW+WDwP7WGY1H5rB4ZeJPQSedDwDOucalvvSvkUNpzb3bOqLR+QDgnGtMS9cfDpxindGwfPgy5wOAc64xBZW5QMY6o2EJZ3Jtz4HWGY3MBwDnXGMS8Xv/bY1lZ3SOdUQj8wHAOdd42ruPRfX11hkNT/xuAEs+ADjnGo9kfMcTDyewtDjNOqJR+QDgnGssK1a3AOdaZ7hdguAC64RG5QOAc66xbJ9wOqoHW2e4F+g8Fqvviwz4P7pzrrFE6of/46WV1vLJ1hGNyAcA51zjWL7xIOC91hnuVXxNAAO+FKNzrjFctWEiUe/lIGOsU6pkDQOPr06D8+kojUHkasa1/phzpGId1Aj8CIBzLv3aSwvI9K8DSc8FZyKfBx60zqiSFpTziPQ2tpY30FH+Mld1+W2aNeZHAJxz6XXNY/vR13wV6IetU6rsT+xs+T4tvfuDHmcdU2WvRfVTZDKfor30S6AT7b+OhVP+aB2WNn4EwDmXTss3HEFf0/+kcOcP8B0WHb6NSuYGYKd1TA29Bfgq0vQEHeWf0FGcx4oN46yj0sIHAOdc+nSszxP1/y/wJuuUmlA6AbjoyGeBW21j6iKD6jtRWc7W/o20F7/OstLx1lFJ5wOAcy5drnxsElq5CzjCOqVGSrRlf/rin0SXG7ZYmAhyCcIDtJceZVnpMyzrOtI6Kol8AHDOpUd7aSxNTd8DWq1Taka5GhF98c/lntuAp+yCTE1H+AKSKdNevJeO0kf5xup9rKOSwgcA51yafAM41jqihpSocvXLPrJ4dj9wg01ObAQgJ6IsYfz4x2kvtdNemuUrDO6Z/+M459Kho3w6sNA6o6ZE7uOiQterPq7SaVATV/sCC4CVZHt6aC/9O8u7pxo3xZIPAM655GsvjUX1G9YZNafR4Dv6hdlfIvK7OtfEn+ok4DKiYC3tpftYVlpEe+kA66y48AHAOZcC+jHSfN5/wHZ6dcVuPxtFjXYx4HCdgPDfwBMsK32bjvLpLF7Z0Gvh+ADgnEu2Kx4bA/JJ64w6uIlF+ed3+9kKVyPaX8eepBqLcA6qP6Q1+xTLSkvo6JlpHWXBBwDnXLLt23wBcJh1Rs0FeznPf3H4FJH8pE41aTER4aNo9BDtpV+zrPQJriym/3tpFx8AnHMJF6X7wr8BT1EqDWXnfvXev8TtxtEIX6FJfv/iqoNLHh9vHVVLPgA455LryscmgbzNOqPmRK7edbvfnu3T9ANg96cJ3FD8edXBlp0baS/9P5aVT7COqgUfAJxzyZXJnEojvI9JNLTf7M85cjsiN9a4ppEcCPwlovfRXhq4pXBZT2gdVS3p/8FxzqWYvN26oA5+yfzwt0P+6krF7waojcnAZUj02IurDi5ds6911Gj4AOCcS65A3mKdUAfDW+RnYXgf0F2bFMdLVx0MxvyB9vIK2otnJPGWQh8AnHPJtFgDVAvWGTUl2k+/Dm+Z34HnBPjFgPUxduBx03Izrdkyy0qXs7R4tHXUUPkA4JxLpiNKhwBjrTNqKpLbuDgc/oN+MtIJ6F6/zlXTEQiXEsivaS89QHv5r7lqw0TrqD3xAcA5l0wtur91Qs2JjOx8/rxsCfhZdWPcMBwP+g0y/U/QUb6F9uKHWbG6xTrqlXwAcM4llKT7t394ls19t478r49weHDV1ILq+0BWsHX8RtpLX2VZOTbXrfgA4JxLpkh6rRNqS2/g0ik7R/zXm/u+A2yrXo8bpUOAjyO6imWlR2gvLeaqounzK3wAcM4lU9C02Tqhpkb7iN85U/4E+v0q1bhqEl4HfJaMdLOsdBvtpXNZsWFcvTN8AHDOJdO4SU8CfdYZNbKOhbn/HfVWZJi3ELp6yyC8F7ierf1P0F7uZFn3O1GVery4DwDOuWQ6RypA2TqjJpSOqmxnfO4u4PdV2Zartf1B5yLBT+goP0Z76bN0lnO1fEEfAJxzSbbKOqAGIqhcU5UtnSMVlGursi1XT3lgMRUt0l56iPbSx2txS6EPAM65JHvAOqD69HYWFjZUbXMSXQVEVdueq7eZwFfJ9G+gvXgNHcV3s0Iz1diwDwDOuQSLbrMuqIHLq7q1tvxjoLdXdZvOwniQC1C5g63lHpaV/oOO9fnRbNAHAOdccrXlHwMets6oot+wIHdn1beqwVeqvk1n6QiET6OVtbSXV7C0+5iRbMQHAOdc0i2zDqgajT61ay3/6lqYvRt0FIsKuZjKgH6YIPgF7aVb6eyePJy/7AOAcy7ZeqN2RLZYZ4yacjML89X/7f9F8ikg5YsnNbTTqAQPs6y0aKi3EfoA4JxLtkX551H+n3XGKP0BYVFNX6EttwbVf6zpazhr+yH8Nx3lm+h8csLevtgHAOdcCugXgGesK0YoAmmjLfdkzV9pfe4rwI9r/jrO2hlUtt/J8o0H7emLJJ/PP6Kqr6tXVQPqBzYDzwElYB3wi0qlsrKnp6dkWuYACMNwf1U9WUROEpHpwJQoig4VkfFA3ZfnbCRBELy+q6trdVU2tqx4ESJXVmVbdSWfpC1bv4v0ru05kD79Kaqvr9trOhvKo2jmnVw4+fHBPu0DgK01InKtqnYWi8X11jGN5PDDDx8/bty4D6nqXGA2UJX7at3wVHUAAOgo3zLw9LWEUP1PFoafqvvrXvnYJJqa7gVMH0bj6uJB4C9oy+145Sf8FICt6ar6b0B3GIZXt7a2+iBWY9ls9oB8Pv9PY8eO7VHV5cA78Z1/egT9F5KM5YEV9F9Mdv4AF0/ZSNB0Ium6hdIN7jiUJYN9wgeAeGgC5mQymd/mcrnLC4XCftZBaZTL5T4cBMGaXUPXwdY9rgbmFf6ABO8DnrdO2YNtiC6gLfw304r5R/4eOBnFFwlKO2Eey0p/9coP+wAQL00icmkURb/L5/MnWsekRaFQOCSXy90uIiuAw6x7XI0taF2NymnEcwj4NTCTBWE8ntLXlnuOtuzpwCeAndY5roaEL9DZdehLP+QDQDwdqar3hGH4CeuQpMtms8er6q9F5FTrFldHC7M/J4reCTxlnbLLswgfp/eZ42jLrbGOeRkRpS33VSqV16N83zrH1cwBVDJffOkH/CLAmFPVK0ql0ifwh3kMWz6fP0VVfwDsa93iBlf1iwBfafmGI4j6vwscX7PX2LMnUP0mUfM3uejIZ40ahmdp90kEwSeAs/DrY9ImIpBjmJ/9FfgRgNgTkUvDMPyadUfS7Nr534bv/Bvb/CN/z4RtJwOfo36r4FVQbkc5lwnbsiwMP5+YnT/Ahfl7acudTUXzDPy7+e3K6RGg+rEX/uBHAJLj74vF4n9YRyRBPp+fqar3APtYt7g9q/kRgJfq6JmBRl8EzqjJ9kV+RxQtpzm4lrnZJ2ryGhZUheWlt6MyH/gQ4BcpJ9s24Ajacs/5AJAckaqeWiqVfmIdEmfZbPaAIAh+CeSsW9ze1XUAeMGy0vEEfBzlg8CYUW1L5GkivY4g6GRB66rqBMbYksfHM6b3A6jOA96BnyJIKL2UtvBrPgAky1NBELyhq6vrj9YhcRWG4XeBD1p3uKExGQBesGTtwbQ0fwDkdGAWsP+Q/p5IFxr9GPgBvc/ew6Jj+mpYGV8D11fMAeYBR1nnuGH5CW25d/sAkDztxWJxoXVEHOXz+ferql/FnCCmA8BLqQrLN4Ro5Q2oTiIIDkO1edfntiCyEY02ErX8MlHn8+ulvftYJDMP1fOAPa4/72JhMz3liT4AJI9GUXRCuVx+wDokTgqFwpgoitbiS5smSmwGAFcdKzTDluJsJPNR0LOAFusktxsSHON3ASSPiMhnrSPiJoqiNnzn75ytc6TCwvydtGXPobf3CNBLEXnIOssNIoqO8wEggUTk1EKh8BbrjhgJVPX/WEc4515i0bSnaQu/xoLssWTkKAZuKSwbV7k/e40PAAkVRdGF1g1xkcvl3iEioXWHc2435mUfpS23mJ5snih6O8q3gK3WWQ1N9GAfAJLr3BkzZvj5NSAIgrnWDc65IVgsERfm72VhbhHN/YcjOh+ROwG1Tms8wSE+ACTXxJ07d55gHREDgaq+1zrCOTdMc6b8CWm5lSi6CV9t0IC2NFknuJGLomg2cI91h6VCoXB0FEX+aF/nkuKldwpEfWch4kcyLYj80QeAZHubdYC1KIqsHvLinBuOgaWY57K13IYEh/pRf2OqT/sAkGzTrANiYLp1gHNuN5auP5yg/wKQ+Wg0wzrHvYTqMz4AJNuRhUJhTFdX107rEEN56wDn3Eu0l8aCnoEE86D/VFR8PxNHAb/1/8ckm6jq/sAfrEMMHWgd4FJk8comjswfSlA5FAkGHnQTsZ2+/t+zKP+8cV18qQodpZOA+cCHQfZDFRDjMLcbFZoqD/gAkHz70dgDwL7WAS7Blj12CEHmvaicArwF0dehlYH3RY0GvkaAlgDaS8+j/BLhQQK5g3GtP+UcqZi1x8GynhCJ5tFRngu+FkdiKL9lzpQ/+QCQcCLS6FfSNPr/fjdcSx5qZszBZwJ/ieopKH++HVr3+Bvr/gizgdlEehlby8/QXv4eUaWTheF9NMrP4jWP7Ud/84dRnQ/RSfiv+ckzsPYCPgAknKputm4wtsU6wCXEYg1oLZ2NBF9AtVCFLR4EejFBcDEd5fW0l65HMleyYHJ3FbYdL4s14MjiCUgwlz4uAJ1gneRGQaUDfABIukhEGv28pD+a1e3d8uIb0Z6lqBwzcG666iYDl6GVy2gvrUL4FpWd13Ph9GQP6J3l11HRj0B5PgRZ6xxXFfewsPUR8AEg6dY3+B0AAF3WAS7GVIX20j+ifBbVer3fzURZQjDmK3SUOgnka8zLPlqn1x69JQ8103LQ2SiXUtGGX2skdZT/fuG/+lLACSYia60brPm/gdutb6zeh/byDxD5N6Nb0Sag/BUVXU1H+UaW9cT7IjlVoaN8AS0HdQHXI77QWOqIPMT67I0v/NEHgART1futG6xFUdTw/wZuEEu692f8+DsQzrROAQTVDyHRIywrfY7FK+N35LW9NJ2O8s9RvYaB0xkufRThUhZL9MIHfABIMFW927rBWqlUehj4o3WHi5Elj4+nJbgDiNvDssYg/AuTsz+ls5yzjnlRe/Fi4CHgrdYprqY6mZ992S9MPgAk19MTJ058wDoiBhS41TrCxcRiDWjeeQ0Q32dECG+jog+xrGw7oKgK7eUvgXwL8Kv6020tvdHHX/lBHwASSlWvX7VqVZ91RxyIyNXWDS4msj2fQfiAdcYQTCTgDpZ1v9Pk1Vdoho7yNaD/x+T1XT1tguiMwVay9AEgmRRYah0RF93d3fcAj1l3OGPLym9B9bPWGUOmug9B5vss7T6m7q+9pfxN4Py6v66rt52InktbftD3Rx8AkunWUqn0G+uIGIlU9UvWEc7QYg0Q/RbQbJ0yLKr7EAS30tldvwvvOsr/iPDRur2es7IZCU5nQfjj3X2BDwDJEwGfs46Im/Hjx3cC6VuBzQ1NtjQHmGmdMUKHEmWuZYVmav5KHT0nourvH+n3DPBuFrTetacv8gEgYVT1qmKx+JB1R9ysXr26N4qiS6w7nIHFGqDyL9YZo6J6EltKn6npayxdsy8aXQvUftBwln5MJnoLbbm9XiTuA0CCiMjjY8aM+Qfrjrgql8t3ADdYd7g6ay2dDuStM0ZN5B+4qthas+1nxnwGqN32nbU/ISxiQfZU5uXXD+Uv+ACQHJGqzluzZs0z1iFx1tzc/FFgnXWHq6tF1gFVMo6MfKEmW76q2IryiZps21l7HuVLwDQW5L41nKdS+gCQHJ8sFot7PJ/jYO3atZtV9Ryg0R+S1BjaSweAvMs6o4rOpWN99Y9mZOQTwNiqb9dZKoJ+mub+ySzMXUZb7snhbiB+S1K6V1HVL5dKpa9adyRFqVT6TaFQeH8URbfjb3opJ6eBtlhXVFGAVv4Gqvjb+tI1+wJtVdues/Qn0BuB5SzI3Tuc3/YH40cAYk5VryiVSpdZdyRNV1fXPUEQvBf4k3WLq6XoROuCGmhjxYZxVdtaMOYCYL+qbc/VWwW4A+QCJjS9hrbwItrCn4125w9+BCDOeoFPlEqlb1qHJFVXV9c9hUJhdhRF38cfcJJSEt8lf0duf7b0vx+4vkrbm1+l7bj6Wo3QSSVzDRdOfrwWL+ADQDyVVPXcUqn0oHVI0nV1df1y0qRJb25paekAzrDucVU31TqgJoR5VGMAaO+eQpyfi+BeaRPKjWh0NRfm7631i/kpgHjpU9Urmpubj/adf/Vs3Ljx2WKxeKaqngkM6fYYlwBXbZgI7GudUSPvYun6w0e9FZX5gIw+x9VQL8r3Ud5P7zOHsTC3qB47f/AjAHHRC1wdBMEXu7q6fDW7GimVSrfMmDFj5Y4dO/5KVT8JHGbd5EYh03tQin+HyRD0XwB8ecRbWKwBUp5bvSRXZY8AnWQq7cwr/MEiwAcAW78VkWszmcy169at+711TCNYvXr1FuDL2Wz2a0EQfACYA7yLpK0h7yD1d3jIAkYzAGTXz0b92peYeRzlOwjttOV+bR3jA0Dt7QQ2A88CZVVdC/yiubn5bt/p2ymXyzsYOMd6/YwZM/bZsWPH24ETVXU6A+eVDwb2Ib2HmJNPmiI0sq6opaPo6JnJgtZVI/rbUTTPD/7HwjZEvodGnfTk7mKxxOabNvEDQKVSOaqnp+dR6w6XXLuOCty+6z+JEobh74AZ1h0m+nqfpynxb2F7FkXzgOEPAJ1PTiDa8UF01HeKuZFbhfAtKjuv58Lpm61jBpPynx7nXGo1NT3NwNMxU3shAMJ5LHnoUyw6pm9Yfy/adjYq+9Soyu2OSBcadYJcTVuubJ2zNz4AOOeSqS23g/bSBtL9gJtDaD7oNOCmYf2tgav/XX08D3IzWulkQXhXNRboqRcfAJxzySXyMKppHgBgYCGfoQ8And2TqTCrZjUOXlidT+lEuIm27A4AFtpGDZcPAM655FK9D3ifdUZNCaezZO3BLJr29JC+PsrMBU3vaRFbA7fuwfKRPHwnbnwAcM4lWHRXmi8B2KWFMWM+AnxjSF+tOq+2OQ3nD8B1DOz0zW/dq6bU/+Q451KsLf8LIP2LZw11p768/DbSujxyfe1E5Ieg59D7zCTacp9I284f/AiAcy7pVG9A5B+tM2rsODrLr2Neds+3PEf+2/8oPYDSyZjgBi5o3WQdU2s+ADjnkk2bvolUPk3aV3Os6DzgM7v9/IrVLWzlw/ULSo3fo3yXjC5lfvhb65h68lMAzrlkG3hU6nXWGTUnMocVmtnt57eOOws4qH5BCSayBaUTlXfQk53MwtzHG23nD34EwDmXBv39/0RT04eB8dYpNaM6ia2lU4CfDPp5Ceb5yn97FIHej0gnlR2xXZ2vnnwAcM4l38VTNtJe+jLwWeuUGpvPYAPAlcXDIDrVn/w7qLWIXE1QuZp5eX8c+Ev4AOCcS4ee8udpzb4PmGmdUjvyAZau2fdVv71m5HzU389f4jmQW9BKJ23JWp2vnvwaAOdcOiye3U8QnQ88Z51SQ+ORMR961UcFX/oXKojcieh8esccQVt2Hgvzd/rOf/d8YnTOpcf8/Do6ynMg+gEq6Xx/G9jZt7/45+XFNxJxtF2QuV8Dy8lUrmNe4Q/WMUniRwCcc+myIHsryvkMrNeeRiezrCd88U9RQ/72/yzKt1CZSVvuzbTlvuo7/+FL54TsnGtsbeGNLCsFCB3AWOucKhOCaA7wryxe2QRyvnVQnewAbgLpZELrHZwjaR3w6saPADjn0mlh7ttE0buAxD+05dVkLqpCNvce4DXWNTWkoPchLAJeS1vuXNqyt/nOvzr8CIBzLr0uzN9LZ9fRRE1LUU3PUwNVCyxffwKRzkvpnX9lkKup9HdyUaHLOiatfABwzqXbwLnhM+gon43q/wWyxkXVofpxhDOsM6poM8J3iFhOW/anfvV+7fkA4JxrDAuy32V58TEi+Y11SnVoitb91/voHftuFh2+DYCFxjkNwq8BcM41joH13lP3WNfkk6te3Pm7uvEBwDnXWJRO6wT3MluJdn7XOqIR+QDgnGssTZVrgT7rDPcC+Z4/mMeGDwDOucYyr/AHRO6wznC7aMWPyBjxAcA513g08p1OPPyefcKV1hGNygcA51zjmbD9JuAZ64yGJ3T6oj52fABwzjWec2b0AjdaZzQ8vyDTlA8AzrnGFIjvfGw9SFtujXVEI/MBwDnXmOZn7wd8B2RGllsXNDofAJxzjUvkGuuEBtVL784V1hGNzgcA51zj6utbDvhFaPX3QxZNe9o6otEFqprob/4gCFqsG5wzlOhn3VcqlX7TgIunbAT+x7ShEYn64f8YCIBe64jREJF9rRucM5To739V3Wnd4Fei190zjN/+I+sIB4GIJH0A2Me6wTlDPgCMVtO47yCyxTqjgVyz6zZMZywA7H8ARyGKokS/ATo3UrNmzWoCxll3jEalUrF//5n3mq1E+j3rjIahfvtlXASqmuhJzE8BuEZVLpcTf/Rr//33j8f7TxD4Tqk+VrMw+0vrCDcgUNWkP4N5P+sA5ywEQZD073095JBDdlhHAFCevBJYb52Rfn7xX5wEIpL09bCz1gHOWYiiKGfdMErP3XPPPbZ3AbxgsUSgviZAbUX0V663jnB/FqhqogcAVZ1m3eCchUwmk/Tv/Zi992gHoNYVKfbjXbdduphI/BEAEUn6m6BzI5L04VdE4rUQTFv+MeBB64wU88P/MROoarx+CIevNZvNJnoxFOdGKNEDQCyPPqrvpGrkT/SOudk6wr1ckMlkkj4ABEEQTLGOcM7AVOuA0YjlLx9jghtI+K3RsSSygkWHJ/2C89QJSMeVr2+0DnCunqZNm7YvEFp3jFL83nsuaN2EyC3WGalTqfiRlRgKent7y9YRoyUis6wbnKunvr6+k4GMdcdoiEjJumFQGvmaANVVZmF4n3WEe7Vg/fr1m4DnrUNGI4qiU6wbnKsnEZlt3TBaQRDEcwDo6bkdeNI6I0U6EPG7K2LohccBly0jRktEwmw2m7XucK5e0jD09vf3l60bBrV4dj9wg3VGSiiS8fUVYuqFASCek/gwBEGQ+DdE54Zi+vTpB4nI0dYdo9SfzWbje0944OvVV8nPWDC52zrCDe6FAeBR04rqeId1gHP1sHPnztn8+Wc3qdbFZhXAwczP/gr4rXVG4okPUnEWAIhIGr7Rz5oxY0biH47i3N6IyHnWDVUQ//cc33mN1nZUv2sd4XYvTQPAhO3bt59lHeFcLU2ePPlA4HTrjtFS1YetG/aqL7oG0fgepYi/79OWe846wu1eADBp0qR1QDyeyjUKIjLXusG5WmpqajoXGGPdUQXxHwAuDp8ikp9YZySW4kdQYi4AuOeee/pVNfHXAajqO6dOnXqEdYdzNTTHOqAaEnEEYIAvYDMyj7NP9k7rCLdnL72Q6BdmFdWTqVQqF1hHOFcLYRhOAd5m3VEFfyiXyz3WEUMi3AT4YezhUq7hHKlYZ7g9e3EACIIgFSs1qerHZsyY0WLd4VwN/B0g1hFVcB9JeexuW24HyI3WGYkjkd/7nwAvDgAikooBAJi0bds2vxbApUo2m30NsMC6oxpUNVnvNSJ+GmA4RB6iLZ+UUzwN7cUBoKurqxt4wrClakTkM7NmzWqy7nCuWoIg+DSQisdeJ24AWNB6H7DWOiMx/FkKifHKxUTuN6movvz69evPsY5wrhoKhcIhwEetO6pkR1NT06+sI4ZNuM46ISH60Iovo5wQLxsAVPVuq5Aa+AwJf1qacwBRFP0dMMG6o0ru7erq2mkdMWz9uhyIrDMS4FYWTvmjdYQbmpcNAFEU3WYVUgOvz+Vyf2kd4dxo5PP5AvC31h1VdLt1wIhcFPYAP7POiD1/hkKivGwA6OnpKQGPGbVUnYh8obW19bXWHc6NlKpeTkrO/QMEQfAj64YRU18TYC+e5fm+NP0SmXqveqCIqiZzQh/cfk1NTf9hHeHcSORyuQ8Bp1l3VNGGrq6uR6wjRmz7thsR2WKdEVsi13HplOSd3mlgrxoAgiBI0wCAqs4pFAqzrDucG44ZM2bsIyJfse6opsT/cnHJjC1odJN1RmxpxQ//J8yrBgARWUm6Vr6SKIr+258U6JJkx44dXwSOtO6opiAIvm/dUAV+GmAwyqO05dOwmmxDedUA0NXVtVNV0zblTtu+ffuV1hHODUUulztDVS+x7qiypw844IC7rCNGrSd3F7DBOiN2xAejJHrVAAAQBMG36x1SB+eGYdhmHeHcnoRhOFlEOkjHkr8vUtXvrVq1qs+6Y9QWSwS+JsArRGjF/00SaNAB4IADDrhTVZ+pd0wdfDOXyx1tHeHcYGbOnNmsqjcAE61bqk1EVlg3VE0QLbNOiJm7WFjwoyIJNOgAsGrVqr6UnK97pbEicl2hUNjPOsS5V9ESk/QAABmYSURBVNq0adN/iUganvb3Sk8Vi8V7rCOqZn5+Hel4emp1+LMSEmvQAWCX9rpV1NdRlUrlpmw2m5p7q13yhWF4GZC28/4AiMjVQLoeDavqV7wDiGxh69a0XTPWMHY7AHR3d/8cWF3HlroRkVkicgO+VLCLgTAMLwC+aN1RK/39/ek7ZB41Xwf4Pe+qK7hkhq+NkFB7OgIAcFVdKgyIyFlhGH7DusM1tjAMTwc6SNlFfy/x056enketI6ruoiOfRfFV7xQ/EpJgexwAent7O4EddWqxsCifz3/eOsI1plwu93ZgBZDaR1eramp/iUAafufXw/qsPx8hwfY4AGzcuPFZ4Dt1ajGhqv8YhuHX2fvREOeqplAonCUidwDjrVtqRVWf6evrS+/7R+8ztwKN++Q7Zfmu2yJdQu11p6eqXwa0Di2WLgnD8Lt+YaCrh3w+Pz+Kou8A46xbauybGzdu3G4dUTOLjukDucE6w4yq3/ufcHsdAEql0m+BlXVosfb+IAhu81sEXS2FYXiZqraT4sP+u+xU1W9aR9Rcw94Cp/dxYbjWusKNzlAPe/9nTSviY3YURffmcrlp1iEuXQ4//PDxYRi2A/9Oei/4e5GIXF0ul5+07qi5Ba2rgIetM+pOpNGvf0iFIQ0AxWLxdlJ6S+Ag3iAiD+VyuTnWIS4dstns9LFjxz4ALLBuqRPt7+9P1ZMM90i4xjqhznagpGdlxwY21CMASorvUx7EPiJydRiGVx1++OGpvUjL1V4Yhm1BEKwC3mDdUkffS+Wtf7tTyVxD2hY62rObaMul6YmxDWvIV74Xi8UbgEdq2BJHF44dO/bBbDb7VusQlyz5fP7QMAyvBZaR4iv9BxEFQfBZ64i6unDy48Cd1hl1EzTqdQ/pM5xb3yqqurhWITE2IwiCn+fz+c5CoXCIdYyLvSCfz89T1dXA+dYxBm7o6upqlNOFL9Ew58SfolT6iXWEq45h3fteKpW+A/y6Ri1xJqo6N4qitWEYfhxfM8ANovD/t3fnYVLUdx7HP9/qbkYCYgY1WZWZ6epuEMWokQQ1ogE1koQ1l0oSA8oMGhI3Ho9r8qz7ZLPk1GyOTTRrVqIcirreGtTEXIxnYhSjJiBHV1XPMEGj4nDJwMx0ffcPYJfHKMdMd32ruj+v55lHnsfn6d97UKjv1PGrQuG4XC73pKouBHCQdY+BchiG37SOMDEsdS+A2j8trroIcyb3W2dQZezrgUxV9WtVKUmGRgA/yuVyT7mu+zHUwd3ctGeFQuHIXC53cxiGTwM43rrH0E2lUmmFdYSJaU09gN5tnVF1qbrf/bCmDOgAlsvlHgZwRoVbkugvIvK9pqamW9vb2zkV1xnXdY92HOcKVT0XfLHU5r6+vsPXrFmz1jrEzAL/FKg8Yp1RNYo/oc09zjqDKmegp7KvQH3d9fp2jlLVhZ2dncvy+fzns9nsO62DqOpS2Wx2Si6Xe0BEnlPVGeDBHwC+U9cHfwA4330MgGedUTV890HNGfAp7Fwudx2AL1awpRZsA/BrVb1p5MiR9y1durTPOogqo1AojAvD8Bxsf5a/xTgnVlTVV9VxpVKpll8ctnfmB3MA1N5TEKL9UGlCq1v7mzvVkQEPAGPGjDmov79/FbZfF6e/9wqAO1X1V6r6aKlUqv0bhGrIpEmT0mvWrJkA4FRVPQfA0dZNMXaW7/v3WEfEwvwgC8BH7d0ftBit7sesI6iyBvU/qeu6F4rI3ErF1LAygGcBLBGRJQCe9TzvFeMm2sW73/3uYcOGDTtSVT8oIpMBnAJguHVXAjzo+/4/WkfEyvzgUQAnW2dUlOo5aMvV7psd69Rgp1RxXfd3IjKpEjF1phvAKlVdISIrAZRUdZ3jOJvDMHwjk8ls2rJly3rHcWr9TYxVl8lkhvf39w9PpVLDARwAYISIHKaqYwGM2fHVbBqZTJsAHOX7fqd1SKzM8y+AyM+sMyqoG5v6D8Elo7dZh1BlDfo0VS6XGw3gedT+q02JaBciconneddad8TOotUj0Jd+CbWyA6Tgp5jpXmSdQZU36A1tfN9fDaA+N/8gql9/9Dyv9l/3OxDTR2+E4H7rjIpR3v1fqyqyo11zc/P3ADxVic8iotjbUi6XZ4KPAr+92jlorsbMLP9ur1EVGQDa29v70+n0udh+TZCIapiIXF5Xb/sbiI7sryDSZZ0xeLIAIrwPqUZVbE/7VatW+QAuq9TnEVEsPeR5Hp/82ZM5EkJxm3XGIIVIlRdZR1D1VPSlNr7vz1PV2yv5mUQUG39T1TYA/Ilwb6gssE4YHF2C8/J8wqOGVfytduVy+Yuq6lf6c4nIVL+IfDYIgr9ZhyRGW8tybN//I5m49W/Nq/gA0NnZ2Q3gkwC2VPqziciGql7ped4S647EESy0ThigN/BGD3d3rHFVea99EAQvALiwGp9NRJG7LwiCH1hHJJJkbgHQa50xAHfhn8Ztto4woyq4paMR1z+TsU6ppqruV+267jUicnE11yCiqlrpOM6EYrG40Tokseb7dwFylnXGPlFMQptbu682BoBrVjdg//SJAE4AcDiAsQBy2L4F+K6bOPUC2AxFBwSroFgJ0WfQq49idn5D9OGVU9UBYPz48Znu7u5fADitmusQUeWp6joROXHHZl80UAv9CQglSc/SP41Wd4J1RFUs7DoQ2v8ZaPhJQD6Awe1gu/0dL4IHEDqL0NaSuHvfqv7GqkKhMCIMw8fAt6kRJUmviHyY1/0rZEHpMahOtM7YKyJnY2b2buuMilrgn4JQLoNgKoAhVVhBIfIEQr0Ow7N3YJokYpOsSF5ZOWbMmMP6+/v/AGBUFOsR0aCoqp4XBAGfAa+U+f6ZgPzcOmMvrMaw7BFJOYDt0QL/DMD5t4iHr9WAXI1hLQvj/vsY2Tur8/n8eFV9BMCwqNYkogG50vf9q60jas784F4An7DO2A2F4iNocx+2Dhm0hWsOQ1i+CtAZhhXPQ+UitGWfNGzYrcgGAADI5XKnAXgAwH5RrktEe0dVrwmC4FLrjpp0c+kQ9OsyAI3WKW/jerS6X7COGBRVwfzSZRB8C/F4G2MIYC6GpS/HtKYe65g3i3QAAIBsNjvFcZz7ATREvTYR7dZ83/dngTv9Vc+84HwIFlhnvIUOZPqPxvTRyX3a43rvADSkboDq2dYpf0fxIsLyNFxQ+It1yq6qsg/A7pRKpYcBnAugP+q1ieht3eX7/oXgwb+62tyFUI3bngobAHwi0Qf/+cFYDHGei+XBHwAERyCd/j0WlKZap+wq8gEAAHzfv0dELgBfJ0oUB3c3Nzd/FvzzGI1W98tAbM4C9AB6Jlrd56xDBmy+934AjwLIGpfsnupwqN6Pef4F1ik7mQwAAOB53kIR+RyAPqsGIsKtzc3Nn2lvb+cZuaiIKHrXfR6A9Va7WyByDlpzjxl3DNyN3kTAWQLgYOuUvZSCyFzML11kHQIY3APwZrlcbiqAu8AbA4midr3v+xdh+41KFDVVwYLSVwB8B1H/MCbShXL5k5iVfybSdSvphuJRSKUeATDSOmUAQoh+FjNzd1hGmA8AAOC67odE5F7wEUGiSIjI9z3P+wp4zd/ePP9siNwIYEREK7YjVf40ziu8EtF6lfez1aOQTj8F4FDrlEHYBsUUyy2XzS4B7CoIgl8DmAyArxolqi4F8HXP874MHvzjoS13F9IyFoq5qO7ZmHUALkNH9rREH/znLEkjk7kNyT74A0ADBLfj5tIhVgGxOAOwUzabzTqO8yCAI61biGrQVhGZ6Xne7dYh9DbmlT4A0W8D+CAq9/fzeijmYkj/txN9p/9O84OrAPyLdUbFKJZgePZDFrsGxmoAAIBsNvtOx3HuwfYzAkRUAaq6znGcj3ue94R1C+2Fhd4YhE4bRGZB9aABfspSCObCGXoLzvuHNyraZ2V+cAKAJxCTs9cVo3ox2nI/iXrZ2A0AADBu3LghPT091wCYbd1ClHSq+idV/VSpVCpZt9A+mrMkjabmY+E4EwGdCJUjITgIwEH4/7+/eyCyDqp/heIpiD6OtPM4ZmRfMiyvvDs0hc2lpyF4r3VKFWxEWsZG/d8slgPATq7rTheR6xGPLR2JkmjR1q1bZ69du3aLdQhVkKrgxq5GDMlsq5mf7vdknv8liFxrnVE1ipvQ5p4f5ZKxHgAAIJvNHisid4tIzrqFKEH6AXzV9/3vWocQDdo1qxuwf9pH8m/8250QoR6JWbmVUS0Y++sopVLpuYaGhgmqer91C1FCeKp6Eg/+VDP2z8xCbR/8AcCBI1dGuWDszwDsKp/Pn6eq14H7BRC9JRG5s1wuf75UKq23biGqiDnqoKVUBOBap1SdaD/CMIe2wpoolov9GYBdeZ53UxiG7wPwrHULUcxsBDDd87xpPPhTTcl2TkY9HPwBQCUNpKZHtVyiBgAAKJVKK4YOHXoigG8A6LXuIYqBB0XkKN/3b7EOIao4DWdYJ0Qssu83UZcA3qxQKIxT1RtU9QTrFiIDr4vIlZ7nzbUOIaqKO5YNwRvveA3A/tYpEXtvFG9oTNwZgF0Vi8VlnuedJCKXANhk3UMUEVXVhUOGDBnDgz/VtC1DT0D9HfwB1dOjWCbRA8AOoed515bL5cNVdS74TnOqbc+q6geDIJi5YsWKddYxRFWlUp87wko033ctDAAAgI6OjpeCIJgtIscDeNy6h6jCXgNwme/7E4IgSO7724n2iZ5sXWDkZMzRqh+fa2YA2MnzvKW+758C4FwAq617iAZps4h8O5PJ5Hzf/zF4hovqioyzLjCyP0YFTdVeJNE3Ae4Fx3Xds0TkOwAK1jFE+2DLjhtcryqVSi9bxxBF7nrvAAxx6veRVtEpmJn7VTWXqLkzAG8SBkFw59ChQ8cB+CKADusgoj3YAuDHYRjmgyC4lAd/qltDMMY6wVRY/e8/Xe0F4mDZsmW9AP4bwFzXdac6jvOvfHSQYuYVAD9Np9M/WbVq1WvWMUT2nAOtC0yJVP37r4sBYBdhEASLASwuFAqTwjC8HMBU1P6ZEIqv5ar6I1W9uVQqbbWOIYoN1eGQWr9KvRuqVX/8sd4GgP9TLBbbAbQ3NTUdmslkZgCYjXrZbpKsbRWRxao61/f93wJQ6yCi2BEZbp1gSzgAVNuaNWvWAvgugO/ncrkpAFqx/azAUNMwqjUK4I8AFgK41fO8DcY9RPGm0Jq/TX13pPo/GNT9ALCLsu/7DwF4aNSoUUMzmczpjuOco6pnAXiHdRwl1nIAdwK4xfd9PpZKtLcc2Qyt55NjsrHaK3AAeAtdXV09ABYDWJzL5S4G8NEdX2cAeJdlG8XeVgCPAfil4zj3F4tFzzqIKJnCTbX/pPruhFXf3p4DwB74vr8BwG07vpxcLneciHwYwOmqOgG8VFDvQgDLRaRdVX+5devWJWvXrt1iHUWUeOK8WtdnAFSq/jRQPY9XgzZ+/PjMunXrxjuO8wEAEwFMAHCYcRZV1yYAfxKRx1X1yf7+/ic7Ozu7raOIas5NLw9DuWcT6vU4pXIa2rK/q+YS9fkbW0Vjx449sK+v72gA7wHwnjAMx4lIFsAhpmG0rzYCKInISgAviMifHcf586pVqwLwrn2iaCworYHqKOsME2HqMMxqXlvNJTgARCSbze6nqm4qlXIBtAA4WFUPFJEDd/4TwAhVzYhICsCICi09AkCqQp9lYSMqsP+9iPSEYbh1x6+7VXWTiLwG4FVVXSci61S1y3GcIJPJlPimPaIYmBc8BMFHrDMMvI6Z2YMgUtUfNngPQER2bPLy4o6vyORyuWUAjoxyzUpyHOfEYrG43LqDiAwIHgXqcgBor/bBH+AOeEREFFeOVvUaeGypLoliGQ4AREQUT0PdpQDq73JcSqv6FsCdOAAQEVE8TZMyoLdbZ0RK5Bmcn18VxVIcAIiIKMbkZuuCaGlk3y8HACIiiq9W9w8AlllnRKQHYf9tUS3GAYCIiOJN9WrrhGjIDWgb/WpUq3EAICKieBvu3gag1l+m1Ydy+IMoF+QAQERE8TZNyhD5unVGlV2HC3IdUS7IAYCIiOJvZvYWALW6L8DfAMyJelEOAERElAzqXAyg1zqj8uRytLrro16VAwARESVDW8tyQK60zqgoxR1ozd5qsTQHACIiSo6ZLf8Jxb3WGRUhUsSQ/gutlucAQEREySGiaHBmQaN9sVoVbICWP4XpozdaBXAAICKiZPlcSzdS6Q8BiPSu+QrqhYZnozX/Z8sIDgBERJQ85zf9FeJMBfCKdco+6oPIuWjL/8Y6hAMAEREl08yWZVDnRCRnk6A34MjHMTN7t3UIwAGAiIiSrK3FB3AKgKXWKXvwEsJwEs7P/sI6ZCcOAERElGyt7svY1H8SFNcAUOucv6NYgrSMx6z8M9Ypu+IAQEREyXfJ6G1ocy8F5GwAL1vn7NAD4Ep0Zk/HjOxL1jFvxgGAiIhqR2v2HvSGY3ecDSibdYg8gJSMQ6t7NeZIaNaxGxwAiIiotszOb0CbeynUORrQWxDtINAOldMwM3smzssGEa67zzgAEBFRbWprWY7W3HSUyzvPCLxapZW2ALgV4kxEqzsZbdlEvLRIrAOounK53DIAR1p3DJTjOOOKxeJy6w4iqgHXP5NBpnEKHOdTUJwKoGUQn7YO0HaoLIZuuwezxm6qVGZU0tYBREREkZj9vj4AD+z4AhZ05qHh8RAcAcXhgLZAZCRUhwNogEgZqhuh2ABBFyAroOEqpJylCFqej+u1/b3FAYCIiOrTzGYPgGedYYX3ABAREdUhDgBERER1iAMAERFRHeIAQEREVIc4ABAREdUhDgBERER1iAMAERFRHeIAQEREVIc4ABAREdUhDgBERER1iAMAERFRHeIAQEREVIc4ABAREdUhDgBERER1iAMAERFRHeIAQEREVIc4ABAREdUhDgBERER1iAMAERFRHeIAQEREVIc4ABAREdWhtHWAsVRzc/MI64gqS1kHDEZ/f/+I5ubmRuuOagnDcGtXV1ePdQcR1R+xDohCU1PToel0+lQROUlVxzqOM0ZVDwTQYN1GBEABrAPQAWAlgKdVdUkQBC/s+HdERBVXswNAc3NzYyqV+pyIzAAwwbqHaAD+qqq3plKpBcVicbl1DBHVlpobAPL5/LvCMLxCRL4AYH/rHqIKUBFZrKrf8n3/aesYIqoNtTQAOPl8fnoYhj8UkQOtY4iqQEVkEYArPM97xTqGiJKtJgaAQqEwKgzD2wBMtG4hisCrYRjOKJVKD1uHEFFyJfoOcQAoFAqTwjD8LYCx1i1EERkmIuc2NjZKd3f3I9YxRJRMiR4AXNf9GIB7ARxg3UIUMQEwqbGxMXvMMcc8WCqVQusgIkqWxA4AruueKSL3gI/yUX07duPGjW53d/d91iFElCyJHADy+fxJAH4OHvyJAOCYkSNHpru7u39nHUJEyZG4AaBQKBysqr8BMNK6hShGTh45cuTz3d3dK6xDiCgZEvcugDAMFwA4zLqDKGZEVW9samo61DqEiJIhUQNAPp//NICPWncQxdTIdDr9Q+sIIkqGxOwDMGrUqKENDQ1FVeVPOES74TjO5GKx2G7dQUTxlpgzAA0NDRfy4E+0Z2EYfs26gYjiLykDQEpV/9k6gighJhcKhROtI4go3hIxAOTz+TMANFt3ECWFqrZZNxBRvCViAFDVGdYNREmiqudks9n9rDuIKL6SMACkAHzYOoIoYQ5wHOck6wgiiq/YDwD5fP5YAI3WHURJIyKTrRuIKL5iPwCo6gTrBqIkUtUTrBuIKL6SMADwNb9EA3O4dQARxVfsBwARyVs3ECXUYbwRkIjeTuwHAADvtA4gSihJpVIjrCOIKJ6SMAAMtw4gSjAOAET0lpIwAKh1AFFSpVKp0LqBiOIpCQPAJusAoqQKw5B/fojoLcV+AFDV160biBKq3NDQsME6gojiKfYDgOM4q60biJJIVTuWLVvWa91BRPEU+wEgDMMV1g1ESSQiK60biCi+Yj8ApFKp31s3ECWRiDxp3UBE8RX7AaBYLC4XkbXWHURJIyK/tW4goviK/QAAAGEYPmDdQJQwL48aNepp6wgiiq9EDAAicrN1A1HC3Nbe3t5vHUFE8ZWIAcD3/ScALLPuIEqI0HGcG60jiCjeEjEAAFBVvdo6gigh7isWixyYiWi3kjIAoKWl5X9E5EXrDqKYK6vqN6wjiCj+xDpgX7iue4qItCNh3URRUdVrgyC4xLqDiOIvZR2wL9avX9/R2NjYBOA46xaiGOoQkWnd3d3brEOIKP4Scwlgp97e3osBvGDdQRQzfSJyru/73PufiPZK4gaArq6uHlWdBuA16xaiuBCRL3mex53/iGivJW4AAIAgCFaq6lQAm61biGLg3z3Pm2sdQUTJksgBAACCIPgjgFMBvGrdQmREAXzd933e9U9E+yzxd9O3tLQckUql7gVwuHULUYR6VHV2EATcJZOIBiSxZwB26ujoeDGTybwfwCLrFqKILAdwPA/+RDQYiT8DsKt8Pn+qqv4XgLHWLURV0APgPxzHuapYLPJRPyIalJoaAABg3LhxQ7Zu3foZVf0qgNHWPUQVsE1VF6ZSqW8Wi8Uu6xgiqg01NwDsNGnSpHRnZ+cUVZ0hIlMBDLduItoHZQBPAVjU29t7e1dX1+vWQURUW2p2ANjV+PHjM+vXr5+gqhOx/fLAGAAHY/tQsJ9pHNU1VQ0BbBCR9QB8EVkF4Om+vr5HOjs7u43ziIiIiIiolvwvLE576hMwOXwAAAAASUVORK5CYII=",person:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAACXBIWXMAALP6AACz+gFmujCYAAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAIABJREFUeJzs3XeYXHXZ//HPfWa2pm8SAiHJzswOMbgQRJogTaQXK4RHhZBNwFhRfo/6WFBj4cEuii2UbGgqAQvtAQUB6dKUEkjZKZsNoSXZTcJmd2dnzv37Y6OApmw5M/cpn9d1cakI4Z1lZs4953zP9wiIKLgWr5yEeDyBeGw6XHcS4EwG3ImATITIRLg6EYJxAGq3/R3jADgAYgDGbvtzmwGUIFKC6uZtf64Xik1wZANUNwC6ASrrAX0VIuvhumtRLOax8C3rK/sbJiKviHUAEe3CktWT4VTPhrr7ANIEaAIiSQAJqI42bRN5Dao5AHkochBkIc6z6Ot9isMBkb9xACDyC1VB65q9IaUDAGdfQPcDMBvA7tZpw/QigGcAeQpwn0HMeRxnN66AiFqHEREHACI7ix+vQs3k2VD3cEDeCcG7oDrJOqvMNkPkUag+CHUfwOjqBzFneo91FFEUcQAgqpRF6iCZOxCunATFCRAcCKDKOstYAcDjEPwJ6t6O9tQTWCSudRRRFHAAICqnxSsnobrqXVA5FoLTAOxhneRrIuuhuAeid6EUuxULZqyzTiIKKw4ARF67au1EaOEUwDkDcE+EStw6KaBcQB8G5AbEZRnOTrxoHUQUJhwAiLxwRUcD4v2n8qBfNq8PA0X9Lc5LvWwdRBR0HACIhmvRPXHMSJwCR87lQb+CRItQuR3QyzEq+X+YIyXrJKIg4gBANFSXr56GePwjAD4BYIZ1TsS9COBqqHMZ5jdmrWOIgoQDANFgLFIHM/KnQfAJAMdiYDc98g8XwJ0Q/QXyyVt5JwHRrnEAINqZn66uwdjYmXDlixDsbZ1Dg5IBcCkKNZdj4dSt1jFEfsUBgGh7lqyeDIl/EiKfjMDmPGH1KoAlcGM/5e2ERP+JAwDRG125Ziqc4pcBWYDXH6BDwdYDyBWI42LeSkj0Og4ARMC2DXuqPwfgfAB11jlUFn1QXAXB19GSfMk6hsgaBwCKtis6GhArng/gArz+eFwKt24orkS8dBHmpl+xjiGywgGAoumnq2swJn4BgC+BB/6o2gToRRjV8xPMaS5YxxBVGgcAip7W7GmA/BhAk3UK+YBIG9T9MlpSN1inEFUSBwCKjqvze6OkPwJwonUK+dLdcPQCnJN62jqEqBI4AFD4Lc6MQ41zMRQfBRCzziEfEy1CnV+iqv9CnLXXZusconLiAEDhtiRzKsT5BYDp1ikUKC8C8im0JH5vHUJULhwAKJwuz05B3Pk+oGdbp1CAidwKiX0M50x/wTqFyGscAChcVAVL21sA/QGACdY5FAobAfw3WpJLrUOIvMQBgMJjYPveKwGcZp1CofQnAPO4iRCFBQcACofW7HGALAUw1TqFQu0ViMzHvMRt1iFEI8UBgIKtNVcLYBGAz4OP6KXKUCguR3/NBXzaIAUZBwAKriva9kEs9lsAzdYpFElPQ50PYX7jc9YhRMPBb0wUTK25/0Is9gh48Cc7s+Ho37A0O8c6hGg4eAaAgmXRPXE0Jr4N4H+sU4j+RXEZ+jd8CgsP7LdOIRosDgAUHEtWT4bEfgPIu61TiLbjPgBn8i4BCgoOABQMS3KHQPA7AHtapxDtRAdc9wNY0PS4dQjRrnANAPnfVfn3Q3A3ePAn/5sOx7mf6wIoCDgAkL+15j4DV28EUG+dQjRItVD5LVpzi6xDiHaGlwDIn5ZpDFvbL4Hqp6xTiIZNcRnW5D+JRe8qWqcQ/TsOAOQ/P18+GvV1vwXkFOsUIg/chELNh7lpEPkNBwDyl8WZcah2/g/AYdYpRJ4ReQB9pVOxsGmTdQrRP3EAIP+4rn0CCu4dAA62TiEqgydRKJyAhW9Zbx1CBHAAIL+4PDsFcbkTwL7WKURlo3geGjsWC2ass04h4gBA9q7OzEDJuQvAXtYpRBWQQ0zejbmJnHUIRRsHALJ1RbYRMfkrgEbrFKIKyiPmHoW5TWusQyi6uA8A2bm6bTfE5A7w4E/Rk4Ab+wuuye9hHULRxQGAbCxeOQml2N0AZlmnEJlQTaOEP+OqtROtUyiaeAmAKm/gVr+/ADjAOoXIB/6BaucYfKSx0zqEooVnAKiyfr58NKqc28GDP9E/vQ39ejOufmmUdQhFCwcAqpxlGkN9/a8hONQ6hchXVA9HqWcZFt0Tt06h6OAAQJXTnfsJgNOsM4h86mTMSPzcOoKigwMAVUZr7n8A+aR1BpGvCT6KJbkLrDMoGrgIkMpvSfZ0iFwPDpxEg+ECcgZaEr+3DqFw4wBA5bUkfxhE/wKg1jol0kReg+oGAEUAXQAARWHg/0P1tr9qAoAYRCZCdbRFJv1LDxTvwvzk36xDKLw4AFD5XLlmKpzSEwB2t04JuX4AKyCyEkD+X39oaQ3cqg3o7tuA8/fqG9Kv+NPVNRhVMxFO/0QoGgFJAEhAkIA4b4HqWwBUefmboP+wDsABaEm+ZB1C4cQBgMpj2fJqdNffAz7W12v9AJ4E8DCgT8LF0xjT8zzmNBcqWjHw7/etgO4LyNsBHAbRt0OFq9i9dR8KG47FwgP7rUMofDgAUHm0Zn/GRX+eKAH4G6B3QOU+9Nc8hoVTt1pHbdfidfWo6jsIDo6CixMhOBhAzDorBC5BS5ILA8lzHADIe0uzc6FylXVGgG0C5Gao3gY3fifOnb7ROmhYrlo7EW7/cYCeCshpAMZaJwWW4sOYn/yNdQaFCwcA8lZr7m0AHgJQZ50SMFsA3ALFMrxWvGPI1+z9rjVXC+BECOYAchoXGQ5ZN+AeipamZ6xDKDw4AJB3rn5pFEo9TwB4i3VKgDwBwWXo3vprfLL5NeuYiljWUYfu/lMhzkeheqx1TmAonkd/zYG+vQREgcMBgLzTmr8M0POsMwKgB8DVcPWXWJB6yjrGVGvubVB8HIK54K2ig6C/QEuKa2vIExwAyButufcB+IN1hs+9CmAJ3NhPsWDGOusYX1myejIkPh/A+QCmWuf4mAL6XrSkbrEOoeDjAEAjd+WaqYi5T0F1knWKT70I6MWAXI6WZK91jK8t66hDd3EhgC8CmGKd41OvANiP+wPQSHEAoJFRFbTmb4PgJOsUH9oA4Pso1FzK67ZDtHhdPar7zgPwJXAQ2J4/Y17iRIiodQgFFwcAGpml+U9C9WfWGT7TB+ASuH0XYcGsLdYxgXbt6rEoxL8CwWcA1Fjn+IriY5ifXGydQcHFAYCGb2Cr3+cAjLNO8Q2RWwHns5g3I2OdEipXZ2agFPs2oGdbp/jIZhSLzThvr7XWIRRMfDobDZ9TvAw8+P9TDtDjMS9xGg/+ZTC3aQ1aEnMBnISBZx0QMBbx+KXWERRcHABoeJbkPgTIKdYZPuBCcRm2bp2NltSd1jGh15K8A4WaZgDfxcA2yVH3PizJnm4dQcHESwA0dANbvD4HYDfrFGOroJjLR7Yaac29AyLXQDVtnWLsJVQ7b8VHGjutQyhYeAaAhs7t/yGifvAXuQKxurfz4G+oJfkIurv3B7DEOsXY7ujX71lHUPDwDAANzZLcIRA8jOi+djbCkXNxToKbHvnJkuzpELkcwHjrFCMuxDkY8xqfsA6h4OAZABo8VYHgJ4juwf8pqHMQD/4+ND91I0qlgwA8bZ1ixIHrXgrVqL43aRg4ANDgLc2dBeAQ6wwbeh0KNYdhfmPWuoR24Nx0G4BDIGi1TjEhOBRL82daZ1BwcFqkwRl40t9KAHtap1SYC8XnMD/5Y+sQGoIl2c9B5LuI3pecNSjU7M2dJ2kwovbmoOEqbv0Sonfw74Xoh3jwD6D5qR/AkdMBRO1AOAPVfZ+3jqBg4BkA2rWBHf/aANRZp1TQy3D0PTgn9ah1CI1Aa+4dAG4GMNk6pYK6AaT5sCDaFZ4BoF1zil9BtA7+awD3CB78Q6Al+QhcPQJAh3VKBY3CwNMUiXaKZwBo567OzEDJWYXoPIglD3XezcV+IXNFthFx564IbRrUi2JxLz4ngHaGZwBo59zYVxGVg7/iebixd/LgH0LnptohsaMBrLBOqZBaxONfsY4gf+MZANqx1lwCwEoA1cYllZCBGzsSC2assw6hMro8OwVx+SuAt1inVEA/YvIWzE3krEPIn3gGgHZM8Q1E4eAvshYxOY4H/wg4L/UytHQcgHbrlAqoQsnlWQDaIZ4BoO1rzSUguhoqceuUMnsJcI9ES9Nq6xCqoKsyM+E69yP8z7Toh5aaMD8dpUWQNEg8A0A78tkIHPx7oHgfD/4RdE7TKrjuKRi4ZS7MqgDnM9YR5E88A0D/qTU3HiIdUB1tnVJGLoAPoiX5R+sQMrQkcyrE+SOAmHVKGW1BwZ2OhU2brEPIX3gGgLZnYcgP/gD0szz4E+Y33QpF2HfOG4MqOc86gvyHZwDozRY/XoWaSVmoTrNOKR+5Bi2JudYV5CNLc0ugaLHOKKMXMGprCnOaC9Yh5B88A0BvVtPwoVAf/EUeB/Sj1hnkM/XxT0Lxd+uMMtoTr9XNsY4gf+EAQG+m8knrhDLaCAdz0JLstQ4hn5kzvQeuvh8i661Tykc+YV1A/sIBgF53VXY2gIOtM8pEITKXm6LQDp2baoer51pnlI3gUFzRto91BvkHBwB6nYvwnhoX+TnmJW6zziCfm5+8CYrLrDPKJhYL74BDQ8YBgAYs66gD5MPWGWXyHOpjX7COoIDor7kA4X1mwDkD73UiDgD0T1v7zwAwwTqjDPrhyFmYM73HOoQCYuHUrXDdsyFatE4pg/HYWvqAdQT5AwcAGqBhPf2v38c5iTCv7qZyWND0OOBcYp1RFhridQ40JBwACFjSngLkMOuMMlgFyLesIyig+qq/DiBjnVEGR2170idFHAcAAsSdg/BtCqWAnstb/mjYFk7dCnEWAlDrFI8JVE+3jiB7HAAIAM60DvCeXIuW1P3WFRRw8xr/AsUN1hmeE+GmQMQBIPKuyswE8DbrDI9tRax0oXUEhUXpcwC2Wld47CBc0Za2jiBbHACizpXwfftXvRhzm9ZYZ1BIzE93QORH1hmei8V4GSDiOABEnpxhXeApkbUYXfVD6wwKGaf2OwBetM7wlIKXASKOA0CUtWb2ArCvdYanVC/iPf/kubm7dwN6sXWGpwT7D9wBRFHFASDSnJOtCzzWjlFbl1hHUEhtKV0GoMM6w1OiJ1onkB0OANEWrje/4ht83jmVzfl79UFxkXWGtzgARBkHgKga2A/8KOsMD7VjTf4a6wgKudFbWyGy1jrDQ8fgp6trrCPIBgeAqOopHQ0gPA8FUfwEi94Vxr3byU/mNBcAvdQ6w0OjMNo5wjqCbHAAiCoXJ1kneGgz+l1e+6fKiBd/BWCTdYZ3hJcBIooDQGTpCdYFnhG5DAubQvSBTL521l6bAb3SOsMzwgEgqjgARNHl2SkAZlpneERRLC62jqCI0djPEZ5nBLwVS1ZPto6gyuMAEEVx553WCR66C+em26wjKGLmN2ahuNc6wyMCib3DOoIqjwNAJLkhGgD0cusCiiiRK6wTvCMh+kygweIAEElymHWBR17BqJ6brCMoqvT3ADZYV3hCOABEEQeAqBm4///t1hne0Bu48Q+ZaUn2AvJ76wxPqB6E1lytdQZVFgeAqNnafxCAausMTwiWWSdQxIlcb53gkRqohOSLAQ0WB4CoUedA6wSPrEM++YB1BEVc/Yx7AbxsneEJ0YOtE6iyOABEjs62LvCG/A6LxLWuoIibIyVAf2ed4ZFwPRmUdokDQNQoQjIAuLdYFxABABznVusET4iE5LOBBosDQJQsuicOwd7WGR7oBuR+6wgiAEBd7F4APdYZI6bajGUas86gyuEAECWJ1FsABH+lr8g9AyuwiXxgzvQeAPdZZ3igDltyaesIqhwOAFGibliu8d1hHUD0b263DvCEcB1AlHAAiBQNx5tbS2H4tkXh8lfrAG9IOD4jaFA4AESKNFkXeKAL7anl1hFEbzIq8QzC8Ihg0TB8RtAgcQCIlqR1wIgpHubtf+Q7c6QE4G/WGR5IWAdQ5XAAiJZG64CR04esC4i2S/CgdcLISfC/JNCgcQCIisXr6gHsZp0xYiKPWycQbZ88YV3ggT34TIDo4AAQFVX9CQBinTFibuxp6wSi7XJKz1gneEDgagjOFNJgcACICkfDcGpvAxbMWGcdQbRdc5vWAOi0zhgxkYR1AlUGB4CoUJ1uneCBMHzDonAL/mvUCcNaIRoMDgBRoTrJOmHEBM9bJxDtlGKFdcKIqQT/s4IGhQNAZMhk6wIP5K0DiHYhbx0wYhKCLws0KBwAokJ0onXCyGneuoBoF/LWASPmIgSfFTQYHAAiIwSn9VRz1glEOyUI/mtUEPzPChoUDgDR0WAdMHJOh3UB0U65sTXWCR7gGYCI4AAQHUFfA6AobNhgHUG0U2O2rAeg1hkjxDMAEcEBIDrGWgeM0GYsPLDfOoJop+Y0FwC8Zp0xIiLjrBOoMjgAREeNdcAIrbcOIBqkYJ+pUg36ZwUNEgeA6Ki2DhihjdYBRIMU7AEg+J8VNEgcAKJgkToAqqwzRmirdQDRIAX9tVoN1eA/N4R2iQNAFDTmwzDR91kHEA2OFqwLRkhww3NB/8JAg8ABIAqqisEfAESC/qFKkSHBH1a3xLgOIAI4AERBIfALAAF1g/+hStGgIThbFR8d/C8NtEscAIiIvCTqWieMWKmHx4YI4L/kKOh3QnD6XPiNhIKi1jpgxKpDcBaDdokDQBRMqA7BAMBbkygoQjCsbuQAEAUcAKLguWnBfzMrBwAKjOCvufl0OgxfGmgXOABEwSJxIVq0zhgRQZ11AtEgBf0SQD9Egv48AxoEDgBRoYG/jS4ETzOkiAj20/QkBLcx0qBwAIiOoA8AfEIZBUWwX6uqHAAiggNAdGy2Dhih8VimMesIop1adE8cYXjyJkUCB4Co0MA/oMRB56oJ1hFEO5Wa3gAg6Pvo88FbEcEBICokBI/Tra6eZp1AtFNu1XTrBA+8ah1AlcEBIDqCfgYAABLWAUQ7pwnrgpHTMHxW0CBwAIgKkeCfAeAAQH7nuknrhJELxWcFDQIHgKjQUEz1CesAop2SMLxGQ/FZQYPAASAqVMMw1b/FOoBo52SmdcHIORwAIoIDQFSIrLVO8MBs6wCiXQjBa9TtsC6gyuAAEB156wAPTMXilcHeZIXCa8nqyQCmWGeMWMnNWSdQZXAAiIpCSN7UtTX7WicQbZ+zn3WBJ6TYbp1AlcEBICoWNm0C0GmdMWIu9rdOINo+eZt1wYiJrMeCWVusM6gyOABEiYbhMoB7mHUB0XaJHG6dMGKq4ThTSIPCASBa8tYBIxeCD1kKH1UBcKh1xogpOABECAeASNGsdYEHpmDpmibrCKI3uTq7F4DdrDNGTDgARAkHgCgRedY6wRNaOsI6gehNSnKkdYInVMPxGUGDwgEgSlSetk7wyAnWAURvIjjROsETMYTlM4IGgQNAlLzWvxyiResMD5yAZRqzjiACACy6Jw7Iu60zPNCPup4V1hFUORwAouT8vfrgymrrDA9MQE/7wdYRRACAxsZDAYy3zvDACsxpLlhHUOVwAIgaCckpvpJ7inUC0QA52brAI89YB1BlcQCIGpFwvMlFzrBOIAIAiJxuneCRcHw5oEHjABA1rj5uneCRmWjNBX/nNQq2KzMHQjVtneENfdK6gCqLA0DUVBcfBlCyzvCEYI51AkWcyH9ZJ3ikBLfwiHUEVRYHgKg5a6/NAJZbZ3hC8V/bdmAjqrxF6kAkHEOo4mk+AyB6OABEkeBB6wSPJHHVmmOsIyiiGvPHA5huneEJkQesE6jyOABEkoRlAADUPc86gaJKz7Uu8IxqeD4TaNA4AESRg4esEzz0flzdFvw92ClYLs9OAeQ91hmeKRU5AEQQB4AompvIAXjBOsMj1SjFWqwjKGJiMh9AlXWGR/I4b6+11hFUeRwAokrwZ+sED52PZcurrSMoIn66ugaCT1tneOhP1gFkgwNAZOkd1gUemoqtdWG5HYv8bmzVWQD2sM7wUJg+C2gIOABEVVXszpA8GGiAyud4SyCVnapA9QLrDA/1o+DeYx1BNjgARNVHGjsBJ0wbf+yL1iyfD0DldXX7+wA0W2d46EEsbNpkHUE2OABEmeuG69qfON/gWQAqG1WBq1+3zvCU4HbrBLLDASDSnP+zLvDY27G0/f3WERRSrfk5APazzvCUhGotEA0RB4Aoa2n8O4B26wxv6SIsUr6uyVvLNAYgXN/+gSzmJsPxdFAaFn5QRpmIQuQG6wyP7YsZufnWERQy3e0LIdjbOsNTgushotYZZIcDQNSVStdbJ3hO5CIszoyzzqCQuK59AgTfsM7wXEnD996nIeEAEHULmh6HSJt1hsd2Q5XzZesICok+dxFUJ1lneGwVFqSeso4gWxwACFC90TrBc4LPoDU3yzqDAu6Ktn0g+Lh1hudEllknkD0OAAQAYTwVWAPFEi4IpGFbpA5iscUIz57/byC/tS4ge/xwJKAl+Q8Ay60zPCc4FDPyC60zKKAS+U8BOMw6owyewrzG8L3facg4ANA/XWEdUBaC7+Dy1dOsMyhgrsg2QvFt64yyUA3ne52GjAMADXCqrgHQa51RBmMRj1/LSwE0aIvUQUyWABhjnVIGPaiJXWcdQf7AD0UacM60DRD8wTqjTI7CjNz/s46ggGhs/yKAY6wzykNuHHgOCBEHAHojkcutE8pG5H/RmjnIOoN8bmn7AUDI9vt/Eze873EaMj44hV6nKliaXwlgL+uUMlmFgnswn35G23Vd+wQU3McANFmnlMlKzEvszd3/6J94BoBeJ6KA/Mo6o4xmotq5ik8MpP+wSB0UStcgvAd/APgVD/70RhwA6M3c3ssBhPkb8ntxVTt3CaQ3a8x/DZBTrDPKaDOqikusI8hfOADQmy2YtSXUawEAQPUbWJoP84c9DcXS7HsAfNU6o8x+ibP22mwdQf7CAYD+k8QuAVCwziijGIDf4qr8/tYhZGxJ/u2Acx3C/VnYj2LxZ9YR5D9hftHTcJ0z/YXQ7xWuOhqu3oarMzOsU8jIVR17wsFNUB1tnVJm1+G8vdZaR5D/cACg7RP8yDqhAvZAybkV17VPsA6hCruiowFu8U9QDfsukQq4UXgv0zBwAKDtOyfxdwB3WGdUwL4ouLfjyhVh3PWNtufa1WMRK94BoNk6pexEbkNL0zPWGeRPHABox8S5EEAUbhs6BE717bj6pVHWIVRmyzrq0B+/GUAUNoVSaOmb1hHkXxwAaMfmNT4BxS3WGZUh70Sp53dY1lFnXUJlsnhdPbqLfwRwlHVKhfwBLU2PWUeQf3EAoJ0T90IArnVGhZyA7uIduHb1WOsQ8tjVL41Cde/NAI63TqkQF67y2z/tFAcA2rmWpmcADetDgrbnSBSr/oKr1k60DiGPXNc+AaWeuwB5t3VKBS3DgtRT1hHkbxwAaNck9nVE5ywAoHog3P67cVXHntYpNEJL2qajX+8D8A7rlAoqAfiGdQT5HwcA2rV5jcsBbbXOqLDZcIuPDWwUQ4F0VXY2JPYgVPexTqmwy9GSXGEdQf7HAYAGp4ivAIjaVqJ7QPRetOZOtA6hIVqaPwXqPAhgunVKhXVBi1+zjqBg4ABAg3Ne6mUILrLOMDAGwK1ozS3CIuX7xe9UBa25/4FqFHb4+0+Kb2L+Xq9aZ1Aw8LGoNHjLlleju/4ZADOtU4zcgoJ7NhY2hflpicF15YoxcKpbAfmgdYoJkTbUdzdjTnOYn+NBHuI3Ghq8Oc0FKL5gnWHoNFQ7j6A1s691CP2b1tzb4NQ8HtmD/4DP8uBPQ8EBgIZmfvImAHdaZxiaBTiPojX3WajyDJo1VUFr/v8BeATRPTMFAP+HeYnbrCMoWPgBRkO3dE0TtPQ0gHrrFGN/QlxacHbiReuQSLpyzVQ4paUAjrNOMdYNYB+0JPPWIRQsPANAQzdvRgbC+4wBnICiPofW3Ge4QLCCVAVLs3PhlJ4GD/6A4qs8+NNw8AwADc+ie+JoTDwC4ADrFJ+4H8BHef91mS1d0wQtLo7Yrn478xhGJQ7FHClZh1DwcACg4bsqvz/UfRQqcesUn+iF6g8Rr78Yc3fvto4JlZ8vH41R9V+G4gIAtdY5PtEPRw/EOamnrUMomHjakobvnMTf4cqPrDN8pBYiX0GpZxWW5j7KywIeUBW0Zs9Aff1yKL4EHvxfp/o9HvxpJHgGgEamNVcLkcciuN3qYDwBR76KcxK3W4cE0tL8KVD9JgBux/yfnsaW4sE4f68+6xAKLg4ANHJL25uh7mMA6qxTfOoRQP8XLalbrEMC4crM4XCcbwM4yjrFp3rh6CH89k8jxQGAvLEkdwEEvBywc09A9KfIt/8ai95VtI7xlUXqoDF3CiBfBHCYdY6viXwK8xI/t86g4OMAQN5QFSzN3w7gBOuUAMhA5Mco9V6NBbO2WMeYunb1WBRicyFyAYCUdY7/6W2YlzwNImpdQsHHAYC8c3XbbijFngYwxTolIHoBuQVaugzzm+6yjqmope0HwHU/Ckc+HMmH9gzPqwBmoyX5knUIhQMHAPLWwMKtm8E7TIZG5FkofgNxrse8GRnrnLJozewFic2B6ocBvNU6J2BcKE7G/OSfrEMoPDgAkPdac4sAfN06I7BEHoe6y6Cx2zC/8TnrnBG5om0fxGKnAJgDruYfPtWvYn7q29YZFC4cAMh7i9RBY/4WACdbp4TAGijuQEzuQG/f/Vj4lvXWQTu1ZPVkSNURAE4E9EQA062TAk9xM1oS7+N1f/IaBwAqj+vaJ6DgPg4u7PKSQrECog8B8gCAf2DU1ufMHgG7bHk1uuvfCsX+EByOgdX7s0xawms1Cu5BWNi0yTqEwocDAJXPldn94MhD4FMDy6kfIisBfQaKlRDNQZGDunmsaXoBi8Qd0a++SB3MyOwJx0kCSEAlCWAWRPaB6lsAVHnxm6Dt6kYUc0g2AAAgAElEQVSp9A6cm37WOoTCiQMAldeS3IcguA58rVlQKRa6pdjXLX093bFCTx9K/UUp9onTXyhCVUQgCnHdeFWVVtW6iFXFS9W1dVpTX6fxmlEarx4F/ruzoICeiZbUDdYhFF58Y1P5LcleCJFvWWcQBcgX0ZL8rnUEhRsHAKqM1twvAXzMOoPI//RKtKTOta6g8OO92lQZhQ3nA/izdQaRz92B9nYOylQRPANAlXPlijFwah4AMNs6hch3RJ5FX+lwrvinSuEAQJW1pG06JHY/gEbrFCIfycKJH4lzpr9gHULRwQGAKm/pmiZo6T4AU61TiHzgBahzJOY3Zq1DKFq4BoAqb96MDFw9BsDL1ilExl6FOsfz4E8WOACQjQWplXD1BACd1ilERjZBnJMC/7wHCiwOAGRnQeopqJwKkdesU4gqauA1fyLmNT5hnULRxQGAbM1PPAQtHQNgo3UKUYV0wcUJaEk+Yh1C0cZFgOQPV+X3h6t/AjDZOoWojDYC7oloaXrMOoSIZwDIH85J/B3AkQB4GxSF1UsolY7iwZ/8gmcAyF+uzidR0rvAxwhTuLSjVDoW56bbrEOI/olnAMhf5iZyiLnvArDcOoXII8/Aib+TB3/yGw4A5D9zm9bA7TsUitutU4hGROQuFNwjuMMf+REHAPKnBbO2YE3+PQAWW6cQDYugFX3rT+be/uRXXANA/tea+wyAH4OvVwoGhVv6Nhakv2YdQrQzMesAop1wksnkqRPvv+bjVRtfmL41fQjg8CVL/iX9fdjtpu/KlN99c+aECRPGjBkz5qlNmzb1WncRbQ+/UZHvNDc3j+7p6VkA4AK84amBhd3TeOn0RShO2MMujmgH4ptewZQbF6Fm3co3/uktqtoqIj/MZrNrrNqItocDAPlGIpHY3XGcjwE4H8CE7f01pbqxeOX9X0ZP00GVjSPaifq2R7HbHy+G07N5R39Jv4j80XXdH+RyuUcr2Ua0IxwAyFwymdwPwCdEZC6A2l3+DSLoOvRMbDxmASBcx0qGVDH+4evRcPeVgLqD/bseVNXv5nK5WwFoGeuIdooDAJlpamo6QFW/CeDk4fz93TMPw6vv+TzcurEelxHtWqxnMybf9F3Urx72lv7/UNWv53K5W8BBgAxwAKCKS6fTzar6dVU9HSN8DZZGN+DV93wBW3lJgCqoLvckJt/0XcS3rPfil3taVb+dy+Vu8OIXIxosDgBUMY2NjXvH4/EvqeqH4eUdKCLYdND7sfHYhdBY3LNflujfiVvC+Aeuw4T7rhnKKf/B/doij7iu+7/bzggQlR0HACq7RCKREJEvicgClPHW08LkBF75wIUo7JYs1z+CIqxq/Rrs9oeLUPNS2Xf0fVBEvprJZO4p9z+Ioo0DAJVNIpFIOI7zVQBzAVTkq7lW1WLjMQuw6cD3cs8A8oZbwrhHf4+Ge1sh/X0V+8eKyJ9c1/0a7xqgcuEAQJ6bMmXKqFGjRn0ewP9gMKv6y6Bv9zTWn/Y59O2+l8U/nkKi+pUcJt/6A9S8sMIy41bXdT+dz+fzlhEUPhwAyEvS1NR0tqp+B4D5bj0qDjYdOgedR50DjVdb51CASLGA8Q/9FuMfuA5SKlrnAEAPgJ9WVVVdtHLlyi3WMRQOHADIE8lk8mAAl4jIodYt/65/0gy8evIF6G2cbZ1CAVCX/wcm3fYjVG305QP8XhCRL2cymWvAWwdphDgA0IjMnDlzz1KpdLGqngWfv562zjwU64//JLcSpu2Kb1mPCXdfgTHP3AWo74+tj4nIZzOZzEPWIRRcvv7AJv+aOnVqfW1t7acBXAhgtHXPYGlVDTYd9H50HXEW3Oo66xzyAenvxfiHl2H8g7+BFAvWOUOhInKjqn6Ozxmg4eAAQEOWTCZPE5GfA5hu3TJcpTGT0HnkXGze/yRuJxxVqhj1/H2YeNevEN/0inXNSLwG4KvZbPZSACXrGAoODgA0aMlkcorjON9X1bOtW7xS2C2JziPORvfeRwLCt0NU1OWeRMNfLkfNi6usUzyjqn+PxWLntrW1PWndQsHATzwalGQyeYaI/ALAJOuWcujbc290HnEWtu71DusUKqO63JNouOdK69v6yqkI4Ieu6y7K5/O91jHkbxwAaKcaGxuTsVjsVwCOt26phN7G2dh4VAvvGAiZuvanMOGeJajteNY6pVLaRGRhJpO52zqE/IsDAO2I09TUdK6q/hABWuTnlb49ZmLTwR/Aa/scwx0Fg0pd1Lc9ivEP/iZKB/43UhG5tq+v77Nr167daB1D/sMBgP5DMpncT0SuAHCgdYu1/vF7YPMhH8Tm/U+CVplsakhDJKV+jFp+LyY8+GtUrefieAAvqOoncrnczdYh5C8cAOiNJJVKnQ/gewC4dd4blOrGYvNB78WWt5+K4phQLoMIvPiW9RjzxC0Y+/jNiPVsts7xHRG5pra29hPLly9/zbqF/IEDAAEAEonE7iLSKiInWrf4mjjoSbwNm99+KrbOOhzKywO21EVd/h8Y++StqH/+fojHj+gNobyInJXJZB60DiF7HAAIqVTqA6p6mYhMtG4JktKYidiy73HYcsCp6B/P3QUrKb5lPUY/cxfGPn5T0O/ht1AEcFE2m/0WuG9ApHEAiLCpU6fW19TUXCwi51u3BJo46J2xD17b+yh0730kSqMbrItCKbZlA0avuB+jlt+D2rXPAfy2PyIi8oiInNXW1paxbiEbHAAiKpVKHQTgOgB8Xq6XxEHvtLei+61H47W3HsVhYIScns2oX/03jH7+r6hb/Tee4vfeZlX9VC6Xu8Y6hCqPA0D0xFKp1OcAfAtAlXVMmKk46G2cjZ6mg7G16SAUpqSsk/xPFdWvZFGfeQz1bY8O3L7n8ix1uYnIDf39/QvXrFnTad1ClcMBIEJmzpw5qVgs/gbAsdYtUVQcMwk96YFhoCf5dri1kdteYbucni2oyz05cNDPPIbYlvXWSVG1BsAHs9ns49YhVBkcACIinU6/3XXd3wFIWLcQACeGwsTp6J3ejN7p+6IwdSYKkxqtqyoitmUDajue/dcfNS+18Xq+f/QC+EQ2m221DqHy4wAQAU1NTXNV9VcA+PxbHyuOmYTeGfuib4+ZKExpQmG3ZODXEMS2bED1q3lUv5xBzYurULvmGcT5Dd/3VPWy+vr6Ty9fvjxQz0emoeEAEGLpdLpGVS9V1fOsW2h4SvXj/jUMFCYnUGzYE/3jdx/YjMgnexCIlhDb9CqqNr2M+MYXBg74r+RQ/VIbN+QJtgf7+/vndHR0rLMOofLgABBS6XR6muu6NwI4xLqFvKdODMWxu6E4fncUJ+yB4tjJKNWNhVs/DqX6ca//97qx0KqaYf0zpL8XsZ4tcLZuQqxnM2JbN/3rv8c3vYJ410uo2vQSYptegXChXli9KiJnZjKZe6xDyHscAEIolUodC+A3COmje+l1qrpBRDb88z8BrP+3/w3XdbsKkxrrpaqqWKwd1+eOnVSrVbU9xYapVQDgbHyxN9bfM9rZvL7X6dkUl0JfdfXGjq0AxjqOE3Ndd+y2TaImA5i4nT/iJr95qpR+EfnvTCZzqXUIeYsDQMg0NTV9XlUvBuCP88M0Er0A2kUkr6o5DGzjmi+VSnkA7fl8/hUA5qvnZs2aNbG3t3d6LBZLqGpCVZMiksTAgtMEgDGmgeSVax3HObetra3POoS8wQEgJI4++uh4R0fHL3i9P5B6ACwH8DSAZ0Tk6UKhsKKjo+NFAGqbNnKzZs2aWCwWZ6rqvqo6G8C+AGYDGG+cRkP3QHV19ftWrFixwTqERo4DQAik0+mxqrpMVU+wbqGd23Zq/mFV/QcGDvhP53K5NkRwT/ZUKjUDA8PAvqr6NhE5DMB04yzatVUickomk2mzDqGR4QAQcNOnT58aj8dvFZH9rVtou14UkQdU9UEReSCTyfwdPjht71eNjY17OI5zoIi8E8DhAA4CH03tRxtV9f25XO4+6xAaPg4AAZZIJN7mOM6tAPa0bqF/eUZE/iwi96vqw5lMho+qG4Hm5ubRPT09h2BgGDgWwDvARYd+0auq5+RyuWXWITQ8HAACKplMHi8iNwAYa90Scd0AHgZwK4A/ZLPZNcY9oTZlypRR9fX1xwA4VUROAi8ZWFMA38xms4usQ2joOAAEUCqV+hiAS8FvQlaeAnC767p3JBKJB++9996idVBESTKZnC0iJ4nIiap6OHj3iwlVvayxsfGTfC8ECweAYJFUKvW/AL5oHRJBT6vqMsdxrufiJ39Kp9OTXdf9oKqeKSJHgMNApd3e29t7+rp167Zah9DgcAAIDkmlUj8G8BnrkAh5DsANpVLp+vb29uetY2jwZs2aNbG/v/8UVT0DwEngMFAp9zuOc2pbWxv3gA4ADgDBEEulUlcAmGcdEgFrVXXptm/6z1rH0Mht2xb7dAy8f/YzzomCRwuFwklr167daB1CO8cBwOeOPvro+Jo1a1oBnGXdEmIugLu3Xcf8A69jhldTU9MBrut+VEQ+BO5QWE7P9ff3H8cHCfkbBwAfS6fTNa7r/hbA+6xbQmotgOsA/IKr96Nl2rRpdVVVVaeKyEcxcHsheW+liByXyWQ6rENo+zgA+NSUKVNGjRo16o/gh5PXSgD+COBX2Wz2bnBTnshLJpP7bRsEzgEwyronZHLxePzYVatWZa1D6D9xAPChbZuf3AzgXdYtIdKtqtcB+FEul1tpHUP+k06nx7qu2wLgcwCmWfeEyEvbzgRwTY3PcADwmWnTpjVUV1f/CcCB1i0h8SKASwuFwmIuSqLBSKfTNar6IVX9bwD7WPeExCuqelwul3vaOoRexwHAR7Z9A7kTwMHWLSGwCsAvXNddnM/ne61jKJhSqdThAP4HwCng5+VIveo4ztFtbW3PWYfQAL6gfWLatGl1NTU1t6vqUdYtAbdcVb+Ry+VuRAgepUv+kEwmZzuOc+G2fQVo+F6Ix+NHck2AP3AA8IHm5ubqnp6ePwA42bolwFaIyMWZTOY6RPDRulQZiUTiHY7jfAXAqdYtAbZGVY/M5XLt1iFR51gHEGK9vb3Xggf/4WoXkYUzZszYN5PJXA0e/KmM8vn8I9ls9jQRORzAPdY9ATVDRO5MJBK7W4dEHc8A2IqlUqlrAfyXdUgAdajqNxsaGq564okn+q1jKJoSicQJjuN8C8BB1i0B9HShUHgXF+fa4QBgR5LJ5K+23X9Mg7cVwKV1dXXfXr58+WvWMUQYeC+fLiLfB9BoHRMkqvp3VT0mn893WbdEEQcAI01NTT/YdpsRDY6KyI2u636e1w7Jj6ZOnVpfW1v7BQBfAFBn3RMgD3V3dx//8ssvd1uHRA0HAAPJZPKbIvJV644AedRxnM+2tbU9bB1CtCuJRCIRi8W+xzsGhuT2GTNmvIfP4agsDgAVlkqlWgAsse4IAhFZB+BLmUzmGvCWPgqYZDJ5JIBLRGR/65YgUNXLcrncQuuOKOEzsisonU4frarXgz/3XVERubavr++97e3tj1jHEA1HV1dXe1dX1+UNDQ3rMLCtd7V1k5+JyAENDQ09nZ2dD1q3RAXPAFRIOp1+q+u6DwIYb93ic20isjCTydxtHULklcbGxmQsFvsVgOOtW3xOAZydzWavsw6JAg4AFZBIJHZ3HOcRcIXwzhQB/NB13UXcupfCKplMniEivwAwybrFx3pF5NhMJsMzAWXGAaDMpk2bVlddXX0PgEOsW3zsHyJybiaTecI6hKjcmpqadgPwA1U927rFr1R1g4gcls1mV1m3hBkHgPKKpVKpPwA4zTrEp/pU9cJcLvdjcAc/iphkMvkeEbkcwG7WLT61urq6+tAVK1ZssA4JK24FXEbJZPJH4MF/R1Y4jnNoLpf7AXjwpwjK5XI3i8i+AG61bvGpvQqFwh8TiUStdUhYcTV6mSSTyU+KyDesO3xIAfyyUCh8MJ/Pd1jHEFnq7Ozs7uzs/O348ePXi8i7AFRZN/nMDBFJdHZ2/sE6JIx4CaAM0un0oa7r3gve9vPvXlXVBblc7hbrECK/aWxs3DsWi/0awNusW/xGRM7PZDKXWneEDc8AeCyZTE4BcBeACdYtPnNnf3//ie3t7VzoR7QdmzZtWj9x4sSlqloF4DDwC9obHTt+/Pi/dnV1cRtwD/EF5qEDDjigqrOz8y8AjrBu8ZGiiHw5k8n8ANzNj2hQUqnUKQCuBfcNeaMXS6XSAe3t7S9ah4QFFwF6aOPGjT8AD/5vtF5VT85kMt8HD/5Eg5bNZm8DsB+Ax61bfGQPx3F+19zczEurHuElAI+kUqkPicj3rDt85EnXdY/N5/NPWocQBVFnZ+emcePGXSMiewLg8wQAiMj0/v7+8V1dXbdbt4QBBwAPpFKpfQHcBC76AwCIyDWFQuEDa9asWW/dQhRkXV1dxc7OzpsaGhpeBHAC+JkNETmkoaGhvbOz8x/WLUHHNQAjlEgkxjuO8xiAtHWLD/RtW617mXUIUdg0NTW9U1VvALCHdYsP9DqO8862tjaeYRwBrgEYGXEc52rw4A8Ar7iuezQP/kTlkclkHuzv7z9QVf9u3eIDta7rLkulUuOsQ4KMA8AINDU1fQrc6Q8A2gAcns/n+eheojLq6OhYt3Xr1iMAcC8NoAnAz6wjgizy15OGK51Ov3Xb6bio79z1UDweP7atrW2tdQhRFHR3d/d3dnYua2hoaABwsHWPsdkTJkxo6+zsfMY6JIg4AAxDOp2ucV33DgDTrFssicgNruu+P5PJbLZuIYoY7ezsvH3ChAldAI5HtNdzvXvcuHG/7erq6rIOCRpeAhgG13UvxsA9upGlqj/NZDJn5vP5XusWoqjKZrM/EZHTAWy1bjE0znGca8EvtEPGH9gQJZPJ40XkZ4juxF0CcF4ul7vYOoSIgM7OzhXjxo27W0Q+AKDOusfIjIaGhmJnZ+d91iFBEtWD2LDMnDlzUrFYfBrRvQ2noKofyeVyN1qHENGbNTY27h2Px+9S1anWLUaKjuMc2dbW9rB1SFDwEsAQlEqlXyC6B/8+ETmTB38if2pvb3++WCweDiBn3WIkXiqVrk2n02OtQ4KCA8AgNTU1LVTVM6w7jHSr6mmZTOaP1iFEtGPt7e05AEcDWG2cYkJEUq7r/sS6Iyh4CWAQZs6cmdp26n+UdYuBTSJyciaTecg6hIgGZ/r06VOrqqruBPBW6xYLIvJ+fmHZNZ4BGIRisfhLRPPg36mqx/PgTxQsHR0d6wqFwhEAHrVusaCqv0gkEnyU8i5wANiFpqameRi4zzZSVHUDgKNyuVwkP0CIgm7t2rUbXdc9IaJbB+/hOM53rCP8jpcAdmLbqv/nAEy2bqmwzQCOzWazj1mHENHIbPscuxdAs3VLhamIHJvJZO62DvErngHYif7+/p8hegf/rap6Gg/+ROGwatWq9ar6bgArrVsqTFT1l4lEotY6xK84AOxAKpU6WUTOtO6osIKInJ7L5biZBlGI5HK5l0XkOAB565YKmxmLxS60jvArXgLYjnQ6PdZ13WcBTLduqaB+Vf1gLpfjU8aIQqqpqSmtqvchWvuZFB3HObitrS2KayF2imcAtsN13e8gWgf/kojM5cGfKNwymUwbgBO2LfKNirjruovBre//A38g/yaVSh2OgWdMR+bsiIh8IpPJXGXdQUTl19nZ+cr48ePvE5GPIDqPM99zwoQJmzo7O7lN8BvwDMAbHH300XEAv0S0fi7fy2Qyi60jiKhy8vn8IwDOBuBat1TQN6ZPnx7V5yRsF88AvIGIfFxE5ll3VNCN2Wz2YwDUOoSIKquzs/P58ePHbxWRqOxzUu04zuSuri7uELgNB4BtZsyYMSEWi/0OQL11S4U81tvb+74tW7YUrEOIyEZXV9dDDQ0NkwAcbN1SCSIye9y4cXd0dXW9YN3iB1E61b1TsVhsEYBJ1h2VoKpZETl13bp1W61biMhWJpP5rKreZN1RIRKLxS5BhNZ47QwHAACJRGKWiHzcuqMStq3+PTmTybxi3UJEvlDq6+v7MCLy3ABVfUcqlfqwdYcfcAAA4DjOjxCN1bD/vNc/ajuCEdFOrFu3bmt/f//7Abxo3VIh35kyZUoUH/D2JpEfAFKp1MkATrLuqJDP5/P5v1pHEJH/dHR0rHMc54MAorAuaNqoUaO+YB1hLdKLAI8++uj4pk2bfgdgN+uWCvhNNpuN/AueiHZs48aNaxsaGjYjGl+KDh43btx1XV1dXdYhViI9ADiO8xkM3Asbds90d3e/t7u7u986hIj8rbOz828TJkxIAHibdUuZVQHYo6ur60brECuRXQmZSCTGO46TBTDBuqXMukTkoG1bgBIR7dLUqVPra2trHwYw27qlzNR13cO2bYwUOZFdAyAi/w/hP/iriMznwZ+IhmLdunVbXdd9bwSeGSCO43zTOsJKJAeAWbNmTRSRz1h3VMC3MpnMH6wjiCh48vl8XkTOQfh3Cj0umUweaR1hIZIDQKFQ+DyAsdYdZfZgNpuN7GRLRCOXzWZvA3CJdUe5ichF1g0WIjcApNPpyQA+Yd1RZptc1z0LQMk6hIiCzXGcLwF4yrqjzA5PpVLvto6otMgNAK7rfhnAGOuOMvtEPp/PW0cQUfC1tbX1OY7zYQA91i3lpKrfsm6otEjdBtjY2LiH4zhXI8S7/onIDdls9mvWHUQUHhs3bnw17PsDiMj0hoaGRzs7OyOzaDpSZwBisdiFAOqsO8qoo7+/f6F1BBGFTyaT+RmAW607ymnbWYDI3B4fmQEglUrNALDAuqOMXMdx5q5Zs6bTOoSIQkkdx5kP4CXrkDI6IJ1Ov8c6olIiMwCIyIUAaqw7yui7bW1t91pHEFF4tbW1vaqqH7XuKCfXdb+JiJwFiMQagGQyOQVAK4C4dUuZrHJd90NdXV1F6xAiCreurq5VEyZMmAVgH+uWMpkyYcKExzo7O1dbh5RbJM4AbNv0p9a6o0xURD6ez+d7rUOIKBri8finAbxq3VFG/20dUAmhHwCmTp1aH/JTVoszmczd1hFEFB2rVq1aLyJhfrrou5LJ5MHWEeUW+gGgrq5ugYhMtO4okxdd1/2SdQQRRU8mk1kK4M/WHeUShe3iwz4AxFQ1tP8SReQT+Xw+ss+yJiJb286uvmbdUSZzkslko3VEOYV6AEgmkx8A0GTdUQ4ickMmk/mjdQcRRVcul2tX1UXWHWUSF5HzrSPKKdQDgOM4/8+6oUw2F4vF0J7ZIKLgyOVyl6jq3607yuS8VCo1zjqiXEI7AKRSqcNV9R3WHeUgIt9ub29/0bqDiAhAyXGcTyGcjw0eIyKh3V01tAMAQnobh6pmReSn1h1ERP+UyWQeEpEbrTvKQVXPb25urrbuKIdQDgAzZ85MAQjldo6O4/x3W1tbn3UHEdEblUqlLyCcTwzcs6en5wzriHII5QBQLBbPQzh/b3dz4R8R+VE+n8+r6g+tO8oklHvJhO4gefTRR8dFZK51RxmUAHzWOoKIaEf6+vouBrDGuqMMjmxsbNzbOsJroRsAOjo6TlPVqdYdZbA4m80+Yx1BRLQj69at26qqF1p3lIPjOC3WDV4L3QCgqudaN5TBpng8/nXrCCKiXcnlctcCeMy6w2sick7YFgOGagBIp9PTAJxg3VEGP161atV66wgiokFQ13W/ah1RBrtt3bo1VIvLQzUAuK57LsL3iOMu13V/Yh1BRDRY+Xz+TwDus+7wmoicZ93gpTANAA6AedYRZfA97vdPREET0rUAx6XT6dBsLx+aASCVSp0IIGwPblhfVVX1M+sIIqKhyuVy9wMI26PKpVQqnWMd4ZXQDAAAQnVqBgBU9TsrV67cYt1BRDQcIhK6tQAiMh8hudQcigGgqalpNwCnWnd47MX+/v5fWEcQEQ1XJpN5CMDt1h0e2zOVSoVisXkoBgBV/SCAuHWHl0Tk4rVr14ZxW00iipavIWQPChKR/7Ju8EIoBgAROdO6wWOv9vX1XWEdQUQ0Utls9nEAd1p3eElV35dIJGqtO0Yq8ANAIpHYXVUPt+7w2M/57Z+IwiKEzwgYE4/HA38ZIPADQCwWm4OQLMjYpk9Vf2UdQUTklVwu92cA/7Du8JLruoE/8xz4AUBV51g3eGxpLpd72TqCiMhLInKJdYPH3jNlypRR1hEjEegBYNvWv4dad3hIS6USd/0jotAZP378rwF0WHd4aNSoUaNOtI4YiUAPAK7rnoGA/x7+za3t7e3PW0cQEXntiSee6Afwc+sOLwV9AXqgD54iEqrT/67rhm2hDBHRvziO80sAm607vKKqpzQ3N4+27hiuwA4AyWSyUVUPse7wiqr+PZ/P/9W6g4ioXNra2jar6lXWHR6q7+3tPcU6YrgCOwAAOB2AWEd4RUQus24gIio3x3FC9VkX5IXogR0ARCSwU9d2dDuO82vrCCKicstkMs+KyCPWHR46rrm5udo6YjgCOQBsu+ZymHWHh65va2sLzXUxIqKdUdXLrRs8NKavry+Qx6NADgC9vb3HAqix7vCK67phejMQEe1Ud3f39QjRYkDXdU+ybhiOQA4AQf1h78Cz+Xw+TKfDiIh26uWXX+4G8BvrDg8F8pgUyAFARAK/B/M/iQi//RNR5ITss2/fpqam6dYRQxW4ASCdTjcDaLTu8EhvX1/ftdYRRESVlslkngDwpHWHV1zXPd66YagCNwCUSqVAb734RiJy89q1azdadxARWRCR0OwJICKBuwwQuAEgiD/kHVHV660biIislEqlZQBK1h0eOe6AAw6oso4YikANANuevHS4dYdHthQKhdutI4iIrOTz+ZdE5AHrDo+M3bhx4zusI4YiUANAfX39uxGe2/9uXrt2bY91BBGRJVVdZt3glaCdoQ7UACAix1g3eCVML3oiouFyHOcGAEXrDo+82zpgKAI1AAB4p3WARzar6p+tI4iIrLW1tb0KIMd10y0AAA+rSURBVCwPQtt/6tSp9dYRgxWYAWDb9f/9rDu8oKp/yOfzvdYdRER+ICJhOSNaVV1dfZB1xGAFZgAYPXr0wQACtcJyR0L0YiciGrFYLPZ7AP3WHV4QkcCcqQ7MAOC6biAftrAdr9XV1d1lHUFE5BerVq1aDyAUdwNwACiPUNz+p6p/Wb58ecG6g4jIT0TkDusGjxyGgBxbAxEJwBGRQ6wjvBCiFzkRkWdc1w3LZ+P4dDq9t3XEYARiAEilUs0AJlh3eCEej3P1PxHRv8nlck8D6LDu8IKqBuKMdSAGAITk9j8ReX7VqlVZ6w4iIp8KyxekQByzOABUkKpy618ioh1Q1VBcBnBdNxDHrKAMAIHaX3lHwvLiJiIqBxG5EyHYFVBEUslkcop1x674fgBIp9NjATRZd3igW1Xvt44gIvKrbDa7CcDD1h1ecBxnf+uGXfH9AKCq+wAQ646REpEHuPsfEdEuhWWflH2tA3YlCANAKLb/RUg2uSAiKqcQPR6YA4AHfP9DHKQHrQOIiPzutdde+xtCsA5AVWdbN+xKEAYA3/8QB6FYW1v7mHUEEZHfvfzyy90AnrLu8MDezc3N1dYRO+P3AUAANFtHeOAfy5cvf806gogoIMJwGaC6t7d3pnXEzvh6AEgkEo0Axlt3eICn/4mIBklVQ/GZ6ffLAL4eAETE1z+8wQrLi5mIqBKKxWJYPjN9vYbN1wMAfP7DG6xYLBaK+1qJiCqho6NjHYC8dYcHfP0llgNA+XW0tbWttY4gIgqYMHxx4gAwXCISigWA1gFERAEUhjsBpqVSqXHWETvi6wEAQNI6YKRUNQwvYiKiihKRp60bvOC6rm+PY74dAJqamnYDMMq6wwPPWAcQEQWNiITiszMWi3EAGKpSqeTbH9pQuK4bihcxEVEltbW1rVXVDdYdI6WqCeuGHfHtABCLxRLWDR7oSyaTq60jiIiCyHGcZ60bRooDwDCoahjOADx77733Bn5PayIiI4E/gyoivj2W+XYAAJCwDvBAKBaxEBEZCfwAAB8vZvftACAiCesGDwT+9BURkZVSqRSGL1EJ64Ad8e0AEIZLAKrK6/9ERMNUW1sbhs/Q0TNnzpxkHbE9fh0ABMAM64iRchwnZ91ARBRUK1as2ABgs3XHSBWLRV9+ofXlADB9+vQ9ANRad4xUPB5vt24gIgq4vHXASPn1TgBfDgCxWCzw3/4BrF+5cuUW6wgioiBT1TCcSW20DtgeXw4AIrKbdYMHwvCiJSIyJSJ564aREhGuARgsEZlo3TBSYXjREhH5QN46wAMcAAbLr9PSUITktBURkamQLKb25ZdaXw4AqurLH9YQcQEgEdEIlUqlvHWDB3z5pdaXA4CINFg3eGCNdQARUdCpauC/TPn1srYvBwBVnWzdMFKq+op1AxFR0OXz+S4ABeuOkfj/7d1rjFx1Hcbx53dmdtutQtkpcmnrOnNmXNYUqVbQSIk2IQgFLFFjUBRiuMgLjfhCUGMMqIlBMcEY44WLgFEjEggxSgqNQlGCRFCBLlgy58zs2riBuju72lLYzv5/vug2KZPetjOzv///zPNJ+q4vvi82e55z2XNUlVcAFsDLtbQQuVwu+M9YEhF5Yso6oE0FeHi89S4IyMZDgM65/1g3EBFlROgnVLmhoaHl1hGtvBwAGXgIcG+apsG/vpKIyAciEvwJVT6f9+7E1scBINh3uSRkUwDUOoKIKAtUNfQrAHDOeXdi690AiOP4eAB56442Bf/DSkTkC1UN/gpAFEXendh6NwBUNfiPAAEI/oeViMgXIpKFkyrvjm3eDQARWWLd0AEcAEREHZKFWwAAvDu2+TgA+q0b2qWqu6wbiIgyJPiHqn08ueUA6IIoil63biAiyoooioJ+EdA8745t3g0AeHiZ5BhwABARdU4Wfqd6d2zzbgA0m03vVtJCqWoW1ioRkRey8DvVOefdsc27AeDjfZJjkIW1SkTkiyz8TvXu2ObjAPBuJR2D4NcqEZFHgh8APh7bvBsA8PBBiYXKwuUqIiJfZOR3qnfHNu8GQEZuAWThh5WIyAuqGvwVAPAWwJE55/qsG9qVkT9ZISLyBQdAF3g3AJCBj+hkYcQQEfnCx/vnC6WqzrqhlXcDIJfLBX/2LCLHWTcQEWWFiBxv3dAuH18Q590AyMK9HlX17qtPREShysjvVO9Obr0bAMjGvZ63WwcQEWVFFEXD1g0d8Jp1QCvvBsDc3FzDuqFdIjJi3UBElBWqepp1Q7ucc94d27wbAPl8Pguf0i0ODw+vso4gIsqI9dYB7YqiaKd1QyvvBkCz2czCAECz2fygdQMRUejK5fJbAZSsO9qlqpPWDa28GwD1ev01ZODbz6q6ybqBiCh0zrlLrBs65GXrgFbeDYB5deuAdonIJXEcL7fuICIKWRRFn7Ju6IS+vr66dUMrLweAqtasGzpgqYh8wjqCiChUlUpljaq+z7qjXao6uX379v9Zd7TycgCISN26oRNU9UsActYdREQhUtUvAxDrjnaJiJcntV4OAAD/tA7okEqpVPqkdQQRUWjiOB5W1UxcRRWRF60bDsbLASAiz1k3dIqI3FKpVIJ/jSUR0SK7FUAmvqvinPPymOblAMjn888jAx8FmneKc+4b1hFERKGI4/hjAC607uiUKIq2WTccjJcDYP5hidS6o4OuKxaL51tHEBH5bv7v/m+z7uikZrP5rHXDwXg5AOY9aR3QQRJF0T3FYrFoHUJE5KtisbjUOXcvgCx8/Ge/2tjY2IR1xMH4PACesA7osJOjKNpSqVTeYh1CROQhiaLoThF5v3VIJ4nIn60bDoUDYHFVnHObOQKIiN4gF8fxHQAusw7pAm+PZd4OgDRNRwG8Yt3RBetUdStvBxARAWvWrHlzqVS6H8CV1i3doKqPWjccircDAIAD8Ih1RDeo6juiKHqmXC5vtG4hIrISx/Hwnj17nhSRrLzvv1UtTdOXrCMOxecBAACbrQO6qKCqvy+Xyz8fGRlZYR1DRLRYNmzYkI/j+DoATwM43bqnix6yDjgcrwdAf3//ZgBN644uElW9fHZ29vlSqfS5SqWyxDqIiKiLpFQqbRofH38awPcBHGcd1GVeDwDv37Ecx/EjAM6z7lgkO0TkNlW9J03TcesYIqJOiON4uYhcqqrXAlhn3bNIGgMDA6eMjo7OWoccivcDoFQqXS0it1t3LDKnqk+JyBYR2eqcG63Vat59S5qI6GAqlcrxc3NzIyKyHvtO4DYAGLCtWnR3pWnq9YON3g+AkZGRFbOzsxPIyDuh29AAMAlgZv6fs80hInqD5dh3SX85gFONW8yJyMYkSbx+js37AQAAcRw/AOAj1h1ERERHYWJoaGjoscce8/oZNq8fAtyvB28BEBFRoFT1Tt8P/kAgAyBJkocBjFl3EBERHYHmcrm7rSOORhADAPvud//UOoKIiOgINler1cQ64miEMgDQbDZ/AmCXdQcREdGhiMj3rBuOVjADYHx8vAHgHusOIiKiQ3g2SRJv3/3fKpgBAABRFN2KbL8ZkIiIAiUiNwNQ646jlbMOWIipqanG4OBgEcC7rVuIiIgO8EKapp9HQAMgqCsAAKCq3wTg7asViYio96jqTQjsBW1BXQEAgOnp6ZnBwcGVAM6ybiEiIgLwj1qt9kUEdPYPBHgFAACiKLoRwLR1BxEREYDrEdjZPxDgFQAAmJqaevWEE06YE5EPWbcQEVFPeyBN05utI45FkFcAAGDZsmU/APCSdQcREfWs16IousE64lgFOwBGR0dnnXOfRWD3XIiIKBtU9VuhvPXvYIIdAABQr9e3ArjLuoOIiHrOtkKhcIt1RDuC+Bzw4axevbrQ39+/Dfz+NBERLY4559w59Xr9L9Yh7Qj6CgAA7NixY0pVPwPeCiAiokWgqt8O/eAPBPpXAK2mp6eTQqFwIoD3WrcQEVGmPVMoFK6YmJgI7s/+WgV/C2C/1atXD/T39z8F4J3WLURElEkzInJmkiRV65BOCP4WwH47duzYIyIfBV8QREREnacArsrKwR/I0AAAgCRJqqp6Bfg8ABERddZ30jS93zqikzLxDMCBpqenXxocHASADcYpRESUAaq6uVarXY2MnVxmbgAAQKPReLxQKMQA1lq3EBFR0EZF5MJGo7HHOqTTMnUL4AAqItcA+JN1CBERhUlE/i0iG9M0nbFu6YasDgBUq9XXAXwYwN+sW4iIKDjTInJxkiT/sg7plswOAABI03QmiqILRORF6xYiIgrGqyJycbVa/bt1SDdlegAAQLVa3QngfACZ+dMNIiLqmt3zZ/5PWId0W2ZeBHQkxWLxlCiKtgA43bqFiIi8tEtENiVJ8qh1yGLomQEAAOVy+SRV3QLgDOsWIiLyyhSAC9I0/at1yGLJ/C2AAyVJ8kpfX985qrrZuoWIiLxRd86t76WDP5DR9wAczuTk5OyqVavuazabJfBKABFRr3sun8+fmyRJzTpksfXcAACAnTt3zjUajQcLhUIT+94Y2FO3QoiICBCR3+zevXvT+Pj4pHWLhZ4/8JXL5Y2q+ksAg9YtRES0KOYAfC1N0+8iY6/3XYieHwAAUC6XK6r6awDvsW4hIqKumgBweZqmf7AOsdaTtwBaNRqNqbVr1/5sZmZGAXwAHEZERFm0xTl3Qa1We946xAc80LUolUrnicjtAN5m3UJERB2xS1W/UqvVfoQevuTfilcAWkxPT6cDAwO35fP5PICzwZFERBQsEdkqIhelafqwdYtveHA7jHK5vF5VfwjgXdYtRES0IBOqekOtVvuFdYivOACOLCqXy59W1VsAnGQdQ0REh7VXVX+cy+W+Xq1W/2sd4zMOgKM0NDQ0mM/nrwfwBQBvsu4hIqI3cAB+FUXRTdVqNbGOCQEHwAKVSqWTReSrAK4BsMy6h4ioxzkAD4rIjUmSbLOOCQkHwDEaHh4+sdlsXgXgOgCnWvcQEfWYWRG5V0RurlarL1jHhIgDoE0rV65ctmTJkstE5FoAZ1r3EBFl3JiI3NFsNu8cGxubsI4JGQdAB1UqlXXOuSsBfBx8YJCIqFNeFZHfAbg7SZKHse+yP7WJA6A7cqVS6VwRuRTARQBOtg4iIgrMbgBbANw3MDDw29HR0V3WQVnDAdB9URzH6wBcCOA87LtNsNQ2iYjIOw7ANgB/VNWHcrnc49Vq9XXrqCzjAFhklUpliXPuLBE52zm3LoqiM1R1GHwrIxH1ljEAz6nqsyLyJIAn0jSdsY7qJRwAHigWi0tF5LQoikqqWlLVkoicqqonisgKEVmhqgPz/52fLSYiX+0CsBfAXhGZVNVJVZ0E8LKI1EWkNjc3VwOwvV6vT9um0v8BQSsLYXHUz6oAAAAASUVORK5CYII=",playlist:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAACXBIWXMAALP6AACz+gFmujCYAAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAIABJREFUeJzt3XmAXGWZ7/Hfc6qS0IkRAigaIF1V3VkggCAyKAgExVHHcZlBmTsiIR02d/QOXlwvmfHqlfE6jjCiYUl3iNsEddSBGRckAQfcQNYAga6q7gQD6EjCEgKdqvPcP5IOWTpJd3Wd89by/fyV2k79Qkjep98651cSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACoJ6vXgWbNmnVgHMcnxnF8uKRZkqZLmiypo17vAQBAG9lkZhvd/VFJq6MoeiCbzf7Xgw8++Kd6HHxcA0Aul8tlMpmz3P2vJR0lKapHKAAAMKLY3e+Oouj7cRwvK5fLg7UeqKYBoKur6wR3/6Skv6j1GAAAYFxiSf8RRdHn+/v7fznWF49p8e7u7u6K4/hySW8e6xsBAIDEXJ/NZi986KGHSqN9QWaUz7Ourq6Puft1kg6rLRsAAEjIrDiOz99vv/2e27Bhw69G84K97gDMmTPngKGhoWXip34AAJrB9ZVKZf6aNWvW7+lJexwADj300OkTJkz4T205wQ8AADSH+83sTcVice3unrDbASCfz3ea2S2SZiQSDQAAJGlQ0smlUmnNSA+OeNnerFmzDjSzH4vFHwCAZtUp6eddXV0vHenBkQaATLVa/a6kOYnGAgAASet29+9ohJP+d7kjn8//g6T5aaQCAACJy0+bNs3Xr1+/cvs7dzgHIJ/PH2Vmd0jKppkMAAAkqhrH8asGBgbuGr5j+48AIjO7Uiz+AAC0mkwURV/Vdj/4bxsA8vn8X0s6PkQqAACQuBO6urreMXxj2wBgZh8PkwcAAKQhjuPPaOsuQCRJ+Xz+JEnHhgwFAACSZWbHFAqFE6WtA4CZnR02EgAASIO7nyVJ0bx587KSTg8bBwAApMHM3ikpY7lc7vgoikb1zUEAAKAlHBdlMplTQqcAAADpcfd5kbsfGToIAABI1RGRpNmhUwAAgPREUTQ7MrODQwcBAADpcfdDI3efGjoIAABI1dRI0uTQKQAAQKqmRJKeC50CAACkalMk6ZnQKQAAQHrM7KlI0qOhgwAAgPS4+2ORu68OHQQAAKTqwSiKolWhUwAAgPS4+/1RtVq9JXQQAACQHjO7Ocpms7+S9GzoMAAAIBXPdHR0/Cbq7+9/3t3/PXQaAACQih+tWrVqKJIkM1sWOg0AAEje8JpvW29nCoXCg5K6w0UCAAAJe7hUKh0mqRptvaPq7peGTAQAABL3fyVVJWl4ANDkyZOvlUQnAAAAren+adOmfWP4hm3/SC6XOyWKohU73w8AAJqbmb2+WCzeNHw7s/2DGzZsGNx///0PkfTK1JMBAICkLC6VSpdvf0e08zOq1eqHJN2dWiQAAJCk+4aGhj668527DAADAwPPRVF0uqTHU4kFAACS8lg2m337I488smnnB3b7WX93d/cxcRyvkLRvotEAAEASnozjeN7AwMBdIz24yw7AsP7+/jvN7LWSfp9YNAAAkITHoig6dXeLv7SHAUCSisXifVEUnSLOCQAAoFncVa1WT+jv779zT0/K7OlBSXriiSfWT5kyZWkmkzlA0rHiEkEAABqRS/paHMdnDA4O/vfenjymxTyfz59kZldIOqLWdAAAoO5WS/pAqVT6+WhfsMePAHZWLpd/USqVXuHuZ0i6f6zpAABAXd1vZmfPmDHjiLEs/tL4tvOjrq6uee5+lqR3SNpvHMcCAACjs17SD8xsWbFYvFlSXMtB6vV5fqZQKBwj6WRJh0uaJWm6pBdJmlin9wAAoJ0MSXpG0jozW+3uD5jZzcVi8S5t/UIfAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAG3O6nWg7u7uuXEcn+Tuh5vZbHd/iaR9zWyqpGy93gcAgDZQcfenJT1pZn9099VRFK0ys1/09/ffX483GNcAkMvlXh1F0VmSTpd0UD0CAQCAPXpM0vfiOF42MDDw61oPUssAEOXz+beY2acl/VmtbwwAAMbtbjP7p2Kx+E1J1bG8cEwDQHd39yvjOL5C0vFjeR0AAEiOu9/p7u8fGBj41WhfM6oBYO7cuRM3bdr0BUkXSopqDQgAABITm9mX99tvv0/ccccdm/f25L0OAIVCYYak70o6rh7pAABAon4dRdE7+/v7H9nTk/Y4AHR2dh6WyWR+IunQukYDAACJMbN17v6mUql0726fs7sHurq6jojjeKWZHZBMPAAAkBR3/1Mmkzmlv79/1UiPjzgA5PP5TjO7VdLBiaYDAABJekTSiaVSac3OD+xyQl93d/ckM/u+WPwBAGh2h0j691wut8/OD+wyAMRx/E+SXplGKgAAkLijzOwfd75zh48ACoXCayXdsvP9AACgqXkcx6cODAzcPHzHth2AY489doKkr4vFHwCAVmNRFF0+b968bd/Ns20A2LBhw5mS5gaJBQAAknbk4ODg3w7fGB4AInf/WKBAAAAgBWb2SW1d+yNJyuVyb5B0eMhQAAAgcXPy+fzrpeEpIIrmh80DAADSEEXRWZJkW7/o5wlJUwJnAgAAyXt62rRpB0TPPvvs8WLxBwCgXUzdsGHDcZGkk0MnAQAA6XH3UyIzOyJ0EAAAkKq5kbvPDp0CAACkanZkZi8PnQIAAKTHzKZHkqaGDgIAANLj7lMjSbt8RSAAAGhpkyNJm0KnAAAAqdoYSXo6dAoAAJCqpyNJ60KnAAAAqfp9JGl16BQAACA9ZrY6knRv6CAAACBV90VRFN0cOgUAAEhPHMcro0MOOeS3kp4KHQYAAKRiQ7lcviNauXJlRdL3Q6cBAACp+J6kaiRJZnZt4DAAACAFcRwvkyTbetsKhcJdko4KFwkAACTs7lKpdIwkj7be4Wb2f0MmAgAAyXL3z0ly6YUdAEnKFAqFX0s6NkgqAACQpN+WSqVXS4olKdrugaqk9w4/AAAAWkbs7h/Udmt8ZvtH169fv27atGlTJJ2YdjIAAJCYL5TL5R1O+I92fsaMGTM+JenW1CIBAIDEmNmvpk2bdsku94/05O7u7pfEcfxfkmYlngwAACSlGMfxawcGBh7b+YFddgAkqb+//49m9hZJjyYeDQAAJOHRKIreONLiL+1mAJCkYrHYH8fxCZIeSioZAACoP3cvmdnJ/f39xd09Z7cDgCQNDAwMmNlJklbUPR0AAEjCjZlM5tXFYrF/T08a8RyAEWQKhcKnJH1a0oRxRwMAAPU2ZGafLRaLn9coLukf7QAgSeru7j68Wq1+1czm1ZoOAADU3U1xHH9gYGDgwdG+YEwDwLBCoXCau3+KQQAAgKBWmNn/KRaLN431hTUNAMM6OzsPy2QyZ0k6XVwyCABAGlab2Xer1eo3xvIT/87GNQBsb9asWQdXKpWTzWyupFnufpCkF7n7fvV6DwAA2oWZbZD0jJk9Hsfx6iiKVg0NDd2ydu3adaGzAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACQNAsdAADGZOnag6XqLFV9luQzZXaAZFNkmib3yZI2y2yzYn9apk1yf1Rma+X+e0WZsjxepZ78c6F/G0BoDAAAGpe76ZriXEXRPJnmSXaypJeM86hVSQ9Lulum21Sp3qRzulbJzMcbF2gmDAAAGk9veY7MzpT7mZLyKbzjHyTdKNn3NCXznzrj0E0pvCcQFAMAgMawaEVWufzfyP1CSccFy2H2jNxvkKtXa3I/0yKLg2UBEsQAACCs5Ws7tLHaI/lFSuen/dEz65f0dU2wJTqzc33oOEA9MQAACKe39FbJLpOUCx1lj8yeUexLVPXP67zC46HjAPXAAAAgfdeUZiuyyyW9IXSUMXpa7pfJhy7VOXOeDh0GGA8GAADpcTf1lT8o2RclTQodZxzWSfYxLej8NlcPoFkxAABIx9Vr91emco2kd4SOUke3KGPv1fzcA6GDAGPFAAAgeUtLRym2f5c0I3SUBDwv+ec0ZdOlOmPuUOgwwGgxAABIVl/pZLn9SNK+oaMkyuw+uZ+nnvyvQkcBRoMBAEBy+kpvk9t3JHWEjpKSWK6r5c9fxEmCaHQMAACSsXTgrxT7dZIyoaMEMCDXe7Uw/5PQQYDdYQAAUH9LyqfI9GNJ+4SOEpZdJ9/8AS2c+cfQSYCdRaEDAGgxvcUjZfo3tf3iL0n+Lln2QfWVzw+dBNgZOwAA6mfpIwfIK3fJ/ZDQURqP3yCP36eF3WtDJwEkdgAA1Iu7Kd58DYv/7thbZJkH1Vu+WMu9Hc+LQINhBwBAfSwpf1Smfwodo0ncJo/O08LO+0MHQftiAAAwfn2Dc+Xx7yRNDB2liWwpEBp64gu64FWbQ4dB++EjAADjF8eXi8V/rCZJ9g+adODvtKR8fOgwaD/sAAAYn96Bd0v+zdAxmhwFQkgdAwCA2n111Ys0efJqSdNDR2kRAzK/QAsKPw0dBK2PjwAA1G7KlAvE4l9PObn9RL0Dy7V49YGhw6C1sQMAoDaLb5+giQcUJR0aOkqLekKmT2hB/srQQdCa2AEAUJsJ+58tFv8k7S/XYvWWb9C1xVb8GmUExgAAoDZmHw0doU38harRveodeL8WOf9mo274CADA2PUNHiuPbw8dow1RIIS6YZoEUIP4zNAJ2tQJsvgu9Za/oMsenhQ6DJobOwAAxma5Z7Rx4BFJLwsdpa2Z3afYz9XC/K9DR0FzYgcAwNhsGvwzsfiH536ETLdpSXmxvrrqRaHjoPkwAAAYm6rPCx0B20Qyna/Jk+/VkvIbQ4dBc2EAADA2pnmhI2AXOZl+TIEQxoJzAACM3uLbJ2jSgU/InS3nxvUHSReqJ/+d0EHQ2NgBADB6HQd2s/g3vJdK+jYFQtgbBgAAo1fxWaEjYNT+QtXofvWWL6ZACCPhfwoAo2cMAE1miqQvqHPgF1oyeHjoMGgsDAAAxiCaGToBanKCLP6dlpQ+rcW3TwgdBo2BAQDA6LlzhnnzmiSzz2rSgb/TkvLxocMgPAYAAKMX2dTQETBOFAhhKwYAAKPHFQCt4oUCob7Sn4cOgzAYAACMnhkDQGvJye0n6i33aekjB4QOg3QxAAAYPfds6AhIxNmKN9+vvtL80EGQHgYAAIAkvVRuSykQah8MAACA7VEg1Cb4wwUA7OyFAqFrBw4LHQbJYAAAAOzOCar63eotf0HLV00MHQb1xQAAANiTCZIu1sbJt1Mg1FoYAAAAo3EkBUKthQEAADBawwVC91Ag1PysXgfK5/OzzexUdz8miqLZ7p6XNFXSvmLQQOvaJGmjmf3R3VdLWu3ut5rZLaVS6cnQ4equt/yApDmhY6BR2HUaev79umD2f4dOgrEb1wCQy+XmRFE0X9KZkrhuFHhBVdJKM7v2mWee+d7jjz++MXSgumAAwK7+IPOPaUHh2tBBMDY1DQC5XO7VURR9UtJf1noMoI08IemySqVy2Zo1a9aHDjMuDADYvf9QJn6f5netCR0EozOmxbuzs/Pl2Wz2Und/z1hfC0DrJf19qVT6F23ZIWg+DADYs6ck/W8N5i7XIotDh8GejXoRLxQKfyvp65JenFwcoC3cEkXRmf39/Y+EDjJmzT4AmD0j9/WSDg0dpcX9QrGfp3MKq0MHwe7t9eS8Y489dkKhUPiapG+JxR+oh5PjOL6zUCicFjpI23Ffr6FJcyRdKomfUJNzkiK7lwKhxrbHAaC7u3vS+vXrvyPpvSnlAdrFgZJu2LqzhjRdMP1Z9eQ/LreTJN0fOk4Lo0Cowe12AMjlcvvEcfyfkv46xTxAO5ko6Rv5fP6s0EHa0sLcbRr609GSPi5pKHScFkaBUIPa3QCQiaLom5JOTTMM0IYiM7umq6vrzaGDtKULXrVZPflLVa0eK+nXoeO0MAqEGtCIA0ChUPiM+MkfSMsEd//XQqEwK3SQtnVu930azJ0g0wUyeyZ0nBaWl9tP1DuwXItXHxg6TLvbZQDo7u6eJ+nT6UcB2tpUSd+cO3cuJ0yFsshiLchfKfcjJf0kdJzW5u/SxIn3qa80P3SSdrbDANDd3T0pjuOvS8oEygO0s1dt2rTpo6FDtL2e/IB68m+S/AyZUXGbnIPktlS9peu1pJ/LMgPYYQCI4/hiSbMDZQEgfaarq4t/DBtBT+E6RZW5ki0LHaW12VtkmfvUW75Qi5zvjUnRtv/YhUJhX0n/M2AWANIUd/9E6BDYan73H9STmy/ZWyRRcZucF0v6Z3WWb9G1A4eFDtMutg0AZvYhbfnmPgBhLTz00EOnhw6B7fTk/kOZjsNFgVDC7ERV/W4KhNIxPABE7n5+0CQAhk3KZrM9oUNgJ/NftpECoVS8UCC0tPRnocO0skiS8vn860U3NtAwzOxs8YVbjYkCobQcqdh+SYFQciJJMrPTQwcBsIOZXV1dc0OHwG5QIJQWCoQSNPwRwOuCpgAwEv5eNjoKhNJCgVAColwu9zJJM0MHAbAjdz8ldAaMwo4FQj8NHae1USBUT1Emkzk8dAgAuzIzLodqJlsKhN5IgVDiKBCqk8jd6R8HGpC7d8+bNy8bOgfGiAKhlFAgNF6RpJeFDgFgRBMeeeSRaaFDoAYUCKWFAqFxiMyMyyuABhVF0dTQGTAOFAilxE5U1X+n3vIiCoRGL5I0KXQIACOL47gjdAaM0/YFQq4HQsdpYftIuoQCodGL3P3Z0CEAjKxarXJpWatYmLtNm//0ClEglDQKhEYpMrOnQ4cAMLJJkyYxALQSCoTS8kKBUG/pDaHDNKpI0trQIQCMaOODDz74ROgQSAAFQmnJS/ZTCoRGFlWr1dWhQwAY0WpJHjoEEkKBUIooEBpJlM1m75dUCR0EwC7uCR0AKaBAKC0UCO0k6u/vf0rS70IHAbAjM1sROgNSRIFQSigQGjb8bYA3hg4CYAeeyWR+HjoEUkaBUFooENILA8C3QgcBsINfPPTQQ78PHQKBUCCUkvYuEIokqb+/f5W73xk6DIAt3J1t4HZHgVBa2rZAaNvnH1EUfSVkEADb/PfkyZO/EzoEGgQFQmlpuwKhbQPAfvvt9y1J5YBZAGzxpVWrVnFtOF4wXCCk+FWiQChJbVUgtG0AuOOOOzab2SdDhgGgtRs3brw8dAg0qJ6ueykQSkVbFAjtcAlEsVj8jrv/OFQYoN2Z2Ycff/zxjaFzoIENFwhFOkoUCCWstQuEdrkGMoqi8939TyHCAG3uO8Vi8QehQ6BJzM+VKRBKRcsWCO0yABSLxbVRFJ0rKkiB1JjZAx0dHeeFzoEmRIFQSuwtssy9rVQgNOJvolgs/sDMPp52GKBN/dHd386Jf6gZBUJp2VfDBUK95Tmhw4zXbqeYYrH4j5L+McUsQDt6IoqiN5ZKpYdDB0EL6Mn9hyZUjpTrMlEglCA7UdKdzV4gtMdtjFKpdLGkj4iPA4AkPOrup/b391PChfp5z8yntDB/oSw6mQKhRDV9gdBeP8colUpfMbN3S3o6hTxAu/ivbDZ7XLlc5hv/kIwFnbdSIJSKpi0QGtWJDMVi8TuSXiXpN8nGAVreZnf/PzNmzDiVrn8kjgKhtDRlgdCoz2QslUoPlUql15jZeyVxyQkwdiuiKDq6XC5/ZuXKlZXQYdBGKBBKywsFQksfOSB0mL0Z66UMcbFYXNzR0ZF394vMbF0iqYDW4ZJ+FsfxvFKp9Lr+/v77QwdCm6JAKEX+LsWbVzV6gZCN8/WZXC53mpm928zeIOnl9QgFNLmqpDvN7EeVSuUbg4ODrfMdG73lByQ18+VPa9WTnxE6REPoLb1LFl0h95atum0IZtcrrrxfC7vXho6ys/EOADvo7Ow8LJPJHOPuc8ysYGZT3X1yPd8DaDRmtt7dn5D0kJndX61WfzUwMLAhdK5EMAC0lqtKBykbfVHys0JHaXFPSrpEg7nLtcga5vLMug4AAFocA0Br6ht4i9yvkMR/m0T5rZKdq578g6GTSGM/BwAA0GoW5G6gQCgNjVUgxAAAAKBAKD3DBUK/DV0gxAAAAHgBBUJpOUquW7Wk/JVQBUIMAACAHe1YIEQBXFLcsjJ9OFSBEAMAAGBkWwqEXkOBUOKCFAgxAAAAdo8CoRSlWyDEAAAA2Lv5ubJ68m+U/AyZUQefnIPktlR9A/+uJf2HJvlGDAAAgNHrKVynzfERki0LHaWluf+lLHOvessXapEnslYzAAAAxua8wuPqyc2X+dsl8a2WydlX0j9rxsCNurrUWe+DMwAAAGqzoPAjTagcLunr2vLFV0iC6VRl7B4tKZ9dz8MyAAAAaveemU+pJ/8+WXQSBUKJerFMfeobWKbF6+ryHTsMAACA8VvQeatMr5T75yRtDh2nZbm/RxOfv0VXPXzIeA/FAAAAqI+e/HNaWPi0FB8rCoSSdKyy2d+ot3z0eA7CAAAAqK+erns1JXeCZH8n6dnQcVrUyyWt0DXF19Z6AAYAAED9nWFV9eT+SRk7QhQIJWU/RdGPtaR8Si0vZgAAACRnfq6sBbk3SeqR9EToOC1oikw/0pLy8WN9IQMAACBZZq6efJ8qfjgFQol4sUw3aGlx1lhexAAAAEgHBUJJOkBxdP1YvkyIAQAAkK7hAiHXZZLi0HFayEzFQ/+q5Z4ZzZMZAAAA6XvPzKe0MH+hLDqZAqF6stdr48BnRvNMBgAAQDjDBULyz4sCoXr5jPpKJ+/tSQwAAICwevLPqafwKQqE6iaSW5+ueXDqnp8EAEAjGC4QMrtIFAiNV17RPp/b0xMYAAAAjeMMq2pB7ksUCNWDv1/XlF6xu0cZAAAAjWd+rqye/BslP0Nm/x06TpPKKNJX5W4jPcgAAABoXD2F67Q5PkKu5aGjNCc7Ub0DbxvpEQYAAEBjO6/wuBbm/0Zmfylpbeg4Tcf0WS3yXdZ7BgAAQHNYkLtBQ/GRkr4uyUPHaSJHKj/49p3vZAAAADSPC7qeVE/+fbLoJAqExsD1P3e+iwEAANB8thUI6e8lDYWO0/DcX6triq/a/i4GAABAc+rJP6ee/CLF/mcyuz10nIYXZc7f4WaoHAAA1MU5hbs10Hm8TBfI7JnQcRqXn6HlazuGbzEAAACa3yKLtSB/pSIdJelnoeM0qH21sfrm4RsMAACA1rGlQOjPKRDaHT99+FcMAACA1jNcICRbFjpKg3mTFq3ISgwAAIBWdV7hcfXk5sv1Dkm/Dx2nQeyvXOF4iQEAANDqFuZ/qAmVw+W6TFIcOk5w7qdIDAAAgHbwnplPaWH+Qll0ctsXCJleIzEAAADaybYCIf+8pM2h4wTyaokBAADQbnryz6mn8CkpPlbSb0LHSZ37gbqqdBADAACgPfV03avB3GvaskAoa4cxAAAA2tdwgVBsr5D856HjpMY1mwEAAICFnSX1FE5rowKh6QwAAAAMa5cCIbOXMwAAALC9tigQ8pcyAAAAMJKF+R9qKJ7bogVCkxkAAADYnQu6ntTC/IWK41NarEBoHwYAAAD25pyu/1JcfZukJ0JHqZOJDAAAAOyJu6mvNF+ZzK8l7R86Tp08nw2dAACAhtW3pkt9A1dK9rrQUepsEwMAAAA7W3z7BE068H/Jq5+WtE/oOAnYyAAAAMD2estHS7pa7seGjpIcf4wBAAAASVq+tkMbK5dIukhSJnScRLkeZQAAAKC39AZtrHxdUiF0lHTY7xkAAADtq7e8n1yXSjpPkoWOkxrTAwwAAID21Ft6q6SvyXRw6CipmxitZgAAALSXqx4+RJnsVyW9LXSUQNbozM71DAAAgPbgblpaPktuX1brFPrU4jZJYgAAALS+1i30GTvTLyUGAABAK2v9Qp+xM18pMQAAAFpVWxT6jNlanV24R2IAAAC0msXrJmvic5+VdKFavdBn7G4Y/gUDAACgdfSVTpY/f5Vks0JHaUiRLR/+JQMAAKD5DRf6eJsV+ozNOnV03jJ8gwEAANDc+kpnyHWZTAeFjtLglukMqw7fYAAAADSnZQMvVyW+XG6nh47SBKrK2OLt74hCJQEAoCbupr7SfFX8PonFf5R+qPm58vZ3sAMAAGge15Rmq2/gKslOCh2lqbh9aee7GAAAAI1v0YqsOnN/J2mRKPQZq59qYe62ne9kAAAANLbe4nFSdJWkV4SO0oRckS0a6QEGAABAY1q+tkMbK5dIukgU+tTqX3V27pcjPZDoANDd3T1paGhocpLvAYS2Zs2a9aEzAC2nr3SyNlaukkShT+2eVdU/vrsH6zIAdHd3T6pUKq+OouhUMzvG3edIysdxPCGbZZMBra1QKEjSBkmrJT3g7rdlMpmb+vv7i2GTAU3o6rX7K1P5klxni0Kf8XG/ROcWBnf38LhW53w+f7KZLYjj+J1RFE3d8n4+nkMCzWo/ScdLOn7r3wkVCoVVZnZtpVJZNjg4+GjogEDD6y29Vap8TdLBoaM0Pdcv9aL8l/f0lFoGAOvu7n5bHMefknRcbcmAtjDX3S/NZDL/UCgUlrj7peVyebfTONC2lq49WNXKFZLeFjpKi9ioTLxg+9a/kYypCKhQKMwsFAo/juP4B2LxB0ZrkqT3mdkDhUJhUS6X4xImQHqh0Ceu3CNj8a8b8/fr7K6H9va00Q4AVigUPiLpPkl/Pq5gQPvqkHRJFEW3d3d3Hx46DBDUlkKfm+W2VNL+oeO0DNPXtKBw7WieutcBYPr06ZMLhcL3JX1Z0sTxZgNcg2nOAAAOL0lEQVSguXEc/6arq+tvQgcBUrdoRVa95QsV2e8k0eZXX7foqcpHR/vkPQ4AM2bMmLbPPvv8VNI7xh0LwPamuPu38/n8RaGDAKnpLR+tztyvJP2zJC4RryfXA5oYvUMfnvn8aF+y25MAu7u7XxzH8Y2SXlmXcAB2Zmb2xUKhUC2VSns8WxdoaovXTdaE5/5B0kdEoU8SysrGb9KZ+TF1koy4A9Dd3T1p64l+LP5A8r5UKBTeHToEkIi+0sma+PydMvs7sfgnYY08Ok3zu9aM9YUjDgDVavWLkk4ddywAo2GSrunu7j4mdBCgbq5eu7/6ykvktlK0+SVltaRTtLCzVMuLdxkAuru7325mHxx3LABjsU8cx9+ePn06n4ui+fWW3qpM5R65ekSbX1J+I6+cpJ78QK0H2GEAmD179tQ4jr8q/sCAEGZ3dHR8KnQIoGZL1x6sJeUfSvYj0eaXHNO3NTTpVC2c+cfxHGaHAaBSqVwi/tCAYNz9okKhwHYpmguFPukwr0j6uBbk360Lpj873sNtGwDy+fxB7v7+8R4QwLhMNLNPhw4BjFrfmi71DdxIoU/iSlJmnnryl9brgNsGADP7qLY0lQEIyN3/dtasWYXQOYA9Wnz7BPUOfFJevU/S60LHaWGxzP5FQ5OO1ILOW+t54EiS5s2bl5W0oJ4HBlCzbLVaXRg6BLBbveWjNenA2yT/nCS+2yIpZv2K7DQtyH2oHlv+O4skaXBw8C8kHVTvgwOojbu/R2P8si4gccvXdqi3/AVJt8v9VaHjtKwtn/VfKvcjdXZuRVJvk5UkM/urpN4AQE06u7q6jikWi3eEDgJI2lLos7FylbimP2l3KY7O0cLc75J+o+Eq4HlJvxGAMXudJAYAhNVb3k+uS+U6T1winqRNkv5eU3L/T2dYNY03zHZ3dx8Sx3EujTcDMHrufpKkL4bOgTbWW3qrpK/JuDw8YTcris/X2V0Ppfmm2Wq1ergZQx3QgOaEDoA21Vt+meT/ItnpoaO0uA0yXayzc1fJzNN+80h8ngM0qvzcuXMnhg6BNjJc6COtYvFPmNn1irJHaEH+yhCLvyRlzewlId4YwF5ln3322WmSHg8dBG1gS6HPlZJxTX+yHpXsg1qQ+37oIFlJLwodAsDIoiiaKgYAJGnRiqw6cx+QVz8naUroOC3M5bpKEysf03tmPhU6jLRlB2Cie5DdBwB7YWaTQmdAC7um9Aploqu5pj9hZv0ynZ/kNf21yLr7xtAhAIwsjuOnQ2dAC1q+tkMbK5dIukjumdBxWpZ5RW5fkvsiLcg/FzrOzrLu/hRXAQCNqVKpMACgvrYU+lwpaXboKC3uLilzrno6G7bLI2tmg6FDABjRk2vWrFkfOgRaBIU+aUm90KdWWUmrQ4cAMCL+bqI+KPRJS5BCn1pln3vuufv32WefIUlcbww0EHe/K3QGNDkKfdIStNCnVtG6deuelfSb0EEA7CiKoptCZ0CTotAnPQ1Q6FOr4S8D+pmk14YMAmAHVUkNdckQmkTfmi71lRdL9vrQUVpcwxT61CqSJDP7lqSmmlyAVmZmNxaLxT+EzoEmsmhFVr3lC+XVu1n8E+WSLVM1e4R6mnfxl7buABSLxf5CoXCbpBMD5wEgyd2Xhc6AJkKhT1qKcjtfC3Mt8fFcdrtff1kMAEAjWNvR0XFd6BBoAhT6pGO40EdapIW5hiv0qdW2AaBUKv1boVC4X9LhAfMAbc/dL121atVQ6BxocBT6pKXhC31qtf0OQOzuHzWznwRLA+ChTCZzdegQaGAU+qSlaQp9ahVtf6NcLv9U0vcCZQHanZvZe/v7+58PHQQNakuhz30ynS8W/yTdoig+Wj35S1t18Zd23AGQJJnZ+yW9xt2nB8gDtLOvFItFLv3DrnrLL5PZ5XJ/Z+goLa4pC31qFe18R7FY/IOZnSmpEiAP0K5+3dHRcXHoEGgw2xf6sPgnq4kLfWq1ywAgSf39/SvdvUd0AwCJc/dSHMfv4MQ/7GBLoc/P5LZU0v6h47SwR2X2Ti3IvVVnH/r70GHSNOIAIEnlcvkbkv5ODAFAktZmMpk/HxgYeCx0EDQICn3S8kKhz4JcW577tss5ANsrlUpf7urq+pO7Xy1pQkqZgLZgZg+4+5v6+/vXhM6CBkGhT1paqtCnVrvdARhWLBavlfRmSfyEAtTP96vV6gmlUonFH1sKfXrLixTZb1n8E2RekXSppCPaffGX9rIDMKxUKv08l8sdE0XRlZLemnAmoJU9JekTpVLpitBB0CAo9ElLyxb61GpUA4Akbf2M8m35fP5tZvYlSd3JxQJaTizp25s3b/5fa9euXRc6DBoAhT5paflCn1qNegAYVi6XfyTphkKh8D8kXSTp6LqnAlrHc+6+PI7jLwwODj4QOgwaxJZCn6/JdHDoKC3uFkXxeTq766HQQRrRmAeAraqlUumbkr6Zz+ePMrMz3f0NZvYKjeK8AqDFPSXpZnf/oZl9t1wuPxk6EBoEhT5paatCn1rVddtpzpw5BwwNDR0taZa75yXtK2nfKIoYCtCS4jjeZGbPSPqDpIeiKFp9yCGH3LNy5crWLNLqLT8gaU7oGOOwVj35Gam/q7tpafksuX1ZXNOfLLPrZZn3tts1/bXgcycAo8cAMHZ9a7rklcVc05+4R2X2oXa9pr8WtX4EAADYk0UrsurMfUBe/ZxkU0LHaWEu2TdUzXxE5x76ROgwzYQBAADqjUKftFDoMw4MAABQL8vXdmhj5WJJn5Q77alJMa8otiu0edIndMH0Z0PHaVYMAABQD72lk7SxcpUo9EnalkKfhRT6jBcDAACMx3Chjyj0SRiFPnXGAAAAteotvVVmV0h+SOgoLY5CnwQwAADAWG1f6OP0zCSIQp8EUdADAKPlbuorzZe0ija/hJldryh7hBbkr2TxTwY7AAAwGn1rutRXptAneRT6pIQBAAD2hEKftFDokzIGAADYHQp90kKhTwAMAACwMwp90jFc6JPt+KTmv2xj6DjthgEAALZHoU9a7lbVz9U5hdtDB2lXDAAAIFHokx4KfRoEAwAAUOiTFgp9GggDAID2RaFPWij0aUAUAQFoPxT6pIdCn4bFDgCA9kKhT1oek9kHKfRpXAwAANrJS+XVeyXrCB2khbmkKzUUX6wLup4MHQa7xwAAoJ1MCh2gxRVl0QVa0Pnz0EGwd5wDAAAYH/OKXJcp0/EKFv/mwQ4AAGA8KPRpUgwAAIBaUOjT5BgAAABjdYtiP1/nFFaHDoLaMQAAAEaLQp8WwkmAAIC9o9Cn5bADAADYk8fk/iH15L8bOgjqiwEAADASl+wbqmY+onMPfSJ0GNQfAwAAYGcU+rQBzgEAAGxBoU9bYQcAACBR6NN22AEAMBabQwdA3W0p9Bn603E6p4vFv42wAwBgLJ4OHQB19QvFfh6FPu2JAQDAWDAAtAYKfcBHAADGwIwBoNmZXa9K5UgKfcAOAIDR8/hxyUKnQG3WSfqAFuR+EDoIGgM7AABGz+yh0BEwZi7ZMlWzR6onz+KPbdgBADB6sVazAdBUKPTBbrEDAGD0TJwt3gwo9MEosAMAYPQGc2vUObBe0rTQUbBbd8jtXC3M3xU6CBobOwAARm+RxZJuDh0DIxou9HmNelj8sXfsAAAYG9MKud4ROgZ2QKEPxowBAMDYVKo3KZMJnQJbUOiDmnE+L4CxcTf1DTwsqSt0lPbm35Psg+rJPxY6CZoT5wAAGJstP2l+I3SMNvaY3N+lnsI7WfwxHgwAAMYuY0slseWcruFCn7laWPhu6DBofnwEAKA2fQO/kPtrQ8doEw/LdZ4W5rkCA3XDDgCAWv1z6AAt74VCn2NY/FFv7AAAqI27aengPXI/InSUFnW34vhcndN1e+ggaE3sAACojZnL438MHaMFDRf6HMfijySxAwCgdotWZDUjd49Mh4WO0iJuUrV6gc7t7g8dBK2PAQDA+PSVTpbbSvHvyXg8KekSDeYu31q3DCSOv7AAxq+v/C25/jZ0jKZkdr02b36fzpv5SOgoaC8MAADGb9nAy1Xx+yXtFzpKE1mnyD6os3P/FjoI2hMnAQIYv7Nyj0o+X5QDjcaWQp9owlEs/giJHQAA9dM7cJnkHwodo4GV5PEFWth1Y+ggADsAAOrn6c0fk/Tb0DEajnlF0qWakj2CxR+Ngh0AAPW15OGXyLK3SpoZOkqDoNAHDYkdAAD1tXDmH2WZN0tq92+qo9AHDY0dAADJ6Bs8Vh7/XNK+oaOkzrVCcfV8Cn3QyNgBAJCMBZ13qFp9raTfh46SoiclfURrcqex+KPRsQMAIFm95Zykn0iaFThJsij0QZNhAACQvGv7X6pq5l8lzQsdJQGPKrIPcE0/mg0fAQBI3vzuP2hK7jTJPiupVbruq5JfIelwFn80I3YAAKRrSfE0WdQn6eDQUcbhF5I+rJ78XaGDALViAACQvmsenKpo4iKZPiy3bOg4Y7BK8r/Xgvx3ZUbtMZoaAwCAcHqLR8qjr8h0augoe7FKrs9qTe46vq4XrYIBAEB4fYMnSv5xub9FjfPvUiyzm+TxZVqQv56f+NFqGuUvGgBsKQ9S/AG5Tpf04iAZXHdKuk7VyjIu6UMrYwAA0HiWr+3QxupfSX6mpFMldST4bpskv02yG1WtfpcCH7QLBgAAje2yhydpavY1cp0q0zxJcyUdUOPRqnI9JNM9ct0t6TY9U/mVPjzz+brlBZoEAwCA5rP0kQNUrcyWfKbMDpD5i+T2IrkPf+/Ahq1fwbtBpscVR4/IfJ2erpRZ7AEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJCE/w9jHD/E5U+qbwAAAABJRU5ErkJggg==",radio:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAACXBIWXMAAHYcAAB2HAGnwnjqAAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAIABJREFUeJzs3Xl8XXWd//HX59wkTRdaoUCRgTYphba5aQXrhuDPIigoMIwiyKjQJgWLA+4io+NP6zIqLoMwopalpYDitA6jLOMGgsimEqltbtJCaVJAlraUpWuWe76/PxJ/IrZN2tybzzn3vJ+PBw8dJjnf9/Xk3vO+33PO9xgikk7XrNqH6up9KUb7EWw/LB5PsP2A/YhsP+IwFmMcWASAsS8AIUTAuJdtLcbshf7/fy/Y5v5/3Q22BWMTcdiERZsgbMLCJnrjTVjNJqLiJprqdwzPixaRUjHvACKyE0sLNWzeZ39y4ZWE4mSwyQQOxuyVECYDhwNjvWO+xA7gSczWEoe1GGux8BRxeBKq1jJm4jrOtKJ3SBH5KxUAEU9LCzVsG3M4odgAlgdrgJAHpgI573gl1AM8AlaA0AahgOXaGDVxlYqBiA8VAJHhsuiRA4iqX0ccXgcciZEH6oHIOZmnLqAdox2shRD/nu7aFuYfvM07mEilUwEQKYeFD1Yz4oCZhPhYsFkQZgHT0XtuMIrAarAWCC1YdA+jJi7XTIFIaenDSKQUlj4+kq09x4IdD7wFOBKodk5VSTYD92PcAdEddE58iAUWe4cSSTMVAJG9sTTk2PbYkYT4BMxOIIRjgVrvWBmyGbPfEcLtWHQ7cye1eAcSSRsVAJHBWrh6f6prTgVOxXgLf38rnfhZB/ZLjJ8Swh26LVFkYCoAIrtz9dpJVNmJYKcSwoloWj8NtmH2a4iXEexmmuqf9w4kkkQqACIvd83aVxHZO4HT6DuXL+nVA9wF9hPi6CfMm/ikdyCRpFABEAG45rGDiYpnEJiDcZR3HCmLGML9mF1HsetG5k3b7B1IxJMKgGRX35X7p2DRORCfRLAq70gybLaD3Qrx9axb9zMWHNfrHUhkuKkASLaEYCx57C0Q5hLCO4HR3pHE3Z/BfkiOxZxT1+4dRmS4qABINtzwyFh6q84i8GEg7x1HEqsFC5fTtelG5r+mxzuMSDmpAEhlu65zOr3hfIx56Nu+DN7TwBJC8QqapzzuHUakHFQApPJc/sgIxla/mzhcgHG0dxxJtR4C/wN8l+b633iHESklFQCpHFcUxjBq1DzMPkkIh3jHkYqzHAuXMqr+B3ougVQCFQBJv4Wr96em5kLgQmC8dxypeI8C/wks1IqDkmYqAJJeizsOAs4HPgaMdU4j2fM08G1yI7/DOQdt9Q4jsqdUACR9rl47iZx9Dng/UOMdRzLObCOBS8nVXqYiIGmiAiDp0TfV/0ngI+jJe5I0ZhsJ4ZvAZTo1IGmgAiDJ13dx3wXAZ9BUvyTf4xhfZlTdNbpYUJJMBUCSa2mhhm2j5hL4EnCgdxyRPRJox8LnmVv/Y8yCdxyRl1MBkOQJwVjceQ7GV4CDveOIDNHvCHyE5vrfeQcReSkVAEmWRZ2vxuLLwY7xjiJSQgHsx4TeT2hlQUkKFQBJhiVPjKfY8zmMC4CcdxyRMtkKfJPNvV/lw4d3eYeRbFMBEF8L7qyirq6ZwFfQIj6SHY9g9jHm1t3mHUSySwVA/Fy79v8Q7HtAg3cUEReBm6mKP8Q5hz3mHUWyRwVAht/CJ0dR0/U54CIg8o4j4mwb8EXW1X2DBRZ7h5HsUAGQ4bWk8+3E4fvARO8oIglzHzk7l3Pq2r2DSDaoAMjw+MG6femKv4bxAe8oIgm2A7iE0du+wpn5bu8wUtlUAKT8FnX8M8ZlwAHeUURSIfAQOZvHnLqHvKNI5VIBkPL5wbp96Q4LIZzhHaXCPU/fk+k2YbaJOGzCeA6j/7/bFgh/eUjNDkLY3vdfc9uIrAuKo4lD30OVcrl9iOMqAALjMBsDth/E+2G2H4H9gP3ou2PjYPRMhnLqIfB5Hqu7RNcGSDmoAEh5LOp4M8b1wKHeUSrAC0A7ZmsI8WNgj4M9htk6itsfY960zW7JrltzID02karcocRhIsYkQpgIdjgwDT2tsRR+QyierQWEpNRUAKS0Fj5YzYjxXyBwMbrCf09tBlaCFSC0QSjQW2znvMOf8A62VxbcWUX9xMnEuUaM6RDyBBrou+2z2jteyjwHYT5Nk5d5B5HKoQIgpXNdZz3FcAPwRu8oKVAEVoO1QGjBonvonPhQJqZ6Fz5YzYgDjoD4GIIdC2EWMB19Hg2CXU+84wLXWR+pGHrDSWks6mgisssJYYx3lITaAeFegt1BiH9L78g/Mv/gbd6hEmPh6v0ZMeL1wGzicDzGq9AM0s6ZrSEU30vTYX/wjiLppgIgQ3P5IyPYp/o/IZznHSVhisBy4HZCfDsW3UNT/Q7vUKmxcPX+1FQf3f9QqBOAWd6REqYLuJim+su8g0h6qQDI3rt67SRy9t/ow/kvNoP9HPgJNfYz3jfpOe9AFaPv9NJpwGnAm9ADo/oYiwn8i8ql7A0VANk7iztmA/8FHOicxJfZRgI/g/gWcqP+l3MO2jrwL8mQXP34fuR6jofoVAj/BOzjHcnZckJ0Os2T1noHkXRRAZA9E4KxZN1nCOELZPdb2PMElmLhBtbV35uJC/eSauGTo6jZcTLY2cBJZPfugk3A+2iq/7l3EEkPFQAZvIWPjqM6ug7jH72jOOjp+6YfrsfsVk25JtCiRw7AcmeBvR94nXccBzGEBcyt/zJmwTuMJJ8KgAzO1WsnURXdSgiN3lGG2UoIV9HdcyPzp270DiODtLhjGsY5BJqBCd5xhtmPgCaVVBmICoAMbHHHkZjdQgiHeEcZJt1gPyUUr6Rp8h36NpViSws1bB15GhZ9gBCOJzufeQ+QK57GOVPWeweR5MrKm0H21pLOdxKHG4BR3lGGwVPAdfT2fie1q+/Jri3umEbgg0TWnJH1KtaSs1P0eGHZFRUA2bVrOz9BCF+n8hdk+SMWLmFU/X9zphW9w0iZLXx0HCOi+QQ+CrzSO06ZPUdkpzOn7k7vIJI8KgDy95aGHFs7LgO7wDtKeYV7gUuYW3+rpvkzaGmhhm0jzyLYZ4Cp3nHKxkIvsV1Ic/1C7yiSLCoA8reWFmrYOmopfQuuVKIYuJnA12iu/513GEmApSHHls53Y/wrcKR3nLIJ4SKaJ3/TO4YkhwqA/FXfPf5LCeHd3lHKInAzFn+WpsNWekeRBArBWNJxKsG+DMzwjlMWgX+huf573jEkGVQA5K8Wrf0sZl/yjlFygTsxPkNT/QPeUSQFFoSIiR3vxewLwGTvOCXWA+F4mib/1juI+FMBkD6LO44Efk8lraRm9iAh/gxNk3/lHUVSaOGD1dTsfx6Ez1JZFws+SveImXoapVT61d0yWIH/oHIO/o9h4T3MmfQ6Hfxlr81/TQ9Ndd+le8QUCJ8DKuWAeRg13R/1DiH+NAMgsHjtm8Du9o5RAtsJfIOeEZfo242U3KI1h0LumxhnekcpgU2M3vZKzsx3ewcRP5oBEDD7oHeEErgJaKC5/vM6+EtZNE95nOb69wDHASu84wzRfmwd9Q7vEOJLBSDrlhZqCJziHWMIVhHit9JUfzpN9Z3eYSQDmurvYl3nLMwuBJ73jrPXzN7nHUF8qQBk3faRR5LO56n3YPZlNvceSfNht3uHkYxZcFwvc+uuIM7lgZ94x9krIbzNO4L40jUAWXft2nMItsQ7xh76ExbNY+6kFu8gIgAsXnsq2PeAf/COsodeSVP9094hxIdmADIvOtw7wR7YDvwro+tm6eAvidI0+RagkcCVQHqWlQ4VvASyDKjKO4A4C/ErUzIRdB/F4hzOnbLGO4jITjXVPw/MZ1HHTRiLgIO9Iw0sHOCdQPxoBiDrzJL9N2ChF1jAus436+AvqdBc/wu6u19FGq4NsEh3zGSYZgCyLoTnEjwDsI7A2TTVa9lSSZf5UzcC7+TatedAdAUhjPGOtFMhbPWOIH6S/e1Pys9snXeEnTK7geremVqzXFJt7uTrCOG1wB+9o+yUxU96RxA/KgCZF5Z7J3iZbRDOYW7d2bz/8Be9w4gMWVP9KkZvOxq4zDvKyzzD3Mk6rZZhKgBZ92Lxd8Bm7xgAmK0hCkfTNPl67ygiJXVmvpum+o8C7wQSUmzDPZil544FKbnEnvyVYbS440bgLOcUtwDn9F9JLXtiaaGGF0dMpKp6EnF8CLAfhPFEth/B9ocwHhgHgNk4QojoK/9/+XdbCaFvTfjACxgxsBXYBOFZiDZBvAGLNgFPg3USjejknIN0/nhvXLsuT4hvAo5wzWF2LnPrrnHNIK5UAAQWd8wG7nQavYjZ55kz6Sv6NrIbIRiLH6snKjYSokaIG4A6sDr6HlU7/LN5ZhsJYR2wDmM1gRUUi60Un1/N/Nf0DHueNLnhkbH0VC0B/skpwfPkRh6iEpdtKgDSZ3HH3cCbhnnU5wmcRXP9L4Z53GQLwbi2cyqBo4E3YLwKs3xiryT/ez3AKmAl8HuicD87Nj2kUvAyIRjXrvs0hC8z7J/F4XM0Tf7S8I4pSaMCIH0Wdb6aKP4dwYbr1tAOcnYy59S1D9N4ybXgziomTTqawJsx6zvow37esUpsO2YtxOE+LNzDtu13ckF+i3eoRFi89gywJcDIYRqxg9zIGfr2LyoA8leLOxYAnx+GkR4gVzyNc6asH4axkmnRuslE8QkEOwHCW4FXeEcaZkVgOXA7cXwrj0++jwUWe4dys7jjDfQtHDShrONY6CW2E2iu/01Zx5FUUAGQv1oQIiZ13gScVrYxzH7MqNw5nHno9rKNkUQhGNeufQ0hejeRvYsQpnhHSpgNwC1E9mNGbr2DM/Pd3oGG3XWd9RTDrUBDGUf5KE31SbsdUZyoAMjfWtxRS+AmjLeXYeuXMLfu05m62K/viu8zgPcCaXrwkqfnwW6B+Ba6a29j/sHZWa52cccrMFtGCCeUfuP2bzTVfaX025W0UgGQv7fwwWpGjL+MwAdLtMXthPABmiffUKLtJds1jx1MVDwbs3P1TX/IXiDwX4T4euYddo93mGGx4M4qJtZ9C+PDJdriDizMZ+7k60q0PakQKgCya4s6TsO4gqE849zsHkI4j6b6VaULlkBLCzVsHXkiRGdj8TuH8WLKLGkDriP0LqL58A3eYcpu0aOnEOW+RwiH7P1Gwr3kovN0sa3sjAqA7N7Sx0eypfd8ImsmhMZB/57ZPRB/gzn1t1T0lP91aw6kmGsCPsRQipLsiS6wpUTxN5kzeYV3mLL6y/vPuBCYPMjfKgK/Br7L3LqfVvT7T4ZEBUAGb8namcTRuyHkgWn0fSBtB7YTeAH4A4TfEsd3Vfyjexd3HEnggxhnM3y3b8nfCfcClzG6/ibOtKJ3mrJZECImdr4WwpvA3oSRB8YCIwAwe5gQr8bs9+RsGWfXPeWaV1JBBUBkT1y77nhC/FlgtncU+RsPE/gaPc/eoAWHRAZHBUBkMK559Fii6AvAW7yjyG6tAy5lc+/3+fDhXd5hRJJMBUBkd65d+zaCfR54o3cU2SOdEL5C96ZrNSMgsnMqACI7s2hdA1b8OtjJ3lFkSB6G8FmaJi/zDiKSNCoAIi91zWMHY8XPY8wDct5xpGQeINgnaK67zzuISFKoAIhA3+1WW3svBj4JjPaOI2URY/ZDcnxKV8mLqACIwOKO2cD36Lu1USrfC8DnGV33nYq+dVBkACoAkl1XrZ1AVfQNCO9H74XsCTyExfNpOuwP3lFEPOhDT7InBGNxxzzMvkH2HsMrL2Whl8DljK7+bOaeUCmZpwIg2XLV2gnk7EqMf/SOIonyKBbNYe6ke72DiAwXFQDJjsVrzwD7HjDeO4okkIVegn2L0ds+x5n5bu84IuWmAiCV7wfr9qU7/i5wlncUSYUW4P0V/wRLyTwVAKlsizpfjYVlDP5JaiIA2zH7EHPrrvEOIlIuKgBSua5dew7Bvo+e1id7za6nu+Z85h+8zTuJSKmpAEjluaIwhtGjriTwz95RpAIEHiIunlnxj7iWzFEBkMpy9ZopRLmbMaZ7R5GK8jyBs2iu/4V3EJFSibwDiJTMteuOIZe7Twd/KYNXYNzG4o6LvYOIlIpmAKQyLFp7LmZXADXeUaTS2VV0b7xAjxmWtFMBkHRbECImdX4L+Kh3FMmUX1MTvZv3TXrOO4jI3lIBkPRaWqhh66jrgPd4R5FMaqO390TOO/wJ7yAie0MFQNLpuqdHU9z+Y+Ak7yiSaZ1E8YnMOexh7yAie0oFQNJnyRPjiXv+F3idd5SE2QZ0Ap0Y68D+DGED2LOE8CzEzxKqtgJg8TZqoi4AtuzIUV07FoCqMIKe4ngsGg/sB2E8ZocAkwhMwpjU9+/lJdYT7O001/3RO4jInlABkHS5vvOV9IQ7Mn6lf4xZW9/jbEMrgRWEYoHmKY8Py+hXP74fUe8MImskhBkEZmK8GhgxLOMn04vE8cnMO+we7yAig6UCIOnxg3X70hPuJoRG7yjDbAdm9xDCPQQeoCd+gPmHveAd6m9c/sgIxlW/mpijIRwDHAfs6x1rmL0AzKapfrl3EJHBUAGQdAjBWLLuZkI4xTvKMFkN/IzIfsmOmt+kbinapSHH1s7XYryNmJMwXk821h3ppCZ6te4OkDRQAZB0WLz2PLArvWOUWRtwC3F8a8VNJS9cvT8jqt8B0RkQn0SwKu9IZXQtTfVN3iFEBqICIMl3wyNj6alaC4z3jlIG6wnheqLcYuZOKniHGRaLOw6CcDZYMzDNO04ZBAJH01z/O+8gIrujAiDJt7jjX4GvescooQD8gsiuZMfGWzO9oty1646BeF7/g5tqveOUjNmtzK071TuGyO6oAEiyhWBc2/kIcJh3lBLoAluK2SWZ+bY/WIseOQCrasbsQkI4xDtOCcSEYt2w3ZkhshdUACTZlqx9HbGlfSr1OQiXUqy+gnMP3eQdJtGWFmrYMup9RPYZQpjiHWdIAh+nuf5S7xgiu5KFq3IlzWI7zjvCEGwihP9LdW8dTZO/pIP/IJyZ76a5fjGdHdOxMAd4xDvSXovsLd4RRHankq/ElcpwhHeAvbAdwqVUFy/h/Ye/6B0mlRYc1wtcx9LwA7Z0NGH2ReCV3rH2SAhp/NuVDNEMgCSb2UTvCHsggC0DGmia/G86+JfAmVakefLVdI+YAvwrsNk70h6YSAg6zSqJpT9OSbZFHW0pWfb3jxCfT9Nhf/AOUtGueuQQqnLfBjvdO8qgdHcfwPypG71jiOyMZgAk2Yxu7wgD2Ab8K6PrXqeD/zA47/AnaJr8bsxOoe/BR8nW27vDO4LIrqgASNI96x1gN35Ob+9Umuov4UwreofJlLl1t9E9Io9xKRB7x9mFbi7Ib/EOIbIrughQEs6e7Vs3J0HMthCHT9JUdyVmCQuXIX3PR/g4iztuBhYDdb6B/o6m/iXRNAMgyRbiFd4R/kbgfoiOpLl+oQ7+CdFUfxfVva8CrvWO8jLJ+tsVeRkVAEm2EO7yjtAvEMK36Hn2zcyd+Kh3GHmZ9x/+Ik31TQTm0nddRhLc5R1AZHdUACTZHp98H/CUc4rnCbyT5smfzPS6/WnQXL+EYvH1wCrvKETx/3hHENkdFQBJtgUWA56PAW7Dcq+huf6njhlkT5w7pZVt214LOO6zcAdzDnvYb3yRgakASPJ1d38HeMFh5J/THb9RU/4pdEF+C+vq3gVc4jJ+FP27y7gie0ALAUk6LO78OIRvDdt4gcsZU/dx3d5XARZ1zMG4EqgZphF/QlP9O4dpLJG9phkASYd1k74N3D0MIwWMi2mu/4gO/hWiuX4JhFMwG4578tfTG84fhnFEhkwFQNJhgcV0d5+O2ZoyjlKEMJ+59V8v4xjioWnyrygWjwM2lHGUbiI7i/MmP1PGMURKRgVA0mP+1I309r4dWFeGrW8H3k3T5KvKsG1JgnmHPQj8H8r19xPi05lTd2cZti1SFioAki7nTllDVHUM8EAJt/pnAsfRVP+TEm5TkqipfhXwBkr79/MkFr2V5sNuLeE2RcpOBUDSZ86hf2b0tjcDC4ChPGwlQPgBUfWraK7/XWnCSeI11T/Nus43YXyevpmfofghueJRzJ10bymiiQwn3QUg6Xb12klU2cVgZxPCmEH+VgzcTOBrOvBn3HWPTqRoF4PNAUYP8reKBG7D+CpN9aWcSRAZVioAUhmue3o08baTie14ImsghIlYOJhgMX1PFNyI0Urgbqrsp5xd5726oCTJFYUxjB75DmI7HuMoYAKwPzAKeBp4DFhL4C6q7Wb9/YiIiIiIiIiISDroFIBIFi0IEYc/No4tvTHzD/NYZllEnKkAiFSaax47mKg3j0VHEIcjMOqBA4CD+/9z5C5+80XgKcw2EHgKwqNgj2C2mqrulbz/8BeH6yWISPmpAIikWQjGoo6Z5KITCOGNmL2OEA4pw0gx0I7xe4LdQ+j9Fc1THi/DOCIyTFQARNJmaaGGrSNPBDsdOBE4yCVHoJ3IbsPiZcyZ/HuXDCKy11QARNJiSefRhHAegXcCr/CO8zIdhPBDzK6mqb7TO4yIDEwFQCTJlj4+ki29czHOB2Z6xxmEmMAviOwK5kz6X8yCdyAR2TkVAJEkumbVPkQjmoFP0XfxXvqYtUL8DTrX/ZAFx/V6xxGRv6UCIJIkSws1bBs1l8CX6btivxKshvB/mVv/Y80IiCSHCoBIUizq+GeMrwKTvKOUhdk9YB9l7qQW7ygiogIg4m/RuslY/F36ruivdDGBq6npvUjrCoj4UgEQ8RKCsbjzoxj/zq4X56lUjxPiZpoPu907iEhWqQCIeLhq7QSqbBHwDu8ojgKBq+gZ8THmH7zNO4xI1qgAiAy3RY+egEU/AsZ7R0mIP1IM7+Lcyeu8g4hkSeQdQCRTru34AJH9DB38X+rV5KyFxWvf6h1EJEs0AyAyHBY+WE3N+KuAOd5REstCL9gFzK2/0juKSBaoAIiU2xWFMYwctRTj7d5RUuIS5tZ9WmsGiJSXCoBIOS3ueAXwS+C13lHSJXyXufUXqgSIlI8KgEi5LHx0HDXRL4HXeUdJJ7uKdZPOZ4HF3klEKpEuAhQphysKY3TwH6pwHpPWfds7hUilUgEQKbWFD1YzatQydPAvgfAhFnd+xjuFSCVSARAppRCM6vFXAyd5R6kc4css7pjrnUKk0ugaAJFSWtxxMfA17xgVqAfC8TRN/q13EJFKoQIgUirXrjueEP8CyHlHqVBPE1W9hjmH/tk7iEgl0CkAkVK4vvOVEH6EDv7ldBBx740sCPrcEikBvZFESqHIlYSwv3eMDHgTEzs/4h1CpBLoFIDIUC1e+1awX3rHyJAXiKoPY84hz3oHEUkzzQCIDJn9m3eCjBlH6LnAO4RI2mkGQGQoruucTjG0ecfIoD+zrm6iVgkU2XuaARAZiph3eUfIqH9gYqeeryAyBCoAIkMz2ztAZhnHeUcQSTMVAJGhCOEo7wgZdqR3AJE0UwEQ2VsLnxwFjPeOkWGHegcQSTMVAJG9tnmUd4IhMdsCdHnHGIIx3gFE0qzKO4BIatXUbPGOMEh/gnAHwVaQsxX05NYx9pAXONOKACzuqKU3jKOKIyCaAfGrwU4C/sE39gACW70jiKSZbgMUGYpr1/YQLIlF+lGw70K4iab6zj3+7RCMRWtnYXYWZucC40qecKjMbmdu3Vu9Y4ikVRI/uETSI9gTQJ13jJdYDnyBdXU3D+keebMAPAg8yBWFBYwe1Uzg34ADS5SzBMLj3glE0kzXAIgMiSXj8bRmGwmcz+i619BU/5OSLpBzQX4Lc+svpzs+AuNSoKdk2x6KmGT8by+SUioAIkNh4R7vCMBvKEavorl+4f8/r18O8w97gbn1H4f4GKCjbOMMVpS72zuCSJqpAIgMRVz8GVC+g+7ALmF03fHMm/jksI3YdNgfiKpfC/xq2Mb8eyuYO/FRx/FFUk8FQGQomqc8TuA2h5ED2Cdoqv/Xsn7r35U5hzzL6G2nADcN+9gAFr7lMq5IBVEBEBmqKPoiEIZ1TLMP0VT3H8M65sudme9mXed7CCwd1nHNnqBr043DOqZIBVIBEBmquZNagMXDNp5xKXPrrhi28XZnwXG9GHMI3D9sY8bhU8x/TTIuRBRJMRUAkdL4BLB2GMb5X0bVXTQM4wxeU/0OiuGdwLqyjxVYSnO9vv2LlIAKgEgpNNU/D/E/Ac+XcZSVVPf+s8s5/4GcN/kZovCPwOayjRF4iO3b5pVt+yIZowIgUipNh60kcBLwXBm2vpJc8QTef/iLZdh2acyZvIJgJwEvlGHry+npfhsX5NOy/LJI4qkAiJRSc/3viOI3EGgv2TYDN9Mdv4lzpqwv2TbLpbnuPkL0RuDhEm71J2zb9ibmT91Ywm2KZJ6eBSBSDksfH8nW4hcgfASo2attmG0kjj9NU/01/Uvzpsd1T48m3v4lAhewt68fNgCfoqn+2tIFE5G/UAEQKafrOuuJw0UE3g/sM8jfehTsP+iuuZb5B28rZ7yyu+axg4mKHwbOZ/APFHqMwPcJXd9h3rTyXVMgknEqACLDYeGTo6jZcTwwG3gV2D8AI4EuYDOBxzDuJtjdPDZpeUnX8k+ChU+OYkTP0YT4TRCOBXsFsC9QhdmLhPAo8BCR/ZKOSb+ruNcvIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIqlg3gFEZO/k8/ma3t7e/WtqasaHEMaHEMab2QHA+BDCeGC8mY0EqoExACGEUcCI/k2Mo+8z4HkAM+sBtvT/3HYz2xFC2Gpmz8Zx/KyZbTSzZ83sWWBTd3f3szNnznxm2bJlxeF95SJSCioAIgk1a9as6p6enkOKxWKdmdWHEOqAOqC+/59XApFjRIAe4AmgE1gXQug0s84oijp7e3s729vbHwOCa0IR2SkVAJEEmDFjxr5xHOfNbFYIoQHIA68GRjpHG6puYA3QAhSAtjiOH2xvb3/KN5aIqACIDLOBmn9AAAAgAElEQVR8Pn+Qmb0xhHAMcCTwKmC8c6zh9gyw3MweCCHcX1tb+0BLS8sL3qFEskQFQKS8ounTpzeY2TFm9kbgGOAw71AJFJtZWwjhPuD+XC53/4oVK1Z7hxKpZCoAIiWWz+cnAif1/3Mc8ArfRKn1pJn9AvhFb2/v7atWrXrWO5BIJVEBEBmi2bNnV23YsOENwCnACfSdu9d7q7Ri4CHg9jiOb4+i6O5CodDtHUokzfQhJbIXpkyZMra2tvYfgdNDCCfQf5udDJvngJ+a2Y9DCL9SGRDZcyoAIoN09NFHj3zxxRdPAM4A3gWMdo4kfZ4Hbgkh3DJy5MjbWlpatnkHEkkDFQCR3airq6sdPXr0KWZ2ZgjhZGCUdybZrRdCCLeY2Q2FQuFX9J06EJGdUAEQ2YkZM2ZMi+N4LjAP2N85juydPwM3RFF05cqVK9d6hxFJGhUAkX51dXW1o0aNOjWKog/0n9eXyhAD9wPX1dbW3qBTBCJ9VAAk8/L5/JFmdn4I4Z+Bsd55pKw2AUtyudx/rlixosM7jIgnFQDJrHw+fyxwMXAyei9kTQz8bxzHl7W3t9/uHUbEgz70JFPy+XwNcJaZXRRCaPTOI/7M7I8hhMtqa2tvbGlp6fHOIzJcVAAkE/L5/H790/wfAg7yziOJ9Djw7dra2u/rOgHJAhUAqWhTp07dp6qq6l+ATwPjvPNIKmwEvllbW/ufKgJSyVQApCLNnDlzdLFYvJC+c/z7eueRVNoAfGvs2LGX33///du9w4iUmgqAVJRZs2aN6urqOi+E8GlggnceqQgqAlKRVACkIvQ/kGc+8Fl0jl/K4zHg04VC4UYgeIcRGSoVAEm9fD7/FuBSYKZ3FsmEB0MIH29ra/utdxCRoVABkNTK5/NTzOwrIYQzvLNIJt0aRdFHtMywpJUKgKTOrFmzxm3fvv2zZvZhoMY7j2TaDjO7tKen56urV6/e7B1GZE+oAEiqNDY2nh1C+CZwoHcWkZd4HLiwUCjc7B1EZLBUACQVpk2bVpfL5b4PnOidRWQ3bs3lch9csWLFE95BRAaS8w4gMoAon8+fF0XR/wAN3mFEBnBECGHehAkTtq9fv/4P6G4BSTDNAEhiTZ8+vTGXy10VQniDdxaRvXBfCOEDbW1tBe8gIjujGQBJnNmzZ1eNGTPmc2Z2AzDJO4/IXjrUzOZNmDCha/369Q+g2QBJGM0ASKL0n+u/HjjWO4tICd0XRdHZumVQkiTyDiDyF/l8/pxcLrcCHfyl8rwxjuM/NjY2nu0dROQvNAMg7mbNmjVux44d3wXe651FpNzMbFkI4fxCobDJO4tkmwqAuOpfxncJcIh3FpFh9BjwvkKhcI93EMkuFQDxYo2NjZ8JIXwBXYw6VF1AJ/A08CywMYSw0cye7f+/n4vj+C/Ptd9SVVXV09vbG6qqqp4H6O3tfUVVVZXFcRzFcTwOIIqiUcB+IYTxURSNDyHsD4zv/+fQ/n+qh/NFVqAeM7uotbX1Mu8gkk0qADLs+qf8lwCneWdJka1AG7DCzDriOO40s87e3t6O1atXP8UwX2F+xhln5Nrb2w8OIUwys/r+/5wWQmgEpqMlmvfEj4DzCoXCFu8gki0qADKsGhoa8mZ2E3CEd5YEe9LMfh9CWAGsjOP4T+3t7Y8CsXewwZg1a1b19u3bj4iiqDGO45lmdhRwNPAK72wJ1pbL5d61YsWK1d5BJDtUAGTYNDQ0nGZm1wFjvbMkzFrgXuCeEMK9lbpwzIwZMybHcXxsCGGWmR0DHIXuRHqpzSGEeW1tbcu8g0g2qABI2Z1xxhm5QqHwNTP7BPqbA+gMIfzczH7W1dV115o1a170DuRh5syZB8Zx/LY4jk80s7cCE7wzJUAALikUCp9BCwdJmenDWMpq5syZo4vF4g+Bf/TO4qgLuBv4uZn9rLW1td07UALZ9OnTj4qi6G3AycAbyfDsgJkt22effebcf//9272zSOVSAZCyyefzBwG3AK/xzuKgCDxgZsuqq6t/+NBDD23wDpQmRxxxxP7V1dXvAM4ATgKqnCN5+J2Zndba2vqMdxCpTCoAUhb9F/vdRrbW8i8Cd5jZ0hDC/2ihl9KYPn36K6MoOh34Z/pmBrJkbRRFJ69cuXKVdxCpPCoAUnL9i/v8N9m56vvPwA1xHH+vvb19nXeYSjZz5sypxWKxCZhLdq4ZeA44vVAo3OkdRCqLCoCUVD6fnwNcReUvEtMD3AxcVSgUfkVKbtGrFLNmzaretm3byVEUzQPeTuUvJtUdQmhua2v7gXcQqRwqAFIyDQ0NHzKzy6jsv6sNZvZd4Hs6N5sMM2fOrC8Wix8GmqnsW0xjM7ugtbX1+95BpDJU8ge1DKN8Pn8x8DXvHGX0qJn954gRI65qaWnZNvCPy3CbOnXqPtXV1c0hhI8Cdd55yiSY2adaW1u/6R1E0k8FQIYsn89/Gfg37xxlcg/wjUKhcCua5k+F/nUn3mVmnwVmeucphxDCgra2ti9455B0UwGQobB8Pv9N4OPeQcrgd8C/FwqFW7yDyF6zfD5/ipktCCG82jtMGXynUCh8GC0YJHtJBUD2luXz+cuBC72DlNjKEMKX2trafow+WCuF5fP5U4Av0Lf8cCW5slAofBDNTsleUAGQvWH5fP5K4FzvICW0ysw+09ra+hN04K9UUT6fPwv4KjDRO0ypmNnC1tbWD6K/W9lDlX7rjJRBQ0PDN8ysUr75Pw8s6Orqmrtq1apW7zBSVmHDhg0rp0yZsrCrq2sz8DpghHeoEnjNAQccsO+GDRt+7h1E0kUFQPZIQ0PDv5vZxd45SiAGbsjlcv/Y2tr6y02bNhW9A8nweOKJJ3o3bNhw77777nt1FEW1ZvYaUv7cATN7/YQJE2z9+vV3eWeR9NApABm0xsbGz4QQ/t07RwncGcfxh9vb2/WNX2hoaDjKzL5P34xAqpnZRbpFUAZLBUAGpX+Rn8u9cwzR88DFhULhKnS+VP5WlM/nzwW+CezjHWYIQv9iQd/zDiLJp1MAMqDGxsZm4HukuzD+GDi5UCj8xjuIJFLYsGFDy4QJE24ApgBTvQPtJQPePmHChLXr169f4R1Gki3NH+gyDPL5/InAraT3caxPhhD+pa2t7afeQSQ98vn8u4HvkN4HDvWEEN7e1tZ2h3cQSS4VANml/kf63kN6n+r338AH9Fhe2RtHHXXUAd3d3VcBp3ln2UsvRlF07MqVK1d6B5FkUgGQnZo6derBVVVV95PO+6U3A58sFApXegeR9Mvn8+cAVwBjvLPshU4ze4MeXCU7owIgfyefz48Bfgsc6Z1lL/weeF+hUFjjHUQqR/8TB68HjvHOshdacrncm1esWLHVO4gkS6rvfZXSmz17dpWZ/RfpO/jHwBcPOOCAY3Twl1JbsWJFR21t7XHAN0jfHSSzisXidejzXl5GdwHI3xg9evRlwPu8c+yh50II725ra7uqs7NTa6JLWTz11FPxhg0bfjVhwoSVwNtJ1yqC0w844IDRGzZs+JV3EEkOnQKQ/6+hoeF9ZnaDd4499CczO721tfVR7yCSHdOnTz88iqL/BmZ4Z9lDcwqFwnXeISQZNCUkAOTz+VeZWdoumrsxl8sdo4O/DLf29vZHxo4d+3rgWu8se+i706dPb/QOIcmgGQAhn8/vBzwI1HtnGaQicFGhULjUO4hIPp//FH1PGEzLF6qHu7q6XrtmzZoXvYOIr7T8wUr5RMANpOfgvy2EcLoO/pIUhULh62Z2BrDNO8sgHTFixIjr0RfAzNNFgBmXz+e/CMzzzjFITwMntrW1/do7iMhLrV+/vv2AAw64w8xOJR3rBUw98MADt2/YsOFe7yDiRw0ww6ZPn/6OKIpuIR0zQW3FYvHkVatWdXoHEdmVGTNmTI7j+DZgmneWQSgCbysUCirUGaUCkFEzZ848sFgsriAda53fU11dfery5cuf9w4iMpAZM2bs218CjvbOMghP9fT0zHz44Yc3egeR4ZeGb35SelYsFq8mHQf/u4C36+AvabFy5crncrncW4E03HP/yurq6qu9Q4gPXQOQQfl8/kLgo945BuG2rVu3nvbII4+k5eIqEQCeeeaZnnHjxi2trq5uJPmnA6ZNmDDhifXr1z/kHUSGl2YAMqaxsXE68HXvHAMJISytra19Z2dn5w7vLCJ7Y82aNV3777//GcD13lkGEkK4bPr06Yd755DhpQKQIVOmTBkRQvghMNI7ywCW5PP597a0tPR4BxEZirvuuqu3oaGhCVjinWUAo6MoWjJ79uwq7yAyfFQAMqSmpubLJP8hPz9qaGiYt2zZsqJ3EJFSWLZsWbGhoWEe8CPvLAM4esOGDZ/xDiHDR3cBZERDQ8Przexekn3dx09ra2vP0Dd/qUSzZs2q3rFjx38Dp3pn2Y3eKIresHLlyhbvIFJ+KgAZMHv27KoNGzb8gQR/+zez27ds2XKqzvlLJcvn8zXAT+h7mmBS/am2tva1KuKVT6cAMmDDhg2fJsEHf+C+EIIu+JOKVygUumtra99tZnd7Z9mNV+3YseND3iGk/DQDUOFmzJgxLY7j5ST32eUru7q6jtWDSSRLZs2aNa6rq+ueEEJSn8y3tVgsNmrlzcqmGYDKFsVxfBXJPfg/BZyig79kTUtLywu5XO4k4AnvLLswOpfLfc87hJSXCkAFy+fz5wPHeufYhW3APxUKhce8g4h4+NOf/vTnOI5PA7Z6Z9mFkxobG9/jHULKR6cAKlRjY+OEEMJqYJx3lp0omtlpra2tt3kHEfHW0NBwmpndRDK/kD0TRdH0lStXPucdREoviX9wUgIhhC+TzIM/wEd08Bfp09bW9lPgE945dmFCCOEL3iGkPDQDUIHy+fyRwIMk857/6wuFwjneIUSSJp/PXw3M886xE70hhCPb2toK3kGktDQDUJm+TTIP/g+NHTt2vncIkSTaunXrhUASF+CpMrNLvENI6akAVJiGhoYzgDd759iJZ3O53On333//du8gIknU2dm5I47j04GN3ll24uR8Pn+idwgpLRWAClJXV1drZkl80l/RzN67YsWKDu8gIknW3t6+zszeCyTxWRj/oYcFVRYVgAoyZsyYjwN13jl24rOtra2/9A4hkgatra2/MrMve+fYiYb169cn8RoF2Uu6CLBC5PP5/YAOYKx3lpf5daFQeCsQewcRSZEon8//muSdzlvf1dV1uBbvqgyaAagcF5G8g//zQBM6+IvsqTiXy70fSNr99weOGDHiI94hpDQ0A1ABjjjiiP2rq6vXAvt4Z3kpMzurtbX1v7xziKRVY2Pj+0MI13vneJkXqqur65YvX/68dxAZGs0AVIDq6upPk7CDfwhhkQ7+IkPT2tp6A3Cjd46XGdfT0/Nh7xAydCoAKTd16tSDgQ9653iZtcVi8aPeIUQqQRRFFwCPe+d4mY8deeSRr/AOIUOjApByVVVVnwZGeud4iRDH8fzVq1dv9g4iUgn61+E/zzvHy7yit7dXJT/ldA1AijU2Nh4aQniEBD3u18wWt7a2NnvnEKk0+Xz+B8B7vXO8xAtRFNXrQUHppRmAFAshfIwEHfyBZ0IIn/QOIVKJcrncx4BN3jleYlwcxx/zDiF7TwUgpaZMmTKWhD04JITw4UKhkKQPKJGKsWLFivVmdpF3jpe5cObMmaO9Q8jeUQFIqdra2vkk677/W9ra2pZ6hxCpZK2trYuBu7xzvMS+xWJxjncI2TsqACk0a9as6hBCkm7D6YqiSBcEiZRfyOVy5wPd3kFe4iPoWJJK2mkp1NXVdRZwiHeOvzCz/1i5cuVa7xwiWbBixYrVwBXeOV7iiHw+f7J3CNlzKgAp1H/xX1I8s2PHjq95hxDJkiiKvkSyHhucpM8kGSQVgJRpaGg4HjjKO8dfhBA+rQeDiAyvlStXPhdC+KJ3jpc4Lp/PH+kdQvaMCkDKmNm/eGd4iQfb2tqWeIcQyaKRI0d+H1jlneMldB1QyqgApEg+nz8IONU7x0t8Cj3pT8RFS0tLT8JuC3xP/2PJJSVUANJlLlDtHaLfrwuFwp3eIUSyrLW19Vbgt945+tWSrJUKZQAqAOlhQGKW2I3j+AveGUQE4jhO0rUASXtmgeyGCkBK5PP544DDvXP0+1l7e/vd3iFEBNrb2283s6S8H2c2NDQk5iJl2T0VgPRIUrNe4B1ARP4qhJCYGTkzS9QS5bJrehpgChxxxBH7V1dXP0EyHvxzc6FQOM07hIj8rcbGxt+EEP6Pdw7gua1btx7c2dm5wzuI7J5mAFKgurr6LJJx8Af4uncAEfl7CboWYN/Ro0e/yzuEDEwFIB3O9A4AYGYPFAqFe71ziMjfa2truwNY7p2j3zneAWRgKgAJN3Xq1IOBY7xzAIQQvumdQUR261LvAP3eMm3atPHeIWT3VAASrqqq6j0kYz91NDQ0/MQ7hIjsWm1t7Y3AE945gOqqqipdK5RwSTiwyG6YWSKm/4H/WLZsWdE7hIjsWv/qgN/3zgEQQni3dwbZPRWABMvn8xNDCK/3zgG8AFzrHUJEBtbd3b0Q2O6dAzhhxowZ+3qHkF1TAUiw/m//SbhV84eFQmGLdwgRGdjDDz+8MYRwo3cOoDqOY50GSDAVgARLyhRaHMdXe2cQkcEzs0XeGQDM7AzvDLJrSfh2KTsxc+bMA4vF4lP4l7SWQqHwGucMIrKH8vl8OzDNOUZ3bW3tgS0tLS8455Cd8D64yC7EcXwiydg/V3oHEJG9stg7AFDT1dV1vHcI2bkkHGBkJ0IIb/fOAGzt6ur6kXcIEdlzZrYE6PHOEUI40TuD7JwKQAKdccYZOeCt3jmAm9asWfOidwgR2XOtra3PAP/rnQNQAUgoFYAEam1tfS2wv3cOM/sv7wwisvdCCD/wzgBMmjlz5lTvEPL3VAASKJfLneSdAXg+hPAr7xAisvdGjhx5G7DVO0f/NU2SMCoACZSE8/8hhJsKhUK3dw4R2XstLS3bgJ9550CnARJJBSBhZs2aNQ5wv+3OzJZ5ZxCRoTOzH3tnCCHMrqurq/XOIX9LBSBhduzYcTT+++XZ2traO5wziEgJhBBuw39p4FH77LNPEpY1l5fwPtDI33ujdwDgtpaWFvfbh0Rk6PqX8XY/DVAsFpPw2SYvoQKQPMd6ByABHxYiUjohhFu9M5jZ0d4Z5G+pACTI7Nmzq4DXOscoFotFXf0vUkFCCD8HgnOMN6Ll5xNFBSBBNm7ceCQwxjnG71etWvWscwYRKaH29vanzKzgHGP8zJkzj3DOIC+hApAsx3gHQNP/IpXqF94Bent7dR1AgqgAJEgcx0l4c/zcO4CIlF6xWHR/b+s6gGRRAUgQM5vlHOH5QqHQ4pxBRMpg+/bt9wDbPDOoACSLCkBC5PP5MUC9ZwYzuw+IPTOISHl0dnbuAB7wzBBCmH700UeP9Mwgf6UCkBBRFM3Af3/c6zy+iJTXfc7j51544YVpzhmkn/cBR/oVi8WZ3hnMTAVApILFcXy/d4Yoihq9M0gfFYCEMLMZzhF6ampq/uCcQUTKaMSIEe6n+UIIKgAJoQKQHN4zAMv7nxwmIhVq+fLlzwOrnGN4f9mRfioAyeHais3M9eIgERk23qcBVAASQgUgARobGw8F9vXMEEJY4Tm+iAwPM3vQOcIhM2bMcP28kz4qAAkQQpjinQFQARDJgBBCq3eGOI4bvDOICkAimJnr/f9AnMvlvNcJF5FhUFtbuxLnBwOZ2WTP8aWPCkAChBDqnCOsWbFixVbnDCIyDFpaWl4AnvDMkIDPPEEFIBFCCN4zAJr+F8kW79MAk5zHF1QAEsHMXN8MSTgnKCLDyrv01zmPL6gAJIXrDEAURY96ji8iw857LYA65/EFFQB3+Xy+BjjYM0MIocNzfBEZduucxz8UHX/caQf4m4jzfqiqqur0HF9EhlexWPQu/TUzZ850/eIjKgBJcJDz+F1/+tOfnnLOICLD6KCDDnoC6PXMEEI41HN8UQFwF8fx/s4R1uH8cBARGV533XVXL/BnzwwJ+OzLPBUAZ7lcbrxzhE7n8UXER6fz+N6ffZmnAuAshOD9JnjSeXwR8fGY5+AJ+OzLPBUAf97TYBucxxcRH67v/SiKVACcqQA4S0ALftZ5fBFxYGau7/0EfPZlngqAMzPzngFQARDJoDiOvd/7KgDOVAD87ec5uJlt8hxfRNx4v/dVAJypAPgb4zl4sVjc6Dm+iPjwPgUAjHMeP/NUAPzVOI/v/S1ARHx4FwDvz77MUwHwN8Jz8Fwut91zfBHxEcfxNucIKgDOVAD8eb8Jup3HFxEHURR1OUdw/fIjKgBJ4P0mUAEQySbv9773l5/MUwHw5/omqKqq8v4WICIONAMgKgD+XAtALpfz/hYgIg7MzPu9rxkAZyoA/lxb8OTJk72/BYiIg+rqahWAjFMB8JfzHHzZsmVFz/FFxEdLS0uPc4Rq5/EzTwVAREQkg1QAREREMkgFQEREJINUAERERDJIBUBERCSDVABEREQySAVAREQkg1QAREREMkgFQEREJINUAERERDJIBUBERCSDVABEREQySAVAREQkg1QAREREMkgFQEREJINUAERERDJIBUBERCSDVABEREQySAVAREQkg1QAREREMkgFQEREJINUAERERDJIBUBERCSDVABEREQySAVAREQkg1QAREREMkgFQEREJINUAERERDJIBUBERCSDVABEREQySAVAREQkg1QAREREMkgFQEREJINUAERERDJIBUBERCSDVABEREQySAVAREQkg1QAREREMkgFQEREJINUAERERDJIBUBERCSDVABEREQySAVAREQkg1QAREREMkgFQEREJINUAERERDJIBUBERCSDVABEREQySAVAREQkg1QAREREMkgFQEREJINUAERERDJIBUBERCSDVABEREQySAVAREQkg1QAREREMkgFQEREJINUAERERDJIBUBERCSDVABEREQySAVAREQkg1QAREREMkgFQEREJINUAERERDJIBUBERCSDVABEREQySAVAREQkg1QAREREMkgFQEREJINUAERERDJIBUBERCSDqrwDiCTBlClTxo4YMeJk4C3Aq4A64BVA9QC/2gM8D3QCy4Ff9/b23rZ69erN5Uu7Ezc8MpbuqpOJ7C2EsCf5B/KS12fLIfyauOs25k0b1teX+v0jkkDmHSDr8vl88By/UChk+m9g2rRpR0RRdLGZnQWMKtFmtwE3xnF8SXt7+yMl2ubOLXn0COLoYqCU+QeyDcKNEC6h6bCyvr7U75+E0+dPtul/fGd6A/o4+uijR27evPlLIYSPUL6ZsB7g21u3bv1cZ2fnjpJueenjI9nS8yUiPkIwr5m8HrBvQ/gcTfUlfX2p3z8poc+fbNM1AJI506dPP3zz5s2/DyF8gvKeBqsGLhozZsyd+Xz+oJJtdfGjh7Ot+HvMPuF48AeohnARcCeLO0r2+lK/f0RSQgVAMqWhoeGoKIruDSE0DteYIYQ3AH+YMWPGjCFvbEnnURDdyzDmH4Q3YPYHFj865NeX+v0jkiIqAJIZ06dPP9zMfgEc4DD8IXEc3zakb5qLHz2cOHjl370QDoHotqHMBKR+/4ikjAqAZEJdXV1tFEXL8D14HgrcNGXKlBF7/JuLO2rBPf9ADiVwE5c/ssevL/X7RySFVAAkE8aMGfNl+m4f83b0iBEjPrPHvxVCUvLvnnE0Y6r2+PWlfv+IpJAKgFS8adOmHdF/NXlSfHyPppqXPHoEEUnKv3uRfXxPTgWkfv+IpJQKgFS8KIouJlmLXo0BPjfon46ji52v9t8zIYzBBv/6Ur9/RFJKBUAq2pQpU8b2LyKTNOdMnTp1nwF/6oZHxtK3yE+6BM7hmlUDvr7U7x+RFFMBkIrWv3zscK2QtydGV1dXv2PAn+quSmr+gYzGRgz4+lK/f0RSTAVAKt1bvAPsSghh4GyRJTb/IAwme2Jf36D2j0iKqQBIpUvCleU7ZWYzB/yhvgf7pJMx8OtL+/4RSTEVAKl09d4BdiWEMHnAHzJLbP5BGPj1pX3/iKSYCoBUurHeAXZj3IA/EUKS8w9k4NeX9v0jkmIqACIiIhmkAiCV7kXvALvxwoA/YZbk/AMZ+PWlff+IpJgKgFS6Du8Au2Jmawf8oRASm38QBn59ad8/IimmAiCVbrl3gN3408A/YknOP5BBvL607x+R9FIBkEr3a+8AuxLH8R0D/1RIbP6BhUG8vrTvH5H0UgGQSncrsMU7xE5sNbOfDfhT27bdilkS8w9kK9u2D/z60r5/RFJMBUAqWqFQ2AL8l3eOnfhBf7bduyC/hRAnMf/uBX7ABfkBX1/q949IiqkASMWL4/gSoMc7x0t0R1F0yeB/PCQt/0C6YfCvL/37RySdVACk4rW3tz8CfNs7x1+Y2bdWrlw5+CvMmw57BCwx+QdkfIvmSYN+fanfPyIppQIgmbB169bPmdkD3jmA+3bs2PGFPf+18DkgCfkHch8v9u7x60v//hFJHxUAyYTOzs4dIYR3Ao87xniyt7f3jDVr1nTt8W821e8AvPMP5Eni3Bl8+PA9fn2p3z8iKaQCIJlRKBSejqLoZOAJh+Efj+P4xNWrVz+511toqn8a4pMx88g/kMcpFk9k3sS9fn2p3z8iKaMCIJmycuXKlT09PUeZ2d3DOOz9wOva29tbh7ylpsNW0tV1FDCc+Xcv9L0+zp0y5NeX+v0jkiIqAJI5Dz/88MYdO3a8DfgisLWMQ3Wb2Ve7urqOKxQKT5dsq/OnbmRz79sIZc8/kG6Mr7Kl97i+2YnSSP3+EUkJ8w6Qdfn8/2vv7kLkuss4jv+emX0ZTWNSk8wGgi9F2CV7htmFlSLWYoKvsbagshakTQUVoRQFb0qRFowXFquglXqhQrAlLcQI3rRYKU1SNNSXzermnOxuSAmlLV0yzJ8AAAbgSURBVHEdUivtmm12Zh8vtpht0zSbZHafM3u+n5tcJf/vvsyZJ+ec+Z/EI9fPsqzQvwNJkmyVdJ+k3ZLWtemfnZW0r1wu3z8xMbGye93vPbVVpvvkbe2/lFm59qnL7tfuD67o19fxP5+c4/hTbHzzg/ECzIckSa4xs5sk7XT3YUnXSdooqecSf/WcpFcknXL3cUkHzeyJVd9E5qHsGr3r3TfJtFPS5fRfyv+/PknjMj+o2bNPLGeTn3bq+J9PTnH8KTa++cF4AQKIwvGn2LgHAACAAmIAAACggBgAAAAoIAYAAAAKiAEAAIACYgAAAKCAGAAAACggBoB4zcjFd+zY0RW5PoAYIyMj3cEJ88HrFx4DQLxXIxc/c+bM+sj1AcSYnZ19T3ACuzEGYwCIF/oiWFhYeH/k+gBimNkHghNC//MDBoA8CH0RuHstcn0AMcrlchKcwAAQjAEgXuiLwMx2RK4PIMzOyMXNjAEgGANAvOjnkN/CjYBAsYyMjHS7++cjG9z9dOT6YADIgxPB61dnZmZCDwQAVtfc3NwtkrYEZ0Qf+wqPASCYmU1HN5RKpXvEo6GBojBJ90RHuHv4sa/oGACC5eRFcP3g4OBXoiMArLwkSe6QNBLdUS6Xp6Ibio4BIFhPT08eBgCZ2U/q9fp10R0AVk6tVvuQpB9Hd0jS/Pw8lwCCMQAEGx8fb0h6LrpD0uZWq/X4yMjIhugQAO03MDCwXtLvJL03ukXSiampqTPREUXHAJAPT0cHvGH73NzcY/V6fV10CID2qdfr67q6uvbnZd8Pd8/LMa/QGADy4WB0wBK7Wq3Wke3bt0fvEgagDYaGhra1Wq1Dkj4b3bIEA0AOMADkw0FJHh2xRL1UKj2bJMmXxKcDgI6VJMnNzWbzqKQPR7cs4b29vYeiI8DBPTeSJPm7pKHojrcys2dbrdbdk5OTz0S3AFieJElukHSvpM9Et7yNsSzL8jSQFBY7wOWEme1z99wNAO7+kVKpdLhWq6Xuvl/S081mc2J6epptPIGcGBgYWN/V1VV390+a2aik6H3+38mj0QFYxBmAnBgaGtrWbDafl1SOblmmf2nxSYb/jg4BCuxaSesVv6vfcrUWFhbeNzk5yTbAOcAAkCNJkvxB0qeiOwBghfw+y7Jd0RFYxE2AOWJmD0c3AMAKeiQ6AOcxAOTI3NzcbyS9FN0BACvgRUkHoiNwHgNAjpw8efJ1ST+K7gCAdnP3H2ZZdi66A+cxAORMpVL5hRZvsAOAtWJmw4YNv4qOwJt1yh3nhXH69On5vr6+HkmfiG4BgHYwsz1Hjx49HN2BN+MMQA65+4OSXojuAIA2eL63t/eh6AhciDMAOdRoNM5Vq9UXJH05ugUAroa7f3ViYiKN7sCF2Acgx2q12uPu/rnoDgC4Qk9mWZanhxBhCS4B5Ji7f1vSXHQHAFyBs6VS6c7oCFwclwByrNFovNzX1/ea8vUYTwBYju+kafpkdAQujksA+WdJkhyQ9MXoEABYpgNZlo1GR+CdcQkg/7y7u/trkk5FhwDAMjxXqVS+Hh2BS+MMQIdIkuR6SYclVaJbAOAizpZKpRuPHTs2Fh2CS+MMQIfIsuwvkm6V1IxuAYC30TKz23jz7xzcBNhBGo3GdLVanZF0c3QLACzhkr6ZZdm+6BAsHwNAh2k0GmNbtmyRme2IbgEASTKze7Ms+2l0By4PA0AHajQah6vValnSx6NbABSbmX0vTdPvR3fg8jEAdKhGo3GwWq02JO0SN3MCWH0tM7srTVMeYd6heOPocLVa7Qvu/qj4dACA1fO6u+8+fvz4/ugQXDkGgDVgcHDwRjN7TNK26BYAa96LZnZrmqZHokNwdRgA1oj+/v7N3d3dD2vxkgAAtJ2ZPSXptjRNZ6JbcPUYANaW0uDg4N1mtkdSV3QMgDWjKem7WZY9oMWP/GENYABYg5IkGZL0c0kfjW4B0PH+JunOLMv+Gh2C9mIAWLssSZLbJT0gqRodA6DjvGxme9I0/ZmkhegYtB8fA1zDGo3GPzZt2rS3VCp1SapL6oluApB7r7n7g+VyeTRN00PilP+axRmAgujv79/c09Nzl7t/S9K10T0AcudVd99rZj/Isuyf0TFYeQwABTM8PLyx2Wx+Q9Jud69F9wCIZWappF/39vb+cmxs7D/RPVg9DAAFNjg4mJjZ7ZLukLQ1ugfAqjkj6beSHsmy7I/RMYjBAACNjo6Wp6amht39Y5JucPdPS9oQ3QWgbf5rZkfc/SlJf6pUKn8eGxubj45CLAYAXCBJkh5Jw5K2m9mAu/e/8ec2SRvF7w2QRy7pFTN7yd2nzeyEu09LmqxUKuO84eOt/gd4kLPwSY/IrwAAAABJRU5ErkJggg=="};var _t;!function(e){e.PLAY_NOW="play",e.PLAY_NOW_CLEAR_QUEUE="replace",e.PLAY_NEXT="next",e.PLAY_NEXT_CLEAR_QUEUE="replace_next",e.ADD_TO_QUEUE="add",e.RADIO="radio"}(_t||(_t={}));const $t={en:{"browser.card.favorites":"Favorites","browser.card.recents":"Recents","browser.card.recommendations":"Recommendations","browser.enqueue.play":"Play Now","browser.enqueue.next":"Play Next","browser.enqueue.play_clear":"Play Now & Clear Queue","browser.enqueue.next_clear":"Play Next & Clear Queue","browser.enqueue.queue":"Add to Queue","browser.enqueue.radio":"Play Radio","browser.search.placeholder":"Search Music Assistant","browser.sections.album":"Albums","browser.sections.artist":"Artists","browser.sections.audiobook":"Audiobooks","browser.sections.playlist":"Playlists","browser.sections.podcast":"Podcasts","browser.sections.radio":"Radios","browser.sections.track":"Tracks","player.controls.power":"Power","player.controls.shuffle":"Shuffle","player.controls.repeat":"Repeat","player.controls.favorite":"Favorite","player.controls.previous":"Favorite","player.controls.play":"Play","player.controls.pause":"Pause","player.controls.play_pause":"Play/Pause","player.controls.next":"Next","player.header":"Media Player","player.messages.inactive":["Except the sound of silence.","It's just so quiet in here.","Are you seeing other players?","Please don't leave me alone with my thoughts.","I hope you don't have tinnitus.","Why not do something productive instead?","Let's use our imagination instead."],"player.title.inactive":"Nothing is currently active!","players.header":"Players","queue.header":"Queue"},nl:{"browser.card.favorites":"Favorieten","browser.card.recents":"Recent afgespeeld","browser.card.recommendations":"Aanbevelingen","browser.enqueue.play":"Nu afspelen","browser.enqueue.next":"Volgende afspelen","browser.enqueue.play_clear":"Nu afspelen & wachtrij wissen","browser.enqueue.next_clear":"Volgende afspelen & wachtrij wissen","browser.enqueue.queue":"Toevoegen aan wachtrij","browser.enqueue.radio":"Radio afspelen","browser.search.placeholder":"Zoek in Music Assistant","browser.sections.album":"Albums","browser.sections.artist":"Artiesten","browser.sections.audiobook":"Luisterboeken","browser.sections.playlist":"Afspeellijsten","browser.sections.podcast":"Podcasts","browser.sections.radio":"Radiozenders","browser.sections.track":"Nummers","player.controls.power":"Power","player.controls.shuffle":"Random","player.controls.repeat":"Herhalen","player.controls.favorite":"Favoriet","player.controls.previous":"Vorige","player.controls.play":"Afspelen","player.controls.pause":"Pauze","player.controls.play_pause":"Afspelen/Pauzeren","player.controls.next":"Volgende","player.header":"Mediaspeler","player.messages.inactive":["Behalve het geluid van stilte.","Het is hier zo stil.","Zie je andere spelers?","Laat me niet alleen met mijn gedachten.","Hopelijk heb je geen oorsuizen.","Waarom niet iets productiefs doen?","Laten we onze verbeelding gebruiken."],"player.title.inactive":"Er is momenteel niets actief!","players.header":"Spelers","queue.header":"Wachtrij"},pt:{"browser.card.favorites":"Favoritos","browser.card.recents":"Recentes","browser.card.recommendations":"Recomendações","browser.enqueue.play":"Reproduzir Agora","browser.enqueue.next":"Reproduzir Seguinte","browser.enqueue.play_clear":"Reproduzir Agora e Limpar Fila","browser.enqueue.next_clear":"Reproduzir Seguinte e Limpar Fila","browser.enqueue.queue":"Adicionar à Fila","browser.enqueue.radio":"Reproduzir Rádio","browser.search.placeholder":"Pesquisar Music Assistant","browser.sections.album":"Álbuns","browser.sections.artist":"Artistas","browser.sections.audiobook":"Audiolivros","browser.sections.playlist":"Listas de Reprodução","browser.sections.podcast":"Podcasts","browser.sections.radio":"Rádios","browser.sections.track":"Faixas","player.controls.power":"On/Off","player.controls.shuffle":"Aleatório","player.controls.repeat":"Repetir","player.controls.favorite":"Favorito","player.controls.previous":"Anterior","player.controls.play":"Reproduzir","player.controls.pause":"Pausar","player.controls.play_pause":"Reproduzir/Pausar","player.controls.next":"Seguinte","player.header":"Leitor Multimédia","player.messages.inactive":["Excepto o som do silêncio.","Está tão silencioso aqui.","Estás a ver outros leitores?","Por favor, não me deixes sozinho com os meus pensamentos.","Espero que não tenhas zumbidos no ouvido.","Porque não fazer algo produtivo?","Vamos usar a nossa imaginação."],"player.title.inactive":"Não há nada activo!","players.header":"Leitores","queue.header":"Fila"}},ei=$t.en;function ti(e,t){const i=$t[t?.language??"en"]??ei,r=ei[e]??e;return i[e]??r}const ii={album:Gt.DISC,artist:Gt.PERSON,audiobook:Gt.BOOK,playlist:Gt.PLAYLIST,podcast:Gt.MICROPHONE_MAGIC,track:Gt.CLEFT,radio:Gt.RADIO};function ri(e,t){return[{option:Kt.ALBUM,icon:e.ALBUM,title:ti("browser.sections.album",t)},{option:Kt.ARTIST,icon:e.ARTIST,title:ti("browser.sections.artist",t)},{option:Kt.AUDIOBOOK,icon:e.BOOK,title:ti("browser.sections.audiobook",t)},{option:Kt.PLAYLIST,icon:e.PLAYLIST,title:ti("browser.sections.playlist",t)},{option:Kt.PODCAST,icon:e.PODCAST,title:ti("browser.sections.podcast",t)},{option:Kt.RADIO,icon:e.RADIO,title:ti("browser.sections.radio",t)},{option:Kt.TRACK,icon:e.MUSIC,title:ti("browser.sections.track",t)}]}const Ai="favorites",si="main";var oi,ni=class{constructor(e,...t){this.slotNames=[],this.handleSlotChange=e=>{const t=e.target;(this.slotNames.includes("[default]")&&!t.name||t.name&&this.slotNames.includes(t.name))&&this.host.requestUpdate()},(this.host=e).addController(this),this.slotNames=t}hasDefaultSlot(){return[...this.host.childNodes].some(e=>{if(e.nodeType===Node.TEXT_NODE&&""!==e.textContent.trim())return!0;if(e.nodeType===Node.ELEMENT_NODE){const t=e;if("wa-visually-hidden"===t.tagName.toLowerCase())return!1;if(!t.hasAttribute("slot"))return!0}return!1})}hasNamedSlot(e){return null!==this.host.querySelector(`:scope > [slot="${e}"]`)}test(e){return"[default]"===e?this.hasDefaultSlot():this.hasNamedSlot(e)}hostConnected(){this.host.shadowRoot.addEventListener("slotchange",this.handleSlotChange)}hostDisconnected(){this.host.shadowRoot.removeEventListener("slotchange",this.handleSlotChange)}},ai=Object.defineProperty,ci=Object.getOwnPropertyDescriptor,li=e=>{throw TypeError(e)},di=(e,t,i,r)=>{for(var A,s=r>1?void 0:r?ci(t,i):t,o=e.length-1;o>=0;o--)(A=e[o])&&(s=(r?A(t,i,s):A(s))||s);return r&&s&&ai(t,i,s),s},ui=(e,t,i)=>t.has(e)||li("Cannot "+i),hi=":host {\n  box-sizing: border-box !important;\n}\n\n:host *,\n:host *::before,\n:host *::after {\n  box-sizing: inherit !important;\n}\n\n[hidden] {\n  display: none !important;\n}\n",gi=class extends ve{constructor(){var e,t,i;super(),e=this,i=!1,(t=oi).has(e)?li("Cannot add the same private member more than once"):t instanceof WeakSet?t.add(e):t.set(e,i),this.initialReflectedProperties=new Map,this.didSSR=Boolean(this.shadowRoot),this.customStates={set:(e,t)=>{Boolean(this.internals?.states)&&(t?this.internals.states.add(e):this.internals.states.delete(e))},has:e=>!!Boolean(this.internals?.states)&&this.internals.states.has(e)};try{this.internals=this.attachInternals()}catch{console.error("Element internals are not supported in your browser. Consider using a polyfill")}this.customStates.set("wa-defined",!0);let r=this.constructor;for(let[e,t]of r.elementProperties)"inherit"===t.default&&void 0!==t.initial&&"string"==typeof e&&this.customStates.set(`initial-${e}-${t.initial}`,!0)}static get styles(){const e=Array.isArray(this.css)?this.css:this.css?[this.css]:[];return[hi,...e].map(e=>"string"==typeof e?h(e):e)}attributeChangedCallback(e,t,i){var r,A;ui(r=this,A=oi,"read from private field"),A.get(r)||(this.constructor.elementProperties.forEach((e,t)=>{e.reflect&&null!=this[t]&&this.initialReflectedProperties.set(t,this[t])}),((e,t,i)=>{ui(e,t,"write to private field"),t.set(e,i)})(this,oi,!0)),super.attributeChangedCallback(e,t,i)}willUpdate(e){super.willUpdate(e),this.initialReflectedProperties.forEach((t,i)=>{e.has(i)&&null==this[i]&&(this[i]=t)})}firstUpdated(e){super.firstUpdated(e),this.didSSR&&this.shadowRoot?.querySelectorAll("slot").forEach(e=>{e.dispatchEvent(new Event("slotchange",{bubbles:!0,composed:!1,cancelable:!1}))})}update(e){try{super.update(e)}catch(e){if(this.didSSR&&!this.hasUpdated){const t=new Event("lit-hydration-error",{bubbles:!0,composed:!0,cancelable:!1});t.error=e,this.dispatchEvent(t)}throw e}}relayNativeEvent(e,t){e.stopImmediatePropagation(),this.dispatchEvent(new e.constructor(e.type,{...e,...t}))}};oi=new WeakMap,di([Qe()],gi.prototype,"dir",2),di([Qe()],gi.prototype,"lang",2),di([Qe({type:Boolean,reflect:!0,attribute:"did-ssr"})],gi.prototype,"didSSR",2);var pi=class extends gi{constructor(){super(...arguments),this.hasSlotController=new ni(this,"footer","header","media"),this.appearance="outlined",this.withHeader=!1,this.withMedia=!1,this.withFooter=!1,this.orientation="vertical"}updated(){!this.withHeader&&this.hasSlotController.test("header")&&(this.withHeader=!0),!this.withMedia&&this.hasSlotController.test("media")&&(this.withMedia=!0),!this.withFooter&&this.hasSlotController.test("footer")&&(this.withFooter=!0)}render(){return"horizontal"===this.orientation?W`
        <slot name="media" part="media" class="media"></slot>
        <slot part="body" class="body"></slot>
        <slot name="actions" part="actions" class="actions"></slot>
      `:W`
      <slot name="media" part="media" class="media"></slot>
      <header part="header" class="header">
        <slot name="header"></slot>
        <slot name="header-actions"></slot>
      </header>
      <slot part="body" class="body"></slot>
      <footer part="footer" class="footer">
        <slot name="footer"></slot>
        <slot name="footer-actions"></slot>
      </footer>
    `}};pi.css=["@layer wa-utilities {\n  :host([size='small']),\n  .wa-size-s {\n    font-size: var(--wa-font-size-s);\n  }\n\n  :host([size='medium']),\n  .wa-size-m {\n    font-size: var(--wa-font-size-m);\n  }\n\n  :host([size='large']),\n  .wa-size-l {\n    font-size: var(--wa-font-size-l);\n  }\n}\n",":host {\n  --spacing: var(--wa-space-l);\n\n  /* Internal calculated properties */\n  --inner-border-radius: calc(var(--wa-panel-border-radius) - var(--wa-panel-border-width));\n\n  display: flex;\n  flex-direction: column;\n  background-color: var(--wa-color-surface-default);\n  border-color: var(--wa-color-surface-border);\n  border-radius: var(--wa-panel-border-radius);\n  border-style: var(--wa-panel-border-style);\n  box-shadow: var(--wa-shadow-s);\n  border-width: var(--wa-panel-border-width);\n  color: var(--wa-color-text-normal);\n}\n\n/* Appearance modifiers */\n:host([appearance~='plain']) {\n  background-color: transparent;\n  border-color: transparent;\n  box-shadow: none;\n}\n\n:host([appearance~='outlined']) {\n  background-color: var(--wa-color-surface-default);\n  border-color: var(--wa-color-surface-border);\n}\n\n:host([appearance~='filled']) {\n  background-color: var(--wa-color-neutral-fill-quiet);\n  border-color: transparent;\n}\n\n:host([appearance~='filled'][appearance~='outlined']) {\n  border-color: var(--wa-color-neutral-border-quiet);\n}\n\n:host([appearance~='accent']) {\n  color: var(--wa-color-neutral-on-loud);\n  background-color: var(--wa-color-neutral-fill-loud);\n  border-color: transparent;\n}\n\n/* Take care of top and bottom radii */\n.media,\n:host(:not([with-media])) .header,\n:host(:not([with-media], [with-header])) .body {\n  border-start-start-radius: var(--inner-border-radius);\n  border-start-end-radius: var(--inner-border-radius);\n}\n\n:host(:not([with-footer])) .body,\n.footer {\n  border-end-start-radius: var(--inner-border-radius);\n  border-end-end-radius: var(--inner-border-radius);\n}\n\n.media {\n  display: flex;\n  overflow: hidden;\n\n  &::slotted(*) {\n    display: block;\n    width: 100%;\n    border-radius: 0 !important;\n  }\n}\n\n/* Round all corners for plain appearance */\n:host([appearance='plain']) .media {\n  border-radius: var(--inner-border-radius);\n\n  &::slotted(*) {\n    border-radius: inherit !important;\n  }\n}\n\n.header {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  border-block-end-style: inherit;\n  border-block-end-color: var(--wa-color-surface-border);\n  border-block-end-width: var(--wa-panel-border-width);\n  padding: calc(var(--spacing) / 2) var(--spacing);\n}\n\n.body {\n  display: block;\n  padding: var(--spacing);\n}\n\n.footer {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  border-block-start-style: inherit;\n  border-block-start-color: var(--wa-color-surface-border);\n  border-block-start-width: var(--wa-panel-border-width);\n  padding: var(--spacing);\n}\n\n:host(:not([with-header])) .header,\n:host(:not([with-footer])) .footer,\n:host(:not([with-media])) .media {\n  display: none;\n}\n\n/* Orientation Styles */\n:host([orientation='horizontal']) {\n  flex-direction: row;\n\n  .media {\n    border-start-start-radius: var(--inner-border-radius);\n    border-end-start-radius: var(--inner-border-radius);\n    border-start-end-radius: 0;\n    object-fit: cover;\n  }\n}\n\n:host([orientation='horizontal']) ::slotted([slot='body']) {\n  display: block;\n  height: 100%;\n  margin: 0;\n}\n\n:host([orientation='horizontal']) ::slotted([slot='actions']) {\n  display: flex;\n  align-items: center;\n  padding: var(--spacing);\n}\n"],di([Qe({reflect:!0})],pi.prototype,"appearance",2),di([Qe({attribute:"with-header",type:Boolean,reflect:!0})],pi.prototype,"withHeader",2),di([Qe({attribute:"with-media",type:Boolean,reflect:!0})],pi.prototype,"withMedia",2),di([Qe({attribute:"with-footer",type:Boolean,reflect:!0})],pi.prototype,"withFooter",2),di([Qe({reflect:!0})],pi.prototype,"orientation",2),pi=di([be("wa-card")],pi);const vi=Ki(),mi=Ki(),wi=Ki(),fi=Ki(),Ei=Ki(),Ci=Ki(),Bi=Ki(),bi=Ki(),Ii=Ki(),yi=Ki(),Qi=Ki(),Di=Ki(),Ri=Ki(),ki=Ki(),xi=Ki(),Pi=Ki(),Mi=Ki(),Hi=Ki(),Si=Ki(),Oi=Ki(),qi=Ki(),Li=Ki(),Ui=Ki(),Ti=Ki(),Ji=Ki(),Vi=Ki(),Fi=Ki(),zi=Ki(),Yi=Ki(),Xi=Ki(),ji=Ki();function Ki(){return"10000000-1000-4000-8000-100000000000".replace(/[018]/g,e=>(+e^crypto.getRandomValues(new Uint8Array(1))[0]&15>>+e/4).toString(16))}var Gi,Ni=g`
  :host {
    --me-menu-background-color: var(--md-sys-color-secondary-container);
    --me-menu-text-color: var(--md-sys-color-on-secondary-container);
    --mass-menu-selected-background-color: var(--md-sys-color-secondary);
    --mass-menu-selected-text-color: var(--md-sys-color-on-secondary);
  }
  .menu-expressive {
    --mdc-theme-text-primary-on-background: var(--me-menu-text-color);
    --mdc-theme-text-icon-on-background: var(--me-menu-text-color);
    --mdc-theme-surface: var(--me-menu-background-color);
    --mdc-shape-medium: var(--menu-border-radius);
    --mdc-list-vertical-padding: 0px;
  }
  .svg-menu {
    color: var(--md-sys-color-primary);
  }
  .inactive-item {
    background-color: var(--mdc-theme-surface);
  }
  .selected-item {
    --mdc-theme-text-icon-on-background: var(--mdc-theme-on-primary);
    --mdc-theme-text-primary-on-background: var(--mdc-theme-on-primary);
    background-color: var(--mdc-theme-primary);
  }
  .selected-item-expressive {
    --mdc-theme-text-icon-on-background: var(--mass-menu-selected-text-color);
    --mdc-theme-text-primary-on-background: var(
      --mass-menu-selected-text-color
    );
    background-color: var(--mass-menu-selected-background-color);
    border-radius: var(--menu-selected-item-border-radius);
  }
  .svg-menu-expressive {
    color: var(--md-sys-color-on-background);
  }
`;!function(e){e.QUEUE="queue",e.MUSIC_PLAYER="music-player",e.PLAYERS="players",e.MEDIA_BROWSER="media-browser"}(Gi||(Gi={}));const Wi=[Gi.MUSIC_PLAYER,Gi.QUEUE,Gi.PLAYERS,Gi.MEDIA_BROWSER];function Zi(e){try{return"http"==window.location.protocol||function(e){try{return!e.startsWith("http:")}catch{return!1}}(e)}catch{return!1}}function _i(e){if(isNaN(e))return"0:00";const t=Math.floor(e/60),i=Math.floor(e%60);return`${t.toString()}:${i<10?"0":""}${i.toString()}`}function $i(e,t){const i=e?.attributes,r=t?.attributes,A=e?.state,s=t?.state,o=A!=s,n=["active_queue","app_id","entity_picture_local","is_volume_muted","media_album_name","media_artist","media_content_id","media_content_type","media_duration","media_position","media_title","repeat","shuffle","volume_level"].filter(e=>{try{return i[e]!==r[e]}catch{return!0}}).length>0;return o||n}function er(e,t,i){const r=!(i.inactive_when_idle?["off","idle"]:["off"]).includes(t.state),A=!!t?.attributes?.media_content_id,s="music_assistant"==t.attributes.app_id,o=!!t.attributes?.active_queue,n=e.connected,a=new Date(t.last_updated).getTime(),c=(new Date).getTime();return r&&s&&o&&n&&c-a<=18e5&&A}function tr(e,t){return JSON.stringify(e)==JSON.stringify(t)}class ir extends ve{constructor(){super(...arguments),this.onSelect=e=>{""!=e.target.value&&(this._selectedItem=e.target.value,this.onSelectAction(e))}}set initialSelection(e){this._initialSelection=e,this._selectedItem=e}get initialSelection(){return this._initialSelection??""}set items(e){tr(this._items,e)||(this._items=e,this._selectedItem||(this._selectedItem=e[0].option))}get items(){return this._items}renderMenuItems(){return this.items?this._items.map(e=>W`
        <ha-list-item
          class="menu-list-item ${this._selectedItem==e.option?"selected-item":"inactive-item"}${this.useExpressive?"-expressive":""}"
          part="menu-list-item"
          .value="${e.option}"
          .graphic=${e.icon}
        >
          <ha-svg-icon
            class="menu-list-item-svg ${this.useExpressive?"svg-expressive":""}"
            part="menu-list-item-svg"
            slot="graphic"
            .path=${e.icon}
          ></ha-svg-icon>
          ${e.title}
        </ha-list-item>
      `):W``}render(){return W`
      <div id="menu-button" part="menu-button">
        <ha-control-select-menu
          id="menu-select-menu"
          class="${this.useExpressive?"menu-expressive":""}"
          part="menu-select-menu"
          naturalMenuWidth
          ?fixedMenuPosition=${this.fixedMenuPosition}
          @selected=${this.onSelect}
        >
          <ha-svg-icon
            slot="icon"
            class="${this.useExpressive?"svg-menu-expressive":"svg-menu"}"
            part="menu-svg"
            .path=${this.iconPath}
          ></ha-svg-icon>
          ${this.renderMenuItems()}
          <slot></slot>
        </ha-control-select-menu>
      </div>
    `}shouldUpdate(e){return e.size>0}static get styles(){return Ni}}e([Qe({attribute:!1})],ir.prototype,"iconPath",void 0),e([Qe({attribute:!1})],ir.prototype,"_items",void 0),e([Qe({type:Boolean,attribute:"fixedMenuPosition"})],ir.prototype,"fixedMenuPosition",void 0),e([n({context:Ti,subscribe:!0})],ir.prototype,"useExpressive",void 0),e([De()],ir.prototype,"_selectedItem",void 0),e([Qe({attribute:!1})],ir.prototype,"initialSelection",null),customElements.define("mass-menu-button",ir);var rr=g`
  mass-menu-button::part(menu-button) {
    position: absolute;
    bottom: 1.5em;
    right: -0.75em;
    --ha-ripple-color: rgba(0, 0, 0, 0);
  }
  mass-menu-button::part(menu-list-item) {
  }
  mass-menu-button::part(menu-list-item-svg) {
    height: 2em;
    width: 2em;
  }
  mass-menu-button::part(menu-select-menu) {
    --mdc-icon-size: 5em;
    --control-select-menu-height: 6em;
    --control-select-menu-background-color: unset;
  }
  mass-menu-button::part(menu-svg) {
    color: var(--md-sys-color-primary);
    background-color: var(
      --ha-card-background,
      var(--card-background-color, #fff)
    );
    border-radius: 50%;
  }

  wa-card {
    --inner-border-radius: var(--browser-card-border-radius);
    --wa-panel-border-radius: var(--browser-card-border-radius);
    --wa-panel-border-style: var(--ha-card-border-style);
    --wa-color-surface-border: var(--ha-color-border-neutral-normal);
    --wa-panel-border-width: var(--ha-card-border-width);
    --wa-shadow-s: var(--ha-card-box-shadow);
    height: 100%;
    width: 100%;
  }

  #container {
    width: 100%;
    position: relative;
    display: flex;
    border-radius: var(--browser-card-border-radius) !important;
    overflow: visible !important;
    margin: 0px 3px 3px 3px;
    aspect-ratio: 1;
  }

  #card-button-div {
    position: absolute;
    width: 100%;
    height: 100%;
    display: contents;
    top: 0;
    left: 0;
  }

  #enqueue-list-item {
  }
  .enqueue-item-svg {
    height: 2em;
    width: 2em;
  }
  #enqueue-menu-control {
    --control-select-menu-background-color: unset;
    --ha-ripple-color: rgba(0, 0, 0, 0);
    --mdc-icon-size: 5em;
    --control-select-menu-height: 6em;
  }
  #enqueue-svg {
    color: var(--md-sys-color-primary);
    background-color: var(
      --ha-card-background,
      var(--card-background-color, #fff)
    );
    border-radius: 50%;
  }

  .media-card {
    border-radius: var(--browser-card-border-radius) !important;
    overflow: hidden;
  }
  .media-card::part(body) {
    padding: unset;
    text-align: center;
  }
  .media-card-expressive {
    box-shadow: var(--md-sys-elevation-level2);
  }

  .thumbnail {
    border-radius: var(--browser-card-border-radius);
    overflow: hidden !important;
  }
  #thumbnail-div {
    background-size: 100%;
    background-repeat: no-repeat;
    background-position: center;
    height: 100%;
    aspect-ratio: 1;
  }
  .thumbnail-section {
    background-repeat: no-repeat;
    background-size: contain;
    width: 100%;
    aspect-ratio: 1;
  }

  #title-div {
    font-size: 1.2rem;
    text-transform: capitalize;
    position: absolute;
    width: 100%;
    line-height: 160%;
    bottom: 0;
    background-color: rgba(
      from var(--md-sys-color-primary-container) r g b / 0.9
    );
    color: var(--md-sys-color-on-primary-container);
    border-radius: 0px 0px var(--default-border-radius)
      var(--default-border-radius);
  }
`;async function Ar(e,t,i,r=!0){const A=nr(e,i);return t.startsWith("http://")&&r&&(t=await async function(e,t){if("string"!=typeof t)return"";try{return await e.callWS({type:"mass_queue/download_and_encode_image",url:t})}catch(e){return console.error("Error getting image",e),""}}(e,t)),`background-image: url(${t}), url(${A})`}function sr(e,t,i){return`background-image: url(${t}), url(${nr(e,i)})`}function or(e,t){return`background-image: url(${nr(e,t)})`}function nr(e,t){return e&&e.themes.darkMode?Wt[t]:Zt[t]}function ar(e,t,i){const r=ri(t,i).find(t=>t.option==e);return r?.icon??Gt.CLEFT}var cr="M12,11A1,1 0 0,0 11,12A1,1 0 0,0 12,13A1,1 0 0,0 13,12A1,1 0 0,0 12,11M12,16.5C9.5,16.5 7.5,14.5 7.5,12C7.5,9.5 9.5,7.5 12,7.5C14.5,7.5 16.5,9.5 16.5,12C16.5,14.5 14.5,16.5 12,16.5M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z",lr="M19,1L17.74,3.75L15,5L17.74,6.26L19,9L20.25,6.26L23,5L20.25,3.75M9,4L6.5,9.5L1,12L6.5,14.5L9,20L11.5,14.5L17,12L11.5,9.5M19,15L17.74,17.74L15,19L17.74,20.25L19,23L20.25,20.25L23,19L20.25,17.74",dr="M12,21.35L10.55,20.03C5.4,15.36 2,12.27 2,8.5C2,5.41 4.42,3 7.5,3C9.24,3 10.91,3.81 12,5.08C13.09,3.81 14.76,3 16.5,3C19.58,3 22,5.41 22,8.5C22,12.27 18.6,15.36 13.45,20.03L12,21.35Z",ur="M13.5,8H12V13L16.28,15.54L17,14.33L13.5,12.25V8M13,3A9,9 0 0,0 4,12H1L4.96,16.03L9,12H6A7,7 0 0,1 13,5A7,7 0 0,1 20,12A7,7 0 0,1 13,19C11.07,19 9.32,18.21 8.06,16.94L6.64,18.36C8.27,20 10.5,21 13,21A9,9 0 0,0 22,12A9,9 0 0,0 13,3",hr="M21,3V15.5A3.5,3.5 0 0,1 17.5,19A3.5,3.5 0 0,1 14,15.5A3.5,3.5 0 0,1 17.5,12C18.04,12 18.55,12.12 19,12.34V6.47L9,8.6V17.5A3.5,3.5 0 0,1 5.5,21A3.5,3.5 0 0,1 2,17.5A3.5,3.5 0 0,1 5.5,14C6.04,14 6.55,14.12 7,14.34V6L21,3Z",gr="M15,6H3V8H15V6M15,10H3V12H15V10M3,16H11V14H3V16M17,6V14.18C16.69,14.07 16.35,14 16,14A3,3 0 0,0 13,17A3,3 0 0,0 16,20A3,3 0 0,0 19,17V8H22V6H17Z",pr="M14,10A3,3 0 0,0 11,13A3,3 0 0,0 14,16A3,3 0 0,0 17,13A3,3 0 0,0 14,10M14,18A5,5 0 0,1 9,13A5,5 0 0,1 14,8A5,5 0 0,1 19,13A5,5 0 0,1 14,18M14,2A2,2 0 0,1 16,4A2,2 0 0,1 14,6A2,2 0 0,1 12,4A2,2 0 0,1 14,2M19,0H9A2,2 0 0,0 7,2V18A2,2 0 0,0 9,20H19A2,2 0 0,0 21,18V2A2,2 0 0,0 19,0M5,22H17V24H5A2,2 0 0,1 3,22V4H5";function vr(e){return{name:"hide",type:"expandable",schema:e.map(e=>({name:e,selector:{boolean:{}},default:!1}))}}const mr={enabled:!0,limit:25,items:[],favorites_only:!0},wr={enabled:!0,albums:mr,artists:mr,audiobooks:mr,playlists:mr,podcasts:mr,radios:mr,tracks:mr},fr={back_button:!1,search:!1,recents:!1,titles:!1,enqueue_menu:!1,add_to_queue_button:!1,play_next_button:!1,play_next_clear_queue_button:!1,play_now_button:!1,play_now_clear_queue_button:!1},Er={add:"add_to_queue_button",play:"play_now_button",next:"play_next_button",replace:"play_now_clear_queue_button",replace_next:"play_next_clear_queue_button"},Cr=[],Br={enabled:!0},br={enabled:!0,favorites:wr,recents:wr,recommendations:Br,sections:Cr,hide:fr,columns:2},Ir=["back_button","search","titles","enqueue_menu","add_to_queue_button","play_now_button","play_now_clear_queue_button","play_next_button","play_next_clear_queue_button"];function yr(e){return{name:e,type:"expandable",schema:[{name:"",type:"grid",schema:[{name:"enabled",selector:{boolean:{}},default:!0},{name:"limit",selector:{number:{min:0,max:500,mode:"box"}}}]}]}}function Qr(e){return{...mr,...e}}function Dr(e){let t=e.media_browser;return t=function(e){return{...br,...e}}(t),t=function(e){let t=e.favorites;return t={...wr,...t},t={...t,albums:Qr(t.albums),artists:Qr(t.artists),audiobooks:Qr(t.audiobooks),playlists:Qr(t.playlists),podcasts:Qr(t.podcasts),radios:Qr(t.radios),tracks:Qr(t.tracks)},{...e,favorites:t}}(t),t=function(e){let t=e.sections;return t=[...Cr,...t],{...e,sections:t}}(t),t=function(e){const t=e.recommendations;return{...e,recommendations:{...Br,...t}}}(t),t=function(e){const t=e.hide;return{...e,hide:{...fr,...t}}}(t),{...e,media_browser:t}}class Rr extends ve{constructor(){super(...arguments),this.queueable=!1,this._firstLoaded=!1,this._play=!1,this.hide=fr,this.onEnqueue=e=>{e.stopPropagation();const t=e.target,i=t.value;i&&(t.value="",this.onEnqueueAction(this._config.data,i))},this.onSelect=()=>{this.onSelectAction(this._config.data)}}set activeSection(e){this._play=e==Gi.MEDIA_BROWSER,this._activeSection=e,this.generateCode()}get activeSection(){return this._activeSection}set config(e){e&&(tr(this._config,e)||(this._config=e,this.updateHiddenElements(),this.cardConfig&&this.generateArtworkStyle(),this.generateCode()))}get config(){return this._config}set cardConfig(e){e&&(tr(this._cardConfig,e)||(this._cardConfig=e,this.config&&this.generateArtworkStyle()))}get cardConfig(){return this._cardConfig}set sectionConfig(e){tr(this._sectionConfig,e)||(this._sectionConfig=e,this.updateHiddenElements())}get sectionConfig(){return this._sectionConfig}set Icons(e){tr(this._icons,e)||(this._icons=e)}get Icons(){return this._icons}set entityConfig(e){tr(this._entityConfig,e)||(this._entityConfig=e,this.updateHiddenElements(),this._search_buttons=ri(this.Icons,this.hass))}get entityConfig(){return this._entityConfig}set artwork(e){e!=this._artwork&&(this._artwork=e,this.generateCode())}get artwork(){return this._artwork}updateHiddenElements(){if(!this.config||!this.entityConfig||!this.sectionConfig)return;const e=this.entityConfig.hide.media_browser,t=this.sectionConfig.hide;this.hide={back_button:e.back_button||t.back_button,search:e.search||t.search,titles:e.titles||t.titles,enqueue_menu:e.enqueue_menu||t.enqueue_menu,add_to_queue_button:e.add_to_queue_button||t.add_to_queue_button,play_next_button:e.play_next_button||t.play_next_button,play_now_button:e.play_now_button||t.play_now_button,play_next_clear_queue_button:e.play_next_clear_queue_button||t.play_next_clear_queue_button,play_now_clear_queue_button:e.play_now_clear_queue_button||t.play_now_clear_queue_button,recents:e.recents||t.recents},this.updateEnqueueButtons(),this.generateCode()}updateEnqueueButtons(){const e=function(e,t){return[{option:_t.PLAY_NOW,icon:e.PLAY_CIRCLE_OUTLINE,title:ti("browser.enqueue.play",t)},{option:_t.PLAY_NEXT,icon:e.SKIP_NEXT_CIRCLE_OUTLINED,title:ti("browser.enqueue.next",t)},{option:_t.PLAY_NOW_CLEAR_QUEUE,icon:e.PLAY_CIRCLE,title:ti("browser.enqueue.play_clear",t)},{option:_t.PLAY_NEXT_CLEAR_QUEUE,icon:e.SKIP_NEXT_CIRCLE,title:ti("browser.enqueue.next_clear",t)},{option:_t.ADD_TO_QUEUE,icon:e.PLAYLIST_PLUS,title:ti("browser.enqueue.queue",t)},{option:_t.RADIO,icon:e.RADIO,title:ti("browser.enqueue.radio",t)}]}(this.Icons,this.hass),t=Er,i=e.filter(e=>{const i=t[e.option];return!this.hide[i]});this._enqueue_buttons=i}renderThumbnailFromBackground(){return Be` ${this.config.background} `}async generateArtworkStyle(){const e=this.config.thumbnail;this.artwork=await Ar(this.hass,e,this.config.fallback,this.cardConfig.download_local)}artworkStyle(){const e=this.config.thumbnail;return Zi(e)?sr(this.hass,e,this.config.fallback):or(this.hass,this.config.fallback)}renderThumbnailFromThumbnail(){const e=this.artwork||"";return Be`
      <div
        id="thumbnail-div"
        slot="media"
        class="wa-grid"
        style="${e}"
      ></div>
    `}renderThumbnail(){return this.config.background?this.renderThumbnailFromBackground():this.renderThumbnailFromThumbnail()}renderTitle(){return this.hide.titles?Be``:Be` <div id="title-div">${this.config.title}</div> `}renderEnqueueButton(){return this.hide.enqueue_menu||!this.queueable?Be``:Be`
      <mass-menu-button
        id="enqueue-button-div"
        .iconPath=${this.Icons.PLAY_CIRCLE}
        .items=${this._enqueue_buttons}
        .onSelectAction=${this.onEnqueue}
        fixedMenuPosition
      ></mass-menu-button>
    `}generateCode(){this._enqueue_buttons&&this.hass&&this.activeSection&&this.sectionConfig&&this.Icons&&this.entityConfig&&(this.code=Be`
      <wa-animation
        id="animation"
        name="pulse"
        easing="ease"
        iterations="1"
        play=${this._play}
        playback-rate="1"
      >
        <div id="container">
          <wa-card
            class="media-card ${this.useExpressive?"media-card-expressive":""}"
            @click=${this.onSelect}
          >
            <div slot="media" id="media">${this.renderThumbnail()}</div>
            ${this.renderTitle()}
          </wa-card>
          ${this.renderEnqueueButton()}
        </div>
      </wa-animation>
    `)}render(){return this.code}firstUpdated(){this._firstLoaded=!0}shouldUpdate(e){return e.size>0}connectedCallback(){this._firstLoaded&&(this._animation.play=!0),super.connectedCallback()}static get styles(){return rr}}e([Qe({type:Boolean})],Rr.prototype,"queueable",void 0),e([De()],Rr.prototype,"code",void 0),e([ke("#animation")],Rr.prototype,"_animation",void 0),e([n({context:vi})],Rr.prototype,"hass",void 0),e([n({context:Ti})],Rr.prototype,"useExpressive",void 0),e([n({context:Pi,subscribe:!0})],Rr.prototype,"activeSection",null),e([n({context:yi,subscribe:!0})],Rr.prototype,"cardConfig",null),e([n({context:ki,subscribe:!0})],Rr.prototype,"sectionConfig",null),e([n({context:Ji,subscribe:!0})],Rr.prototype,"Icons",null),e([n({context:mi,subscribe:!0})],Rr.prototype,"entityConfig",null),customElements.define("mass-media-card",Rr);var kr=g`
  :host {
    width: 100%;
  }
  mass-media-card {
    max-height: 100%;
    aspect-ratio: 1;
    width: 100%;
    justify-content: center;
  }
  .icons {
    display: flex;
    justify-content: space-evenly;
    flex-wrap: wrap;
    row-gap: 20px;
    overflow-y: scroll;
    max-height: calc(var(--mass-player-card-height) - 4em);
    scrollbar-width: none;
  }
`;class xr extends ve{constructor(){super(...arguments),this.onItemSelected=e=>{this.resetScroll(),this.onSelectAction(e)},this.onEnqueue=(e,t)=>{this.onEnqueueAction(e,t)}}set browserConfig(e){tr(this._browserConfig,e)||(this._browserConfig=e,this.items&&this.generateCode())}get browserConfig(){return this._browserConfig}set items(e){e?.length&&(tr(this._items,e)||(this._items=e,this.browserConfig&&this.generateCode()))}get items(){return this._items}resetScroll(){this._iconsElement.scrollTop=0}generateCode(){const e=this.items.map(e=>{const t=e.data?.media_content_id?.length>0&&e.data?.media_content_type?.length>0?Ee`queueable`:Ee``,i=1/this.browserConfig.columns*100-2;return Be`
        <mass-media-card
          style="max-width: ${i.toString()}%"
          .config=${e}
          .onSelectAction=${this.onItemSelected}
          .onEnqueueAction=${this.onEnqueue}
          ${t}
        >
        </mass-media-card>
      `});this.code=Be` <div class="icons wa-grid">${e}</div> `}render(){return this.code}shouldUpdate(e){return e.size>0}static get styles(){return kr}}e([De()],xr.prototype,"code",void 0),e([n({context:vi,subscribe:!0})],xr.prototype,"hass",void 0),e([ke(".icons")],xr.prototype,"_iconsElement",void 0),e([n({context:ki,subscribe:!0})],xr.prototype,"browserConfig",null),e([n({context:ji,subscribe:!0})],xr.prototype,"items",null),customElements.define("mass-browser-cards",xr);var Pr=g`
  .end {
    display: block;
    position: absolute;
    right: 1em;
    top: 0.5em;
    z-index: 1;
  }

  #header {
    padding: 0.5em 0.5em 0em 0.5em;
    box-sizing: border-box;
    width: 100%;
    display: block;
    position: relative;
    z-index: 1;
    height: 3.5em;
  }
  .header {
  }
  .header-expressive {
    background-color: var(--md-sys-primary-container);
    border-radius: 20px 20px 0px 0px;
  }

  .label {
    display: block;
    position: relative;
    height: 40px;
    width: 100%;
    font-size: 1.5rem;
    text-align: center;
    font-weight: 600;
    z-index: 0;
    color: var(--md-sys-color-on-primary-container);
  }

  .start {
    display: block;
    position: absolute;
    left: 1em;
    top: 0.5em;
    z-index: 1;
  }
`;class Mr extends ve{constructor(){super(...arguments),this._initialUpdate=!1}render(){return W`
      <div
        id="header"
        class="${this.useExpressive?"header-expressive":"header"}"
        part="header"
      >
        <slot name="start" part="start" class="start"></slot>
        <slot name="label" part="label" class="label"></slot>
        <slot name="end" part="end" class="end"></slot>
      </div>
    `}shouldUpdate(e){return!this._initialUpdate||e.size>0}firstUpdated(){this._initialUpdate=!0}static get styles(){return Pr}}e([n({context:Ti,subscribe:!0})],Mr.prototype,"useExpressive",void 0),customElements.define("mass-section-header",Mr);var Hr=g`
  .button-min,
  filter-menu::part(menu-button) {
    height: 35px;
    width: 35px;
    --wa-color-fill-quiet: rgba(from var(--md-sys-color-primary) r g b / 0.1);
    position: relative;
  }
  .button-min::part(base) {
    --wa-form-control-padding-inline: 0px;
    height: 35px;
    width: 35px;
  }
  .button-expressive::part(base) {
    background-color: var(--md-sys-color-secondary-container);
  }
  .button-expressive::part(base),
  .filter-menu-expressive::part(menu-select-menu) {
    box-shadow: var(--md-sys-elevation-level1);
    border-radius: var(--button-small-border-radius) !important;
  }

  #container {
    box-shadow: unset;
    height: var(--mass-player-card-height);
  }
  .container-expressive {
    border-radius: var(--expressive-border-radius-container);
    background-color: var(--expressive-color-container);
  }
  #filter-menu {
  }
  #filter-menu::part(menu-button) {
  }
  #filter-menu::part(menu-list-item) {
  }
  #filter-menu::part(menu-list-item-svg) {
    height: 2em;
    width: 2em;
  }
  #filter-menu::part(menu-select-menu) {
    --mdc-icon-size: 1.5em;
    --control-select-menu-padding: 0px;
    --control-select-menu-background-color: unset;
    --control-select-menu-height: 35px;
    width: 35px;
  }
  #filter-menu::part(menu-svg) {
    height: 30px;
    width: 30px;
    position: absolute;
    top: 2.5px;
    left: 2.5px;
  }
  #filter-menu-expressive::part(menu-select-menu) {
    --control-select-menu-background-color: var(
      --md-sys-color-secondary-container
    );
  }
  #filter-menu-expressive::part(menu-svg) {
    color: var(--md-sys-color-on-background);
  }

  #header-buttons-end {
    display: flex;
    gap: 8px;
  }

  .header-icon {
    height: 2rem;
    width: 2rem;
    color: var(--md-sys-color-on-secondary-container);
  }

  #mass-browser {
    padding-top: 8px;
  }
  .mass-browser-expressive {
    background-color: var(--md-sys-color-background);
    height: calc(100% - 3em);
    border-radius: var(--expressive-border-radius-container);
  }

  #search::part(end) {
    width: calc(100% - 3em - 40px);
  }
  #search-favorite-button::part(base) {
    width: 36px;
    vertical-align: top;
  }
  #search-input {
    height: 40px;
    position: relative;
    width: calc(100% - 5em);
    z-index: 2;
  }
  #search-media-type-menu {
  }
  #search-media-type-menu::part(menu-button) {
  }
  #search-media-type-menu::part(menu-list-item) {
  }
  #search-media-type-menu::part(menu-list-item-svg) {
    height: 2em;
    width: 2em;
  }
  #search-media-type-menu::part(menu-select-menu) {
    --mdc-icon-size: 1.5em;
    --control-select-menu-padding: 0px;
    --control-select-menu-background-color: unset;
    height: 35px;
    width: 35px;
  }
  #search-media-type-menu::part(menu-svg) {
    height: 30px;
    width: 30px;
    position: absolute;
    top: 2.5px;
    left: 2.5px;
  }
  #search-media-type-menu-expressive::part(menu-svg) {
    color: var(--md-sys-color-on-background);
  }
  #search-options {
    height: 35px;
    display: flex;
  }

  .svg-menu-expressive {
    color: var(--md-sys-color-on-background);
  }
  .svg-xs {
    height: 30px;
    width: 30px;
  }

  #title {
    text-indent: var(--title-indent);
    text-transform: capitalize;
  }
`;class Sr{constructor(e){this.hass=e}set hass(e){e&&(this._hass=e)}get hass(){return this._hass}async actionPlayMedia(e,t,i){await this.hass.callService("media_player","play_media",{entity_id:e,media_content_id:t,media_content_type:i})}async actionPlayMediaFromService(e,t){const i=e.split(".");await this.hass.callService(i[0],i[1],{entity_id:t})}async actionEnqueueMedia(e,t,i,r){const A={entity_id:e,media_id:t,media_type:i,enqueue:r};await this.hass.callService("music_assistant","play_media",A)}async actionGetLibraryRecents(e,t,i=25){const r=await this.getPlayerConfigEntry(e);return(await this.hass.callWS({type:"call_service",domain:"music_assistant",service:"get_library",service_data:{limit:i,config_entry_id:r,media_type:t,order_by:"last_played_desc"},return_response:!0})).response.items}async actionGetLibrary(e,t,i=25,r=!0){const A=await this.getPlayerConfigEntry(e);return(await this.hass.callWS({type:"call_service",domain:"music_assistant",service:"get_library",service_data:{favorite:r,limit:i,config_entry_id:A,media_type:t},return_response:!0})).response.items}async actionSearchMedia(e,t,i,r=!1,A=20){const s={limit:A,library_only:r,config_entry_id:await this.getPlayerConfigEntry(e),name:t,media_type:[i]},o=`${i}s`;return(await this.hass.callWS({type:"call_service",domain:"music_assistant",service:"search",service_data:s,return_response:!0})).response[o]}async actionGetRecommendations(e,t){const i={type:"call_service",domain:"mass_queue",service:"get_recommendations",service_data:{entity:e,...t?{providers:t}:{}},return_response:!0};return await this.hass.callWS(i)}async actionPlayRadio(e,t,i){await this.hass.callService("music_assistant","play_media",{entity_id:e,media_id:t,media_type:i,radio_mode:!0})}async getPlayerConfigEntry(e){return(await this.hass.callWS({type:"config/entity_registry/get",entity_id:e})).config_entry_id}}let Or=class extends ve{constructor(){super(...arguments),this.searchMediaType=Kt.TRACK,this.searchLibrary=!1,this.activeSection=Ai,this.activeSubSection=si,this.previousSections=[],this.previousSubSections=[],this.searchTerm="",this.onServiceSelect=e=>{e.service?this.actions.actionPlayMediaFromService(e.service,this.activeEntityConfig.entity_id):(this.actions.actionPlayMedia(this.activeEntityConfig.entity_id,e.media_content_id,e.media_content_type),this.onMediaSelectedAction())},this.onSectionSelect=e=>{this.setPreviousSection(),this.activeSection=e.subtype,this.activeSubSection=e.section,this.setActiveCards()},this.onItemSelect=e=>{this.actions.actionPlayMedia(this.activeEntityConfig.entity_id,e.media_content_id,e.media_content_type)},this.onSelect=e=>{(0,{section:this.onSectionSelect,item:this.onItemSelect,service:this.onServiceSelect}[e.type])(e)},this.onEnqueue=(e,t)=>{const i=e.media_content_id,r=e.media_content_type;t!=_t.RADIO?this.actions.actionEnqueueMedia(this.activeEntityConfig.entity_id,i,r,t):this.actions.actionPlayRadio(this.activeEntityConfig.entity_id,i,r)},this.onBack=()=>{this.activeSection=this.previousSections.pop()??Ai,this.activeSubSection=this.previousSubSections.pop()??si,this.setActiveCards()},this.onSearchButtonPress=()=>{this.setPreviousSection(),this.searchMediaTypeIcon||(this.searchMediaTypeIcon=ar(Kt.TRACK,this.Icons,this.hass)),this.searchTerm="",this.activeSection="search",this.cards.search=[],this.activeCards=this.cards.search},this.onSearchMediaTypeSelect=async e=>{const t=e.target.value;t&&(e.target.value="",this.searchMediaType=t,this.searchMediaTypeIcon=ar(t,this.Icons,this.hass),await this.searchMedia())},this.onSearchLibrarySelect=async()=>{this.searchLibrary=!this.searchLibrary,await this.searchMedia()},this.onSearchInput=e=>{const t=e.target.value.trim();if(!(t.length<3)){if(this.searchTerm=t,this._searchTimeout)try{clearTimeout(this._searchTimeout)}finally{this._searchTimeout=0}this._searchTimeout=setTimeout(()=>{this._searchTimeout=0,this.searchMedia()},1e3)}},this.onFilterType=e=>{const t=e.target.value;t.length&&(e.target.value="",Object.keys(this.cards).includes(t)&&(this.activeSection=t,this.activeSubSection="main",this.activeCards=this.cards[t].main))},this.onCardsUpdated=e=>{const t=e.detail,i=t.section;"all"==i&&(this._cards=t.cards),this.cards&&(this?.activeCards?.length||"all"!=i&&i!=this.activeSection||this.setActiveCards())}}set activeCards(e){tr(this._activeCards,e)||(this._activeCards=e)}get activeCards(){return this._activeCards}set hass(e){this._hass=e,this.actions||(this.actions=new Sr(e))}get hass(){return this._hass}set browserController(e){this._browserController=e}get browserController(){return this._browserController}set config(e){this._config=e}get config(){return this._config}set cards(e){tr(this._cards,e)||(this._cards=e,"search"!=this.activeSection?this.setActiveCards():this.activeCards=[])}get cards(){return this._cards}setPreviousSection(){this.previousSections.push(this.activeSection),this.previousSubSections.push(this.activeSubSection)}setActiveCards(){const e=this.activeSection,t=this.activeSubSection;if(!this.cards)return;const i=[...this.cards[e][t]];tr(i,this.activeCards)||(this.activeCards=i)}resetActiveSections(){this.activeSection=Ai,this.activeSubSection=si,this.previousSections=[],this.previousSubSections=[],this.setActiveCards()}async searchMedia(){const e=this.searchTerm;if(e.length<3)return;const t=await this.browserController.search(this.activeEntityConfig.entity_id,e,this.searchMediaType,this.searchLibrary,20);this.activeCards=t}renderBrowserCards(){return W`
      <mass-browser-cards
        .onSelectAction=${this.onSelect}
        .onEnqueueAction=${this.onEnqueue}
      ></mass-browser-cards>
    `}renderTitle(){const e=this.activeSection;return W` <span slot="label" id="title"> ${e} </span> `}renderSearchMediaTypeButton(){if("search"==this.activeSection){const e=ri(this.Icons,this.hass);return W`
        <mass-menu-button
          id="search-media-type-menu"
          class="${this.useExpressive?"search-media-type-menu-expressive":""}"
          .iconPath=${this.searchMediaTypeIcon}
          .initialSelection=${this.searchMediaType}
          .items=${e}
          .onSelectAction=${this.onSearchMediaTypeSelect}
          fixedMenuPosition
        ></mass-menu-button>
      `}return W``}renderSearchLibraryButton(){return"search"==this.activeSection?W`
        <ha-button
          appearance="plain"
          variant="brand"
          size="medium"
          id="search-favorite-button"
          @click=${this.onSearchLibrarySelect}
          class="button-min"
        >
          <ha-svg-icon
            .path=${this.searchLibrary?this.Icons.LIBRARY:this.Icons.LIBRARY_OUTLINED}
            class="svg-xs ${this.useExpressive?"svg-menu-expressive":""}"
          ></ha-svg-icon>
        </ha-button>
      `:W``}renderSearchBar(){const e=this.hass.themes.darkMode,t="https://cdn.jsdelivr.net/npm/@shoelace-style/shoelace@2.20.1/cdn/themes/"+(e?"dark.css":"light.css"),i=ti("browser.search.placeholder",this.hass);return W`
      <span slot="end" id="search-input">
        <link rel="stylesheet" href="${t}" />
        <sl-input
          placeholder="${i}"
          type="search"
          class="${e?"sl-theme-dark":"sl-theme-light"}"
          inputmode="search"
          size="medium"
          clearable
          pill
          @sl-input=${this.onSearchInput}
        >
          <span slot="suffix">
            <div id="search-options">
              ${this.renderSearchMediaTypeButton()}
              ${this.renderSearchLibraryButton()}
            </div>
          </span>
        </sl-input>
      </span>
    `}renderEndButtons(){return W`
      <span slot="end" id="buttons-end">
        <div id="header-buttons-end">
          ${this.renderFilterButton()} ${this.renderSearchButton()}
        </div>
      </span>
    `}renderSearchButton(){return this.config.hide.search||this.activeEntityConfig.hide.media_browser.search?W``:W`
      <ha-button
        appearance="plain"
        variant="brand"
        size="medium"
        id="button-search"
        class="button-min ${this.useExpressive?"button-expressive":""}"
        @click=${this.onSearchButtonPress}
      >
        <ha-svg-icon
          .path=${this.Icons.SEARCH}
          class="header-icon"
        ></ha-svg-icon>
      </ha-button>
    `}renderBackButton(){return this.config.hide.back_button||this.activeEntityConfig.hide.media_browser.back_button?W``:W`
      <span slot="start" id="back-button">
        <ha-button
          appearance="plain"
          variant="brand"
          size="medium"
          id="button-back"
          class="button-min ${this.useExpressive?"button-expressive":""}"
          @click=${this.onBack}
        >
          <ha-svg-icon
            .path=${this.Icons.ARROW_LEFT}
            class="header-icon"
          ></ha-svg-icon>
        </ha-button>
      </span>
    `}renderFilterButton(){const e=function(e,t,i){const r=[];return i.favorites.enabled&&r.push({option:"favorites",icon:e.HEART,title:ti("browser.card.favorites",t)}),i.recents.enabled&&r.push({option:"recents",icon:e.RECENTS,title:ti("browser.card.recents",t)}),i.recommendations.enabled&&r.push({option:"recommendations",icon:e.SUGGESTIONS,title:ti("browser.card.recommendations",t)}),r}(this.Icons,this.hass,this.config),t=this.Icons.FILTER;return W`
      <mass-menu-button
        id="filter-menu"
        class="hdr-menu ${this.useExpressive?"filter-menu-expressive":""}"
        .iconPath=${t}
        .initialSelection=${this.activeSection}
        .items=${e}
        .onSelectAction=${this.onFilterType}
        fixedMenuPosition
      ></mass-menu-button>
    `}renderSearchHeader(){return W`
      <mass-section-header id="search">
        ${this.renderBackButton()} ${this.renderSearchBar()}
      </mass-section-header>
    `}renderSubsectionHeader(){return W`
      <mass-section-header>
        ${this.renderBackButton()} ${this.renderTitle()}
        ${this.renderEndButtons()}
      </mass-section-header>
    `}renderMainHeader(){return W`
      <mass-section-header>
        ${this.renderTitle()} ${this.renderEndButtons()}
      </mass-section-header>
    `}shouldUpdate(e){return e.size>0}renderHeader(){return"search"==this.activeSection?this.renderSearchHeader():this.activeSection==Ai&&this.activeSubSection==si?this.renderMainHeader():this.renderSubsectionHeader()}firstUpdated(){this.browserController._host.addEventListener("cards-updated",this.onCardsUpdated)}render(){return W`
      <div
        id="container"
        class="${this.useExpressive?"container-expressive":""}"
      >
        ${this.renderHeader()}
        <div
          id="mass-browser"
          class="${this.useExpressive?"mass-browser-expressive":""}"
        >
          ${this.renderBrowserCards()}
        </div>
      </div>
    `}static get styles(){return Hr}};e([Qe({attribute:!1})],Or.prototype,"_config",void 0),e([Qe({attribute:!1})],Or.prototype,"onMediaSelectedAction",void 0),e([De()],Or.prototype,"_cards",void 0),e([De()],Or.prototype,"searchMediaTypeIcon",void 0),e([De()],Or.prototype,"searchMediaType",void 0),e([De()],Or.prototype,"searchLibrary",void 0),e([o({context:ji}),De()],Or.prototype,"_activeCards",void 0),e([n({context:Ti,subscribe:!0})],Or.prototype,"useExpressive",void 0),e([n({context:Ji})],Or.prototype,"Icons",void 0),e([n({context:mi,subscribe:!0})],Or.prototype,"activeEntityConfig",void 0),e([De()],Or.prototype,"activeCards",null),e([n({context:vi,subscribe:!0})],Or.prototype,"hass",null),e([n({context:Li,subscribe:!0})],Or.prototype,"browserController",null),e([n({context:ki,subscribe:!0})],Or.prototype,"config",null),e([n({context:Xi,subscribe:!0})],Or.prototype,"cards",null),Or=e([be("mass-media-browser")],Or);
/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const qr="important",Lr=" !"+qr,Ur=Se(class extends Oe{constructor(e){if(super(e),e.type!==Pe||"style"!==e.name||e.strings?.length>2)throw Error("The `styleMap` directive must be used in the `style` attribute and must be the only part in the attribute.")}render(e){return Object.keys(e).reduce((t,i)=>{const r=e[i];return null==r?t:t+`${i=i.includes("-")?i:i.replace(/(?:^(webkit|moz|ms|o)|)(?=[A-Z])/g,"-$&").toLowerCase()}:${r};`},"")}update(e,[t]){const{style:i}=e.element;if(void 0===this.ft)return this.ft=new Set(Object.keys(t)),this.render(t);for(const e of this.ft)null==t[e]&&(this.ft.delete(e),e.includes("-")?i.removeProperty(e):i[e]=null);for(const e in t){const r=t[e];if(null!=r){this.ft.add(e);const t="string"==typeof r&&r.endsWith(Lr);e.includes("-")||t?i.setProperty(e,t?r.slice(0,-11):r,t?qr:""):i[e]=r}}return Z}}),Tr=["role","ariaAtomic","ariaAutoComplete","ariaBusy","ariaChecked","ariaColCount","ariaColIndex","ariaColSpan","ariaCurrent","ariaDisabled","ariaExpanded","ariaHasPopup","ariaHidden","ariaInvalid","ariaKeyShortcuts","ariaLabel","ariaLevel","ariaLive","ariaModal","ariaMultiLine","ariaMultiSelectable","ariaOrientation","ariaPlaceholder","ariaPosInSet","ariaPressed","ariaReadOnly","ariaRequired","ariaRoleDescription","ariaRowCount","ariaRowIndex","ariaRowSpan","ariaSelected","ariaSetSize","ariaSort","ariaValueMax","ariaValueMin","ariaValueNow","ariaValueText"],Jr=Tr.map(Fr);
/**
 * @license
 * Copyright 2023 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */function Vr(e){return Jr.includes(e)}function Fr(e){return e.replace("aria","aria-").replace(/Elements?/g,"").toLowerCase()}
/**
 * @license
 * Copyright 2023 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */const zr=Symbol("privateIgnoreAttributeChangesFor");function Yr(e){return`data-${e}`}function Xr(e){return e.replace(/-\w/,e=>e[1].toUpperCase())}
/**
 * @license
 * Copyright 2023 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */const jr=function(e){var t;class i extends e{constructor(){super(...arguments),this[t]=new Set}attributeChangedCallback(e,t,i){if(!Vr(e))return void super.attributeChangedCallback(e,t,i);if(this[zr].has(e))return;this[zr].add(e),this.removeAttribute(e),this[zr].delete(e);const r=Xr(e);null===i?delete this.dataset[r]:this.dataset[r]=i,this.requestUpdate(Xr(e),t)}getAttribute(e){return Vr(e)?super.getAttribute(Yr(e)):super.getAttribute(e)}removeAttribute(e){super.removeAttribute(e),Vr(e)&&(super.removeAttribute(Yr(e)),this.requestUpdate())}}return t=zr,function(e){for(const t of Tr){const i=Fr(t),r=Yr(i),A=Xr(i);e.createProperty(t,{attribute:i,noAccessor:!0}),e.createProperty(Symbol(r),{attribute:r,noAccessor:!0}),Object.defineProperty(e.prototype,t,{configurable:!0,enumerable:!0,get(){return this.dataset[A]??null},set(e){const i=this.dataset[A]??null;e!==i&&(null===e?delete this.dataset[A]:this.dataset[A]=e,this.requestUpdate(t,i))}})}}(i),i}(ve);class Kr extends jr{constructor(){super(...arguments),this.value=0,this.max=1,this.indeterminate=!1,this.fourColor=!1}render(){const{ariaLabel:e}=this;return W`
      <div
        class="progress ${zt(this.getRenderClasses())}"
        role="progressbar"
        aria-label="${e||_}"
        aria-valuemin="0"
        aria-valuemax=${this.max}
        aria-valuenow=${this.indeterminate?_:this.value}
        >${this.renderIndicator()}</div
      >
    `}getRenderClasses(){return{indeterminate:this.indeterminate,"four-color":this.fourColor}}}e([Qe({type:Number})],Kr.prototype,"value",void 0),e([Qe({type:Number})],Kr.prototype,"max",void 0),e([Qe({type:Boolean})],Kr.prototype,"indeterminate",void 0),e([Qe({type:Boolean,attribute:"four-color"})],Kr.prototype,"fourColor",void 0);
/**
 * @license
 * Copyright 2023 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
class Gr extends Kr{constructor(){super(...arguments),this.buffer=0}renderIndicator(){const e={transform:`scaleX(${100*(this.indeterminate?1:this.value/this.max)}%)`},t=this.buffer??0,i=t>0,r={transform:`scaleX(${100*(this.indeterminate||!i?1:t/this.max)}%)`},A=this.indeterminate||!i||t>=this.max||this.value>=this.max;return W`
      <div class="dots" ?hidden=${A}></div>
      <div class="inactive-track" style=${Ur(r)}></div>
      <div class="bar primary-bar" style=${Ur(e)}>
        <div class="bar-inner"></div>
      </div>
      <div class="bar secondary-bar">
        <div class="bar-inner"></div>
      </div>
    `}}e([Qe({type:Number})],Gr.prototype,"buffer",void 0);
/**
 * @license
 * Copyright 2024 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
const Nr=g`:host{--_active-indicator-color: var(--md-linear-progress-active-indicator-color, var(--md-sys-color-primary, #6750a4));--_active-indicator-height: var(--md-linear-progress-active-indicator-height, 4px);--_four-color-active-indicator-four-color: var(--md-linear-progress-four-color-active-indicator-four-color, var(--md-sys-color-tertiary-container, #ffd8e4));--_four-color-active-indicator-one-color: var(--md-linear-progress-four-color-active-indicator-one-color, var(--md-sys-color-primary, #6750a4));--_four-color-active-indicator-three-color: var(--md-linear-progress-four-color-active-indicator-three-color, var(--md-sys-color-tertiary, #7d5260));--_four-color-active-indicator-two-color: var(--md-linear-progress-four-color-active-indicator-two-color, var(--md-sys-color-primary-container, #eaddff));--_track-color: var(--md-linear-progress-track-color, var(--md-sys-color-surface-container-highest, #e6e0e9));--_track-height: var(--md-linear-progress-track-height, 4px);--_track-shape: var(--md-linear-progress-track-shape, var(--md-sys-shape-corner-none, 0px));border-radius:var(--_track-shape);display:flex;position:relative;min-width:80px;height:var(--_track-height);content-visibility:auto;contain:strict}.progress,.dots,.inactive-track,.bar,.bar-inner{position:absolute}.progress{direction:ltr;inset:0;border-radius:inherit;overflow:hidden;display:flex;align-items:center}.bar{animation:none;width:100%;height:var(--_active-indicator-height);transform-origin:left center;transition:transform 250ms cubic-bezier(0.4, 0, 0.6, 1)}.secondary-bar{display:none}.bar-inner{inset:0;animation:none;background:var(--_active-indicator-color)}.inactive-track{background:var(--_track-color);inset:0;transition:transform 250ms cubic-bezier(0.4, 0, 0.6, 1);transform-origin:left center}.dots{inset:0;animation:linear infinite 250ms;animation-name:buffering;background-color:var(--_track-color);background-repeat:repeat-x;-webkit-mask-image:url("data:image/svg+xml,%3Csvg version='1.1' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 5 2' preserveAspectRatio='xMinYMin slice'%3E%3Ccircle cx='1' cy='1' r='1'/%3E%3C/svg%3E");mask-image:url("data:image/svg+xml,%3Csvg version='1.1' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 5 2' preserveAspectRatio='xMinYMin slice'%3E%3Ccircle cx='1' cy='1' r='1'/%3E%3C/svg%3E");z-index:-1}.dots[hidden]{display:none}.indeterminate .bar{transition:none}.indeterminate .primary-bar{inset-inline-start:-145.167%}.indeterminate .secondary-bar{inset-inline-start:-54.8889%;display:block}.indeterminate .primary-bar{animation:linear infinite 2s;animation-name:primary-indeterminate-translate}.indeterminate .primary-bar>.bar-inner{animation:linear infinite 2s primary-indeterminate-scale}.indeterminate.four-color .primary-bar>.bar-inner{animation-name:primary-indeterminate-scale,four-color;animation-duration:2s,4s}.indeterminate .secondary-bar{animation:linear infinite 2s;animation-name:secondary-indeterminate-translate}.indeterminate .secondary-bar>.bar-inner{animation:linear infinite 2s secondary-indeterminate-scale}.indeterminate.four-color .secondary-bar>.bar-inner{animation-name:secondary-indeterminate-scale,four-color;animation-duration:2s,4s}:host(:dir(rtl)){transform:scale(-1)}@keyframes primary-indeterminate-scale{0%{transform:scaleX(0.08)}36.65%{animation-timing-function:cubic-bezier(0.334731, 0.12482, 0.785844, 1);transform:scaleX(0.08)}69.15%{animation-timing-function:cubic-bezier(0.06, 0.11, 0.6, 1);transform:scaleX(0.661479)}100%{transform:scaleX(0.08)}}@keyframes secondary-indeterminate-scale{0%{animation-timing-function:cubic-bezier(0.205028, 0.057051, 0.57661, 0.453971);transform:scaleX(0.08)}19.15%{animation-timing-function:cubic-bezier(0.152313, 0.196432, 0.648374, 1.00432);transform:scaleX(0.457104)}44.15%{animation-timing-function:cubic-bezier(0.257759, -0.003163, 0.211762, 1.38179);transform:scaleX(0.72796)}100%{transform:scaleX(0.08)}}@keyframes buffering{0%{transform:translateX(calc(var(--_track-height) / 2 * 5))}}@keyframes primary-indeterminate-translate{0%{transform:translateX(0px)}20%{animation-timing-function:cubic-bezier(0.5, 0, 0.701732, 0.495819);transform:translateX(0px)}59.15%{animation-timing-function:cubic-bezier(0.302435, 0.381352, 0.55, 0.956352);transform:translateX(83.6714%)}100%{transform:translateX(200.611%)}}@keyframes secondary-indeterminate-translate{0%{animation-timing-function:cubic-bezier(0.15, 0, 0.515058, 0.409685);transform:translateX(0px)}25%{animation-timing-function:cubic-bezier(0.31033, 0.284058, 0.8, 0.733712);transform:translateX(37.6519%)}48.35%{animation-timing-function:cubic-bezier(0.4, 0.627035, 0.6, 0.902026);transform:translateX(84.3862%)}100%{transform:translateX(160.278%)}}@keyframes four-color{0%{background:var(--_four-color-active-indicator-one-color)}15%{background:var(--_four-color-active-indicator-one-color)}25%{background:var(--_four-color-active-indicator-two-color)}40%{background:var(--_four-color-active-indicator-two-color)}50%{background:var(--_four-color-active-indicator-three-color)}65%{background:var(--_four-color-active-indicator-three-color)}75%{background:var(--_four-color-active-indicator-four-color)}90%{background:var(--_four-color-active-indicator-four-color)}100%{background:var(--_four-color-active-indicator-one-color)}}@media(forced-colors: active){:host{outline:1px solid CanvasText}.bar-inner,.dots{background-color:CanvasText}}
`
/**
 * @license
 * Copyright 2023 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */;let Wr=class extends Gr{};Wr.styles=[Nr],Wr=e([be("md-linear-progress")],Wr);var Zr=g`
  .progress {
    padding-left: 36px;
    padding-right: 36px;
    padding-bottom: 8px;
    touch-action: none;
  }
  .progress-plain {
    --_light: var(
      --md-sys-color-primary,
      var(
        --md-linear-progress-track-color,
        var(--md-sys-color-surface-container-highest, #e6e0e9)
      )
    );
    --_dark: var(--light);
    --_size: 6px !important;
  }

  #progress-bar {
    --primary: var(
      --md-sys-color-primary,
      var(
        --md-linear-progress-track-color,
        var(--md-sys-color-surface-container-highest, #e6e0e9)
      )
    );
    --_light: unset;
    --_dark: unset;
  }

  #progress-div {
    margin-bottom: 4px;
  }
  .prog-incomplete {
    position: absolute;
    left: var(--incomplete-progress-start-pct);
    --height: 6px;
    top: calc(50% - (var(--height) / 2 - 1px));
    height: var(--height);
    background-color: var(
      --md-sys-color-secondary-container,
      var(
        --md-linear-progress-track-color,
        var(--md-sys-color-surface-container-highest, #e6e0e9)
      )
    );
    width: calc(100% - var(--incomplete-progress-start-pct));
    border-radius: 0px 3px 3px 0px;
  }

  #progress-handle {
    background-color: var(
      --md-sys-color-primary,
      var(
        --md-linear-progress-track-color,
        var(--md-sys-color-surface-container-highest, #e6e0e9)
      )
    );
    top: 0;
    height: 100%;
    border-radius: 4px;
  }

  progress.wavy {
    --_size: 4px;
    background-size: var(--_size);
    block-size: calc(var(--_size) * 3);
  }

  #time {
    justify-self: center;
    margin-bottom: 4px;
    padding-top: 4px;
  }
  .time-expressive {
    color: var(--md-sys-color-on-primary-container) !important;
  }

  .wavy {
  }
`;class _r extends ve{constructor(){super(...arguments),this.entity_duration=1,this.entity_position=0,this._prog_pct=0,this._lastUpdate=0,this._handleBarWidth=8,this._refreshMilliseconds=5e3,this._tick_duration_ms=250,this._dragging=!1,this._requestProgress=!0,this._currentSetPosition=0,this._newSetPosition=0,this.tickProgress=()=>{const e=this.player_data?.playing;if(!e||this._dragging)return;const t=(new Date).getTime();if(this._requestProgress&&(!this.media_duration||t-this._lastUpdate>=this._refreshMilliseconds))return this._lastUpdate=t,void this.requestProgress();let i=(this.media_position??0)+this._tick_duration_ms/1e3;this._currentSetPosition!=this._newSetPosition&&(this._currentSetPosition=this._newSetPosition,i=this._currentSetPosition),this.media_position=Math.min(i,this.media_duration)},this.onSeek=async e=>{const t=this.progressBar?.offsetWidth??1,i=e.offsetX/t,r=Math.floor(i*this.media_duration);await this.actions.actionSeek(r),this._dragging=!1,this._requestProgress=!0,window.removeEventListener("pointerup",this.onPointerUp),this.removeEventListener("pointermove",this.pointerMoveListener)},this.pointerMoveListener=e=>{const t=this.progressBar,i=t?.offsetParent?.offsetLeft??36,r=t.offsetWidth,A=(e.offsetX-i)/r;let s=Math.floor(A*this.media_duration);s=Math.min(this.media_duration,s),s=Math.max(0,s),this.media_position=s,this._newSetPosition=s,this.entity_position=s},this.onPointerDown=()=>{this._dragging=!0,this._requestProgress=!1,window.addEventListener("pointerup",this.onPointerUp),this.addEventListener("pointermove",this.pointerMoveListener)},this.onPointerUp=()=>{try{this.actions.actionSeek(this._newSetPosition)}finally{window.removeEventListener("pointerup",this.onPointerUp),this.removeEventListener("pointermove",this.pointerMoveListener)}this._newSetPosition=this.media_position,this._updateTimeout&&clearTimeout(this._updateTimeout),this._dragging=!1,this._updateTimeout=setTimeout(()=>{this._requestProgress=!0,this.requestProgress()},5e3)}}set media_position(e){this._media_position=e;const t=Math.min(1,e/(this._media_duration??1));this._prog_pct=t}get media_position(){return this._media_position||this.requestProgress(),this._media_position}set media_duration(e){this._media_duration=e,this._media_duration||this.requestProgress();const t=Math.min(1,this._media_position/(e??1));this._prog_pct=t}get media_duration(){return this._media_duration}set activePlayer(e){if(this._activePlayer&&!$i(this._activePlayer,e))return;const t=e.attributes.media_duration,i=this?._activePlayer?.attributes?.media_title&&e.attributes.media_title!=this._activePlayer?.attributes?.media_title?1:e.attributes.media_position;this._activePlayer=e,this.entity_duration??=t,this.media_duration??=t,this.entity_position??=i,this.media_position??=i,this.requestProgress()}get activePlayer(){return this._activePlayer}set player_data(e){this._player_data=e,this.requestProgress()}get player_data(){return this._player_data}requestProgress(){this.activePlayerController.getPlayerProgress().then(e=>{e=Math.min(e??1,this.entity_duration??e),this.entity_position=e??this.entity_position,this._newSetPosition=e??this.entity_position}),this.activePlayerController.getPlayerActiveItemDuration().then(e=>{this.media_duration=e??this.media_duration,this.entity_duration=e??this.entity_duration})}renderTime(){return`${_i(this.media_position)} - ${_i(this.media_duration)}`}renderVolumeBarHandle(){return W`
      <div
        id="progress-handle"
        style="
          width: ${this._handleBarWidth.toString()}px; 
          position: absolute;
          left: calc(${(100*this._prog_pct).toString()}% - (${this._handleBarWidth.toString()}px / 2));
        "
      ></div>
    `}render(){const e=this.player_data.playing&&this.controller.config.expressive?"wavy medium":"medium progress-plain";return W`
      <div class="progress">
        <div
          id="time"
          class="${this.controller.config.expressive?"time-expressive":""}"
        >
          ${this.renderTime()}
        </div>
        <div
          id="progress-div"
          @pointerdown=${this.onPointerDown}
          @click=${this.onSeek}
        >
          <link
            href="https://cdn.jsdelivr.net/npm/beercss@3.12.11/dist/cdn/beer.min.css"
            rel="stylesheet"
          />
          <div
            class="prog-incomplete"
            style="--incomplete-progress-start-pct: ${Math.round(100*this._prog_pct)}%;"
          ></div>
          <progress
            class="${e}"
            id="progress-bar"
            value="${this._prog_pct}"
            max="1"
          ></progress>
          ${this.renderVolumeBarHandle()}
        </div>
      </div>
    `}connectedCallback(){this._tickListener||(this._tickListener=setInterval(this.tickProgress,this._tick_duration_ms)),this.activePlayerController&&this.hasUpdated&&this.requestProgress(),super.connectedCallback()}disconnectedCallback(){if(this._tickListener)try{clearInterval(this._tickListener)}finally{this._tickListener=void 0}super.disconnectedCallback()}shouldUpdate(e){return e.size>0}static get styles(){return Zr}}function $r(e,t,i){const r=e=>Object.is(e,-0)?0:e;return r(e<t?t:e>i?i:e)}e([De()],_r.prototype,"_media_duration",void 0),e([De()],_r.prototype,"_media_position",void 0),e([ke("#progress-bar")],_r.prototype,"progressBar",void 0),e([n({context:Hi,subscribe:!0})],_r.prototype,"activePlayerController",void 0),e([n({context:Si,subscribe:!0})],_r.prototype,"actions",void 0),e([n({context:Oi,subscribe:!0})],_r.prototype,"controller",void 0),e([n({context:Ei,subscribe:!0})],_r.prototype,"activePlayer",null),e([n({context:Bi,subscribe:!0}),De()],_r.prototype,"player_data",null),customElements.define("mass-progress-bar",_r);var eA=class{constructor(e,t){this.timerId=0,this.activeInteractions=0,this.paused=!1,this.stopped=!0,this.pause=()=>{this.activeInteractions++||(this.paused=!0,this.host.requestUpdate())},this.resume=()=>{--this.activeInteractions||(this.paused=!1,this.host.requestUpdate())},e.addController(this),this.host=e,this.tickCallback=t}hostConnected(){this.host.addEventListener("mouseenter",this.pause),this.host.addEventListener("mouseleave",this.resume),this.host.addEventListener("focusin",this.pause),this.host.addEventListener("focusout",this.resume),this.host.addEventListener("touchstart",this.pause,{passive:!0}),this.host.addEventListener("touchend",this.resume)}hostDisconnected(){this.stop(),this.host.removeEventListener("mouseenter",this.pause),this.host.removeEventListener("mouseleave",this.resume),this.host.removeEventListener("focusin",this.pause),this.host.removeEventListener("focusout",this.resume),this.host.removeEventListener("touchstart",this.pause),this.host.removeEventListener("touchend",this.resume)}start(e){this.stop(),this.stopped=!1,this.timerId=window.setInterval(()=>{this.paused||this.tickCallback()},e)}stop(){clearInterval(this.timerId),this.stopped=!0,this.host.requestUpdate()}},tA=g`
  :host {
    --slide-gap: var(--sl-spacing-medium, 1rem);
    --aspect-ratio: 16 / 9;
    --scroll-hint: 0px;

    display: flex;
  }

  .carousel {
    display: grid;
    grid-template-columns: min-content 1fr min-content;
    grid-template-rows: 1fr min-content;
    grid-template-areas:
      '. slides .'
      '. pagination .';
    gap: var(--sl-spacing-medium);
    align-items: center;
    min-height: 100%;
    min-width: 100%;
    position: relative;
  }

  .carousel__pagination {
    grid-area: pagination;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: var(--sl-spacing-small);
  }

  .carousel__slides {
    grid-area: slides;

    display: grid;
    height: 100%;
    width: 100%;
    align-items: center;
    justify-items: center;
    overflow: auto;
    overscroll-behavior-x: contain;
    scrollbar-width: none;
    aspect-ratio: calc(var(--aspect-ratio) * var(--slides-per-page));
    border-radius: var(--sl-border-radius-small);

    --slide-size: calc((100% - (var(--slides-per-page) - 1) * var(--slide-gap)) / var(--slides-per-page));
  }

  @media (prefers-reduced-motion) {
    :where(.carousel__slides) {
      scroll-behavior: auto;
    }
  }

  .carousel__slides--horizontal {
    grid-auto-flow: column;
    grid-auto-columns: var(--slide-size);
    grid-auto-rows: 100%;
    column-gap: var(--slide-gap);
    scroll-snap-type: x mandatory;
    scroll-padding-inline: var(--scroll-hint);
    padding-inline: var(--scroll-hint);
    overflow-y: hidden;
  }

  .carousel__slides--vertical {
    grid-auto-flow: row;
    grid-auto-columns: 100%;
    grid-auto-rows: var(--slide-size);
    row-gap: var(--slide-gap);
    scroll-snap-type: y mandatory;
    scroll-padding-block: var(--scroll-hint);
    padding-block: var(--scroll-hint);
    overflow-x: hidden;
  }

  .carousel__slides--dragging {
  }

  :host([vertical]) ::slotted(sl-carousel-item) {
    height: 100%;
  }

  .carousel__slides::-webkit-scrollbar {
    display: none;
  }

  .carousel__navigation {
    grid-area: navigation;
    display: contents;
    font-size: var(--sl-font-size-x-large);
  }

  .carousel__navigation-button {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    background: none;
    border: none;
    border-radius: var(--sl-border-radius-small);
    font-size: inherit;
    color: var(--sl-color-neutral-600);
    padding: var(--sl-spacing-x-small);
    cursor: pointer;
    transition: var(--sl-transition-medium) color;
    appearance: none;
  }

  .carousel__navigation-button--disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .carousel__navigation-button--disabled::part(base) {
    pointer-events: none;
  }

  .carousel__navigation-button--previous {
    grid-column: 1;
    grid-row: 1;
  }

  .carousel__navigation-button--next {
    grid-column: 3;
    grid-row: 1;
  }

  .carousel__pagination-item {
    display: block;
    cursor: pointer;
    background: none;
    border: 0;
    border-radius: var(--sl-border-radius-circle);
    width: var(--sl-spacing-small);
    height: var(--sl-spacing-small);
    background-color: var(--sl-color-neutral-300);
    padding: 0;
    margin: 0;
  }

  .carousel__pagination-item--active {
    background-color: var(--sl-color-neutral-700);
    transform: scale(1.2);
  }

  /* Focus styles */
  .carousel__slides:focus-visible,
  .carousel__navigation-button:focus-visible,
  .carousel__pagination-item:focus-visible {
    outline: var(--sl-focus-ring);
    outline-offset: var(--sl-focus-ring-offset);
  }
`;function iA(){return window.matchMedia("(prefers-reduced-motion: reduce)").matches}
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var rA=class extends Lt{constructor(){super(...arguments),this.loop=!1,this.navigation=!1,this.pagination=!1,this.autoplay=!1,this.autoplayInterval=3e3,this.slidesPerPage=1,this.slidesPerMove=1,this.orientation="horizontal",this.mouseDragging=!1,this.activeSlide=0,this.scrolling=!1,this.dragging=!1,this.autoplayController=new eA(this,()=>this.next()),this.dragStartPosition=[-1,-1],this.localize=new yt(this),this.pendingSlideChange=!1,this.handleMouseDrag=e=>{this.dragging||(this.scrollContainer.style.setProperty("scroll-snap-type","none"),this.dragging=!0,this.dragStartPosition=[e.clientX,e.clientY]),this.scrollContainer.scrollBy({left:-e.movementX,top:-e.movementY,behavior:"instant"})},this.handleMouseDragEnd=()=>{const e=this.scrollContainer;document.removeEventListener("pointermove",this.handleMouseDrag,{capture:!0});const t=e.scrollLeft,i=e.scrollTop;e.style.removeProperty("scroll-snap-type"),e.style.setProperty("overflow","hidden");const r=e.scrollLeft,A=e.scrollTop;e.style.removeProperty("overflow"),e.style.setProperty("scroll-snap-type","none"),e.scrollTo({left:t,top:i,behavior:"instant"}),requestAnimationFrame(async()=>{var s,o;t===r&&i===A||(e.scrollTo({left:r,top:A,behavior:iA()?"auto":"smooth"}),await(s=e,o="scrollend",new Promise(e=>{s.addEventListener(o,function t(i){i.target===s&&(s.removeEventListener(o,t),e())})}))),e.style.removeProperty("scroll-snap-type"),this.dragging=!1,this.dragStartPosition=[-1,-1],this.handleScrollEnd()})},this.handleSlotChange=e=>{e.some(e=>[...e.addedNodes,...e.removedNodes].some(e=>this.isCarouselItem(e)&&!e.hasAttribute("data-clone")))&&this.initializeSlides(),this.requestUpdate()}}connectedCallback(){super.connectedCallback(),this.setAttribute("role","region"),this.setAttribute("aria-label",this.localize.term("carousel"))}disconnectedCallback(){var e;super.disconnectedCallback(),null==(e=this.mutationObserver)||e.disconnect()}firstUpdated(){this.initializeSlides(),this.mutationObserver=new MutationObserver(this.handleSlotChange),this.mutationObserver.observe(this,{childList:!0,subtree:!0})}willUpdate(e){(e.has("slidesPerMove")||e.has("slidesPerPage"))&&(this.slidesPerMove=Math.min(this.slidesPerMove,this.slidesPerPage))}getPageCount(){const e=this.getSlides().length,{slidesPerPage:t,slidesPerMove:i,loop:r}=this,A=r?e/i:(e-t)/i+1;return Math.ceil(A)}getCurrentPage(){return Math.ceil(this.activeSlide/this.slidesPerMove)}canScrollNext(){return this.loop||this.getCurrentPage()<this.getPageCount()-1}canScrollPrev(){return this.loop||this.getCurrentPage()>0}getSlides({excludeClones:e=!0}={}){return[...this.children].filter(t=>this.isCarouselItem(t)&&(!e||!t.hasAttribute("data-clone")))}handleClick(e){if(this.dragging&&this.dragStartPosition[0]>0&&this.dragStartPosition[1]>0){const t=Math.abs(this.dragStartPosition[0]-e.clientX),i=Math.abs(this.dragStartPosition[1]-e.clientY);Math.sqrt(t*t+i*i)>=10&&e.preventDefault()}}handleKeyDown(e){if(["ArrowLeft","ArrowRight","ArrowUp","ArrowDown","Home","End"].includes(e.key)){const t=e.target,i="rtl"===this.localize.dir(),r=null!==t.closest('[part~="pagination-item"]'),A="ArrowDown"===e.key||!i&&"ArrowRight"===e.key||i&&"ArrowLeft"===e.key,s="ArrowUp"===e.key||!i&&"ArrowLeft"===e.key||i&&"ArrowRight"===e.key;e.preventDefault(),s&&this.previous(),A&&this.next(),"Home"===e.key&&this.goToSlide(0),"End"===e.key&&this.goToSlide(this.getSlides().length-1),r&&this.updateComplete.then(()=>{var e;const t=null==(e=this.shadowRoot)?void 0:e.querySelector('[part~="pagination-item--active"]');t&&t.focus()})}}handleMouseDragStart(e){this.mouseDragging&&0===e.button&&(e.preventDefault(),document.addEventListener("pointermove",this.handleMouseDrag,{capture:!0,passive:!0}),document.addEventListener("pointerup",this.handleMouseDragEnd,{capture:!0,once:!0}))}handleScroll(){this.scrolling=!0,this.pendingSlideChange||this.synchronizeSlides()}synchronizeSlides(){const e=new IntersectionObserver(t=>{e.disconnect();for(const e of t){const t=e.target;t.toggleAttribute("inert",!e.isIntersecting),t.classList.toggle("--in-view",e.isIntersecting),t.setAttribute("aria-hidden",e.isIntersecting?"false":"true")}const i=t.find(e=>e.isIntersecting);if(!i)return;const r=this.getSlides({excludeClones:!1}),A=this.getSlides().length,s=r.indexOf(i.target),o=this.loop?s-this.slidesPerPage:s;if(this.activeSlide=(Math.ceil(o/this.slidesPerMove)*this.slidesPerMove+A)%A,!this.scrolling&&this.loop&&i.target.hasAttribute("data-clone")){const e=Number(i.target.getAttribute("data-clone"));this.goToSlide(e,"instant")}},{root:this.scrollContainer,threshold:.6});this.getSlides({excludeClones:!1}).forEach(t=>{e.observe(t)})}handleScrollEnd(){this.scrolling&&!this.dragging&&(this.scrolling=!1,this.pendingSlideChange=!1,this.synchronizeSlides())}isCarouselItem(e){return e instanceof Element&&"sl-carousel-item"===e.tagName.toLowerCase()}initializeSlides(){this.getSlides({excludeClones:!1}).forEach((e,t)=>{e.classList.remove("--in-view"),e.classList.remove("--is-active"),e.setAttribute("role","group"),e.setAttribute("aria-label",this.localize.term("slideNum",t+1)),this.pagination&&(e.setAttribute("id",`slide-${t+1}`),e.setAttribute("role","tabpanel"),e.removeAttribute("aria-label"),e.setAttribute("aria-labelledby",`tab-${t+1}`)),e.hasAttribute("data-clone")&&e.remove()}),this.updateSlidesSnap(),this.loop&&this.createClones(),this.goToSlide(this.activeSlide,"auto"),this.synchronizeSlides()}createClones(){const e=this.getSlides(),t=this.slidesPerPage,i=e.slice(-t),r=e.slice(0,t);i.reverse().forEach((t,i)=>{const r=t.cloneNode(!0);r.setAttribute("data-clone",String(e.length-i-1)),this.prepend(r)}),r.forEach((e,t)=>{const i=e.cloneNode(!0);i.setAttribute("data-clone",String(t)),this.append(i)})}handleSlideChange(){const e=this.getSlides();e.forEach((e,t)=>{e.classList.toggle("--is-active",t===this.activeSlide)}),this.hasUpdated&&this.emit("sl-slide-change",{detail:{index:this.activeSlide,slide:e[this.activeSlide]}})}updateSlidesSnap(){const e=this.getSlides(),t=this.slidesPerMove;e.forEach((e,i)=>{(i+t)%t===0?e.style.removeProperty("scroll-snap-align"):e.style.setProperty("scroll-snap-align","none")})}handleAutoplayChange(){this.autoplayController.stop(),this.autoplay&&this.autoplayController.start(this.autoplayInterval)}previous(e="smooth"){this.goToSlide(this.activeSlide-this.slidesPerMove,e)}next(e="smooth"){this.goToSlide(this.activeSlide+this.slidesPerMove,e)}goToSlide(e,t="smooth"){const{slidesPerPage:i,loop:r}=this,A=this.getSlides(),s=this.getSlides({excludeClones:!1});if(!A.length)return;const o=r?(e+A.length)%A.length:$r(e,0,A.length-i);this.activeSlide=o;const n=s[$r(e+(r?i:0)+("rtl"===this.localize.dir()?i-1:0),0,s.length-1)];this.scrollToSlide(n,iA()?"auto":t)}scrollToSlide(e,t="smooth"){this.pendingSlideChange=!0,window.requestAnimationFrame(()=>{if(!this.scrollContainer)return;const i=this.scrollContainer,r=i.getBoundingClientRect(),A=e.getBoundingClientRect(),s=A.left-r.left,o=A.top-r.top;s||o?(this.pendingSlideChange=!0,i.scrollTo({left:s+i.scrollLeft,top:o+i.scrollTop,behavior:t})):this.pendingSlideChange=!1})}render(){const{slidesPerMove:e,scrolling:t}=this,i=this.getPageCount(),r=this.getCurrentPage(),A=this.canScrollPrev(),s=this.canScrollNext(),o="ltr"===this.localize.dir();return W`
      <div part="base" class="carousel">
        <div
          id="scroll-container"
          part="scroll-container"
          class="${zt({carousel__slides:!0,"carousel__slides--horizontal":"horizontal"===this.orientation,"carousel__slides--vertical":"vertical"===this.orientation,"carousel__slides--dragging":this.dragging})}"
          style="--slides-per-page: ${this.slidesPerPage};"
          aria-busy="${t?"true":"false"}"
          aria-atomic="true"
          tabindex="0"
          @keydown=${this.handleKeyDown}
          @mousedown="${this.handleMouseDragStart}"
          @scroll="${this.handleScroll}"
          @scrollend=${this.handleScrollEnd}
          @click=${this.handleClick}
        >
          <slot></slot>
        </div>

        ${this.navigation?W`
              <div part="navigation" class="carousel__navigation">
                <button
                  part="navigation-button navigation-button--previous"
                  class="${zt({"carousel__navigation-button":!0,"carousel__navigation-button--previous":!0,"carousel__navigation-button--disabled":!A})}"
                  aria-label="${this.localize.term("previousSlide")}"
                  aria-controls="scroll-container"
                  aria-disabled="${A?"false":"true"}"
                  @click=${A?()=>this.previous():null}
                >
                  <slot name="previous-icon">
                    <sl-icon library="system" name="${o?"chevron-left":"chevron-right"}"></sl-icon>
                  </slot>
                </button>

                <button
                  part="navigation-button navigation-button--next"
                  class=${zt({"carousel__navigation-button":!0,"carousel__navigation-button--next":!0,"carousel__navigation-button--disabled":!s})}
                  aria-label="${this.localize.term("nextSlide")}"
                  aria-controls="scroll-container"
                  aria-disabled="${s?"false":"true"}"
                  @click=${s?()=>this.next():null}
                >
                  <slot name="next-icon">
                    <sl-icon library="system" name="${o?"chevron-right":"chevron-left"}"></sl-icon>
                  </slot>
                </button>
              </div>
            `:""}
        ${this.pagination?W`
              <div part="pagination" role="tablist" class="carousel__pagination">
                ${function*(e,t){if(void 0!==e){let i=0;for(const r of e)yield t(r,i++)}}
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */(function*(e,t,i=1){const r=void 0===t?0:e;t??=e;for(let e=r;i>0?e<t:t<e;e+=i)yield e}(i),t=>{const A=t===r;return W`
                    <button
                      part="pagination-item ${A?"pagination-item--active":""}"
                      class="${zt({"carousel__pagination-item":!0,"carousel__pagination-item--active":A})}"
                      role="tab"
                      id="tab-${t+1}"
                      aria-controls="slide-${t+1}"
                      aria-selected="${A?"true":"false"}"
                      aria-label="${A?this.localize.term("slideNum",t+1):this.localize.term("goToSlide",t+1,i)}"
                      tabindex=${A?"0":"-1"}
                      @click=${()=>this.goToSlide(t*e)}
                      @keydown=${this.handleKeyDown}
                    ></button>
                  `})}
              </div>
            `:""}
      </div>
    `}};rA.styles=[qt,tA],rA.dependencies={"sl-icon":Ft},At([Qe({type:Boolean,reflect:!0})],rA.prototype,"loop",2),At([Qe({type:Boolean,reflect:!0})],rA.prototype,"navigation",2),At([Qe({type:Boolean,reflect:!0})],rA.prototype,"pagination",2),At([Qe({type:Boolean,reflect:!0})],rA.prototype,"autoplay",2),At([Qe({type:Number,attribute:"autoplay-interval"})],rA.prototype,"autoplayInterval",2),At([Qe({type:Number,attribute:"slides-per-page"})],rA.prototype,"slidesPerPage",2),At([Qe({type:Number,attribute:"slides-per-move"})],rA.prototype,"slidesPerMove",2),At([Qe()],rA.prototype,"orientation",2),At([Qe({type:Boolean,reflect:!0,attribute:"mouse-dragging"})],rA.prototype,"mouseDragging",2),At([ke(".carousel__slides")],rA.prototype,"scrollContainer",2),At([ke(".carousel__pagination")],rA.prototype,"paginationContainer",2),At([De()],rA.prototype,"activeSlide",2),At([De()],rA.prototype,"scrolling",2),At([De()],rA.prototype,"dragging",2),At([function(e){return(t,i)=>{const r="function"==typeof t?t:t[i];Object.assign(r,e)}}({passive:!0})],rA.prototype,"handleScroll",1),At([St("loop",{waitUntilFirstUpdate:!0}),St("slidesPerPage",{waitUntilFirstUpdate:!0})],rA.prototype,"initializeSlides",1),At([St("activeSlide")],rA.prototype,"handleSlideChange",1),At([St("slidesPerMove")],rA.prototype,"updateSlidesSnap",1),At([St("autoplay")],rA.prototype,"handleAutoplayChange",1),rA.define("sl-carousel");var AA=(e,t)=>{let i=0;return function(...r){window.clearTimeout(i),i=window.setTimeout(()=>{e.call(this,...r)},t)}},sA=(e,t,i)=>{const r=e[t];e[t]=function(...e){r.call(this,...e),i.call(this,r,...e)}};(()=>{if("undefined"==typeof window)return;if(!("onscrollend"in window)){const e=new Set,t=new WeakMap,i=t=>{for(const i of t.changedTouches)e.add(i.identifier)},r=t=>{for(const i of t.changedTouches)e.delete(i.identifier)};document.addEventListener("touchstart",i,!0),document.addEventListener("touchend",r,!0),document.addEventListener("touchcancel",r,!0),sA(EventTarget.prototype,"addEventListener",function(i,r){if("scrollend"!==r)return;const A=AA(()=>{e.size?A():this.dispatchEvent(new Event("scrollend"))},100);i.call(this,"scroll",A,{passive:!0}),t.set(this,A)}),sA(EventTarget.prototype,"removeEventListener",function(e,i){if("scrollend"!==i)return;const r=t.get(this);r&&e.call(this,"scroll",r,{passive:!0})})}})();var oA=g`
  :host {
    --aspect-ratio: inherit;

    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    width: 100%;
    max-height: 100%;
    aspect-ratio: var(--aspect-ratio);
    scroll-snap-align: start;
    scroll-snap-stop: always;
  }

  ::slotted(img) {
    width: 100% !important;
    height: 100% !important;
    object-fit: cover;
  }
`,nA=class extends Lt{connectedCallback(){super.connectedCallback()}render(){return W` <slot></slot> `}};nA.styles=[qt,oA],nA.define("sl-carousel-item");var aA=g`
  .artwork {
    border-radius: var(--artwork-border-radius);
    max-width: 100%;
    justify-self: center;
    display: block;
  }
  .artwork-large {
    border-radius: var(--artwork-border-radius) var(--artwork-border-radius) 0px
      0px;
  }
  .artwork-medium {
  }
  .artwork-small {
  }
  .asleep {
    height: 100%;
    width: 100%;
  }
  .asleep-expressive {
    color: rgba(from var(--md-sys-color-primary) r g b / 0.7);
  }

  #carousel {
    --aspect-ratio: 1;
    position: absolute;
  }
  .carousel-large {
    height: var(--mass-player-card-height) !important;
    aspect-ratio: 1;
    width: 100%;
  }
  .carousel-medium {
    height: var(--artwork-medium-height);
    aspect-ratio: 1;
    place-content: center;
    position: absolute;
    top: calc(50% - (var(--artwork-medium-height) / 2) - 2em);
  }
  .carousel-small {
    position: absolute;
    height: var(--artwork-small-height);
    display: flex;
    aspect-ratio: 1;
    left: calc(50% - (var(--artwork-small-height) / 2));
    top: calc(50% - (var(--artwork-small-height) / 2));
  }
`;class cA extends ve{constructor(){super(...arguments),this._lastSwipedTS=0,this._disconnected=!1,this._playerLoadedTS=0,this.onCarouselSwipe=e=>{e.stopPropagation(),navigator.vibrate([75,20,75]);const t=e.detail.index,i=this._lastSwipedTS,r=e.timeStamp,A=(new Date).getTime();this._lastSwipedTS=r;const s=r-i,o=A-this._playerLoadedTS;s<=300||o<=300||(0==t?this.previousItemImage&&(this.currentItemImage=this.previousItemImage,this.controller.Actions.actionPlayPrevious()):2==t&&this.nextItemImage&&(this.currentItemImage=this.nextItemImage,this.controller.Actions.actionPlayNext()),this.goToCurrentSlide("instant"))}}set playerData(e){const t=this.playerData;t?.track_artwork!=e?.track_artwork&&(this._playerData=e,this.currentItemImage=e.track_artwork),this._playerLoadedTS=(new Date).getTime()}get playerData(){return this._playerData}set previousQueueItem(e){tr(this.previousQueueItem,e)||(this.previousItemImage=e?.media_image??"",this._previousQueueItem=e??void 0)}get previousQueueItem(){return this._previousQueueItem}set previousItemImage(e){e!=this._previousItemImage&&(this._previousItemImage=e,this.previousCarouselImage&&(this.previousCarouselImage.src=e))}get previousItemImage(){return this._previousItemImage}set currentQueueItem(e){tr(this.currentQueueItem,e)||(this.currentItemImage=e?.media_image??"",this._currentQueueItem=e??void 0)}get currentQueueItem(){return this._currentQueueItem}set currentItemImage(e){if(e==this._currentItemImage)return;this._currentItemImage=e,this.currentCarouselImage&&(this.currentCarouselImage.src=e);const t=new CustomEvent("artwork-updated",{detail:{type:"current",image:e}});this.controller.host.dispatchEvent(t)}get currentItemImage(){return this._currentItemImage}set nextQueueItem(e){tr(this.nextQueueItem,e)||(this.nextItemImage=e?.media_image??"",this._nextQueueItem=e??void 0)}get nextQueueItem(){return this._nextQueueItem}set nextItemImage(e){e!=this._nextItemImage&&(this._nextItemImage=e,this.nextCarouselImage&&(this.nextCarouselImage.src=e))}get nextItemImage(){return this._nextItemImage}goToCurrentSlide(e="instant"){this.carouselElement.goToSlide(1,e)}renderItemArtwork(e,t){const i=nr(this.hass,Gt.CLEFT),r=this.playerConfig.layout.artwork_size;return e?W`
      <img
        id="${t}"
        class="artwork artwork-${r}"
        src="${e}"
        onerror="this.src='${i}';"
      />
    `:W` <img class="artwork artwork-${r}" src="${i}" /> `}renderAsleep(){const e=this.controller.config.expressive?"-expressive":"";return W`
      <ha-svg-icon
        .path=${this.Icons.ASLEEP}
        class="asleep asleep${e}"
      >
      </ha-svg-icon>
    `}renderCarouselItem(e,t){return e=e??Gt.CLEFT,W`
      <sl-carousel-item>
        ${this.renderItemArtwork(e,t)}
      </sl-carousel-item>
    `}renderInactive(){const e=nr(this.hass,Gt.CLEFT),t=this.playerConfig.layout.artwork_size;return W`
      <sl-carousel-item>
        <img
          class="artwork artwork-${t}"
          src="${e}"
          onerror="this.src='${e}';"
        />
      </sl-carousel-item>
    `}renderPriorItem(){const e=this.previousItemImage??Gt.CLEFT;return this.renderCarouselItem(e,"carousel-img-prior")}renderCarouselItems(){return er(this.hass,this.activePlayer,this.controller.ActivePlayer.activeEntityConfig)?W`
      ${this.renderCarouselItem(this.previousItemImage,"carousel-img-prior")}
      ${this.renderCarouselItem(this.activePlayer.attributes.entity_picture_local??this.currentItemImage,"carousel-img-cur")}
      ${this.renderCarouselItem(this.nextItemImage,"carousel-img-next")}
    `:this.renderAsleep()}render(){const e=this.playerConfig.layout.artwork_size;return W`
      <sl-carousel
        id="carousel"
        class="carousel-${e}"
        mouse-dragging
        @sl-slide-change=${this.onCarouselSwipe}
      >
        ${this.renderCarouselItems()}
      </sl-carousel>
    `}shouldUpdate(e){return e.size>0}updated(){this.goToCurrentSlide()}disconnectedCallback(){this._disconnected=!0,super.disconnectedCallback()}connectedCallback(){this._disconnected&&this.goToCurrentSlide(),this._disconnected=!1,super.connectedCallback()}static get styles(){return aA}}var lA,dA,uA;e([n({context:vi,subscribe:!0})],cA.prototype,"hass",void 0),e([n({context:Oi,subscribe:!0})],cA.prototype,"controller",void 0),e([n({context:Di,subscribe:!0}),De()],cA.prototype,"playerConfig",void 0),e([n({context:Ei,subscribe:!0}),De()],cA.prototype,"activePlayer",void 0),e([n({context:Ji})],cA.prototype,"Icons",void 0),e([ke("#carousel")],cA.prototype,"carouselElement",void 0),e([ke("#carousel-img-prior")],cA.prototype,"previousCarouselImage",void 0),e([ke("#carousel-img-cur")],cA.prototype,"currentCarouselImage",void 0),e([ke("#carousel-img-next")],cA.prototype,"nextCarouselImage",void 0),e([De()],cA.prototype,"_playerData",void 0),e([n({context:Bi,subscribe:!0})],cA.prototype,"playerData",null),e([n({context:Yi,subscribe:!0})],cA.prototype,"previousQueueItem",null),e([n({context:Fi,subscribe:!0})],cA.prototype,"currentQueueItem",null),e([n({context:zi,subscribe:!0})],cA.prototype,"nextQueueItem",null),customElements.define("mass-artwork",cA),function(e){e.COMPACT="compact",e.SPACED="spaced"}(lA||(lA={})),function(e){e.SMALL="small",e.MEDIUM="medium",e.LARGE="large"}(dA||(dA={})),function(e){e.SMALL="small",e.LARGE="large"}(uA||(uA={}));const hA={favorite:!1,mute:!1,player_selector:!1,power:!1,repeat:!1,shuffle:!1,volume:!1,group_volume:!1},gA={shuffle:{size:uA.SMALL,box_shadow:!1,label:!0},previous:{size:uA.SMALL,box_shadow:!1,label:!1},play_pause:{size:uA.LARGE,box_shadow:!0,label:!1},next:{size:uA.SMALL,box_shadow:!1,label:!1},repeat:{size:uA.SMALL,box_shadow:!1,label:!0}},pA={controls_layout:lA.COMPACT,icons:gA,artwork_size:dA.LARGE},vA={enabled:!0,hide:hA,layout:pA},mA=["favorite","mute","player_selector","power","repeat","shuffle","volume","group_volume"];function wA(e){e=function(e){const t=e.layout,i=gA,r=t.icons;let A={...i,...r};return A={shuffle:{...i.shuffle,...A.shuffle},previous:{...i.previous,...A.previous},play_pause:{...i.play_pause,...A.play_pause},next:{...i.next,...A.next},repeat:{...i.repeat,...A.repeat}},{...e,layout:{...t,icons:A}}}(e);const t=e.layout;return{...e,layout:{...pA,...t}}}function fA(e){let t=e.player;return t=function(e){return{...vA,...e}}(t),t=function(e){const t=e.hide;return{...e,hide:{...hA,...t}}}(t),t=wA(t),{...e,player:t}}function EA(e){return e.size!=uA.LARGE&&e.label?W`slot="start"`:W``}function CA(e,t){return e.size!=uA.LARGE&&e.label?W`${t}`:W``}function BA(e,t){return e==jt.ALL?t.REPEAT:e==jt.ONCE?t.REPEAT_ONCE:t.REPEAT_OFF}class bA extends ve{constructor(){super(...arguments),this.playing=!1,this.repeat=jt.OFF,this.shuffle=!1,this.favorite=!1,this.onPrevious=async e=>{e.stopPropagation(),await this.actions.actionPlayPrevious(),this.requestPlayerDataUpdate()},this.onNext=async e=>{e.stopPropagation(),await this.actions.actionPlayNext(),this.requestPlayerDataUpdate()},this.onPlayPause=async e=>{e.stopPropagation(),this.playing=!this.playing,this.forceUpdatePlayerData("playing",this.playing),await this.actions.actionPlayPause()},this.onShuffle=async e=>{e.stopPropagation(),this.shuffle=!this.shuffle,this.requestUpdate("shuffle",this.shuffle),await this.actions.actionToggleShuffle()},this.onRepeat=async e=>{e.stopPropagation();const t=function(e){return e==jt.ALL?jt.ONCE:e==jt.ONCE?jt.OFF:jt.ALL}(this.playerData.repeat);this.repeat=t,this.requestUpdate("repeat",this.repeat),await this.actions.actionSetRepeat(t)},this.onPower=async e=>{e.stopPropagation(),await this.actions.actionTogglePower()},this.onFavorite=async e=>{e.stopPropagation(),this.favorite=!this.favorite,this.requestUpdate("favorite",this.favorite),this.playerData.favorite?await this.actions.actionRemoveFavorite():await this.actions.actionAddFavorite()}}set _base_player_config(e){const t=e.hide;this._configHiddenElements={power:t.power,repeat:t.repeat,shuffle:t.shuffle,favorite:t.favorite},this.setHiddenElements()}set activeEntityConfig(e){const t=e.hide.player;this._entityHiddenElements={power:t.power,repeat:t.repeat,shuffle:t.shuffle,favorite:t.favorite},this.setHiddenElements()}setHiddenElements(){const e=this?._entityHiddenElements,t=this?._configHiddenElements,i={power:e?.power||t?.power||!1,repeat:e?.repeat||t?.repeat||!1,shuffle:e?.shuffle||t?.shuffle||!1,favorite:e?.favorite||t?.favorite||!1};tr(i,this._hiddenElements)||(this._hiddenElements=i)}get hiddenElements(){return this._hiddenElements}set playerData(e){this._playerData=e,this.playing=e.playing,this.repeat=e.repeat,this.shuffle=e.shuffle,this.favorite=e.favorite}get playerData(){return this._playerData}forceUpdatePlayerData(e,t){const i=new CustomEvent("force-update-player",{detail:{key:e,value:t}});this.controller.host.dispatchEvent(i)}requestPlayerDataUpdate(){const e=new Event("request-player-data-update");this.controller.host.dispatchEvent(e)}shouldUpdate(e){return e.size>0}}e([n({context:Si})],bA.prototype,"actions",void 0),e([De()],bA.prototype,"_hiddenElements",void 0),e([n({context:Oi,subscribe:!0})],bA.prototype,"controller",void 0),e([n({context:Di,subscribe:!0})],bA.prototype,"_base_player_config",null),e([n({context:mi,subscribe:!0})],bA.prototype,"activeEntityConfig",null),e([De()],bA.prototype,"_playerData",void 0),e([n({context:Ji})],bA.prototype,"Icons",void 0),e([n({context:Bi,subscribe:!0})],bA.prototype,"playerData",null);var IA=g`
  .controls {
    grid-area: controls;
    overflow-y: auto;
    margin: 0.25rem;
    padding: 0.5rem;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
  }
  .controls-left {
    display: flex;
    flex-direction: column;
    align-items: end;
    justify-content: center;
  }
  .controls-right {
    display: flex;
    align-items: start;
    justify-content: center;
  }

  .controls-compact {
    flex-direction: column;
  }
  .controls-spaced {
    flex-direction: row;
    gap: 1em;
    margin-left: 1em;
    margin-right: 1em;
  }

  .controls-previous-next::part(base) {
    height: 30px;
    width: 60px;
  }

  .div-medium {
    --ha-button-height: var(--player-play-pause-icon-size);
    margin: 0px 6px 0px 6px;
    --ha-button-border-radius: 50%;
    border-radius: 50%;
  }

  .div-spaced {
    align-self: center;
  }

  .has-box-shadow::part(base) {
    box-shadow: rgba(0, 0, 0, 0.16) 0px 2px 4px 0px;
  }

  .icon-medium {
  }
  .icon-small {
  }

  .icon-accent {
  }
  .icon-accent::part(base) {
    background-color: var(--md-sys-color-primary);
  }
  .icon-accent::part(label) {
    color: var(--md-sys-color-on-primary);
  }

  .icon-filled {
  }

  .icon-outlined {
  }
  .icon-outlined::part(label) {
  }

  .icon-plain {
  }

  .player-controls {
    width: var(--player-control-icon-width);
    height: var(--player-control-icon-width);
  }

  .svg-medium {
    height: 4em;
    width: 4em;
  }
  .svg-small {
    height: 2em;
    width: 2em;
  }
`;class yA extends bA{set config(e){tr(this._config,e)||(this._config=e,this.layoutConfig=e.layout)}renderShuffle(){if(this.hiddenElements.shuffle)return W``;const e=this.layoutConfig.icons.shuffle,t=e.size==uA.LARGE?"medium":"small",i=EA(e),r=CA(e,this.controller.translate("player.controls.shuffle")),A=this.layoutConfig.controls_layout==lA.COMPACT?"div-compact":"div-spaced",s=this._playerData.shuffle?"accent":"plain";return W`
      <div class="shuffle div-${t} ${A}">
        <ha-button
          appearance="${s}"
          variant="brand"
          @click=${this.onShuffle}
          size="${t}"
          class="icon-${t} ${e.box_shadow?"has-box-shadow":""} icon-${s}"
        >
          <ha-svg-icon
            ${i}
            .path=${this._playerData.shuffle?this.Icons.SHUFFLE:this.Icons.SHUFFLE_DISABLED}
            class="svg-${t}"
          ></ha-svg-icon>
          ${r}
        </ha-button>
      </div>
    `}renderPrevious(){const e=this.layoutConfig.icons.previous,t=e.size==uA.LARGE?"medium":"small",i=this.layoutConfig.controls_layout==lA.COMPACT?"div-compact":"div-spaced",r=EA(e),A=CA(e,this.controller.translate("player.controls.previous"));return W` <div class="track-previous div-${t} ${i}">
      <ha-button
        appearance="outlined"
        variant="brand"
        @click=${this.onPrevious}
        size="${t}"
        class="icon-${t} ${e.box_shadow?"has-box-shadow":""}"
      >
        <ha-svg-icon
          ${r}
          .path=${this.Icons.SKIP_PREVIOUS}
          class="svg-${t} icon-outlined"
        ></ha-svg-icon>
        ${A}
      </ha-button>
    </div>`}renderPlayPause(){const e=this.layoutConfig.icons.play_pause,t=e.size==uA.LARGE?"medium":"small",i=this.layoutConfig.controls_layout==lA.COMPACT?"div-compact":"div-spaced",r=EA(e),A=this._playerData.playing?"player.controls.play":"player.controls.pause",s=CA(e,this.controller.translate(A)),o=this._playerData.playing?"filled":"outlined";return W`
      <div class="play-pause div-${t} ${i}">
        <ha-button
          appearance="${o}"
          variant="brand"
          size="${t}"
          class="button-play-pause icon-${t} ${e.box_shadow?"has-box-shadow":""} icon-${o}"
          @click=${this.onPlayPause}
        >
          <ha-svg-icon
            ${r}
            .path=${this._playerData.playing?this.Icons.PAUSE:this.Icons.PLAY}
            class="svg-${t} icon-outlined"
          ></ha-svg-icon>
          ${s}
        </ha-button>
      </div>
    `}renderNext(){const e=this.layoutConfig.icons.next,t=e.size==uA.LARGE?"medium":"small",i=this.layoutConfig.controls_layout==lA.COMPACT?"div-compact":"div-spaced",r=EA(e),A=CA(e,this.controller.translate("player.controls.next"));return W`
      <div class="track-next div-${t} ${i}">
        <ha-button
          appearance="outlined"
          variant="brand"
          @click=${this.onNext}
          size="${t}"
          class="icon-${t} ${e.box_shadow?"has-box-shadow":""}"
          style="display: block;"
        >
          <ha-svg-icon
            ${r}
            .path=${this.Icons.SKIP_NEXT}
            class="svg-${t}"
          ></ha-svg-icon>
          ${A}
        </ha-button>
      </div>
    `}renderRepeat(){if(this.hiddenElements.repeat)return W``;const e=BA(this._playerData.repeat,this.Icons),t=this.layoutConfig.controls_layout==lA.COMPACT?"div-compact":"div-spaced",i=this.layoutConfig.icons.repeat,r=i.size==uA.LARGE?"medium":"small",A=EA(i),s=CA(i,this.controller.translate("player.controls.repeat")),o=this._playerData.repeat==jt.OFF?"accent":"plain";return W`
      <div class="repeat div-${r} ${t}">
        <ha-button
          appearance="${o}"
          variant="brand"
          size="${r}"
          class="icon-${r} ${i.box_shadow?"has-box-shadow":""} icon-${o}"
          @click=${this.onRepeat}
        >
          <ha-svg-icon
            ${A}
            .path=${e}
            class="svg-${r}"
          ></ha-svg-icon>
          ${s}
        </ha-button>
      </div>
    `}renderControlsLeft(){const e=this.layoutConfig,t=this.renderPrevious(),i=this.renderShuffle();return W`
      <div class="controls-left controls-${e.controls_layout}">
        ${e.controls_layout==lA.COMPACT?t:i}
        ${e.controls_layout==lA.COMPACT?i:t}
      </div>
    `}renderControlsRight(){const e=this.layoutConfig;return W`
      <div class="controls-right controls-${e.controls_layout}">
        ${this.renderNext()} ${this.renderRepeat()}
      </div>
    `}render(){return W`
      <div class="controls">
        ${this.renderControlsLeft()} ${this.renderPlayPause()}
        ${this.renderControlsRight()}
      </div>
    `}static get styles(){return IA}}e([n({context:Di,subscribe:!0}),De()],yA.prototype,"config",null),customElements.define("mass-player-controls",yA);var QA=g`
  :host {
    --lower-button-background-color: var(
      --md-sys-color-secondary-container
    ) !important;
    --lower-button-background-color-active: var(
      --md-sys-color-secondary
    ) !important;

    --lower-button-icon-color: var(--md-sys-color-on-secondary-container);
    --lower-button-icon-color-active: var(--md-sys-color-on-secondary);

    --lower-button-border-radius: 8px;
    --lower-button-start-border-radius: 24px 8px 8px 24px;
    --lower-button-end-border-radius: 8px 24px 24px 8px;
    --lower-button-only-border-radius: 24px 24px 24px 24px;

    --next-prev-background-color: var(
      --md-sys-color-secondary-container,
      var(--inherited-background-color, var(--ha-button-background-color))
    ) !important;
    --next-prev-icon-color: var(--md-sys-color-on-surface-variant);

    --next-prev-button-height: var(--play-pause-icon-height);
    --next-prev-button-width: 48px;
    --next-prev-icon-height: 48px;
    --next-border-radius: 36px 18px 18px 36px !important;
    --prev-border-radius: 18px 36px 36px 18px !important;

    --play-pause-icon-height: 64px;

    --play-background-color: var(
      --md-sys-color-primary,
      var(--inherited-background-color, var(--ha-button-background-color))
    ) !important;
    --pause-background-color: var(
      --md-sys-color-secondary-container,
      var(--inherited-background-color, var(--ha-button-background-color))
    ) !important;

    --play-icon-color: var(--md-sys-color-on-primary);
    --pause-icon-color: var(--md-sys-color-on-secondary-container);

    --play-pause-button-width: 96px;
    --play-pause-border-radius: 18px !important;
  }

  .button-lower::part(base) {
    --wa-color-fill-normal: var(--lower-button-background-color);
    --inherited-background-color: var(--lower-button-background-color);
    --ha-button-border-radius: var(--lower-button-border-radius);
    border-radius: var(--ha-button-border-radius);
    box-shadow: var(--md-sys-elevation-level1);
  }
  .button-lower::part(label) {
    color: var(--lower-button-icon-color);
    --inherited-text-color: var(--lower-button-icon-color);
  }

  .button-lower:first-of-type::part(base) {
    --ha-button-border-radius: var(--lower-button-start-border-radius);
    border-radius: var(--ha-button-border-radius);
  }
  .button-lower:last-of-type::part(base) {
    --ha-button-border-radius: var(--lower-button-end-border-radius);
    border-radius: var(--ha-button-border-radius);
  }
  .button-lower:only-of-type::part(base) {
    --ha-button-border-radius: var(
      --lower-button-only-border-radius
    ) !important;
    border-radius: var(--ha-button-border-radius);
  }

  .button-lower-active::part(base) {
    --wa-color-fill-normal: var(--lower-button-background-color-active);
    --inherited-background-color: var(--lower-button-background-color-active);
    --ha-button-border-radius: 20px;
  }
  .button-lower-active::part(label) {
    color: var(--lower-button-icon-color-active);
    --inherited-text-color: var(--lower-button-icon-color-active);
  }

  .button-next-previous::part(base) {
    height: var(--next-prev-button-height);
    width: var(--next-prev-button-width);
    --inherited-background-color: var(--next-prev-background-color);
    --wa-color-fill-normal: var(--next-prev-background-color);
    box-shadow: var(--md-sys-elevation-level1);
  }
  #button-next::part(base) {
    --ha-button-border-radius: var(--prev-border-radius);
    border-radius: var(--ha-button-border-radius);
  }
  #button-previous::part(base) {
    --ha-button-border-radius: var(--next-border-radius);
    border-radius: var(--ha-button-border-radius);
  }
  .button-play-pause::part(base) {
    height: var(--play-pause-icon-height);
    width: var(--play-pause-button-width);
    --ha-button-border-radius: var(--play-pause-border-radius);
    border-radius: var(--ha-button-border-radius);
    box-shadow: var(--md-sys-elevation-level2);
  }
  #button-play::part(base) {
    --wa-color-fill-normal: var(--play-background-color);
    --inherited-background-color: var(--play-background-color);
  }
  #button-pause::part(base) {
    --wa-color-fill-normal: var(--pause-background-color);
    --inherited-background-color: var(--pause-background-color);
  }

  #div-controls {
    container-name: controls;
    container-type: inline-size;
    row-gap: 6px;
    display: grid;
    margin-top: 12px;
    margin-bottom: 6px;
  }

  .icons-lower {
    height: var(--icon-height);
    width: var(--icon-height);
    color: var(--lower-button-icon-color);
  }
  .icons-lower-active {
    color: var(--lower-button-icon-color-active);
  }

  .icons-next-previous {
    color: var(--next-prev-icon-color);
    height: var(--next-prev-icon-height);
    width: var(--next-prev-icon-height);
  }
  .icon-play-pause {
    height: var(--play-pause-icon-height);
    width: var(--play-pause-icon-height);
  }
  #icon-play {
    color: var(--md-sys-color-on-primary);
  }
  #icon-pause {
    color: var(--md-sys-color-on-secondary-container);
  }

  .player-controls {
    justify-items: center;
  }
  #player-controls-lower {
    place-self: center;
    padding: 6px;
    border-radius: 24px;
    background-color: rgba(
      from var(--ha-card-background) r g b / 0.4
    ) !important;
  }
  #player-controls-upper {
    place-self: center;
    column-gap: 4px;
    margin-top: unset;
    row-gap: unset;
  }
  @container controls (width <= 30em) {
    #player-controls-lower {
      --md-sys-typescale-label-large-size: 10px;
      --icon-height: 16px;
    }
    .button-lower::part(label) {
      --md-sys-typescale-label-large-size: 10px;
      --icon-height: 16px;
    }
  }
  @container controls (width > 30em) {
    #player-controls-lower {
      --md-sys-typescale-label-large-size: 14px;
      --icon-height: 24px;
    }
    .button-lower::part(label) {
      --md-sys-typescale-label-large-size: 14px;
      --icon-height: 24px;
    }
  }
`;customElements.define("mass-player-controls-expressive",class extends bA{renderPrevious(){return W`
      <ha-button
        appearance="filled"
        variant="brand"
        @click=${this.onPrevious}
        size="medium"
        id="button-previous"
        class="button-next-previous"
      >
        <ha-svg-icon
          .path=${this.Icons.SKIP_PREVIOUS}
          class="icons-next-previous"
          id="icon-previous"
        ></ha-svg-icon>
      </ha-button>
    `}renderPlayPause(){const e=this.playing;return W`
      <ha-button
        appearance="filled"
        variant="brand"
        @click=${this.onPlayPause}
        size="medium"
        id="${e?"button-play":"button-pause"}"
        class="button-play-pause"
      >
        <ha-svg-icon
          .path=${e?this.Icons.PAUSE:this.Icons.PLAY}
          id="${e?"icon-play":"icon-pause"}"
          class="icon-play-pause"
        ></ha-svg-icon>
      </ha-button>
    `}renderNext(){return W`
      <ha-button
        appearance="filled"
        variant="brand"
        @click=${this.onNext}
        size="medium"
        id="button-next"
        class="button-next-previous"
      >
        <ha-svg-icon
          .path=${this.Icons.SKIP_NEXT}
          class="icons-next-previous"
          id="icon-previous"
        ></ha-svg-icon>
      </ha-button>
    `}renderPower(){return this.hiddenElements.power?W``:W`
      <ha-button
        appearance="filled"
        variant="brand"
        @click=${this.onPower}
        size="small"
        id="button-power"
        class="button-lower"
      >
        <ha-svg-icon
          slot="start"
          .path=${this.Icons.POWER}
          class="icons-power icons-lower"
        ></ha-svg-icon>
        ${this.controller.translate("player.controls.power")}
      </ha-button>
    `}renderShuffle(){if(this.hiddenElements.shuffle)return W``;const e=this.shuffle;return W`
      <ha-button
        appearance="filled"
        variant="brand"
        @click=${this.onShuffle}
        size="small"
        id="button-shuffle"
        class="button-lower ${e?"button-lower-active":""}"
      >
        <ha-svg-icon
          slot="start"
          .path=${e?this.Icons.SHUFFLE:this.Icons.SHUFFLE_DISABLED}
          class="icons-shuffle icons-lower${e?"-active":""}"
        ></ha-svg-icon>
        ${this.controller.translate("player.controls.shuffle")}
      </ha-button>
    `}renderRepeat(){if(this.hiddenElements.repeat)return W``;const e=this.repeat,t=e!=jt.OFF,i=BA(e,this.Icons);return W`
      <ha-button
        appearance="filled"
        variant="brand"
        @click=${this.onRepeat}
        size="small"
        id="button-repeat"
        class="button-lower ${t?"button-lower-active":""}"
      >
        <ha-svg-icon
          slot="start"
          .path=${i}
          class="icons-repeat icons-lower${t?"-active":""}"
        ></ha-svg-icon>
        ${this.controller.translate("player.controls.repeat")}
      </ha-button>
    `}renderFavorite(){if(this.hiddenElements.favorite)return W``;const e=this.favorite;return W`
      <ha-button
        appearance="filled"
        variant="brand"
        @click=${this.onFavorite}
        size="small"
        id="button-favorite"
        class="button-lower ${e?"button-lower-active":""}"
      >
        <ha-svg-icon
          slot="start"
          .path=${e?this.Icons.HEART:this.Icons.HEART_PLUS}
          class="icons-favorite icons-lower${e?"-active":""}"
        ></ha-svg-icon>
        ${this.controller.translate("player.controls.favorite")}
      </ha-button>
    `}renderUpperControls(){return W`
      <div id="player-controls-upper" class="player-controls">
        ${this.renderPrevious()} ${this.renderPlayPause()} ${this.renderNext()}
      </div>
    `}renderLowerControls(){const e=this.hiddenElements;return e.power&&e.shuffle&&e.repeat&&e.favorite?W``:W`
      <div
        id="player-controls-lower"
        class="player-controls"
      >
          ${this.renderPower()}
          ${this.renderShuffle()}
          ${this.renderRepeat()}
          ${this.renderFavorite()}
        </nav>
      </div>
    `}render(){return W`
      <link
        href="https://cdn.jsdelivr.net/npm/beercss@3.12.11/dist/cdn/beer.min.css"
        rel="stylesheet"
      />
      <div id="div-controls">
        ${this.renderUpperControls()} ${this.renderLowerControls()}
      </div>
    `}static get styles(){return QA}});var DA=g`
  .button-min {
    height: 40px;
    width: 40px;
    --wa-color-fill-quiet: rgba(from var(--md-sys-color-primary) r g b / 0.1);
  }
  .button-min::part(base) {
    --wa-form-control-padding-inline: 0px;
  }

  #button-favorite {
    margin-left: 1em;
  }
  #button-mute {
    margin-left: 1em;
  }
  #button-power {
    margin-right: 1em;
  }

  #div-slider {
    width: 100%;
    height: var(--player-volume-slider-height);
    position: relative;
  }

  .svg-plain {
    color: var(--md-sys-color-primary);
    height: 3em;
    width: 3em;
  }

  #ticks {
    height: var(--player-volume-slider-height);
    width: inherit;
    position: absolute;
    display: flex;
    justify-content: space-evenly;
    top: 0;
    align-items: center;
    pointer-events: none;
  }
  .tick {
    width: 1%;
    aspect-ratio: 1;
    display: inline-flex;
    flex-direction: row;
    vertical-align: bottom;
    position: relative;
    height: max-content;
    border-radius: 50%;
  }
  .tick-in {
    background-color: var(--md-sys-color-on-primary);
  }
  .tick-out {
    background-color: var(--md-sys-color-on-primary-container);
  }

  #volume {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-evenly;
    padding-left: 2em;
    padding-right: 2em;
  }

  #volume-slider {
    --control-slider-thickness: 2.25em;
    border-radius: 10px;
    --disabled-color: var(--control-slider-color);
    height: var(--player-volume-slider-height);
  }
  .volume-slider-expressive {
    --control-slider-color: var(--md-sys-color-primary);
    box-shadow: var(--md-sys-elevation-level1);
  }
`;class RA extends ve{constructor(){super(...arguments),this.hide=hA,this.onToggle=async()=>{await this.actions.actionTogglePower()},this.onVolumeMuteToggle=async()=>{await this.actions.actionToggleMute()},this.onVolume=async e=>{let t=e.detail.value;isNaN(t)||(this.player_data.volume=t,t/=100,this.requestUpdate("volume",this.player_data.volume),await this.actions.actionSetVolume(t))},this.onFavorite=async()=>{this.player_data.favorite?await this.actions.actionRemoveFavorite():await this.actions.actionAddFavorite()}}set config(e){tr(this._config,e)||(this._config=e,this._config&&this._entityConfig&&this.updateHiddenElements())}get config(){return this._config}set entityConfig(e){tr(this._entityConfig,e)||(this._entityConfig=e,this.maxVolume=e.max_volume,this._config&&this._entityConfig&&this.updateHiddenElements())}get entityConfig(){return this._entityConfig}set player_data(e){tr(this._player_data,e)||(this._player_data=e)}get player_data(){return this._player_data}updateHiddenElements(){const e=this.entityConfig.hide.player,t=this.config.hide,i=this.controller.config.expressive;this.hide={favorite:e.favorite||t.favorite||i,mute:e.mute||t.mute,power:e.power||t.power||i,volume:e.volume||t.volume,player_selector:!1,repeat:!1,shuffle:!1,group_volume:!1}}renderPower(){return this.hide.power?W``:W`
      <ha-button
        appearance="plain"
        variant="brand"
        size="medium"
        id="button-power"
        class="button-min"
        part="button-power"
        @click=${this.onToggle}
      >
        <ha-svg-icon .path=${this.Icons.POWER} class="svg-plain"></ha-svg-icon>
      </ha-button>
    `}renderMute(){return this.hide.mute?W``:W`
      <ha-button
        appearance="plain"
        variant="brand"
        size="medium"
        id="button-mute"
        class="button-min"
        part="button-mute"
        @click=${this.onVolumeMuteToggle}
      >
        <ha-svg-icon
          .path=${this.player_data.muted?this.Icons.VOLUME_MUTE:this.Icons.VOLUME_HIGH}
          class="svg-plain"
        ></ha-svg-icon>
      </ha-button>
    `}renderFavorite(){return this.hide.favorite?W``:W`
      <ha-button
        appearance="plain"
        variant="brand"
        size="medium"
        id="button-favorite"
        class="button-min"
        part="button-favorite"
        @click=${this.onFavorite}
      >
        <ha-svg-icon
          .path=${this.player_data.favorite?this.Icons.HEART:this.Icons.HEART_PLUS}
          class="svg-plain"
        ></ha-svg-icon>
      </ha-button>
    `}renderTicks(){if(!this.controller.config.expressive)return;const e=[...Array(19).keys()],t=this.player_data.volume;return W`
      <div id="ticks">
        ${e.map(e=>{const i=100*(e+1)/20;return W`
            <div
              class="tick tick-${i<=t?"in":"out"}"
              value=${i}
              tick=${e}
            ></div>
          `})}
      </div>
    `}renderVolumeBar(){return this.hide.volume?W``:W`
      <div id="div-slider">
        <ha-control-slider
          .unit="%"
          .value=${this.player_data.volume}
          .min="0"
          .max=${this.maxVolume}
          @value-changed=${this.onVolume}
          id="volume-slider"
          class="${this.controller.ActivePlayer.useExpressive?"volume-slider-expressive":""}"
          part="volume-slider"
        ></ha-control-slider>
        ${this.renderTicks()}
      </div>
    `}render(){return W`
      <div id="volume" part="volume-div">
        ${this.renderPower()} ${this.renderVolumeBar()} ${this.renderMute()}
        ${this.renderFavorite()}
      </div>
    `}shouldUpdate(e){return e.size>0||!this._initialUpdate}firstUpdated(){this._initialUpdate=!0}static get styles(){return DA}}e([n({context:Oi})],RA.prototype,"controller",void 0),e([n({context:Ji})],RA.prototype,"Icons",void 0),e([De()],RA.prototype,"_player_data",void 0),e([n({context:Si,subscribe:!0})],RA.prototype,"actions",void 0),e([n({context:Di,subscribe:!0})],RA.prototype,"config",null),e([n({context:mi,subscribe:!0})],RA.prototype,"entityConfig",null),e([n({context:Bi,subscribe:!0})],RA.prototype,"player_data",null),customElements.define("mass-volume-row",RA);class kA{constructor(e){this.hass=e}set hass(e){e&&(this._hass=e)}get hass(){return this._hass}async actionPlayPause(e){try{await this.hass.callService("media_player","media_play_pause",{entity_id:e.entity_id})}catch(e){console.error("Error calling play/pause",e)}}async actionMuteToggle(e){const t=undefined,i=!this.hass.states[e.entity_id].attributes.is_volume_muted;try{await this.hass.callService("media_player","volume_mute",{entity_id:e.entity_id,is_volume_muted:i})}catch(t){console.error("Error calling mute",t)}}async actionNext(e){try{await this.hass.callService("media_player","media_next_track",{entity_id:e.entity_id})}catch(e){console.error("Error calling play next",e)}}async actionPrevious(e){try{await this.hass.callService("media_player","media_previous_track",{entity_id:e.entity_id})}catch(e){console.error("Error calling play previous",e)}}async actionShuffleToggle(e){const t=!e.attributes.shuffle;try{await this.hass.callService("media_player","shuffle_set",{entity_id:e.entity_id,shuffle:t})}catch(e){console.error("Error calling shuffle",e)}}async actionRepeatSet(e,t){try{await this.hass.callService("media_player","repeat_set",{entity_id:e.entity_id,repeat:t})}catch(e){console.error("Error calling repeat",e)}}async actionSetVolume(e,t){try{await this.hass.callService("media_player","volume_set",{entity_id:e.entity_id,volume_level:t})}catch(e){console.error("Error setting volume",e)}}async actionSeek(e,t){try{await this.hass.callService("media_player","media_seek",{entity_id:e.entity_id,seek_position:t})}catch(e){console.error("Error calling repeat",e)}}async actionTogglePlayer(e){try{await this.hass.callService("media_player","toggle",{entity_id:e.entity_id})}catch(e){console.error("Error calling repeat",e)}}async actionGetCurrentItem(e){return(await this.hass.callWS({type:"call_service",domain:"mass_queue",service:"get_queue_items",service_data:{entity:e.entity_id,limit_before:1,limit_after:1},return_response:!0})).response[e.entity_id].find(t=>t.media_content_id==e.attributes.media_content_id)}async actionAddFavorite(e){const t=this.hass.entities[e.entity_id].device_id;try{await this.hass.callService("button","press",{device_id:t})}catch(e){console.error("Error setting favorite",e)}}async actionRemoveFavorite(e){try{await this.hass.callService("mass_queue","unfavorite_current_item",{entity:e.entity_id})}catch(e){console.error("Error unfavoriting item for entity.",e)}}async actionUnjoinPlayers(e){try{await this.hass.callService("media_player","unjoin",{entity_id:e})}catch(e){console.error("Error unjoining players",e)}}}var xA=g`
  ha-control-slider {
    --control-slider-thickness: 2.25em;
    --control-slider-color: var(--md-sys-color-primary) !important;
  }

  #button-power {
    margin-right: 1em;
  }
  #button-mute,
  #button-favorite {
    margin-left: 1em;
  }

  #volume {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-evenly;
    padding-left: 2em;
    padding-right: 2em;
  }
`;class PA extends ve{constructor(){super(...arguments),this.maxVolume=100,this.onVolumeChange=async e=>{let t=e.detail.value;t/=100,this.requestUpdate("volume",t),await this._actions.actionSetVolume(this.entity,t)}}set entityId(e){this._entityId=e,this.hass&&(this.entity=this.hass.states[e])}get entityId(){return this._entityId}set hass(e){this._hass=e,this._actions=new kA(e),this.entity=e.states[this.entityId]}get hass(){return this._hass}render(){return W`
      <ha-control-slider
        part="slider"
        style="--control-slider-color: var(--md-sys-color-primary) !important;"
        .disabled=${this.entity.attributes.is_volume_muted}
        .unit="%"
        .value=${100*this.entity.attributes.volume_level}
        .min="0"
        .max=${this.maxVolume}
        @value-changed=${this.onVolumeChange}
      ></ha-control-slider>
    `}shouldUpdate(e){return e.size>0}styles(){return xA}}e([Qe({attribute:!1})],PA.prototype,"maxVolume",void 0),e([De()],PA.prototype,"entity",void 0),e([Qe({attribute:!1})],PA.prototype,"entityId",null),e([n({context:vi,subscribe:!0})],PA.prototype,"hass",null),customElements.define("mass-volume-slider",PA);var MA=g`
  *[hide] {
    display: none;
  }

  *[background] {
    background-color: rgba(var(--player-blur-color), 0.9);
    border-radius: 10px;
  }

  mass-artwork {
    display: flex;
    justify-content: center;
  }

  #active-track-lg {
    width: 100%;
  }
  #active-track-med {
    width: 100%;
  }
  #active-track-sm {
    width: 100%;
  }

  #active-track-text {
    z-index: 0;
    transform: translate3d(0, 0, -1px);
    -webkit-transform: translate3d(0, 0, -1px);
    position: relative;
  }
  .active-track-text-expressive {
  }
  .active-track-text-rounded {
    border-radius: 8px 8px 0px 0px;
  }

  .bg-art-lg {
    z-index: 1;
  }
  .bg-art-med {
  }
  .bg-art-sm {
  }

  #container {
    height: var(--mass-player-card-height);
  }
  .container-expressive {
    border-radius: var(--expressive-border-radius-container);
  }

  .controls-art-lg {
  }
  .controls-art-med {
  }
  .controls-art-sm {
  }

  .divider {
    margin-top: 4px;
  }
  .divider::before {
    content: " ";
    display: block;
    height: 1px;
    background-color: var(--divider-color);
    margin-left: 8px;
    margin-right: 8px;
  }

  .header-art-lg {
    z-index: 2;
    position: relative;
  }
  .header-art-lg::part(header) {
    z-index: 0;
  }
  .header-art-med {
  }
  .header-art-sm {
    position: relative;
  }

  #grouped-players-menu {
    --control-select-thickness: 2.5em;
    max-width: var(--control-select-menu-height);
  }

  .grouped-players-item {
    height: calc(var(--control-select-menu-height) * 2);
    display: contents;
  }

  .grouped-players-volume-slider {
    display: contents;
  }
  #grouped-volume,
  .grouped-players-volume-slider::part(slider) {
    position: relative;
    width: 96%;
    left: 2%;
    height: 2.5em;
  }
  .grouped-button-unjoin {
    width: var(--media-row-icon-width);
    align-content: center;
  }
  .grouped-button-unjoin::part(base) {
    height: 30px;
    width: 30px;
    border-radius: 25%;
    --wa-form-control-padding-inline: 0px;
  }
  .grouped-button-unjoin-expressive::part(base) {
    box-shadow: var(--md-sys-elevation-level1);
    --ha-button-border-radius: var(--button-small-border-radius) !important;
    background-color: var(--expressive-row-button-color);
    --inherited-background-color: var(--expressive-row-button-color);
  }
  .grouped-button-unjoin-expressive::part(base):hover {
    background-color: var(--expressive-row-button-color-hover) !important;
    --inherited-background-color: var(
      --expressive-row-button-color-hover
    ) !important;
    box-shadow: var(--md-sys-elevation-level1);
    --ha-button-border-radius: var(--button-small-border-radius) !important;
  }

  .grouped-button-unjoin-expressive > .title {
    color: var(--expressive-row-color-text);
  }
  .grouped-svg-unjoin {
    height: var(--row-icon-button-height);
    width: var(--row-icon-button-height);
  }
  .grouped-svg-unjoin-expressive {
    color: var(--expressive-row-button-color-text);
  }
  .grouped-svg-unjoin-expressive:hover {
    color: var(--expressive-row-button-color-text-hover);
  }

  .marquee-pause-end {
    left: var(--marquee-left-offset);
    position: relative;
  }
  .marquee {
    animation: marquee var(--marquee-time) linear 2s;
    animation-iteration-count: infinite;
    position: relative;
  }

  .media-controls {
    backdrop-filter: blur(3px);
    background: var(--player-blur-color);
    position: absolute;
    bottom: 0;
    width: 100%;
  }

  .media-controls:not(.media-controls-expressive) {
    background: linear-gradient(
      transparent,
      var(--player-blur-color) 10%
    ) !important;
  }
  .media-controls-expressive {
    background: linear-gradient(
      transparent,
      var(--expressive-player-blur-color) 10%
    ) !important;
  }

  .menu-header::part(menu-select-menu) {
    border-radius: 50%;
    height: 2.5em;
    width: 2.5em;
    --control-select-menu-padding: 7px;
    --mdc-icon-size: 1.5em;
    --control-select-menu-height: 2.5em;
  }
  .menu-header-expressive::part(menu-select-menu) {
    --control-select-menu-background-color: var(
      --md-sys-color-secondary-container
    ) !important;
    box-shadow: var(--md-sys-elevation-level1);
    border-radius: var(--button-small-border-radius);
  }
  .menu-header-expressive::part(menu-svg) {
    color: var(--md-sys-color-secondary-on-container) !important;
  }

  #player-card {
    z-index: 0;
    height: var(--mass-player-card-height);
    background-repeat: no-repeat;
    background-position: center;
    background-size: 22em;
    position: relative;
  }
  .player-card-expressive {
    background-color: var(--md-sys-color-background);
    border-radius: 8px 8px 0px 0px;
  }
  #player-card-header {
    position: absolute;
    top: 0;
    width: 100%;
    z-index: 1;
    border-radius: var(--default-border-radius) var(--default-border-radius) 0px
      0px;
  }
  .player-card-header {
    background: linear-gradient(
      var(--player-blur-color) 90%,
      transparent
    ) !important;
  }
  .player-card-header-expressive {
    background: linear-gradient(
      var(--expressive-player-blur-color) 90%,
      transparent
    ) !important;
  }
  .player-card-header,
  .player-card-header-expressive {
    backdrop-filter: blur(3px);
  }
  .player-header {
    margin: 0em 1.75em 0em 1.75em;
    text-align: center;
    overflow: hidden;
    height: 5em;
  }

  .player-name {
    font-size: 0.8rem;
    color: var(--player-name-color);
  }
  .player-name-expressive {
    color: var(--md-sys-color-on-primary-container) !important;
  }

  .grouped-players-select-item,
  #players-select-menu::part(menu-list-item) {
    height: 3.5em;
  }
  .grouped-players-select-item {
    width: 320px;
  }
  .players-select-item-icon,
  .grouped-players-select-item-icon {
    height: 2em;
    width: 2em;
    color: var(--md-sys-color-primary);
  }
  #players-select-menu,
  #grouped-players-menu {
    --control-select-menu-height: 2.5em;
  }

  .player-track-artist {
    font-size: 1em;
    text-shadow: 0 0 var(--md-sys-color-on-primary-container);
  }
  .player-track-artist-expressive {
    font-size: 1em;
    color: var(--md-sys-color-on-primary-container) !important;
  }
  .player-track-title {
    font-size: 1.5rem;
    color: var(--player-track-color, var(--md-sys-color-primary));
    white-space: nowrap;
    text-overflow: clip;
    text-shadow: 0px 0px var(--md-sys-color-primary);
  }

  #players-select-menu::part(menu-button),
  #grouped-players-menu::part(menu-button) {
    --ha-ripple-color: rgba(0, 0, 0, 0);
  }
  #players-select-menu::part(menu-list-item) {
  }
  #players-select-menu::part(menu-list-item-svg) {
    height: 2em;
    width: 2em;
  }
  .menu-header::part(menu-select-menu) {
    background-color: var(--control-select-menu-background-color);
  }
  .menu-header::part(menu-svg):not(.svg-menu-expressive) {
    color: var(--wa-color-brand-on-normal, var(--wa-color-neutral-on-normal));
    border-radius: 50%;
  }

  #volume {
    width: 100%;
  }

  .volume-expressive::part(volume-div) {
    padding-bottom: 6px;
    position: relative;
  }

  .vol-art-lg {
    z-index: 1;
    position: relative;
  }
  .vol-art-lg::part(volume-div) {
    z-index: 0;
  }
  .vol-art-med {
  }
  .vol-art-sm {
  }

  @keyframes marquee {
    from {
      left: 0px;
    }
    to {
      left: var(--marquee-left-offset);
    }
  }
`;class HA extends ve{constructor(){super(...arguments),this._firstLoaded=!1,this.onForceLoadEvent=e=>{const t=e,i=t.detail.key,r=t.detail.value;this.forceUpdatePlayerDataValue(i,r)},this.onPlayerSelect=e=>{e.stopPropagation();const t=e.target,i=t.value;i.length&&(this.selectedPlayerService(i),t.value="")},this.onUnjoinSelect=e=>{const t=e?.target?.entity;e&&this.actions.actionUnjoinPlayers(t)},this.onGroupVolumeChange=e=>{const t=e.detail.value;this.activePlayerController.setActiveGroupVolume(t)},this.delayedUpdatePlayerData=()=>{setTimeout(()=>{this.updatePlayerData()},2e3)}}set activeEntityConfig(e){this._activeEntityConfig=e}get activeEntityConfig(){return this._activeEntityConfig}get activeMediaPlayer(){return this?.activePlayerController?.activeMediaPlayer}set activeEntity(e){$i(this._activeEntity,e)&&(this._activeEntity=e,this.updatePlayerData())}get activeEntity(){return this._activeEntity}set hass(e){e&&(this.actions=new kA(e));const t=!!this._hass;this._hass=e,t||this.updatePlayerData()}get hass(){return this._hass}set config(e){if(!tr(this._config,e))switch(this._config=e,e.layout.artwork_size){case dA.LARGE:this._artworkHeaderClass="header-art-lg",this._artworkProgressClass="bg-art-lg",this._artworkVolumeClass="vol-art-lg",this._artworkMediaControlsClass="controls-art-lg",this._artworkActiveTrackClass="active-track-lg";break;case dA.MEDIUM:this._artworkHeaderClass="header-art-med",this._artworkProgressClass="bg-art-med",this._artworkVolumeClass="vol-art-med",this._artworkMediaControlsClass="controls-art-med",this._artworkActiveTrackClass="active-track-med";break;case dA.SMALL:this._artworkHeaderClass="header-art-sm",this._artworkProgressClass="bg-art-sm",this._artworkVolumeClass="vol-art-sm",this._artworkMediaControlsClass="controls-art-sm",this._artworkActiveTrackClass="active-track-sm"}}get config(){return this._config}async _getGroupedVolume(){this.activePlayerController&&(this.groupVolumeLevel=await this.activePlayerController.getActiveGroupVolume())}set activePlayerController(e){e&&(this._activePlayerController=e,this.player_data||this.updatePlayerData(),this.groupVolumeLevel||this._getGroupedVolume())}get activePlayerController(){return this._activePlayerController}set groupVolumeLevel(e){e!=this._groupVolumeLevel&&(this._groupVolumeLevel=e)}get groupVolumeLevel(){return this._groupVolumeLevel}set groupedPlayersList(e){const t=this.playerEntities.filter(t=>e?.includes(t.entity_id));tr(this._groupedPlayers,t)||(this._groupedPlayers=t)}get groupedPlayers(){return this._groupedPlayers}updatePlayerData(){this.hass&&this._updatePlayerData().catch(()=>{})}async _updatePlayerData(){if(!this.activeMediaPlayer)return;const e=await this.actions.actionGetCurrentItem(this.activeMediaPlayer),t=this.activePlayerController.getactivePlayerData(e);tr(this.player_data,t)||(this.player_data=t)}forceUpdatePlayerDataValue(e,t){const i=this.player_data;Object.keys(i).includes(e)&&(i[e]=t,this.player_data={...i})}wrapTitleMarquee(){const e=`${this.player_data.track_title} - ${this.player_data.track_album}`;return Be`
      <ha-marquee-text class="player-track-title marquee">
        ${e}
      </ha-marquee-text>
    `}renderPlayerName(){return Be`
      <div
        class="player-name ${this.cardConfig.expressive?"player-name-expressive":""}"
      >
        ${this.player_data?.player_name??this.activePlayerController.activePlayerName}
      </div>
    `}renderTitle(){return er(this.hass,this.activeMediaPlayer,this.activeEntityConfig)?this.wrapTitleMarquee():Be`
        <div class="player-track-title">
          ${this.controller.translate("player.title.inactive")}
        </div>
      `}renderGroupedVolume(){const e=this._groupVolumeLevel;return Be`
      <div class="grouped-players-item grouped-volume">
        <div class="player-name-icon">
          <ha-md-list-item
            class="grouped-players-select-item"
            .graphic=${this.Icons.SPEAKER_MULTIPLE}
            noninteractive
            hide-label
          >
            <ha-svg-icon
              class="grouped-players-select-item-icon"
              slot="start"
              .path=${this.Icons.SPEAKER_MULTIPLE}
            ></ha-svg-icon>
            <ha-control-slider
              part="slider"
              style="--control-slider-color: var(--md-sys-color-primary) !important"
              id="grouped-volume"
              .unit="%"
              .min="0"
              .max="100"
              .value=${e}
              @value-changed=${this.onGroupVolumeChange}
            ></ha-control-slider>
          </ha-md-list-item>
        </div>
        <div class="divider"></div>
      </div>
    `}renderGroupedPlayers(){const e=this.groupedPlayers.length,t=this.cardConfig.expressive;return this.groupedPlayers.map((i,r)=>{const A=i.name.length>0?i.name:this.hass.states[i.entity_id].attributes.friendly_name;return Be`
        <div class="grouped-players-item">
          <div class="player-name-icon">
            <ha-md-list-item
              class="grouped-players-select-item"
              .graphic=${this.Icons.SPEAKER}
              noninteractive
              hide-label
            >
              <ha-svg-icon
                class="grouped-players-select-item-icon"
                slot="start"
                .path=${this.Icons.SPEAKER}
              ></ha-svg-icon>
              <span slot="headline" class="grouped-title"> ${A} </span>
              <span slot="end">
                <ha-button
                  appearance="plain"
                  variant="brand"
                  size="medium"
                  class="grouped-button-unjoin ${t?"grouped-button-unjoin-expressive":""}"
                  @click=${this.onUnjoinSelect}
                >
                  <ha-svg-icon
                    .path=${this.Icons.LINK_OFF}
                    class="grouped-svg-unjoin ${t?"grouped-svg-unjoin-expressive":""}"
                    .entity="${i.entity_id}"
                  ></ha-svg-icon>
                </ha-button>
              </span>
            </ha-md-list-item>
          </div>
          <ha-md-list-item>
            <mass-volume-slider
              class="grouped-players-volume-slider"
              maxVolume=${i.max_volume}
              .entityId=${i.volume_entity_id}
            ></mass-volume-slider>
          </ha-md-list-item>
          ${r<e-1?Be`<div class="divider"></div>`:""}
        </div>
      `})}renderGrouped(){const e=this.config.hide.group_volume||this.activeEntityConfig.hide.player.group_volume;return this?.groupedPlayers?.length>1&&!e?Be`
        <mass-menu-button
          slot="end"
          id="grouped-players-menu"
          class="menu-header ${this.cardConfig.expressive?"menu-header-expressive":""}"
          .iconPath=${this.Icons.SPEAKER_MULTIPLE}
          naturalMenuWidth
        >
          ${this.renderGroupedVolume()} ${this.renderGroupedPlayers()}
        </mass-menu-button>
      `:Be``}renderArtist(){if(!er(this.hass,this.activeMediaPlayer,this.activeEntityConfig)){const e=this.controller.translate("player.messages.inactive"),t=Math.floor(Math.random()*e.length);return Be`
        <div
          class="player-track-artist ${this.cardConfig.expressive?"player-track-artist-expressive":""}"
        >
          ${e[t]}
        </div>
        ;
      `}return Be` <div
      class="player-track-artist ${this.cardConfig.expressive?"player-track-artist-expressive":""}"
    >
      ${this.player_data.track_artist}
    </div>`}renderPlayerItems(){return this.playerEntities.map(e=>{const t=e.name.length>0?e.name:this.hass.states[e.entity_id].attributes.friendly_name;return{option:e.entity_id,icon:this.Icons.SPEAKER,title:t??e.name}})}renderSectionTitle(){const e=this.controller.translate("player.header");return Be` <span slot="label">${e}</span> `}renderHeader(){const e=this.cardConfig.expressive;return Be`
      <div
        id="player-card-header"
        class="player-card-header${e?"-expressive":""}"
      >
        <mass-section-header
          class="${this._artworkHeaderClass} ${this.cardConfig.expressive?"header-expressive":""}"
        >
          ${this.renderPlayerSelector()} ${this.renderSectionTitle()}
          ${this.renderGrouped()}
        </mass-section-header>
        ${this.renderActiveItemSection()}
      </div>
    `}renderPlayerSelector(){const e=this.config.hide.player_selector,t=this.activeEntityConfig.hide.player.player_selector;return e||t?Be``:Be`
      <span slot="start">
        <mass-menu-button
          id="players-select-menu"
          class="menu-header ${this.cardConfig.expressive?"menu-header-expressive":""}"
          .iconPath=${this.Icons.SPEAKER}
          .onSelectAction=${this.onPlayerSelect}
          .initialSelection=${this.activeEntity.entity_id}
          .items=${this.renderPlayerItems()}
        ></mass-menu-button>
      </span>
    `}renderActiveItemSection(){return Be`
      <div id="${this._artworkActiveTrackClass}">
        <div
          id="active-track-text"
          class="${this.cardConfig.expressive?"active-track-text-expressive":""} ${this.config.layout.artwork_size!=dA.LARGE?"active-track-text-rounded":""}"
        >
          ${this.renderPlayerHeader()} ${this.renderProgress()}
        </div>
      </div>
    `}renderPlayerHeader(){return Be`
      <div class="player-header">
        ${this.renderPlayerName()} ${this.renderTitle()} ${this.renderArtist()}
      </div>
    `}renderProgress(){return Be`
      <mass-progress-bar
        class="${this._artworkProgressClass}"
        style="${er(this.hass,this.activeMediaPlayer,this.activeEntityConfig)?"":"opacity: 0;"}"
      ></mass-progress-bar>
    `}renderArtwork(){return Be` <mass-artwork></mass-artwork> `}renderVolumeRow(){return Be`
      <div id="volume">
        <mass-volume-row
          class="${this._artworkVolumeClass} ${this.cardConfig.expressive?"volume-expressive":""}"
        ></mass-volume-row>
      </div>
    `}renderControls(){return Be`
      <div
        class="media-controls ${this._artworkMediaControlsClass} ${this.cardConfig.expressive?"media-controls-expressive":""}"
      >
        ${this?.cardConfig?.expressive?Be`<mass-player-controls-expressive></mass-player-controls-expressive>`:Be`<mass-player-controls></mass-player-controls>`}
        ${this.renderVolumeRow()}
      </div>
    `}render(){const e=this.cardConfig.expressive;return Be`
      <div id="container" class="${e?"container-expressive":""}">
        ${this.renderHeader()}
        <wa-animation
          id="animation"
          name="fadeIn"
          easing="ease-in"
          iterations="1"
          play=${this.checkVisibility()}
          playback-rate="4"
        >
          <div
            id="player-card"
            class="${e?"player-card-expressive":""}"
          >
            ${this.renderArtwork()} ${this.renderControls()}
          </div>
        </wa-animation>
      </div>
    `}connectedCallback(){super.connectedCallback(),this._firstLoaded&&this.updatePlayerData()}disconnectedCallback(){super.disconnectedCallback()}firstUpdated(){this._firstLoaded=!0,this.controller.host.addEventListener("request-player-data-update",this.delayedUpdatePlayerData),this.controller.host.addEventListener("force-update-player",this.onForceLoadEvent),this.controller.host.addEventListener("active-player-updated",()=>{this.updatePlayerData()})}shouldUpdate(e){return!(!this.player_data||!e.size)&&super.shouldUpdate(e)}static get styles(){return MA}}e([n({context:Ji})],HA.prototype,"Icons",void 0),e([n({context:Qi,subscribe:!0})],HA.prototype,"playerEntities",void 0),e([n({context:yi,subscribe:!0})],HA.prototype,"cardConfig",void 0),e([n({context:Oi,subscribe:!0})],HA.prototype,"controller",void 0),e([o({context:Bi}),De()],HA.prototype,"player_data",void 0),e([De()],HA.prototype,"_groupVolumeLevel",void 0),e([De()],HA.prototype,"_activePlayerController",void 0),e([n({context:mi,subscribe:!0})],HA.prototype,"activeEntityConfig",null),e([n({context:Ei,subscribe:!0}),De()],HA.prototype,"activeEntity",null),e([n({context:vi,subscribe:!0})],HA.prototype,"hass",null),e([n({context:Di,subscribe:!0})],HA.prototype,"config",null),e([n({context:Hi,subscribe:!0})],HA.prototype,"activePlayerController",null),e([n({context:Ii,subscribe:!0})],HA.prototype,"groupVolumeLevel",null),e([n({context:bi,subscribe:!0})],HA.prototype,"groupedPlayersList",null),customElements.define("mass-music-player-card",HA);var SA=g`
  .action-button {
    width: var(--media-row-icon-width);
    align-content: center;
  }
  .action-button::part(base) {
    height: 30px;
    width: 30px;
    border-radius: 25%;
    --wa-form-control-padding-inline: 0px;
  }
  .action-button-expressive::part(base) {
    box-shadow: var(--md-sys-elevation-level1);
    --ha-button-border-radius: var(--button-small-border-radius) !important;
    background-color: var(--expressive-row-button-color);
    --inherited-background-color: var(--expressive-row-button-color);
  }
  .action-button-expressive::part(base):hover {
    background-color: var(--expressive-row-button-color-hover) !important;
    --inherited-background-color: var(
      --expressive-row-button-color-hover
    ) !important;
    box-shadow: var(--md-sys-elevation-level1);
    --ha-button-border-radius: var(--button-small-border-radius) !important;
  }

  .button {
    margin: 0.15rem;
    border-radius: --media-row-border-radius;
    background: var(--media-row-background-color);
    height: var(--media-row-height);
  }
  .button-active {
    margin: 0.15rem;
    border-radius: --media-row-border-radius;
    background-color: var(
      --media-row-active-background-color,
      var(--md-sys-color-secondary-container)
    );
    height: var(--media-row-height);
    padding-inline-start: 0px;
    padding-inline-end: 8px;
    color: var(--accent-color);
  }
  .button-active :host {
    --md-sys-color-primary: unset;
  }

  .button-expressive {
    background-color: var(--expressive-row-color) !important;
  }
  .button-expressive > .title {
    color: var(--expressive-row-color-text);
  }

  .button-expressive-active {
    --primary-text-color: var(--expressive-row-active-color-text) !important;
    --font-color: var(--expressive-row-active-color-text) !important;
    background-color: var(--expressive-row-active-color) !important;
  }
  .button-expressive-active > .title {
    color: var(--expressive-row-active-color-text);
  }

  .button-group {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: flex-end;
    gap: 8px;
    height: 48px;
    right: 0;
    padding-right: 16px;
    position: absolute;
  }

  .divider::before {
    content: " ";
    display: block;
    height: 1px;
    background-color: var(--divider-color);
    margin-left: 8px;
    margin-right: 8px;
  }

  .svg-action-button {
    height: var(--row-icon-button-height);
    width: var(--row-icon-button-height);
  }
  .svg-action-button-expressive {
    color: var(--expressive-row-button-color-text);
  }
  .svg-action-button-expressive:hover {
    color: var(--expressive-row-button-color-text-hover);
  }

  .thumbnail {
    width: var(--media-row-thumbnail-height);
    height: var(--media-row-thumbnail-height);
    background-size: contain;
    background-repeat: no-repeat;
    background-position: left;
    border-radius: var(--media-row-border-radius);
  }
  .thumbnail-disabled {
    width: var(--media-row-thumbnail-height);
    height: var(--media-row-thumbnail-height);
    background-size: contain;
    background-repeat: no-repeat;
    background-position: left;
    border-radius: var(--media-row-border-radius);
    filter: opacity(0.5);
  }

  .title {
    font-size: 1.1rem;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    min-width: 0;
    color: var(--font-color);
  }
`;const OA={action_buttons:!1,move_down_button:!1,move_next_button:!1,move_up_button:!1,remove_button:!1,album_covers:!1,artist_names:!1},qA={enabled:!0,limit_before:5,limit_after:100,show_album_covers:!0,show_artist_names:!0,hide:OA},LA=["action_buttons","move_down_button","move_next_button","move_up_button","remove_button","album_covers","artist_names"];var UA;function TA(e){let t=e.queue;return t=function(e){return{...qA,...e}}(t),t=function(e){const t=e.hide;return{...e,hide:{...OA,...t}}}(t),{...e,queue:t}}!function(e){e.CONFIG_MISSING="Invalid configuration.",e.NO_ENTITY="You need to define entity.",e.ENTITY_TYPE="Entity must be a string!",e.MISSING_ENTITY="Entity does not exist!",e.OK="ok"}(UA||(UA={}));class JA extends ve{constructor(){super(...arguments),this.showAlbumCovers=!0,this.hide=OA}set config(e){tr(this._config,e)||(this._config=e,this.updateHiddenElements())}get config(){return this._config}set entityConfig(e){tr(this._entityConfig,e)||(this._entityConfig=e,this.updateHiddenElements())}get entityConfig(){return this._entityConfig}updateHiddenElements(){if(!this.entityConfig||!this.config)return;const e=this._entityConfig.hide.queue,t=this._config.hide;this.hide={album_covers:e.album_covers||t.album_covers,artist_names:e.artist_names||t.artist_names,action_buttons:e.action_buttons||t.action_buttons,move_down_button:e.move_down_button||t.move_down_button,move_next_button:e.move_next_button||t.move_next_button,move_up_button:e.move_up_button||t.move_up_button,remove_button:e.remove_button||t.remove_button}}callMoveItemUpService(e){navigator.vibrate([50,20,25,20,25]),e.stopPropagation(),this.moveQueueItemUpService(this.media_item.queue_item_id)}callMoveItemDownService(e){navigator.vibrate([25,20,25,20,50]),e.stopPropagation(),this.moveQueueItemDownService(this.media_item.queue_item_id)}callMoveItemNextService(e){navigator.vibrate([50,20,25,20,50]),e.stopPropagation(),this.moveQueueItemNextService(this.media_item.queue_item_id)}callRemoveItemService(e){e.stopPropagation(),navigator.vibrate([25,20,75,20,25]),this.removeService(this.media_item.queue_item_id)}callOnQueueItemSelectedService(){this.selectedService(this.media_item.queue_item_id)}shouldUpdate(e){if(e.has("media_item")){const r=e.get("media_item");return t=r,i=this.media_item,t?.media_content_id!==i?.media_content_id||t?.playing!==i?.playing||t?.queue_item_id!==i?.queue_item_id||t?.show_action_buttons!==i?.show_action_buttons||t?.show_artist_name!==i?.show_artist_name||t?.show_move_up_next!==i?.show_move_up_next}var t,i;return e.size>0}artworkStyle(){const e=this.media_item.local_image_encoded??this.media_item.media_image??"";return Zi(e)?sr(this.hass,e,Gt.CLEFT):or(this.hass,Gt.CLEFT)}renderThumbnail(){const e=!this.media_item.show_action_buttons&&!this.media_item.playing;return(this.media_item.local_image_encoded??this.media_item.media_image)&&this.showAlbumCovers&&!this.hide.album_covers?W`
        <span
          class="thumbnail${e?"-disabled":""}"
          slot="start"
          style="${this.artworkStyle()}"
        >
        </span>
      `:W``}_calculateTitleWidth(){let e=0;const t=this.config.hide,i=this.media_item;if(i.show_move_up_next&&!t.move_next_button&&(e+=1),i.show_move_up_next&&!t.move_up_button&&(e+=1),t.move_down_button||(e+=1),t.remove_button||(e+=1),0==e||!i.show_action_buttons||t.action_buttons)return"100%";const r=e-1;return`calc(100% - ((32px * ${e.toString()}) + (8px * ${r.toString()}) + 16px));`}renderTitle(){return W`
      <span
        slot="headline"
        class="title"
        style="width: ${this._calculateTitleWidth()}"
      >
        ${this.media_item.media_title}
      </span>
    `}renderArtist(){return this.hide.artist_names?W``:W`
      <span
        slot="supporting-text"
        class="title"
        style="width: ${this._calculateTitleWidth()}"
      >
        ${this.media_item.media_artist}
      </span>
    `}renderActionButtons(){return this.hide.action_buttons||!this.media_item.show_action_buttons?W``:W`
      <span
        slot="end"
        class="button-group"
        @click=${e=>{e.stopPropagation()}}
      >
        ${this.renderMoveNextButton()} ${this.renderMoveUpButton()}
        ${this.renderMoveDownButton()} ${this.renderRemoveButton()}
      </span>
    `}renderMoveNextButton(){return this.hide.move_next_button||!this.media_item.show_move_up_next?W``:W`
      <ha-button
        appearance="plain"
        variant="brand"
        size="medium"
        class="action-button ${this.useExpressive?"action-button-expressive":""}"
        @click=${this.callMoveItemNextService}
      >
        <ha-svg-icon
          .path=${this.Icons.ARROW_PLAY_NEXT}
          class="svg-action-button ${this.useExpressive?"svg-action-button-expressive":""}"
        ></ha-svg-icon>
      </ha-button>
    `}renderMoveUpButton(){return this.hide.move_up_button||!this.media_item.show_move_up_next?W``:W`
      <ha-button
        appearance="plain"
        variant="brand"
        size="medium"
        class="action-button ${this.useExpressive?"action-button-expressive":""}"
        @click=${this.callMoveItemUpService}
      >
        <ha-svg-icon
          .path=${this.Icons.ARROW_UP}
          class="svg-action-button ${this.useExpressive?"svg-action-button-expressive":""}"
        ></ha-svg-icon>
      </ha-button>
    `}renderMoveDownButton(){return this.hide.move_down_button?W``:W`
      <ha-button
        appearance="plain"
        variant="brand"
        size="medium"
        class="action-button ${this.useExpressive?"action-button-expressive":""}"
        @click=${this.callMoveItemDownService}
      >
        <ha-svg-icon
          .path=${this.Icons.ARROW_DOWN}
          class="svg-action-button ${this.useExpressive?"svg-action-button-expressive":""}"
        ></ha-svg-icon>
      </ha-button>
    `}renderRemoveButton(){return this.hide.remove_button?W``:W`
      <ha-button
        appearance="plain"
        variant="brand"
        size="medium"
        class="action-button ${this.useExpressive?"action-button-expressive":""}"
        @click=${this.callRemoveItemService}
      >
        <ha-svg-icon
          .path=${this.Icons.CLOSE}
          class="svg-action-button ${this.useExpressive?"svg-action-button-expressive":""}"
        ></ha-svg-icon>
      </ha-button>
    `}render(){const e=this.media_item.playing?"-active":"",t=this.useExpressive?`button-expressive${e}`:"";return W`
      <ha-md-list-item
        style="${this.display?"":"display: none;"}"
        class="button${e} ${t}"
        @click=${this.callOnQueueItemSelectedService}
        type="button"
      >
        ${this.renderThumbnail()} ${this.renderTitle()} ${this.renderArtist()}
        ${this.renderActionButtons()}
      </ha-md-list-item>
      <div class="divider"></div>
    `}static get styles(){return SA}}e([Qe({attribute:!1})],JA.prototype,"media_item",void 0),e([n({context:vi,subscribe:!0})],JA.prototype,"hass",void 0),e([n({context:Ji})],JA.prototype,"Icons",void 0),e([n({context:Mi,subscribe:!0}),De()],JA.prototype,"display",void 0),e([n({context:Ti,subscribe:!0})],JA.prototype,"useExpressive",void 0),e([n({context:Ri,subscribe:!0})],JA.prototype,"config",null),e([n({context:mi,subscribe:!0})],JA.prototype,"entityConfig",null),customElements.define("mass-player-media-row",JA);var VA=g`
  *[selected] {
    color: var(--accent-color);
  }
  *[hide] {
    display: none;
  }

  .button-min {
    height: 35px;
    width: 35px;
    --wa-color-fill-quiet: rgba(from var(--md-sys-color-primary) r g b / 0.1);
    position: relative;
  }
  .button-min::part(base) {
    --wa-form-control-padding-inline: 0px;
    height: 35px;
    width: 35px;
  }
  .button-expressive::part(base) {
    box-shadow: var(--md-sys-elevation-level1);
    border-radius: var(--button-small-border-radius) !important;
    background-color: var(--md-sys-color-secondary-container);
  }

  #container {
    overflow: hidden;
    width: 100%;
    justify-content: center;
    box-shadow: unset;
    height: var(--mass-player-card-height);
  }
  .container-expressive {
    border-radius: var(--expressive-border-radius-container);
    background-color: var(--expressive-color-container);
  }

  .header {
    display: flex;
    flex-direction: column;
    font-size: 1.5rem;
    text-align: center;
    font-weight: 600;
    padding-top: 12px;
    height: auto;
  }

  .list {
    height: calc(var(--mass-player-card-height) - 4em);
    overflow-y: scroll;
    -ms-overflow-style: none;
    scrollbar-width: none;
    border-radius: var(--queue-border-radius, 12px);
  }
  .list-expressive {
    background-color: var(--md-sys-color-background);
    border-radius: var(--expressive-border-radius-container);
  }

  .main {
    display: flex;
    height: 100%;
    margin: auto;
    padding: 6px 16px 6px 16px;
    width: 100%;
    justify-content: space-around;
    overflow-x: scroll;
    -ms-overflow-style: none; /* IE and Edge */
    scrollbar-width: none; /* Firefox */
  }

  .name {
    font-weight: 300;
    font-size: var(--fontSize);
    line-height: var(--fontSize);
    cursor: pointer;
  }

  .title {
    text-align: center;
    font-size: 1.2rem;
    font-weight: bold;
    align-items: center;
    justify-content: center;
    padding: 0.5rem;
  }
`;class FA extends ve{constructor(){super(...arguments),this._queue=[],this._firstLoaded=!1,this._tabSwitchFirstUpdate=!1,this._mediaCardDisplay=!0,this.onQueueItemSelected=async e=>{await this.queueController.playQueueItem(e),this.queueController.getQueue(),this.scrollToActive()},this.onQueueItemRemoved=async e=>{await this.queueController.removeQueueItem(e)},this.onQueueItemMoveNext=async e=>{await this.queueController.moveQueueItemNext(e)},this.onQueueItemMoveUp=async e=>{await this.queueController.moveQueueItemUp(e)},this.onQueueItemMoveDown=async e=>{await this.queueController.moveQueueItemDown(e)},this.onClearQueue=async()=>{await this.queueController.clearQueue(this.active_player_entity)},this.onTabSwitch=e=>{e.detail==Gi.QUEUE&&(this._tabSwitchFirstUpdate=!0,this.scrollToActive())}}set queueController(e){this._queueController=e}get queueController(){return this._queueController}set queue(e){if(e)return this.queue?.length?void(tr(this.queue,e)||(this._queue=this.processQueue(e))):void(this._queue=this.processQueue(e))}get queue(){return this._queue}processQueue(e){const t=e.findIndex(e=>e.playing);return e.map((e,i)=>({...e,show_action_buttons:i>t,show_move_up_next:i>t+1}))}set activeSection(e){this._mediaCardDisplay=e==Gi.QUEUE,this._section=e}get activeSection(){return this._section}set hass(e){e&&(this._hass=e)}get hass(){return this._hass}set active_player_entity(e){this._active_player_entity=e}get active_player_entity(){return this._active_player_entity}set config(e){const t=this.testConfig(e,!1);if(t!==UA.OK)throw this.createError(t);this._config={...qA,...e}}get config(){return this._config}testConfig(e,t=!0){if(!e)return UA.CONFIG_MISSING;if(t){if(!this.active_player_entity)return UA.NO_ENTITY;if("string"!=typeof this.active_player_entity)return UA.ENTITY_TYPE}return this.hass&&!this.hass.states[this.active_player_entity]?UA.MISSING_ENTITY:UA.OK}scrollToActive(){if(!this.queue?.length)return;const e=this._activeElement.offsetTop-2*this._activeElement.offsetHeight;this._items.scrollTop=e}renderQueueItems(){const e=this._config.show_album_covers;let t=1;const i=this._tabSwitchFirstUpdate;return this.queue?.map(r=>{const A=W`
        <wa-animation
          id="animation"
          name="fadeIn"
          delay=${62.5*t}
          duration=${125}
          fill="forwards"
          play=${i}
          iterations="1"
        >
          <mass-player-media-row
            style="opacity: 0%;"
            class="${r.playing?"media-active":""}"
            .media_item=${r}
            .showAlbumCovers=${e}
            .selectedService=${this.onQueueItemSelected}
            .removeService=${this.onQueueItemRemoved}
            .moveQueueItemNextService=${this.onQueueItemMoveNext}
            .moveQueueItemUpService=${this.onQueueItemMoveUp}
            .moveQueueItemDownService=${this.onQueueItemMoveDown}
          >
          </mass-player-media-row>
        </wa-animation>
      `;return t++,A})}renderHeader(){const e=ti("queue.header",this.hass),t=this.activePlayerController.useExpressive;return W`
      <mass-section-header>
        <span slot="label" id="title">
          ${e}
        </span>
        <span slot="end" id="clear-queue">
          <ha-button
            appearance="plain"
            variant="brand"
            size="medium"
            id="button-back"
            class="button-min ${t?"button-expressive":""}"
            @click=${this.onClearQueue}
          >
            <ha-svg-icon
              .path=${this.Icons.CLEAR}
              class="header-icon"
            ></ha-svg-icon>
        </span>
      </mass-section-header>
    `}render(){const e=this.activePlayerController.useExpressive;return this.error??W`
        <div id="container" class="${e?"container-expressive":""}">
          ${this.renderHeader()}
          <ha-md-list class="list ${e?"list-expressive":""}">
            ${this.renderQueueItems()}
          </ha-md-list>
        </div>
      `}shouldUpdate(e){return!!e.size&&(!(!e.has("_config")&&!e.has("queue"))||super.shouldUpdate(e))}disconnectedCallback(){super.disconnectedCallback(),this?.queueController?.isSubscribed&&this.queueController.unsubscribeUpdates(),super.disconnectedCallback()}connectedCallback(){this.queueController&&(this.queueController.getQueue(),this.queueController.subscribeUpdates()),this._animations&&this._firstLoaded&&this._animations.forEach(e=>e.play=!0),super.connectedCallback()}firstUpdated(){this._firstLoaded=!0,this.queueController._host.addEventListener("section-changed",this.onTabSwitch)}updated(){this._tabSwitchFirstUpdate=!1}static get styles(){return VA}createError(e){const t=new Error(e),i=document.createElement("hui-error-card");return i.setConfig({type:"error",error:t,origConfig:this._config}),this.error=W`${i}`,t}}e([n({context:Hi})],FA.prototype,"activePlayerController",void 0),e([n({context:mi,subscribe:!0})],FA.prototype,"entityConf",void 0),e([n({context:Ji,subscribe:!0})],FA.prototype,"Icons",void 0),e([o({context:Ri})],FA.prototype,"_config",void 0),e([De()],FA.prototype,"_queue",void 0),e([function(e){return(t,i)=>Re(t,i,{get(){return(this.renderRoot??(xe??=document.createDocumentFragment())).querySelectorAll(e)}})}("#animation")],FA.prototype,"_animations",void 0),e([ke(".media-active")],FA.prototype,"_activeElement",void 0),e([ke(".list")],FA.prototype,"_items",void 0),e([De()],FA.prototype,"_tabSwitchFirstUpdate",void 0),e([n({context:qi,subscribe:!0})],FA.prototype,"queueController",null),e([n({context:Vi,subscribe:!0})],FA.prototype,"queue",null),e([o({context:Mi})],FA.prototype,"_mediaCardDisplay",void 0),e([n({context:Pi,subscribe:!0})],FA.prototype,"activeSection",null),e([n({context:vi,subscribe:!0})],FA.prototype,"hass",null),e([n({context:wi,subscribe:!0}),Qe({attribute:!1})],FA.prototype,"active_player_entity",null),customElements.define("mass-player-queue-card",FA);
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const zA=Se(class extends Oe{constructor(){super(...arguments),this.key=_}render(e,t){return this.key=e,t}update(e,[t,i]){return t!==this.key&&(Ve(e),this.key=t),i}});var YA=g`
  :host {
    --me-font-color: var(--md-sys-color-on-primary-container);
    --me-icon-color: var(--md-sys-color-primary-container);
  }

  .action-button {
    width: var(--media-row-icon-width);
    transform: scale(1);
    align-content: center;
  }
  .action-button::part(base) {
    height: 30px;
    width: 30px;
    border-radius: 25%;
    --wa-form-control-padding-inline: 0px;
  }

  .action-button-expressive::part(base) {
    box-shadow: var(--md-sys-elevation-level1);
    --ha-button-border-radius: var(--button-small-border-radius) !important;
    background-color: var(--expressive-row-button-color);
    --inherited-background-color: var(--expressive-row-button-color);
  }
  .action-button-expressive::part(base):hover {
    background-color: var(--expressive-row-button-color-hover) !important;
    --inherited-background-color: var(
      --expressive-row-button-color-hover
    ) !important;
    box-shadow: var(--md-sys-elevation-level1);
    --ha-button-border-radius: var(--button-small-border-radius) !important;
  }

  .audio-bars {
    width: 0.55rem;
    position: absolute;
    right: 1rem;
    height: 100%;
    margin-left: 1rem;
  }
  .audio-bars > div {
    bottom: 0.05rem;
    height: 0.15rem;
    position: absolute;
    width: 0.15rem;
    display: block;
    animation: player-active 0ms -800ms linear infinite alternate;
  }
  .audio-bars-normal > div {
    --start-color: var(--audio-bars-color);
    --mid-color: var(--audio-bars-color);
    --end-color: var(--audio-bars-color);
  }
  .audio-bars-expressive > div {
    --start-color: var(--expressive-audio-bars-initial-color);
    --mid-color: var(--expressive-audio-bars-middle-color);
    --max-color: var(--expressive-audio-bars-max-color);
  }
  .audio-bars > div:first-child {
    left: 8px;
    animation-duration: 474ms;
  }
  .audio-bars > div:nth-child(2) {
    left: 12px;
    animation-duration: 433ms;
  }
  .audio-bars > div:nth-child(3) {
    left: 16px;
    animation-duration: 407ms;
  }
  .audio-bars > div:last-child {
    left: 20px;
    animation-duration: 375ms;
  }

  .button-group {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: flex-end;
    gap: 8px;
    height: 48px;
    right: 0;
    padding-right: 16px;
    position: absolute;
  }

  .button {
    margin: 0.15rem;
    border-radius: var(--player-row-border-radius);
    background: var(--media-row-background-color);
    height: var(--media-row-height);
  }

  .button-active {
    margin: 0.15rem;
    border-radius: var(--player-row-border-radius);
    background-color: var(
      --media-row-active-background-color,
      var(--md-sys-color-secondary-container)
    );
    height: var(--media-row-height);
    padding-inline-start: 0px;
    padding-inline-end: 8px;
    color: var(--accent-color);
  }

  .button-expressive {
    background-color: var(--expressive-row-color) !important;
  }
  .button-expressive > .title {
    color: var(--expressive-row-color-text);
  }
  .button-expressive-active {
    --primary-text-color: var(--expressive-row-active-color-text) !important;
    --font-color: var(--expressive-row-active-color-text) !important;
    background-color: var(--expressive-row-active-color) !important;
  }
  .button-expressive-active > .title {
    color: var(--expressive-row-active-color-text);
  }

  .divider::before {
    content: " ";
    display: block;
    height: 1px;
    background-color: var(--divider-color);
    margin-left: 8px;
    margin-right: 8px;
  }

  .headline-expressive {
    color: var(--expressive-row-color-text);
  }
  .headline-expressive-active {
    color: var(--expressive-row-color-text-active);
  }

  .svg-action-button {
    height: var(--row-icon-button-height);
    width: var(--row-icon-button-height);
  }
  .svg-action-button-expressive {
    color: var(--expressive-row-button-color-text);
  }
  .svg-action-button-expressive:hover {
    color: var(--expressive-row-button-color-text-hover);
  }

  .thumbnail {
    width: var(--media-row-thumbnail-height);
    height: var(--media-row-thumbnail-height);
    background-size: contain;
    background-repeat: no-repeat;
    background-position: left;
    border-radius: 0.7rem;
  }
  .thumbnail-disabled {
    width: var(--media-row-thumbnail-height);
    height: var(--media-row-thumbnail-height);
    background-size: contain;
    background-repeat: no-repeat;
    background-position: left;
    border-radius: 0.7rem;
    filter: opacity(0.5);
  }

  .title {
    font-size: 1.1rem;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    min-width: 0;
    color: var(--font-color);
    width: fit-content;
  }
  .title-bars {
    display: flex;
    flex-direction: row;
    position: relative;
  }

  @keyframes player-active {
    0% {
      height: 4px;
      background-color: var(--start-color);
    }
    50% {
      height: 14px;
      background-color: var(--mid-color);
    }
    100% {
      height: 24px;
      background-color: var(--max-color);
    }
  }
`;const XA={action_buttons:!1,join_button:!1,transfer_button:!1},jA={enabled:!0,hide:XA},KA=["action_buttons","join_button","transfer_button"];function GA(e){let t=e.players;return t=function(e){return{...jA,...e}}(t),t=function(e){const t=e.hide;return{...e,hide:{...XA,...t}}}(t),{...e,players:t}}class NA extends ve{constructor(){super(...arguments),this.joined=!1,this.selected=!1,this.allowJoin=!0,this.hide=XA}set config(e){tr(this._config,e)||(this._config=e,this.updateHiddenElements())}get config(){return this._config}set entityConfig(e){tr(this._entityConfig,e)||(this._entityConfig=e,this.updateHiddenElements())}get entityConfig(){return this._entityConfig}updateHiddenElements(){if(!this.config||!this.entityConfig)return;const e=this.entityConfig.hide.players,t=this.config.hide;this.hide={action_buttons:e.action_buttons||t.action_buttons,join_button:e.join_button||t.join_button,transfer_button:e.transfer_button||t.transfer_button}}callOnPlayerSelectedService(){this.selectedService(this.player_entity.entity_id)}shouldUpdate(e){return e.size>0}onJoinPressed(e){navigator.vibrate([75,20,20,20,75]),e.stopPropagation(),this.joined?this.unjoinService(this.player_entity.entity_id):(this.joinService(this.player_entity.entity_id),this.joined=!this.joined)}onTransferPressed(e){e.stopPropagation(),navigator.vibrate([75,20,40,20,25]),this.transferService(this.player_entity.entity_id)}artworkStyle(){const e=this.player_entity?.attributes?.entity_picture_local??"";return Zi(e)?sr(this.hass,e,Gt.HEADPHONES):or(this.hass,Gt.HEADPHONES)}renderThumbnail(){return W`
      <span class="thumbnail" slot="start" style="${this.artworkStyle()}">
      </span>
    `}_calculateTitleWidth(){let e=0;const t=this.config.hide;if(!t.join_button&&this.player_entity.attributes?.group_members&&this.allowJoin&&(e+=1),t.transfer_button||(e+=1),this.selected||t.action_buttons)return"100%;";const i=e-1;return`calc(100% - ( (32px * ${e.toString()}) + (8px * ${i.toString()}) + 16px));`}renderTitle(){let e=this.playerName;e.length||(e=this.player_entity.attributes?.friendly_name??"Media Player");const t=er(this.hass,this.player_entity,this._entityConfig)&&"playing"==this.player_entity.state?"audio-bars":"audio-bars-inactive",i=this.useExpressive?"audio-bars-expressive":"audio-bars-normal";return W`
      <span slot="headline">
        <div
          class="title-bars"
          style="max-width: ${this._calculateTitleWidth()}"
        >
          <div class="title">${e}</div>
          <div class="${t} ${i}">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
          </div>
        </div>
      </span>
      <span slot="supporting-text"> </span>
    `}renderTransferButton(){return this.hide.transfer_button?W``:W`
      <ha-button
        appearance="plain"
        variant="brand"
        size="medium"
        class="action-button ${this.useExpressive?"action-button-expressive":""}"
        @click=${this.onTransferPressed}
      >
        <ha-svg-icon
          .path=${this.Icons.SWAP}
          class="svg-action-button ${this.useExpressive?"svg-action-button-expressive":""}"
        ></ha-svg-icon>
      </ha-button>
    `}renderJoinButon(){return this.hide.join_button?W``:this.player_entity.attributes?.group_members&&this.allowJoin?W`
      <ha-button
        appearance="plain"
        variant="brand"
        size="medium"
        class="action-button ${this.useExpressive?"action-button-expressive":""}"
        @click=${this.onJoinPressed}
      >
        <ha-svg-icon
          .path=${this.joined?this.Icons.LINK_OFF:this.Icons.LINK}
          class="svg-action-button ${this.useExpressive?"svg-action-button-expressive":""}"
        ></ha-svg-icon>
      </ha-button>
    `:void 0}renderActionButtons(){return this.selected||this.hide.action_buttons?W``:W`
        <span
          slot="end"
          class="button-group"
          @click=${e=>{e.stopPropagation()}}
        >
          ${this.renderJoinButon()} ${this.renderTransferButton()}
        </span>
      `}render(){const e=this.selected?"-active":"",t=this.useExpressive?"button-expressive":"";return W`
      <ha-md-list-item
        class="button${e} ${t}${e}"
        @click=${this.callOnPlayerSelectedService}
        type="button"
      >
        ${this.renderThumbnail()} ${this.renderTitle()}
        ${this.renderActionButtons()}
      </ha-md-list-item>
      <div class="divider"></div>
    `}static get styles(){return YA}}e([Qe({type:Boolean})],NA.prototype,"joined",void 0),e([Qe({type:Boolean})],NA.prototype,"player_entity",void 0),e([Qe({type:Boolean})],NA.prototype,"selected",void 0),e([n({context:Ji})],NA.prototype,"Icons",void 0),e([n({context:Ti,subscribe:!0})],NA.prototype,"useExpressive",void 0),e([n({context:vi})],NA.prototype,"hass",void 0),e([n({context:xi,subscribe:!0})],NA.prototype,"config",null),e([n({context:mi,subscribe:!0})],NA.prototype,"entityConfig",null),customElements.define("mass-player-player-row",NA);class WA{constructor(e){this.hass=e}set hass(e){e&&(this._hass=e)}get hass(){return this._hass}async actionTransferQueue(e,t){try{await this.hass.callService("music_assistant","transfer_queue",{entity_id:t,source_player:e})}catch(e){console.error("Error calling transfer player",e)}}async actionJoinPlayers(e,t){try{await this.hass.callService("media_player","join",{entity_id:e,group_members:t})}catch(e){console.error("Error joining players",e)}}async actionUnjoinPlayers(e){try{await this.hass.callService("media_player","unjoin",{entity_id:e})}catch(e){console.error("Error unjoining players",e)}}}class ZA extends ve{constructor(){super(...arguments),this.entities=[],this._firstLoaded=!1,this.joinPlayers=async e=>{await this.actions.actionJoinPlayers(this.activePlayerEntity.entity_id,e)},this.unjoinPlayers=async e=>{await this.actions.actionUnjoinPlayers(e)},this.transferQueue=async e=>{await this.actions.actionTransferQueue(this.activePlayerEntity.entity_id,e);const t=this.config.entities.find(t=>t.entity_id==e);this.activePlayerEntity=t,this.selectedPlayerService(e)}}set config(e){this._hass&&e&&this.setEntities(this._hass),this._config={...jA,...e},this._sectionConfig=this._config.players}get config(){return this._config}set hass(e){if(!e)return;if(this._hass=e,this.actions||(this.actions=new WA(e)),!this.entities.length)return void this.setEntities(e);let t=!1;this.entities.forEach(i=>{e.states[i.entity_id]!==i&&(t=!0)}),t&&this.setEntities(e)}get hass(){return this._hass}setEntities(e){if(!this._config)return;const t=[];this._config.entities.forEach(i=>{t.push(e.states[i.entity_id])}),this.entities=t}renderPlayerRows(){const e=this._hass.states[this.activePlayerEntity.entity_id].attributes,t=e?.group_members??[];return this.entities.map(i=>{const r=this.config.entities.find(e=>e.entity_id==i.entity_id);return zA(i.entity_id,W`
          <mass-player-player-row
            .player_entity=${i}
            .playerName=${r.name}
            .selected=${this.activePlayerEntity.entity_id==i.entity_id}
            .selectedService=${this.selectedPlayerService}
            .joinService=${this.joinPlayers}
            .unjoinService=${this.unjoinPlayers}
            .transferService=${this.transferQueue}
            .joined=${t.includes(i.entity_id)}
            .allowJoin=${void 0!==e.group_members}
          >
          </mass-player-player-row>
        `)})}render(){const e=ti("players.header",this.hass),t=this.config.expressive;return W`
      <div id="container" class="${t?"container-expressive":""}">
        <mass-section-header>
          <span slot="label" id="title"> ${e} </span>
        </mass-section-header>
        <wa-animation
          id="animation"
          name="fadeIn"
          easing="ease-in"
          iterations="1"
          play=${this.checkVisibility()}
          playback-rate="4"
        >
          <ha-md-list class="list ${t?"list-expressive":""}">
            ${this.renderPlayerRows()}
          </ha-md-list>
        </wa-animation>
      </div>
    `}connectedCallback(){this._animation&&this._firstLoaded&&(this._animation.play=!0),super.connectedCallback()}firstUpdated(){this._firstLoaded=!0}shouldUpdate(e){return e.size>0}static get styles(){return VA}}e([Qe({attribute:!1})],ZA.prototype,"entities",void 0),e([n({context:mi,subscribe:!0}),Qe({attribute:!1})],ZA.prototype,"activePlayerEntity",void 0),e([ke("#animation")],ZA.prototype,"_animation",void 0),e([o({context:xi})],ZA.prototype,"_sectionConfig",void 0),e([Qe({attribute:!1})],ZA.prototype,"config",null),e([n({context:vi,subscribe:!0})],ZA.prototype,"hass",null),customElements.define("mass-player-players-card",ZA);var _A=g`
  a.active {
    --primary-container: var(--tab-active-indicator-color);
  }
  a.active-expressive {
    box-shadow: var(--md-sys-elevation-level2);
  }

  .action-button-svg {
    --icon-primary-color: var(--tab-active-icon-color);
    height: var(--tab-icon-height);
    width: var(--tab-icon-height);
  }
  .action-button-svg-inactive {
    --icon-primary-color: var(--tab-inactive-icon-color);
    height: var(--tab-icon-height);
    width: var(--tab-icon-height);
  }

  .icon-i {
    height: 100%;
    width: 100%;
  }

  nav.tabbed {
    background-color: var(--tabbed-background-color);
    box-shadow: var(--tabbed-elevation);
  }

  .player-tabs {
    --primary-container: rgba(from var(--primary-color) r g b / 0.25);
  }

  .tabbed {
    --tabbed-elevation: var(--md-sys-elevation-level1);
    --tabbed-background-color: var(--tabbed-background-color);
    --tab-active-icon-color: var(--md-sys-color-on-secondary-container);
    --tab-active-indicator-color: var(--md-sys-color-secondary-container);
    --tab-inactive-icon-color: var(--md-sys-color-on-primary-container);
    --tab-icon-height: 24px;
  }
  .tabbed-expressive {
    --tabbed-background-color: var(--md-sys-color-primary-container) !important;
  }
`;let $A=class extends ve{constructor(){super(...arguments),this.handleTabChanged=e=>{this.setActiveSection(e),e==Gi.MEDIA_BROWSER&&this.returnMediaBrowserToHome()},this.returnMediaBrowserToHome=()=>{const e=this.controller.host,t=e.shadowRoot?.querySelector("mass-media-browser");t&&t.resetActiveSections()}}set active_section(e){this.controller&&(this._activeSection=e)}get active_section(){return this._activeSection}setActiveSection(e){this.controller.activeSection=e}set controller(e){this._controller=e,this.active_section=e.activeSection,this.config=e.config}get controller(){return this._controller}set config(e){this._config=e}get config(){return this._config}renderMusicPlayerTab(){const e=Gi.MUSIC_PLAYER,t=this.Icons.MUSIC;return this.config.player.enabled?this.renderTab(e,t):W``}renderQueueTab(){const e=Gi.QUEUE,t=this.Icons.PLAYLIST;return this.config.queue.enabled?this.renderTab(e,t):W``}renderMediaBrowserTab(){const e=Gi.MEDIA_BROWSER,t=this.Icons.ALBUM;return this.config.media_browser.enabled?this.renderTab(e,t):W``}renderPlayersTab(){const e=Gi.PLAYERS,t=this.Icons.SPEAKER_MULTIPLE;return this.config.players.enabled?this.renderTab(e,t):W``}renderTab(e,t){const i=this.active_section==e;return W`
      <a
        class="${i?"active active-expressive":""} player-tabs"
        @click=${()=>{this.handleTabChanged(e)}}
      >
        <i class="icon-i">
          <ha-svg-icon
            .path=${t}
            class="action-button-svg${i?"":"-inactive"}"
          ></ha-svg-icon>
        </i>
      </a>
    `}render(){return W`
      <div>
        <nav class="tabbed tabbed-expressive">
          <link
            href="https://cdn.jsdelivr.net/npm/beercss@3.12.11/dist/cdn/beer.min.css"
            rel="stylesheet"
          />
          ${this.renderMusicPlayerTab()} ${this.renderQueueTab()}
          ${this.renderMediaBrowserTab()} ${this.renderPlayersTab()}
        </nav>
      </div>
    `}shouldUpdate(e){return!!this.config&&e.size>0}static get styles(){return _A}};e([n({context:Ji})],$A.prototype,"Icons",void 0),e([n({context:Pi,subscribe:!0}),De()],$A.prototype,"active_section",null),e([n({context:Oi,subscribe:!0})],$A.prototype,"controller",null),customElements.define("mass-nav-bar-expressive",$A);class es extends ve{constructor(){super(...arguments),this.handleTabChanged=e=>{this.controller.activeSection=e},this.returnMediaBrowserToHome=()=>{const e=this.controller.host,t=e.shadowRoot?.querySelector("mass-media-browser");t&&t.resetActiveSections()}}set active_section(e){this.controller&&(this._activeSection=e)}get active_section(){return this._activeSection}set controller(e){this._controller=e,this.active_section=e.activeSection,this.config=e.config}get controller(){return this._controller}set config(e){this._config=e}get config(){return this._config}renderMusicPlayerTab(){const e=Gi.MUSIC_PLAYER,t=this.Icons.MUSIC;return this.config.player.enabled?this.renderTab(e,t):W``}renderQueueTab(){const e=Gi.QUEUE,t=this.Icons.PLAYLIST;return this.config.queue.enabled?this.renderTab(e,t):W``}renderMediaBrowserTab(){const e=Gi.MEDIA_BROWSER,t=this.Icons.ALBUM;return this.config.media_browser.enabled?this.renderTab(e,t):W``}renderPlayersTab(){const e=Gi.PLAYERS,t=this.Icons.SPEAKER_MULTIPLE;return this.config.players.enabled?this.renderTab(e,t):W``}renderTab(e,t){const i=this.active_section==e;return W`
      <a
        class="${i?"active":""} player-tabs"
        @click=${()=>{this.handleTabChanged(e)}}
      >
        <i class="icon-i">
          <ha-svg-icon
            .path=${t}
            class="action-button-svg${i?"":"-inactive"}"
          ></ha-svg-icon>
        </i>
        <span></span>
      </a>
    `}render(){return W`
      <div>
        <nav class="tabbed">
          <link
            href="https://cdn.jsdelivr.net/npm/beercss@3.12.11/dist/cdn/beer.min.css"
            rel="stylesheet"
          />
          ${this.renderMusicPlayerTab()} ${this.renderQueueTab()}
          ${this.renderMediaBrowserTab()} ${this.renderPlayersTab()}
        </nav>
      </div>
    `}shouldUpdate(e){return!!this.config&&e.size>0}static get styles(){return _A}}e([n({context:Ji})],es.prototype,"Icons",void 0),e([n({context:Pi,subscribe:!0}),De()],es.prototype,"active_section",null),e([n({context:Oi,subscribe:!0})],es.prototype,"controller",null),customElements.define("mass-nav-bar",es);const ts={queue:qA,player:vA,players:jA,media_browser:br,expressive:!0,entities:[],download_local:!1},is={player:hA,queue:OA,media_browser:fr,players:XA};function rs(e){if("string"==typeof e)return{entity_id:t=e,volume_entity_id:t,name:"",max_volume:100,hide:is,inactive_when_idle:!1};var t;const i=function(e){const t=e?.hide,i={...is,...t};return i.player={...hA,...i?.player},i}(e);return{entity_id:e.entity_id,volume_entity_id:e?.volume_entity_id??e.entity_id,name:e?.name??"",max_volume:e?.max_volume??100,hide:i,inactive_when_idle:e?.inactive_when_idle??!1}}function As(e){return e=GA(e=TA(e=fA(e=Dr(e=function(e){const t=e.entities,i=[];return t.forEach(e=>{i.push(rs(e))}),{...e,entities:i}}(e=function(e){return{...ts,...e}}(e))))))}var ss=g`
  :host {
    --mass-player-card-height: var(--mass-player-card-section-height, 40em);

    --artwork-large-height: var(
      --mass-player-card-artwork-large-height,
      var(--mass-player-card-height)
    ) !important;
    --artwork-medium-height: var(
      --mass-player-card-artwork-medium-height,
      22em
    ) !important;
    --artwork-small-height: var(
      --mass-player-card-artwork-small-height,
      14em
    ) !important;

    --audio-bars-color: var(
      --mass-player-card-audio-bars-color,
      var(--secondary-text-color)
    );
    --expressive-audio-bars-initial-color: var(
      --mass-player-card-audio-bars-initial-color,
      var(--md-sys-color-tertiary)
    );
    --expressive-audio-bars-middle-color: var(
      --mass-player-card-audio-bars-middle-color,
      var(--md-sys-color-secondary)
    );
    --expressive-audio-bars-max-color: var(
      --mass-player-card-audio-bars-max-color,
      var(--md-sys-color-primary)
    );

    --default-border-radius: var(
      --mass-player-card-default-border-radius,
      28px
    );
    --artwork-border-radius: var(
      --mass-player-card-artwork-border-radius,
      var(--default-border-radius)
    );
    --browser-card-border-radius: var(
      --mass-player-card-browser-card-border-radius,
      var(--default-border-radius)
    );
    --queue-border-radius: var(
      --mass-player-card-queue-border-radius,
      var(--default-border-radius)
    );
    --media-row-border-radius: var(
      --mass-player-card-media-row-border-radius,
      0.7em
    );
    --player-row-border-radius: var(
      --mass-player-card-player-row-border-radius,
      0.7em
    );

    --button-small-border-radius: var(
      --mass-player-card-small-button-border-radius,
      12px
    );

    --expressive-border-radius-container: var(
      --mass-player-card-expressive-border-radius-container,
      var(--default-border-radius) var(--default-border-radius) 0px 0px
    );

    --expressive-color-container: var(
      --mass-player-card-expressive-color-container,
      var(--md-sys-color-primary-container)
    );
    --expressive-card-color: var(
      --mass-player-card-expressive-card-color,
      var(--md-sys-color-background)
    );

    --expressive-row-color: var(
      --mass-player-card-expressive-row-color,
      var(--md-sys-color-background)
    );
    --expressive-row-color-text: var(
      --mass-player-card-expressive-row-color-text,
      var(--md-sys-color-on-background)
    );
    --expressive-row-active-color: var(
      --mass-player-card-expressive-row-active-color,
      var(--md-sys-color-secondary-container)
    );
    --expressive-row-active-color-text: var(
      --mass-player-card-expressive-row-active-color-text,
      var(--md-sys-color-on-secondary-container)
    );

    --expressive-row-button-color: var(
      --mass-player-card-expressive-row-button-color,
      var(--md-sys-color-primary-container)
    );
    --expressive-row-button-color-text: var(
      --mass-player-card-expressive-row-button-color-text,
      var(--md-sys-color-on-primary-container)
    );
    --expressive-row-button-color-hover: var(
      --mass-player-card-expressive-row-button-color-hover,
      var(--md-sys-color-tertiary-container)
    );
    --expressive-row-button-color-text-hover: var(
      --mass-player-card-expressive-row-button-color-text-hover,
      var(--md-sys-color-on-tertiary-container)
    );

    --md-list-container-color: var(
      --mass-player-card-list-item-container-color,
      rgba(0, 0, 0, 0) !important
    );
    --md-list-item-leading-space: var(
      --mass-player-card-list-item-leading-space,
      0px
    );
    --md-list-item-two-line-container-height: var(
      --mass-player-card-list-item-two-line-height,
      48px
    );

    --menu-border-radius: var(--mass-player-card-menu-border-radius, 24px);
    --menu-selected-item-border-radius: var(
      --mass-player-card-menu-selected-item-border-radius,
      24px
    );

    --media-row-active-background-color: var(
      --mass-player-card-media-row-active-background-color,
      var(--table-row-alternative-background-color)
    );
    --media-row-height: var(--mass-player-card-media-row-height, 56px);
    --media-row-thumbnail-height: var(
      --mass-player-card-media-row-thumbnail-height,
      var(--media-row-height)
    );

    --player-blur-px: var(--mass-player-card-player-blur-px, 3px);
    --player-blur: blur(var(--player-blur-px));
    --player-blur-color: rgba(
      from var(--mass-player-card-player-blur-color, var(--ha-card-background))
        r g b / 0.6
    );
    --expressive-player-blur-color: rgba(
      from
        var(
          --mass-player-card-expressive-player-blur-color,
          var(--md-sys-color-primary-container)
        )
        r g b / 0.6
    ) !important;

    --player-control-icon-width: var(
      --mass-player-card-player-control-icon-width,
      30px
    );
    --player-volume-slider-height: var(
      --mass-player-card-player-volume-slider-height,
      40px
    );

    --player-name-color: var(
      --mass-player-card-player-name-color,
      var(--ha-color-text-secondary)
    );

    --player-play-pause-color: var(
      --mass-player-card-player-play-pause-color,
      var(--secondary-background-color)
    );
    --player-play-pause-icon-size: var(
      --mass-player-card-player-play-pause-icon-size,
      6rem
    );

    --row-icon-button-height: var(
      --mass-player-card-row-icon-button-height,
      1.5rem
    );
  }

  ha-card {
    max-width: var(--mass-player-card-max-width, 100%);
    font-family: "Roboto Flex", var(--ha-font-family-body), "Roboto" !important;
    border-radius: var(--default-border-radius);
  }
  ha-card#expressive {
    background-color: var(--md-sys-color-background);
  }
  sl-tab-panel {
    height: var(--mass-player-card-height);
    display: block;
  }

  #navbar-expressive {
    background-color: var(--expressive-player-blur-color);
    border-radius: 0px 0px var(--default-border-radius)
      var(--default-border-radius);
  }

  .section-hidden {
    display: none;
  }
`,os=g`
  /*Fonts */
  /* Weight: 400 */
  @font-face {
    font-family: "Roboto Flex";
    font-style: normal;
    font-weight: 300;
    src: url(https://fonts.gstatic.com/s/robotoflex/v30/NaN4epOXO_NexZs0b5QrzlOHb8wCikXpYqmZsWI-__OGbt8jZktqc2V3Zs0KvDLdBP8SBZtOs2IifRuUZQMsPJtUsR4DEK6cULNeUx9XgTnH37Ha_FIAp4Fm0PP1hw45DntW2x0wZGzhPmr1YNMYKYn9_1IQXGwJAiUJVUMdN5YUW4O8HtSoXjC1z3QSabshNFVe3e0O5j3ZjrZCu23Qd4G0EBysQNK-QKavMl12JoUc.woff2)
      format("woff2");
    unicode-range:
      U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC,
      U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193,
      U+2212, U+2215, U+FEFF, U+FFFD;
  }
  /* Weight: 400 */
  @font-face {
    font-family: "Roboto Flex";
    font-style: normal;
    font-weight: 400;
    src: url(https://fonts.gstatic.com/s/robotoflex/v30/NaNnepOXO_NexZs0b5QrzlOHb8wCikXpYqmZsWI-__OGbt8jZktqc2V3Zs0KvDLdBP8SBZtOs2IifRuUZQMsPJtUsR4DEK6cULNeUx9XgTnH37Ha_FIAp4Fm0PP1hw45DntW2x0wZGzhPmr1YNMYKYn9_1IQXGwJAiUJVUMdN5YUW4O8HtSoXjC1z3QSabshNFVe3e0O5j3ZjrZCu23Qd4G0EBysQNK-QKavMl1cKq3tHXtXi8mzLjaAcbaknQ.woff2)
      format("woff2");
    unicode-range:
      U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC,
      U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193,
      U+2212, U+2215, U+FEFF, U+FFFD;
  }
  /* Weight: 600 */
  @font-face {
    font-family: "Roboto Flex";
    font-style: normal;
    font-weight: 600;
    src: url(https://fonts.gstatic.com/s/robotoflex/v30/NaN4epOXO_NexZs0b5QrzlOHb8wCikXpYqmZsWI-__OGbt8jZktqc2V3Zs0KvDLdBP8SBZtOs2IifRuUZQMsPJtUsR4DEK6cULNeUx9XgTnH37Ha_FIAp4Fm0PP1hw45DntW2x0wZGzhPmr1YNMYKYn9_1IQXGwJAiUJVUMdN5YUW4O8HtSoXjC1z3QSabshNFVe3e0O5j3ZjrZCu23Qd4G0EBysQNK-QKavMl12JoUc.woff2)
      format("woff2");
    unicode-range:
      U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC,
      U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193,
      U+2212, U+2215, U+FEFF, U+FFFD;
  }
  /* Weight: 700 */
  @font-face {
    font-family: "Roboto Flex";
    font-style: normal;
    font-weight: 700;
    src: url(https://fonts.gstatic.com/s/robotoflex/v30/NaN4epOXO_NexZs0b5QrzlOHb8wCikXpYqmZsWI-__OGbt8jZktqc2V3Zs0KvDLdBP8SBZtOs2IifRuUZQMsPJtUsR4DEK6cULNeUx9XgTnH37Ha_FIAp4Fm0PP1hw45DntW2x0wZGzhPmr1YNMYKYn9_1IQXGwJAiUJVUMdN5YUW4O8HtSoXjC1z3QSabshNFVe3e0O5j3ZjrZCu23Qd4G0EBysQNK-QKavMl12JoUc.woff2)
      format("woff2");
    unicode-range:
      U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC,
      U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193,
      U+2212, U+2215, U+FEFF, U+FFFD;
  }
`;const ns={ARTIST:"M11,14C12,14 13.05,14.16 14.2,14.44C13.39,15.31 13,16.33 13,17.5C13,18.39 13.25,19.23 13.78,20H3V18C3,16.81 3.91,15.85 5.74,15.12C7.57,14.38 9.33,14 11,14M11,12C9.92,12 9,11.61 8.18,10.83C7.38,10.05 7,9.11 7,8C7,6.92 7.38,6 8.18,5.18C9,4.38 9.92,4 11,4C12.11,4 13.05,4.38 13.83,5.18C14.61,6 15,6.92 15,8C15,9.11 14.61,10.05 13.83,10.83C13.05,11.61 12.11,12 11,12M18.5,10H20L22,10V12H20V17.5A2.5,2.5 0 0,1 17.5,20A2.5,2.5 0 0,1 15,17.5A2.5,2.5 0 0,1 17.5,15C17.86,15 18.19,15.07 18.5,15.21V10Z",ALBUM:cr,ARROW_DOWN:"M11,4H13V16L18.5,10.5L19.92,11.92L12,19.84L4.08,11.92L5.5,10.5L11,16V4Z",ARROW_LEFT:"M20,11V13H8L13.5,18.5L12.08,19.92L4.16,12L12.08,4.08L13.5,5.5L8,11H20Z",ARROW_PLAY_NEXT:"M4.08,11.92L12,4L19.92,11.92L18.5,13.33L13,7.83V22H11V7.83L5.5,13.33L4.08,11.92M12,4H22V2H2V4H12Z",ARROW_UP:"M13,20H11V8L5.5,13.5L4.08,12.08L12,4.16L19.92,12.08L18.5,13.5L13,8V20Z",ASLEEP:"M23,12H17V10L20.39,6H17V4H23V6L19.62,10H23V12M15,16H9V14L12.39,10H9V8H15V10L11.62,14H15V16M7,20H1V18L4.39,14H1V12H7V14L3.62,18H7V20Z",BOOK:"M18,22A2,2 0 0,0 20,20V4C20,2.89 19.1,2 18,2H12V9L9.5,7.5L7,9V2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18Z",CLEAR:"M14 10H3V12H14V10M14 6H3V8H14V6M3 16H10V14H3V16M14.4 22L17 19.4L19.6 22L21 20.6L18.4 18L21 15.4L19.6 14L17 16.6L14.4 14L13 15.4L15.6 18L13 20.6L14.4 22Z",CLOSE:"M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z",FILTER:"M6,13H18V11H6M3,6V8H21V6M10,18H14V16H10V18Z",HEART:dr,HEART_PLUS:"M12.67 20.74L12 21.35L10.55 20.03C5.4 15.36 2 12.27 2 8.5C2 5.41 4.42 3 7.5 3C9.24 3 10.91 3.81 12 5.08C13.09 3.81 14.76 3 16.5 3C19.58 3 22 5.41 22 8.5C22 9.93 21.5 11.26 20.62 12.61C20 12.31 19.31 12.11 18.59 12.04C19.5 10.8 20 9.65 20 8.5C20 6.5 18.5 5 16.5 5C14.96 5 13.46 6 12.93 7.36H11.07C10.54 6 9.04 5 7.5 5C5.5 5 4 6.5 4 8.5C4 11.39 7.14 14.24 11.89 18.55L12 18.65L12.04 18.61C12.12 19.37 12.34 20.09 12.67 20.74M17 14V17H14V19H17V22H19V19H22V17H19V14H17Z",LIBRARY:"M12,8A3,3 0 0,0 15,5A3,3 0 0,0 12,2A3,3 0 0,0 9,5A3,3 0 0,0 12,8M12,11.54C9.64,9.35 6.5,8 3,8V19C6.5,19 9.64,20.35 12,22.54C14.36,20.35 17.5,19 21,19V8C17.5,8 14.36,9.35 12,11.54Z",LIBRARY_OUTLINED:"M12 14.27L10.64 13C9.09 11.57 7.16 10.57 5 10.18V17.13C7.61 17.47 10 18.47 12 19.95C14 18.47 16.39 17.47 19 17.13V10.18C16.84 10.57 14.91 11.57 13.36 13M19 8.15C19.65 8.05 20.32 8 21 8V19C17.5 19 14.36 20.35 12 22.54C9.64 20.35 6.5 19 3 19V8C3.68 8 4.35 8.05 5 8.15C7.69 8.56 10.1 9.78 12 11.54C13.9 9.78 16.31 8.56 19 8.15M12 6C12.27 6 12.5 5.9 12.71 5.71C12.9 5.5 13 5.27 13 5S12.9 4.5 12.71 4.29C12.5 4.11 12.27 4 12 4S11.5 4.11 11.29 4.29C11.11 4.5 11 4.74 11 5S11.11 5.5 11.29 5.71C11.5 5.9 11.74 6 12 6M14.12 7.12C13.56 7.68 12.8 8 12 8S10.44 7.68 9.88 7.12C9.32 6.56 9 5.8 9 5S9.32 3.44 9.88 2.88C10.44 2.32 11.2 2 12 2S13.56 2.32 14.12 2.88 15 4.2 15 5 14.68 6.56 14.12 7.12Z",LINK:"M3.9,12C3.9,10.29 5.29,8.9 7,8.9H11V7H7A5,5 0 0,0 2,12A5,5 0 0,0 7,17H11V15.1H7C5.29,15.1 3.9,13.71 3.9,12M8,13H16V11H8V13M17,7H13V8.9H17C18.71,8.9 20.1,10.29 20.1,12C20.1,13.71 18.71,15.1 17,15.1H13V17H17A5,5 0 0,0 22,12A5,5 0 0,0 17,7Z",LINK_OFF:"M17,7H13V8.9H17C18.71,8.9 20.1,10.29 20.1,12C20.1,13.43 19.12,14.63 17.79,15L19.25,16.44C20.88,15.61 22,13.95 22,12A5,5 0 0,0 17,7M16,11H13.81L15.81,13H16V11M2,4.27L5.11,7.38C3.29,8.12 2,9.91 2,12A5,5 0 0,0 7,17H11V15.1H7C5.29,15.1 3.9,13.71 3.9,12C3.9,10.41 5.11,9.1 6.66,8.93L8.73,11H8V13H10.73L13,15.27V17H14.73L18.74,21L20,19.74L3.27,3L2,4.27Z",MUSIC:hr,PAUSE:"M14,19H18V5H14M6,19H10V5H6V19Z",PLAY:"M8,5.14V19.14L19,12.14L8,5.14Z",PLAY_CIRCLE:"M10,16.5V7.5L16,12M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z",PLAY_CIRCLE_OUTLINE:"M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M10,16.5L16,12L10,7.5V16.5Z",PLAYLIST:gr,PLAYLIST_PLUS:"M3 16H10V14H3M18 14V10H16V14H12V16H16V20H18V16H22V14M14 6H3V8H14M14 10H3V12H14V10Z",PODCAST:"M17,18.25V21.5H7V18.25C7,16.87 9.24,15.75 12,15.75C14.76,15.75 17,16.87 17,18.25M12,5.5A6.5,6.5 0 0,1 18.5,12C18.5,13.25 18.15,14.42 17.54,15.41L16,14.04C16.32,13.43 16.5,12.73 16.5,12C16.5,9.5 14.5,7.5 12,7.5C9.5,7.5 7.5,9.5 7.5,12C7.5,12.73 7.68,13.43 8,14.04L6.46,15.41C5.85,14.42 5.5,13.25 5.5,12A6.5,6.5 0 0,1 12,5.5M12,1.5A10.5,10.5 0 0,1 22.5,12C22.5,14.28 21.77,16.39 20.54,18.11L19.04,16.76C19.96,15.4 20.5,13.76 20.5,12A8.5,8.5 0 0,0 12,3.5A8.5,8.5 0 0,0 3.5,12C3.5,13.76 4.04,15.4 4.96,16.76L3.46,18.11C2.23,16.39 1.5,14.28 1.5,12A10.5,10.5 0 0,1 12,1.5M12,9.5A2.5,2.5 0 0,1 14.5,12A2.5,2.5 0 0,1 12,14.5A2.5,2.5 0 0,1 9.5,12A2.5,2.5 0 0,1 12,9.5Z",POWER:"M16.56,5.44L15.11,6.89C16.84,7.94 18,9.83 18,12A6,6 0 0,1 12,18A6,6 0 0,1 6,12C6,9.83 7.16,7.94 8.88,6.88L7.44,5.44C5.36,6.88 4,9.28 4,12A8,8 0 0,0 12,20A8,8 0 0,0 20,12C20,9.28 18.64,6.88 16.56,5.44M13,3H11V13H13",RADIO:"M20,6A2,2 0 0,1 22,8V20A2,2 0 0,1 20,22H4A2,2 0 0,1 2,20V8C2,7.15 2.53,6.42 3.28,6.13L15.71,1L16.47,2.83L8.83,6H20M20,8H4V12H16V10H18V12H20V8M7,14A3,3 0 0,0 4,17A3,3 0 0,0 7,20A3,3 0 0,0 10,17A3,3 0 0,0 7,14Z",RECENTS:ur,REPEAT:"M17,17H7V14L3,18L7,22V19H19V13H17M7,7H17V10L21,6L17,2V5H5V11H7V7Z",REPEAT_OFF:"M2,5.27L3.28,4L20,20.72L18.73,22L15.73,19H7V22L3,18L7,14V17H13.73L7,10.27V11H5V8.27L2,5.27M17,13H19V17.18L17,15.18V13M17,5V2L21,6L17,10V7H8.82L6.82,5H17Z",REPEAT_ONCE:"M13,15V9H12L10,10V11H11.5V15M17,17H7V14L3,18L7,22V19H19V13H17M7,7H17V10L21,6L17,2V5H5V11H7V7Z",SEARCH:"M9.5,3A6.5,6.5 0 0,1 16,9.5C16,11.11 15.41,12.59 14.44,13.73L14.71,14H15.5L20.5,19L19,20.5L14,15.5V14.71L13.73,14.44C12.59,15.41 11.11,16 9.5,16A6.5,6.5 0 0,1 3,9.5A6.5,6.5 0 0,1 9.5,3M9.5,5C7,5 5,7 5,9.5C5,12 7,14 9.5,14C12,14 14,12 14,9.5C14,7 12,5 9.5,5Z",SHUFFLE:"M14.83,13.41L13.42,14.82L16.55,17.95L14.5,20H20V14.5L17.96,16.54L14.83,13.41M14.5,4L16.54,6.04L4,18.59L5.41,20L17.96,7.46L20,9.5V4M10.59,9.17L5.41,4L4,5.41L9.17,10.58L10.59,9.17Z",SHUFFLE_DISABLED:"M16,4.5V7H5V9H16V11.5L19.5,8M16,12.5V15H5V17H16V19.5L19.5,16",SKIP_NEXT:"M16,18H18V6H16M6,18L14.5,12L6,6V18Z",SKIP_NEXT_CIRCLE:"M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M8,8L13,12L8,16M14,8H16V16H14",SKIP_NEXT_CIRCLE_OUTLINED:"M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4M8,8V16L13,12M14,8V16H16V8",SKIP_PREVIOUS:"M6,18V6H8V18H6M9.5,12L18,6V18L9.5,12Z",SPEAKER:"M12,12A3,3 0 0,0 9,15A3,3 0 0,0 12,18A3,3 0 0,0 15,15A3,3 0 0,0 12,12M12,20A5,5 0 0,1 7,15A5,5 0 0,1 12,10A5,5 0 0,1 17,15A5,5 0 0,1 12,20M12,4A2,2 0 0,1 14,6A2,2 0 0,1 12,8C10.89,8 10,7.1 10,6C10,4.89 10.89,4 12,4M17,2H7C5.89,2 5,2.89 5,4V20A2,2 0 0,0 7,22H17A2,2 0 0,0 19,20V4C19,2.89 18.1,2 17,2Z",SPEAKER_MULTIPLE:pr,SUGGESTIONS:lr,SWAP:"M21,9L17,5V8H10V10H17V13M7,11L3,15L7,19V16H14V14H7V11Z",VOLUME_HIGH:"M14,3.23V5.29C16.89,6.15 19,8.83 19,12C19,15.17 16.89,17.84 14,18.7V20.77C18,19.86 21,16.28 21,12C21,7.72 18,4.14 14,3.23M16.5,12C16.5,10.23 15.5,8.71 14,7.97V16C15.5,15.29 16.5,13.76 16.5,12M3,9V15H7L12,20V4L7,9H3Z",VOLUME_MUTE:"M3,9H7L12,4V20L7,15H3V9M16.59,12L14,9.41L15.41,8L18,10.59L20.59,8L22,9.41L19.41,12L22,14.59L20.59,16L18,13.41L15.41,16L14,14.59L16.59,12Z"},as={ARTIST:"M17.5 20q-1.05 0-1.775-.725T15 17.5t.725-1.775T17.5 15q.2 0 .45.038t.55.162V11q0-.425.288-.712T19.5 10H21q.425 0 .713.288T22 11t-.288.713T21 12h-1v5.5q0 1.05-.725 1.775T17.5 20M11 12q-1.65 0-2.825-1.175T7 8t1.175-2.825T11 4t2.825 1.175T15 8t-1.175 2.825T11 12m-7 8q-.425 0-.712-.288T3 19v-1.8q0-.875.438-1.575T4.6 14.55q1.55-.775 3.15-1.162T11 13q.7 0 1.388.075t1.387.225q.425.1.537.525t-.237.775q-.525.625-.788 1.363t-.262 1.537q0 .325.038.638t.137.637q.125.45-.112.838t-.663.387z",ALBUM:"M12 16.5q1.875 0 3.188-1.312T16.5 12t-1.312-3.187T12 7.5T8.813 8.813T7.5 12t1.313 3.188T12 16.5m0-3.5q-.425 0-.712-.288T11 12t.288-.712T12 11t.713.288T13 12t-.288.713T12 13m0 9q-2.075 0-3.9-.788t-3.175-2.137T2.788 15.9T2 12t.788-3.9t2.137-3.175T8.1 2.788T12 2t3.9.788t3.175 2.137T21.213 8.1T22 12t-.788 3.9t-2.137 3.175t-3.175 2.138T12 22",ARROW_DOWN:"M11 16.175V5q0-.425.288-.712T12 4t.713.288T13 5v11.175l4.9-4.9q.3-.3.7-.288t.7.313q.275.3.287.7t-.287.7l-6.6 6.6q-.15.15-.325.213t-.375.062t-.375-.062t-.325-.213l-6.6-6.6q-.275-.275-.275-.687T4.7 11.3q.3-.3.713-.3t.712.3z",ARROW_LEFT:"m7.85 13l2.85 2.85q.3.3.288.7t-.288.7q-.3.3-.712.313t-.713-.288L4.7 12.7q-.3-.3-.3-.7t.3-.7l4.575-4.575q.3-.3.713-.287t.712.312q.275.3.288.7t-.288.7L7.85 11H19q.425 0 .713.288T20 12t-.288.713T19 13z",ARROW_PLAY_NEXT:"M5 5q-.425 0-.712-.288T4 4t.288-.712T5 3h14q.425 0 .713.288T20 4t-.288.713T19 5zm7 16q-.425 0-.712-.288T11 20v-9.2l-1.9 1.9q-.275.275-.7.275t-.7-.275t-.275-.7t.275-.7l3.6-3.6q.15-.15.325-.212T12 7.425t.375.063t.325.212l3.6 3.6q.275.275.275.7t-.275.7t-.7.275t-.7-.275L13 10.8V20q0 .425-.287.713T12 21",ARROW_UP:"m11 7.825l-4.9 4.9q-.3.3-.7.288t-.7-.313q-.275-.3-.288-.7t.288-.7l6.6-6.6q.15-.15.325-.212T12 4.425t.375.063t.325.212l6.6 6.6q.275.275.275.688t-.275.712q-.3.3-.712.3t-.713-.3L13 7.825V19q0 .425-.288.713T12 20t-.712-.288T11 19z",ASLEEP:"M12.075 22q-2.1 0-3.937-.8t-3.2-2.162t-2.163-3.2t-.8-3.938q0-3.1 1.713-5.625t4.587-3.7q.35-.125.725-.088t.625.238q.2.175.313.488t.112.812q.05 1.975.8 3.763T13 10.975t3.2 2.15t3.775.8q.525 0 .8.088t.45.287q.2.25.263.65t-.063.725q-1.15 2.875-3.7 4.6T12.075 22M14.3 7.3l-1.6-1.6q-.3-.3-.3-.7t.3-.7l1.6-1.6q.3-.3.7-.3t.7.3l1.6 1.6q.3.3.3.7t-.3.7l-1.6 1.6q-.3.3-.7.3t-.7-.3m5 3l-.6-.6q-.3-.3-.3-.7t.3-.7l.6-.6q.3-.3.7-.3t.7.3l.6.6q.3.3.3.7t-.3.7l-.6.6q-.3.3-.7.3t-.7-.3",BOOK:"M6 22q-.825 0-1.412-.587T4 20V4q0-.825.588-1.412T6 2h12q.825 0 1.413.588T20 4v16q0 .825-.587 1.413T18 22zm5-18v6.125q0 .3.238.438t.512-.013l1.225-.725q.25-.15.513-.15t.512.15l1.225.725q.275.15.525.013t.25-.438V4z",CLEAR:"m17 19.4l-1.9 1.9q-.275.275-.7.275t-.7-.275t-.275-.7t.275-.7l1.9-1.9l-1.9-1.9q-.275-.275-.275-.7t.275-.7t.7-.275t.7.275l1.9 1.9l1.9-1.9q.275-.275.7-.275t.7.275t.275.7t-.275.7L18.4 18l1.9 1.9q.275.275.275.7t-.275.7t-.7.275t-.7-.275zM4 16q-.425 0-.712-.288T3 15t.288-.712T4 14h5q.425 0 .713.288T10 15t-.288.713T9 16zm0-4q-.425 0-.712-.288T3 11t.288-.712T4 10h9q.425 0 .713.288T14 11t-.288.713T13 12zm0-4q-.425 0-.712-.288T3 7t.288-.712T4 6h9q.425 0 .713.288T14 7t-.288.713T13 8z",CLOSE:"m12 13.4l-4.9 4.9q-.275.275-.7.275t-.7-.275t-.275-.7t.275-.7l4.9-4.9l-4.9-4.9q-.275-.275-.275-.7t.275-.7t.7-.275t.7.275l4.9 4.9l4.9-4.9q.275-.275.7-.275t.7.275t.275.7t-.275.7L13.4 12l4.9 4.9q.275.275.275.7t-.275.7t-.7.275t-.7-.275z",FILTER:"M11 18q-.425 0-.712-.288T10 17t.288-.712T11 16h2q.425 0 .713.288T14 17t-.288.713T13 18zm-4-5q-.425 0-.712-.288T6 12t.288-.712T7 11h10q.425 0 .713.288T18 12t-.288.713T17 13zM4 8q-.425 0-.712-.288T3 7t.288-.712T4 6h16q.425 0 .713.288T21 7t-.288.713T20 8z",HEART:"M12 20.325q-.35 0-.712-.125t-.638-.4l-1.725-1.575q-2.65-2.425-4.788-4.812T2 8.15Q2 5.8 3.575 4.225T7.5 2.65q1.325 0 2.5.562t2 1.538q.825-.975 2-1.537t2.5-.563q2.35 0 3.925 1.575T22 8.15q0 2.875-2.125 5.275T15.05 18.25l-1.7 1.55q-.275.275-.637.4t-.713.125",HEART_PLUS:"M1 8.475q0-2.35 1.575-3.912T6.5 3q1.3 0 2.475.55T11 5.1q.85-1 2.025-1.55T15.5 3q1.775 0 3.05.888t1.925 2.287q.175.375.025.763t-.525.562t-.763.025T18.65 7q-.45-1-1.325-1.5T15.5 5q-1.15 0-2.1.65t-1.65 1.6q-.125.2-.325.288T11 7.624t-.425-.1t-.325-.275q-.7-.95-1.65-1.6T6.5 5q-1.425 0-2.462.988T3 8.474q0 .825.35 1.675t1.25 1.963t2.45 2.6T11 18.3l2.225-1.95q.3-.275.7-.25t.675.3q.3.3.288.738t-.338.712l-2.225 1.975q-.275.25-.625.375t-.7.125t-.7-.125t-.625-.4q-1.125-1-2.612-2.275t-2.838-2.737t-2.287-3.063T1 8.475M18 14h-2q-.425 0-.712-.288T15 13t.288-.712T16 12h2v-2q0-.425.288-.712T19 9t.713.288T20 10v2h2q.425 0 .713.288T23 13t-.288.713T22 14h-2v2q0 .425-.288.713T19 17t-.712-.288T18 16z",LIBRARY:"M3 17.15V10q0-.8.588-1.35t1.387-.5q1.975.3 3.763 1.163T12 11.55q1.475-1.375 3.263-2.238t3.762-1.162q.8-.05 1.388.5T21 10v7.15q0 .8-.525 1.363t-1.325.612q-1.6.25-3.1.825t-2.8 1.525q-.275.225-.587.337t-.663.113t-.663-.112t-.587-.338q-1.3-.95-2.8-1.525t-3.1-.825q-.8-.05-1.325-.612T3 17.15M12 9q-1.65 0-2.825-1.175T8 5t1.175-2.825T12 1t2.825 1.175T16 5t-1.175 2.825T12 9",LIBRARY_OUTLINED:"M3 17.15V10q0-.8.588-1.35t1.387-.5q1.975.3 3.763 1.163T12 11.55q1.475-1.375 3.263-2.238t3.762-1.162q.8-.05 1.388.5T21 10v7.15q0 .8-.525 1.363t-1.325.612q-1.6.25-3.1.825t-2.8 1.525q-.275.225-.587.337t-.663.113t-.663-.112t-.587-.338q-1.3-.95-2.8-1.525t-3.1-.825q-.8-.05-1.325-.612T3 17.15m9 2.75q1.575-1.175 3.35-1.875T19 17.1v-6.9q-1.825.325-3.588 1.313T12 14.15q-1.65-1.65-3.412-2.637T5 10.2v6.9q1.875.225 3.65.925T12 19.9M12 9q-1.65 0-2.825-1.175T8 5t1.175-2.825T12 1t2.825 1.175T16 5t-1.175 2.825T12 9m0-2q.825 0 1.413-.587T14 5t-.587-1.412T12 3t-1.412.588T10 5t.588 1.413T12 7m0 7.15",LINK:"M17 17h-2.025q-.425 0-.7-.288T14 16t.288-.712T15 15h2v-2q0-.425.288-.712T18 12t.713.288T19 13v2h2q.425 0 .713.288T22 16t-.288.713T21 17h-2v2q0 .425-.288.713T18 20t-.712-.288T17 19zm-7 0H7q-2.075 0-3.537-1.463T2 12t1.463-3.537T7 7h3q.425 0 .713.288T11 8t-.288.713T10 9H7q-1.25 0-2.125.875T4 12t.875 2.125T7 15h3q.425 0 .713.288T11 16t-.288.713T10 17m-1-4q-.425 0-.712-.288T8 12t.288-.712T9 11h6q.425 0 .713.288T16 12t-.288.713T15 13zm13-1h-2q0-1.25-.875-2.125T17 9h-3.025q-.425 0-.7-.288T13 8t.288-.712T14 7h3q2.075 0 3.538 1.463T22 12",LINK_OFF:"M15.625 12.775L13.85 11H15q.425 0 .713.288T16 12q0 .25-.1.45t-.275.325M20.5 21.9q-.275.275-.7.275t-.7-.275l-17-17q-.275-.275-.275-.7t.275-.7t.7-.275t.7.275l17 17q.275.275.275.7t-.275.7M7 17q-2.075 0-3.537-1.463T2 12q0-1.725 1.05-3.075t2.7-1.775L7.6 9H7q-1.25 0-2.125.875T4 12t.875 2.125T7 15h3q.425 0 .713.288T11 16t-.288.713T10 17zm2-4q-.425 0-.712-.288T8 12t.288-.712T9 11h.625l1.975 2zm9.5 2.8q-.225-.35-.162-.75t.412-.625q.575-.425.913-1.05T20 12q0-1.25-.875-2.125T17 9h-3q-.425 0-.712-.288T13 8t.288-.712T14 7h3q2.075 0 3.538 1.463T22 12q0 1.225-.562 2.288t-1.563 1.762q-.35.225-.75.163T18.5 15.8",MUSIC:"M10 21q-1.65 0-2.825-1.175T6 17t1.175-2.825T10 13q.575 0 1.063.138t.937.412V4q0-.425.288-.712T13 3h4q.425 0 .713.288T18 4v2q0 .425-.288.713T17 7h-3v10q0 1.65-1.175 2.825T10 21",PAUSE:"M16 19q-.825 0-1.412-.587T14 17V7q0-.825.588-1.412T16 5t1.413.588T18 7v10q0 .825-.587 1.413T16 19m-8 0q-.825 0-1.412-.587T6 17V7q0-.825.588-1.412T8 5t1.413.588T10 7v10q0 .825-.587 1.413T8 19",PLAY:"M8 17.175V6.825q0-.425.3-.713t.7-.287q.125 0 .263.037t.262.113l8.15 5.175q.225.15.338.375t.112.475t-.112.475t-.338.375l-8.15 5.175q-.125.075-.262.113T9 18.175q-.4 0-.7-.288t-.3-.712",PLAY_CIRCLE:"m10.65 15.75l4.875-3.125q.35-.225.35-.625t-.35-.625L10.65 8.25q-.375-.25-.763-.038t-.387.663v6.25q0 .45.388.663t.762-.038M12 22q-2.075 0-3.9-.788t-3.175-2.137T2.788 15.9T2 12t.788-3.9t2.137-3.175T8.1 2.788T12 2t3.9.788t3.175 2.137T21.213 8.1T22 12t-.788 3.9t-2.137 3.175t-3.175 2.138T12 22",PLAY_CIRCLE_OUTLINE:"m10.65 15.75l4.875-3.125q.35-.225.35-.625t-.35-.625L10.65 8.25q-.375-.25-.763-.038t-.387.663v6.25q0 .45.388.663t.762-.038M12 22q-2.075 0-3.9-.788t-3.175-2.137T2.788 15.9T2 12t.788-3.9t2.137-3.175T8.1 2.788T12 2t3.9.788t3.175 2.137T21.213 8.1T22 12t-.788 3.9t-2.137 3.175t-3.175 2.138T12 22m0-2q3.35 0 5.675-2.325T20 12t-2.325-5.675T12 4T6.325 6.325T4 12t2.325 5.675T12 20m0-8",PLAYLIST:"M16 20q-1.25 0-2.125-.875T13 17t.875-2.125T16 14q.275 0 .525.038T17 14.2V7q0-.425.288-.712T18 6h3q.425 0 .713.288T22 7t-.288.713T21 8h-2v9q0 1.25-.875 2.125T16 20M4 16q-.425 0-.712-.288T3 15t.288-.712T4 14h6q.425 0 .713.288T11 15t-.288.713T10 16zm0-4q-.425 0-.712-.288T3 11t.288-.712T4 10h10q.425 0 .713.288T15 11t-.288.713T14 12zm0-4q-.425 0-.712-.288T3 7t.288-.712T4 6h10q.425 0 .713.288T15 7t-.288.713T14 8z",PLAYLIST_PLUS:"M4 16q-.425 0-.712-.288T3 15t.288-.712T4 14h5q.425 0 .713.288T10 15t-.288.713T9 16zm0-4q-.425 0-.712-.288T3 11t.288-.712T4 10h9q.425 0 .713.288T14 11t-.288.713T13 12zm0-4q-.425 0-.712-.288T3 7t.288-.712T4 6h9q.425 0 .713.288T14 7t-.288.713T13 8zm13 12q-.425 0-.712-.288T16 19v-3h-3q-.425 0-.712-.288T12 15t.288-.712T13 14h3v-3q0-.425.288-.712T17 10t.713.288T18 11v3h3q.425 0 .713.288T22 15t-.288.713T21 16h-3v3q0 .425-.288.713T17 20",PODCAST:"M11 21v-7.275q-.45-.275-.725-.712T10 12q0-.825.588-1.412T12 10t1.413.588T14 12q0 .575-.275 1.025t-.725.7V21q0 .425-.288.713T12 22t-.712-.288T11 21m-5.175-2.475q-.3.3-.725.3t-.7-.325q-1.125-1.325-1.763-2.975T2 12q0-2.075.788-3.9t2.137-3.175T8.1 2.788T12 2t3.9.788t3.175 2.137T21.213 8.1T22 12q0 1.875-.638 3.525T19.6 18.5q-.275.325-.687.338t-.713-.288q-.275-.275-.275-.7t.275-.75q.85-1.05 1.325-2.35T20 12q0-3.35-2.325-5.675T12 4T6.325 6.325T4 12q0 1.45.475 2.738t1.35 2.337q.275.325.287.738t-.287.712M8.65 15.7q-.3.3-.725.313t-.675-.338q-.575-.775-.913-1.7T6 12q0-2.5 1.75-4.25T12 6t4.25 1.75T18 12q0 1.05-.337 1.988t-.913 1.687q-.25.325-.675.338t-.725-.288q-.275-.275-.287-.7t.237-.775q.325-.5.513-1.062T16 12q0-1.65-1.175-2.825T12 8T9.175 9.175T8 12q0 .65.188 1.2t.512 1.05q.25.35.238.763t-.288.687",POWER:"M12 22q-2.075 0-3.9-.788t-3.175-2.137T2.788 15.9T2 12t.788-3.9t2.137-3.175T8.1 2.788T12 2t3.9.788t3.175 2.137T21.213 8.1T22 12t-.788 3.9t-2.137 3.175t-3.175 2.138T12 22m0-2q3.35 0 5.675-2.325T20 12t-2.325-5.675T12 4T6.325 6.325T4 12t2.325 5.675T12 20m0-2q2.5 0 4.25-1.75T18 12q0-.875-.225-1.662t-.65-1.488q-.3-.5-.712-.562t-.763.137t-.488.575t.138.75q.35.475.525 1.05T16 12q0 1.65-1.175 2.825T12 16t-2.825-1.175T8 12q0-.625.175-1.187t.5-1.038q.25-.375.125-.737t-.45-.563t-.737-.15t-.738.525q-.45.675-.663 1.475T6 12q0 2.5 1.75 4.25T12 18m0-12q-.425 0-.712.288T11 7v4q0 .425.288.713T12 12t.713-.288T13 11V7q0-.425-.288-.712T12 6m0 6",RADIO:"M4 22q-.825 0-1.412-.587T2 20V6.65l13.075-5.325q.35-.125.688.013t.462.487t-.012.688t-.488.462L8.3 6H20q.825 0 1.413.588T22 8v12q0 .825-.587 1.413T20 22zm4-3q1.05 0 1.775-.725T10.5 16.5t-.725-1.775T8 14t-1.775.725T5.5 16.5t.725 1.775T8 19m-4-8h12v-1q0-.425.288-.712T17 9t.713.288T18 10v1h2V8H4z",RECENTS:"M12 21q-3.15 0-5.575-1.912T3.275 14.2q-.1-.375.15-.687t.675-.363q.4-.05.725.15t.45.6q.6 2.25 2.475 3.675T12 19q2.925 0 4.963-2.037T19 12t-2.037-4.962T12 5q-1.725 0-3.225.8T6.25 8H8q.425 0 .713.288T9 9t-.288.713T8 10H4q-.425 0-.712-.288T3 9V5q0-.425.288-.712T4 4t.713.288T5 5v1.35q1.275-1.6 3.113-2.475T12 3q1.875 0 3.513.713t2.85 1.924t1.925 2.85T21 12t-.712 3.513t-1.925 2.85t-2.85 1.925T12 21m1-9.4l2.5 2.5q.275.275.275.7t-.275.7t-.7.275t-.7-.275l-2.8-2.8q-.15-.15-.225-.337T11 11.975V8q0-.425.288-.712T12 7t.713.288T13 8z",REPEAT:"m6.85 19l.85.85q.3.3.288.7t-.288.7q-.3.3-.712.313t-.713-.288L3.7 18.7q-.15-.15-.213-.325T3.426 18t.063-.375t.212-.325l2.575-2.575q.3-.3.713-.287t.712.312q.275.3.288.7t-.288.7l-.85.85H17v-3q0-.425.288-.712T18 13t.713.288T19 14v3q0 .825-.587 1.413T17 19zm10.3-12H7v3q0 .425-.288.713T6 11t-.712-.288T5 10V7q0-.825.588-1.412T7 5h10.15l-.85-.85q-.3-.3-.288-.7t.288-.7q.3-.3.712-.312t.713.287L20.3 5.3q.15.15.213.325t.062.375t-.062.375t-.213.325l-2.575 2.575q-.3.3-.712.288T16.3 9.25q-.275-.3-.288-.7t.288-.7z",REPEAT_OFF:"M6 12.05q0 1.175.463 2.25t1.287 1.9l.25.25V15q0-.425.288-.712T9 14t.713.288T10 15v4q0 .425-.288.713T9 20H5q-.425 0-.712-.288T4 19t.288-.712T5 18h1.75l-.4-.35q-1.125-1.125-1.737-2.575T4 12.05q0-1.1.275-2.137t.85-1.988L2.1 4.9q-.3-.3-.288-.712t.313-.713t.713-.3t.712.3l16.975 17q.3.3.3.7t-.3.7t-.712.3t-.713-.3l-3.025-3q-.275.175-.55.3l-.55.25q-.375.15-.738-.038t-.487-.612t.1-.762t.625-.538q.275-.125.5-.275t.475-.3l-.65.7l-8.2-8.2q-.275.625-.438 1.288T6 12.05m12.925 3.975l-1.5-1.5q.275-.6.425-1.25T18 11.95q0-1.175-.462-2.25T16.25 7.8L16 7.55V9q0 .425-.288.713T15 10t-.712-.288T14 9V5q0-.425.288-.712T15 4h4q.425 0 .713.288T20 5t-.288.713T19 6h-1.75l.4.35q1.125 1.125 1.738 2.575T20 11.95q0 1.075-.275 2.1t-.8 1.975m-9.45-9.45l-1.5-1.5q.275-.15.525-.263t.525-.237q.4-.15.75.037t.475.613q.1.4-.112.75t-.588.55q-.025.025-.038.025t-.037.025",REPEAT_ONCE:"M11.5 10.5h-.75q-.325 0-.537-.213T10 9.75t.213-.537T10.75 9H12q.425 0 .713.288T13 10v4.25q0 .325-.213.538T12.25 15t-.537-.213t-.213-.537zM6.85 19l.85.85q.3.3.288.7t-.288.7q-.3.3-.712.313t-.713-.288L3.7 18.7q-.15-.15-.213-.325T3.426 18t.063-.375t.212-.325l2.575-2.575q.3-.3.713-.287t.712.312q.275.3.288.7t-.288.7l-.85.85H17v-3q0-.425.288-.712T18 13t.713.288T19 14v3q0 .825-.587 1.413T17 19zm10.3-12H7v3q0 .425-.288.713T6 11t-.712-.288T5 10V7q0-.825.588-1.412T7 5h10.15l-.85-.85q-.3-.3-.288-.7t.288-.7q.3-.3.712-.312t.713.287L20.3 5.3q.15.15.213.325t.062.375t-.062.375t-.213.325l-2.575 2.575q-.3.3-.712.288T16.3 9.25q-.275-.3-.288-.7t.288-.7z",SEARCH:"M9.5 16q-2.725 0-4.612-1.888T3 9.5t1.888-4.612T9.5 3t4.613 1.888T16 9.5q0 1.1-.35 2.075T14.7 13.3l5.6 5.6q.275.275.275.7t-.275.7t-.7.275t-.7-.275l-5.6-5.6q-.75.6-1.725.95T9.5 16m0-2q1.875 0 3.188-1.312T14 9.5t-1.312-3.187T9.5 5T6.313 6.313T5 9.5t1.313 3.188T9.5 14",SHUFFLE:"M15 20q-.425 0-.712-.288T14 19t.288-.712T15 18h1.6l-2.475-2.475q-.3-.3-.287-.712t.312-.713t.713-.3t.712.3L18 16.55V15q0-.425.288-.712T19 14t.713.288T20 15v4q0 .425-.288.713T19 20zm-10.7-.3q-.275-.275-.275-.7t.275-.7L16.6 6H15q-.425 0-.712-.288T14 5t.288-.712T15 4h4q.425 0 .713.288T20 5v4q0 .425-.288.713T19 10t-.712-.288T18 9V7.4L5.7 19.7q-.275.275-.7.275t-.7-.275m-.025-14Q4 5.425 4 5t.275-.7t.687-.275t.713.275l4.2 4.175q.275.275.288.688t-.288.712q-.275.275-.7.275t-.7-.275z",SHUFFLE_DISABLED:"m5.825 17l1.9 1.9q.3.3.288.7t-.313.7q-.3.275-.7.288t-.7-.288l-3.6-3.6q-.15-.15-.213-.325T2.426 16t.063-.375t.212-.325l3.6-3.6q.275-.275.688-.275t.712.275q.3.3.3.713t-.3.712L5.825 15H20q.425 0 .713.288T21 16t-.288.713T20 17zm12.35-8H4q-.425 0-.712-.288T3 8t.288-.712T4 7h14.175l-1.9-1.9q-.3-.3-.287-.7t.312-.7q.3-.275.7-.288t.7.288l3.6 3.6q.15.15.213.325t.062.375t-.062.375t-.213.325l-3.6 3.6q-.275.275-.687.275T16.3 12.3q-.3-.3-.3-.712t.3-.713z",SKIP_NEXT:"M16.5 17V7q0-.425.288-.712T17.5 6t.713.288T18.5 7v10q0 .425-.288.713T17.5 18t-.712-.288T16.5 17m-11-.875v-8.25q0-.45.3-.725t.7-.275q.125 0 .275.025t.275.125l6.2 4.15q.225.15.338.363T13.7 12t-.112.463t-.338.362l-6.2 4.15q-.125.1-.275.125t-.275.025q-.4 0-.7-.275t-.3-.725",SKIP_NEXT_CIRCLE:"M16.5 17V7q0-.425.288-.712T17.5 6t.713.288T18.5 7v10q0 .425-.288.713T17.5 18t-.712-.288T16.5 17m-11-.875v-8.25q0-.45.3-.725t.7-.275q.125 0 .275.025t.275.125l6.2 4.15q.225.15.338.363T13.7 12t-.112.463t-.338.362l-6.2 4.15q-.125.1-.275.125t-.275.025q-.4 0-.7-.275t-.3-.725",SKIP_NEXT_CIRCLE_OUTLINED:"M16.5 17V7q0-.425.288-.712T17.5 6t.713.288T18.5 7v10q0 .425-.288.713T17.5 18t-.712-.288T16.5 17m-11-.875v-8.25q0-.45.3-.725t.7-.275q.125 0 .275.025t.275.125l6.2 4.15q.225.15.338.363T13.7 12t-.112.463t-.338.362l-6.2 4.15q-.125.1-.275.125t-.275.025q-.4 0-.7-.275t-.3-.725m2-1.875L10.9 12L7.5 9.75z",SKIP_PREVIOUS:"M5.5 17V7q0-.425.288-.712T6.5 6t.713.288T7.5 7v10q0 .425-.288.713T6.5 18t-.712-.288T5.5 17m11.45-.025l-6.2-4.15q-.225-.15-.337-.362T10.3 12t.113-.462t.337-.363l6.2-4.15q.125-.1.275-.125t.275-.025q.4 0 .7.275t.3.725v8.25q0 .45-.3.725t-.7.275q-.125 0-.275-.025t-.275-.125",SPEAKER:"M17 22H7q-.825 0-1.412-.587T5 20V4q0-.825.588-1.412T7 2h10q.825 0 1.413.588T19 4v16q0 .825-.587 1.413T17 22M12 9q.825 0 1.413-.587T14 7t-.587-1.412T12 5t-1.412.588T10 7t.588 1.413T12 9m0 10q1.65 0 2.825-1.175T16 15t-1.175-2.825T12 11t-2.825 1.175T8 15t1.175 2.825T12 19m0-2q-.825 0-1.412-.587T10 15t.588-1.412T12 13t1.413.588T14 15t-.587 1.413T12 17",SPEAKER_MULTIPLE:"M10 19q-.825 0-1.412-.587T8 17V3q0-.825.588-1.412T10 1h9q.825 0 1.413.588T21 3v14q0 .825-.587 1.413T19 19zm4.5-11.5q.625 0 1.063-.437T16 6t-.437-1.062T14.5 4.5t-1.062.438T13 6t.438 1.063T14.5 7.5m0 8.5q1.45 0 2.475-1.025T18 12.5t-1.025-2.475T14.5 9t-2.475 1.025T11 12.5t1.025 2.475T14.5 16m0-2q-.625 0-1.062-.437T13 12.5t.438-1.062T14.5 11t1.063.438T16 12.5t-.437 1.063T14.5 14m.5 9H6q-.825 0-1.412-.587T4 21V6q0-.425.288-.712T5 5t.713.288T6 6v15h9q.425 0 .713.288T16 22t-.288.713T15 23",SUGGESTIONS:"M5.7 21.875q-.825.125-1.487-.387T3.45 20.15L2.125 9.225q-.1-.825.4-1.475T3.85 7L5 6.85V15q0 1.65 1.175 2.825T9 19h9.3q-.15.6-.6 1.038t-1.1.512zM9 17q-.825 0-1.412-.587T7 15V4q0-.825.588-1.412T9 2h11q.825 0 1.413.588T22 4v11q0 .825-.587 1.413T20 17zm3.725-4.8l1.775-1.075l1.775 1.075q.15.1.288 0t.087-.275L16.175 9.9l1.55-1.35q.125-.125.087-.263t-.212-.162l-2.05-.175l-.825-1.9q-.05-.15-.225-.15t-.225.15l-.825 1.9l-2.05.175q-.175.025-.212.163t.087.262l1.55 1.35l-.475 2.025q-.05.175.088.275t.287 0",SWAP:"M5.825 16L7.7 17.875q.275.275.275.688t-.275.712q-.3.3-.712.3t-.713-.3L2.7 15.7q-.15-.15-.213-.325T2.426 15t.063-.375t.212-.325l3.6-3.6q.3-.3.7-.287t.7.312q.275.3.288.7t-.288.7L5.825 14H12q.425 0 .713.288T13 15t-.288.713T12 16zm12.35-6H12q-.425 0-.712-.288T11 9t.288-.712T12 8h6.175L16.3 6.125q-.275-.275-.275-.687t.275-.713q.3-.3.713-.3t.712.3L21.3 8.3q.15.15.212.325t.063.375t-.063.375t-.212.325l-3.6 3.6q-.3.3-.7.288t-.7-.313q-.275-.3-.288-.7t.288-.7z",VOLUME_HIGH:"M19 11.975q0-2.075-1.1-3.787t-2.95-2.563q-.375-.175-.55-.537t-.05-.738q.15-.4.538-.575t.787 0Q18.1 4.85 19.55 7.063T21 11.974t-1.45 4.913t-3.875 3.287q-.4.175-.788 0t-.537-.575q-.125-.375.05-.737t.55-.538q1.85-.85 2.95-2.562t1.1-3.788M7 15H4q-.425 0-.712-.288T3 14v-4q0-.425.288-.712T4 9h3l3.3-3.3q.475-.475 1.088-.213t.612.938v11.15q0 .675-.612.938T10.3 18.3zm9.5-3q0 1.05-.475 1.988t-1.25 1.537q-.25.15-.513.013T14 15.1V8.85q0-.3.263-.437t.512.012q.775.625 1.25 1.575t.475 2",VOLUME_MUTE:"M16.775 19.575q-.275.175-.55.325t-.575.275q-.375.175-.762 0t-.538-.575q-.15-.375.038-.737t.562-.538q.1-.05.188-.1t.187-.1L12 14.8v2.775q0 .675-.612.938T10.3 18.3L7 15H4q-.425 0-.712-.288T3 14v-4q0-.425.288-.712T4 9h2.2L2.1 4.9q-.275-.275-.275-.7t.275-.7t.7-.275t.7.275l17 17q.275.275.275.7t-.275.7t-.7.275t-.7-.275zm2.225-7.6q0-2.075-1.1-3.787t-2.95-2.563q-.375-.175-.55-.537t-.05-.738q.15-.4.538-.575t.787 0Q18.1 4.85 19.55 7.05T21 11.975q0 .825-.15 1.638t-.425 1.562q-.2.55-.612.688t-.763.012t-.562-.45t-.013-.75q.275-.65.4-1.312T19 11.975m-4.225-3.55Q15.6 8.95 16.05 10t.45 2v.25q0 .125-.025.25q-.05.325-.35.425t-.55-.15L14.3 11.5q-.15-.15-.225-.337T14 10.775V8.85q0-.3.263-.437t.512.012M9.75 6.95Q9.6 6.8 9.6 6.6t.15-.35l.55-.55q.475-.475 1.087-.213t.613.938V8q0 .35-.3.475t-.55-.125z"};class cs{constructor(e){this._host=e,this._entitiesConfig=new s(e,{context:Qi}),this._mediaBrowserConfig=new s(e,{context:ki}),this._playerQueueConfig=new s(e,{context:Ri}),this._musicPlayerConfig=new s(e,{context:Di}),this._playersConfig=new s(e,{context:xi}),this._icons=new s(e,{context:Ji})}set config(e){if(tr(this._config,e))return;const t=As(e);this._config=t,this._entitiesConfig.value=t.entities,this._playerQueueConfig.value=t.queue,this._musicPlayerConfig.value=t.player,this._playersConfig.value=t.players,this._mediaBrowserConfig.value=t.media_browser,this.Icons=t.expressive?as:ns}get config(){return this._config}set Icons(e){this._icons.setValue(e)}get Icons(){return this._icons.value}get Entities(){return this.config.entities}get MediaBrowser(){return this.config.media_browser}get PlayerQueue(){return this.config.queue}get MusicPlayer(){return this.config.player}get Players(){return this.config.players}}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ls(e){return e<0?-1:0===e?0:1}function ds(e,t,i){return(1-i)*e+i*t}function us(e,t,i){return i<e?e:i>t?t:i}function hs(e){return(e%=360)<0&&(e+=360),e}function gs(e){return(e%=360)<0&&(e+=360),e}function ps(e,t){return 180-Math.abs(Math.abs(e-t)-180)}function vs(e,t){return[e[0]*t[0][0]+e[1]*t[0][1]+e[2]*t[0][2],e[0]*t[1][0]+e[1]*t[1][1]+e[2]*t[1][2],e[0]*t[2][0]+e[1]*t[2][1]+e[2]*t[2][2]]}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ms=[[.41233895,.35762064,.18051042],[.2126,.7152,.0722],[.01932141,.11916382,.95034478]],ws=[[3.2413774792388685,-1.5376652402851851,-.49885366846268053],[-.9691452513005321,1.8758853451067872,.04156585616912061],[.05562093689691305,-.20395524564742123,1.0571799111220335]],fs=[95.047,100,108.883];function Es(e,t,i){return(255<<24|(255&e)<<16|(255&t)<<8|255&i)>>>0}function Cs(e){return Es(Ps(e[0]),Ps(e[1]),Ps(e[2]))}function Bs(e){return e>>24&255}function bs(e){return e>>16&255}function Is(e){return e>>8&255}function ys(e){return 255&e}function Qs(e,t,i){const r=ws,A=r[0][0]*e+r[0][1]*t+r[0][2]*i,s=r[1][0]*e+r[1][1]*t+r[1][2]*i,o=r[2][0]*e+r[2][1]*t+r[2][2]*i;return Es(Ps(A),Ps(s),Ps(o))}function Ds(e){const t=function(e){return vs([xs(bs(e)),xs(Is(e)),xs(ys(e))],ms)}(e)[1];return 116*Ms(t/100)-16}function Rs(e){return 100*Hs((e+16)/116)}function ks(e){return 116*Ms(e/100)-16}function xs(e){const t=e/255;return t<=.040449936?t/12.92*100:100*Math.pow((t+.055)/1.055,2.4)}function Ps(e){const t=e/100;let i=0;return i=t<=.0031308?12.92*t:1.055*Math.pow(t,1/2.4)-.055,r=0,A=255,(s=Math.round(255*i))<r?r:s>A?A:s;var r,A,s}function Ms(e){const t=24389/27;return e>216/24389?Math.pow(e,1/3):(t*e+16)/116}function Hs(e){const t=e*e*e;return t>216/24389?t:(116*e-16)/(24389/27)}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ss{static make(e=function(){return fs}(),t=200/Math.PI*Rs(50)/100,i=50,r=2,A=!1){const s=e,o=.401288*s[0]+.650173*s[1]+-.051461*s[2],n=-.250268*s[0]+1.204414*s[1]+.045854*s[2],a=-.002079*s[0]+.048952*s[1]+.953127*s[2],c=.8+r/10,l=c>=.9?ds(.59,.69,10*(c-.9)):ds(.525,.59,10*(c-.8));let d=A?1:c*(1-1/3.6*Math.exp((-t-42)/92));d=d>1?1:d<0?0:d;const u=c,h=[d*(100/o)+1-d,d*(100/n)+1-d,d*(100/a)+1-d],g=1/(5*t+1),p=g*g*g*g,v=1-p,m=p*t+.1*v*v*Math.cbrt(5*t),w=Rs(i)/e[1],f=1.48+Math.sqrt(w),E=.725/Math.pow(w,.2),C=E,B=[Math.pow(m*h[0]*o/100,.42),Math.pow(m*h[1]*n/100,.42),Math.pow(m*h[2]*a/100,.42)],b=[400*B[0]/(B[0]+27.13),400*B[1]/(B[1]+27.13),400*B[2]/(B[2]+27.13)];return new Ss(w,(2*b[0]+b[1]+.05*b[2])*E,E,C,l,u,h,m,Math.pow(m,.25),f)}constructor(e,t,i,r,A,s,o,n,a,c){this.n=e,this.aw=t,this.nbb=i,this.ncb=r,this.c=A,this.nc=s,this.rgbD=o,this.fl=n,this.fLRoot=a,this.z=c}}Ss.DEFAULT=Ss.make();
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Os{constructor(e,t,i,r,A,s,o,n,a){this.hue=e,this.chroma=t,this.j=i,this.q=r,this.m=A,this.s=s,this.jstar=o,this.astar=n,this.bstar=a}distance(e){const t=this.jstar-e.jstar,i=this.astar-e.astar,r=this.bstar-e.bstar,A=Math.sqrt(t*t+i*i+r*r);return 1.41*Math.pow(A,.63)}static fromInt(e){return Os.fromIntInViewingConditions(e,Ss.DEFAULT)}static fromIntInViewingConditions(e,t){const i=(65280&e)>>8,r=255&e,A=xs((16711680&e)>>16),s=xs(i),o=xs(r),n=.41233895*A+.35762064*s+.18051042*o,a=.2126*A+.7152*s+.0722*o,c=.01932141*A+.11916382*s+.95034478*o,l=.401288*n+.650173*a-.051461*c,d=-.250268*n+1.204414*a+.045854*c,u=-.002079*n+.048952*a+.953127*c,h=t.rgbD[0]*l,g=t.rgbD[1]*d,p=t.rgbD[2]*u,v=Math.pow(t.fl*Math.abs(h)/100,.42),m=Math.pow(t.fl*Math.abs(g)/100,.42),w=Math.pow(t.fl*Math.abs(p)/100,.42),f=400*ls(h)*v/(v+27.13),E=400*ls(g)*m/(m+27.13),C=400*ls(p)*w/(w+27.13),B=(11*f+-12*E+C)/11,b=(f+E-2*C)/9,I=(20*f+20*E+21*C)/20,y=(40*f+20*E+C)/20,Q=180*Math.atan2(b,B)/Math.PI,D=Q<0?Q+360:Q>=360?Q-360:Q,R=D*Math.PI/180,k=y*t.nbb,x=100*Math.pow(k/t.aw,t.c*t.z),P=4/t.c*Math.sqrt(x/100)*(t.aw+4)*t.fLRoot,M=D<20.14?D+360:D,H=5e4/13*(.25*(Math.cos(M*Math.PI/180+2)+3.8))*t.nc*t.ncb*Math.sqrt(B*B+b*b)/(I+.305),S=Math.pow(H,.9)*Math.pow(1.64-Math.pow(.29,t.n),.73),O=S*Math.sqrt(x/100),q=O*t.fLRoot,L=50*Math.sqrt(S*t.c/(t.aw+4)),U=(1+100*.007)*x/(1+.007*x),T=1/.0228*Math.log(1+.0228*q),J=T*Math.cos(R),V=T*Math.sin(R);return new Os(D,O,x,P,q,L,U,J,V)}static fromJch(e,t,i){return Os.fromJchInViewingConditions(e,t,i,Ss.DEFAULT)}static fromJchInViewingConditions(e,t,i,r){const A=4/r.c*Math.sqrt(e/100)*(r.aw+4)*r.fLRoot,s=t*r.fLRoot,o=t/Math.sqrt(e/100),n=50*Math.sqrt(o*r.c/(r.aw+4)),a=i*Math.PI/180,c=(1+100*.007)*e/(1+.007*e),l=1/.0228*Math.log(1+.0228*s),d=l*Math.cos(a),u=l*Math.sin(a);return new Os(i,t,e,A,s,n,c,d,u)}static fromUcs(e,t,i){return Os.fromUcsInViewingConditions(e,t,i,Ss.DEFAULT)}static fromUcsInViewingConditions(e,t,i,r){const A=t,s=i,o=Math.sqrt(A*A+s*s),n=(Math.exp(.0228*o)-1)/.0228/r.fLRoot;let a=Math.atan2(s,A)*(180/Math.PI);a<0&&(a+=360);const c=e/(1-.007*(e-100));return Os.fromJchInViewingConditions(c,n,a,r)}toInt(){return this.viewed(Ss.DEFAULT)}viewed(e){const t=0===this.chroma||0===this.j?0:this.chroma/Math.sqrt(this.j/100),i=Math.pow(t/Math.pow(1.64-Math.pow(.29,e.n),.73),1/.9),r=this.hue*Math.PI/180,A=.25*(Math.cos(r+2)+3.8),s=e.aw*Math.pow(this.j/100,1/e.c/e.z),o=A*(5e4/13)*e.nc*e.ncb,n=s/e.nbb,a=Math.sin(r),c=Math.cos(r),l=23*(n+.305)*i/(23*o+11*i*c+108*i*a),d=l*c,u=l*a,h=(460*n+451*d+288*u)/1403,g=(460*n-891*d-261*u)/1403,p=(460*n-220*d-6300*u)/1403,v=Math.max(0,27.13*Math.abs(h)/(400-Math.abs(h))),m=ls(h)*(100/e.fl)*Math.pow(v,1/.42),w=Math.max(0,27.13*Math.abs(g)/(400-Math.abs(g))),f=ls(g)*(100/e.fl)*Math.pow(w,1/.42),E=Math.max(0,27.13*Math.abs(p)/(400-Math.abs(p))),C=ls(p)*(100/e.fl)*Math.pow(E,1/.42),B=m/e.rgbD[0],b=f/e.rgbD[1],I=C/e.rgbD[2];return Qs(1.86206786*B-1.01125463*b+.14918677*I,.38752654*B+.62144744*b-.00897398*I,-.0158415*B-.03412294*b+1.04996444*I)}static fromXyzInViewingConditions(e,t,i,r){const A=.401288*e+.650173*t-.051461*i,s=-.250268*e+1.204414*t+.045854*i,o=-.002079*e+.048952*t+.953127*i,n=r.rgbD[0]*A,a=r.rgbD[1]*s,c=r.rgbD[2]*o,l=Math.pow(r.fl*Math.abs(n)/100,.42),d=Math.pow(r.fl*Math.abs(a)/100,.42),u=Math.pow(r.fl*Math.abs(c)/100,.42),h=400*ls(n)*l/(l+27.13),g=400*ls(a)*d/(d+27.13),p=400*ls(c)*u/(u+27.13),v=(11*h+-12*g+p)/11,m=(h+g-2*p)/9,w=(20*h+20*g+21*p)/20,f=(40*h+20*g+p)/20,E=180*Math.atan2(m,v)/Math.PI,C=E<0?E+360:E>=360?E-360:E,B=C*Math.PI/180,b=f*r.nbb,I=100*Math.pow(b/r.aw,r.c*r.z),y=4/r.c*Math.sqrt(I/100)*(r.aw+4)*r.fLRoot,Q=C<20.14?C+360:C,D=5e4/13*(1/4*(Math.cos(Q*Math.PI/180+2)+3.8))*r.nc*r.ncb*Math.sqrt(v*v+m*m)/(w+.305),R=Math.pow(D,.9)*Math.pow(1.64-Math.pow(.29,r.n),.73),k=R*Math.sqrt(I/100),x=k*r.fLRoot,P=50*Math.sqrt(R*r.c/(r.aw+4)),M=(1+100*.007)*I/(1+.007*I),H=Math.log(1+.0228*x)/.0228,S=H*Math.cos(B),O=H*Math.sin(B);return new Os(C,k,I,y,x,P,M,S,O)}xyzInViewingConditions(e){const t=0===this.chroma||0===this.j?0:this.chroma/Math.sqrt(this.j/100),i=Math.pow(t/Math.pow(1.64-Math.pow(.29,e.n),.73),1/.9),r=this.hue*Math.PI/180,A=.25*(Math.cos(r+2)+3.8),s=e.aw*Math.pow(this.j/100,1/e.c/e.z),o=A*(5e4/13)*e.nc*e.ncb,n=s/e.nbb,a=Math.sin(r),c=Math.cos(r),l=23*(n+.305)*i/(23*o+11*i*c+108*i*a),d=l*c,u=l*a,h=(460*n+451*d+288*u)/1403,g=(460*n-891*d-261*u)/1403,p=(460*n-220*d-6300*u)/1403,v=Math.max(0,27.13*Math.abs(h)/(400-Math.abs(h))),m=ls(h)*(100/e.fl)*Math.pow(v,1/.42),w=Math.max(0,27.13*Math.abs(g)/(400-Math.abs(g))),f=ls(g)*(100/e.fl)*Math.pow(w,1/.42),E=Math.max(0,27.13*Math.abs(p)/(400-Math.abs(p))),C=ls(p)*(100/e.fl)*Math.pow(E,1/.42),B=m/e.rgbD[0],b=f/e.rgbD[1],I=C/e.rgbD[2];return[1.86206786*B-1.01125463*b+.14918677*I,.38752654*B+.62144744*b-.00897398*I,-.0158415*B-.03412294*b+1.04996444*I]}}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qs{static sanitizeRadians(e){return(e+8*Math.PI)%(2*Math.PI)}static trueDelinearized(e){const t=e/100;let i=0;return i=t<=.0031308?12.92*t:1.055*Math.pow(t,1/2.4)-.055,255*i}static chromaticAdaptation(e){const t=Math.pow(Math.abs(e),.42);return 400*ls(e)*t/(t+27.13)}static hueOf(e){const t=vs(e,qs.SCALED_DISCOUNT_FROM_LINRGB),i=qs.chromaticAdaptation(t[0]),r=qs.chromaticAdaptation(t[1]),A=qs.chromaticAdaptation(t[2]),s=(11*i+-12*r+A)/11,o=(i+r-2*A)/9;return Math.atan2(o,s)}static areInCyclicOrder(e,t,i){return qs.sanitizeRadians(t-e)<qs.sanitizeRadians(i-e)}static intercept(e,t,i){return(t-e)/(i-e)}static lerpPoint(e,t,i){return[e[0]+(i[0]-e[0])*t,e[1]+(i[1]-e[1])*t,e[2]+(i[2]-e[2])*t]}static setCoordinate(e,t,i,r){const A=qs.intercept(e[r],t,i[r]);return qs.lerpPoint(e,A,i)}static isBounded(e){return 0<=e&&e<=100}static nthVertex(e,t){const i=qs.Y_FROM_LINRGB[0],r=qs.Y_FROM_LINRGB[1],A=qs.Y_FROM_LINRGB[2],s=t%4<=1?0:100,o=t%2==0?0:100;if(t<4){const t=s,n=o,a=(e-t*r-n*A)/i;return qs.isBounded(a)?[a,t,n]:[-1,-1,-1]}if(t<8){const t=s,n=o,a=(e-n*i-t*A)/r;return qs.isBounded(a)?[n,a,t]:[-1,-1,-1]}{const t=s,n=o,a=(e-t*i-n*r)/A;return qs.isBounded(a)?[t,n,a]:[-1,-1,-1]}}static bisectToSegment(e,t){let i=[-1,-1,-1],r=i,A=0,s=0,o=!1,n=!0;for(let a=0;a<12;a++){const c=qs.nthVertex(e,a);if(c[0]<0)continue;const l=qs.hueOf(c);o?(n||qs.areInCyclicOrder(A,l,s))&&(n=!1,qs.areInCyclicOrder(A,t,l)?(r=c,s=l):(i=c,A=l)):(i=c,r=c,A=l,s=l,o=!0)}return[i,r]}static midpoint(e,t){return[(e[0]+t[0])/2,(e[1]+t[1])/2,(e[2]+t[2])/2]}static criticalPlaneBelow(e){return Math.floor(e-.5)}static criticalPlaneAbove(e){return Math.ceil(e-.5)}static bisectToLimit(e,t){const i=qs.bisectToSegment(e,t);let r=i[0],A=qs.hueOf(r),s=i[1];for(let e=0;e<3;e++)if(r[e]!==s[e]){let i=-1,o=255;r[e]<s[e]?(i=qs.criticalPlaneBelow(qs.trueDelinearized(r[e])),o=qs.criticalPlaneAbove(qs.trueDelinearized(s[e]))):(i=qs.criticalPlaneAbove(qs.trueDelinearized(r[e])),o=qs.criticalPlaneBelow(qs.trueDelinearized(s[e])));for(let n=0;n<8&&!(Math.abs(o-i)<=1);n++){const n=Math.floor((i+o)/2),a=qs.CRITICAL_PLANES[n],c=qs.setCoordinate(r,a,s,e),l=qs.hueOf(c);qs.areInCyclicOrder(A,t,l)?(s=c,o=n):(r=c,A=l,i=n)}}return qs.midpoint(r,s)}static inverseChromaticAdaptation(e){const t=Math.abs(e),i=Math.max(0,27.13*t/(400-t));return ls(e)*Math.pow(i,1/.42)}static findResultByJ(e,t,i){let r=11*Math.sqrt(i);const A=Ss.DEFAULT,s=1/Math.pow(1.64-Math.pow(.29,A.n),.73),o=.25*(Math.cos(e+2)+3.8)*(5e4/13)*A.nc*A.ncb,n=Math.sin(e),a=Math.cos(e);for(let e=0;e<5;e++){const c=r/100,l=0===t||0===r?0:t/Math.sqrt(c),d=Math.pow(l*s,1/.9),u=A.aw*Math.pow(c,1/A.c/A.z)/A.nbb,h=23*(u+.305)*d/(23*o+11*d*a+108*d*n),g=h*a,p=h*n,v=(460*u+451*g+288*p)/1403,m=(460*u-891*g-261*p)/1403,w=(460*u-220*g-6300*p)/1403,f=vs([qs.inverseChromaticAdaptation(v),qs.inverseChromaticAdaptation(m),qs.inverseChromaticAdaptation(w)],qs.LINRGB_FROM_SCALED_DISCOUNT);if(f[0]<0||f[1]<0||f[2]<0)return 0;const E=qs.Y_FROM_LINRGB[0],C=qs.Y_FROM_LINRGB[1],B=qs.Y_FROM_LINRGB[2],b=E*f[0]+C*f[1]+B*f[2];if(b<=0)return 0;if(4===e||Math.abs(b-i)<.002)return f[0]>100.01||f[1]>100.01||f[2]>100.01?0:Cs(f);r-=(b-i)*r/(2*b)}return 0}static solveToInt(e,t,i){if(t<1e-4||i<1e-4||i>99.9999)return function(e){const t=Ps(Rs(e));return Es(t,t,t)}(i);const r=(e=gs(e))/180*Math.PI,A=Rs(i),s=qs.findResultByJ(r,t,A);if(0!==s)return s;return Cs(qs.bisectToLimit(A,r))}static solveToCam(e,t,i){return Os.fromInt(qs.solveToInt(e,t,i))}}qs.SCALED_DISCOUNT_FROM_LINRGB=[[.001200833568784504,.002389694492170889,.0002795742885861124],[.0005891086651375999,.0029785502573438758,.0003270666104008398],[.00010146692491640572,.0005364214359186694,.0032979401770712076]],qs.LINRGB_FROM_SCALED_DISCOUNT=[[1373.2198709594231,-1100.4251190754821,-7.278681089101213],[-271.815969077903,559.6580465940733,-32.46047482791194],[1.9622899599665666,-57.173814538844006,308.7233197812385]],qs.Y_FROM_LINRGB=[.2126,.7152,.0722],qs.CRITICAL_PLANES=[.015176349177441876,.045529047532325624,.07588174588720938,.10623444424209313,.13658714259697685,.16693984095186062,.19729253930674434,.2276452376616281,.2579979360165119,.28835063437139563,.3188300904430532,.350925934958123,.3848314933096426,.42057480301049466,.458183274052838,.4976837250274023,.5391024159806381,.5824650784040898,.6277969426914107,.6751227633498623,.7244668422128921,.775853049866786,.829304845476233,.8848452951698498,.942497089126609,1.0022825574869039,1.0642236851973577,1.1283421258858297,1.1946592148522128,1.2631959812511864,1.3339731595349034,1.407011200216447,1.4823302800086415,1.5599503113873272,1.6398909516233677,1.7221716113234105,1.8068114625156377,1.8938294463134073,1.9832442801866852,2.075074464868551,2.1693382909216234,2.2660538449872063,2.36523901573795,2.4669114995532007,2.5710888059345764,2.6777882626779785,2.7870270208169257,2.898822059350997,3.0131901897720907,3.1301480604002863,3.2497121605402226,3.3718988244681087,3.4967242352587946,3.624204428461639,3.754355295633311,3.887192587735158,4.022731918402185,4.160988767090289,4.301978482107941,4.445716283538092,4.592217266055746,4.741496401646282,4.893568542229298,5.048448422192488,5.20615066083972,5.3666897647573375,5.5300801301023865,5.696336044816294,5.865471690767354,6.037501145825082,6.212438385869475,6.390297286737924,6.571091626112461,6.7548350853498045,6.941541251256611,7.131223617812143,7.323895587840543,7.5195704746346665,7.7182615035334345,7.919981813454504,8.124744458384042,8.332562408825165,8.543448553206703,8.757415699253682,8.974476575321063,9.194643831691977,9.417930041841839,9.644347703669503,9.873909240696694,10.106627003236781,10.342513269534024,10.58158024687427,10.8238400726681,11.069304815507364,11.317986476196008,11.569896988756009,11.825048221409341,12.083451977536606,12.345119996613247,12.610063955123938,12.878295467455942,13.149826086772048,13.42466730586372,13.702830557985108,13.984327217668513,14.269168601521828,14.55736596900856,14.848930523210871,15.143873411576273,15.44220572664832,15.743938506781891,16.04908273684337,16.35764934889634,16.66964922287304,16.985093187232053,17.30399201960269,17.62635644741625,17.95219714852476,18.281524751807332,18.614349837764564,18.95068293910138,19.290534541298456,19.633915083172692,19.98083495742689,20.331304511189067,20.685334046541502,21.042933821039977,21.404114048223256,21.76888489811322,22.137256497705877,22.50923893145328,22.884842241736916,23.264076429332462,23.6469514538663,24.033477234264016,24.42366364919083,24.817520537484558,25.21505769858089,25.61628489293138,26.021211842414342,26.429848230738664,26.842203703840827,27.258287870275353,27.678110301598522,28.10168053274597,28.529008062403893,28.96010235337422,29.39497283293396,29.83362889318845,30.276079891419332,30.722335150426627,31.172403958865512,31.62629557157785,32.08401920991837,32.54558406207592,33.010999283389665,33.4802739966603,33.953417292456834,34.430438229418264,34.911345834551085,35.39614910352207,35.88485700094671,36.37747846067349,36.87402238606382,37.37449765026789,37.87891309649659,38.38727753828926,38.89959975977785,39.41588851594697,39.93615253289054,40.460400508064545,40.98864111053629,41.520882981230194,42.05713473317016,42.597404951718396,43.141702194811224,43.6900349931913,44.24241185063697,44.798841244188324,45.35933162437017,45.92389141541209,46.49252901546552,47.065252796817916,47.64207110610409,48.22299226451468,48.808024568002054,49.3971762874833,49.9904556690408,50.587870934119984,51.189430279724725,51.79514187861014,52.40501387947288,53.0190544071392,53.637271562750364,54.259673423945976,54.88626804504493,55.517063457223934,56.15206766869424,56.79128866487574,57.43473440856916,58.08241284012621,58.734331877617365,59.39049941699807,60.05092333227251,60.715611475655585,61.38457167773311,62.057811747619894,62.7353394731159,63.417162620860914,64.10328893648692,64.79372614476921,65.48848194977529,66.18756403501224,66.89098006357258,67.59873767827808,68.31084450182222,69.02730813691093,69.74813616640164,70.47333615344107,71.20291564160104,71.93688215501312,72.67524319850172,73.41800625771542,74.16517879925733,74.9167682708136,75.67278210128072,76.43322770089146,77.1981124613393,77.96744375590167,78.74122893956174,79.51947534912904,80.30219030335869,81.08938110306934,81.88105503125999,82.67721935322541,83.4778813166706,84.28304815182372,85.09272707154808,85.90692527145302,86.72564993000343,87.54890820862819,88.3767072518277,89.2090541872801,90.04595612594655,90.88742016217518,91.73345337380438,92.58406282226491,93.43925555268066,94.29903859396902,95.16341895893969,96.03240364439274,96.9059996312159,97.78421388448044,98.6670533535366,99.55452497210776];
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ls{static from(e,t,i){return new Ls(qs.solveToInt(e,t,i))}static fromInt(e){return new Ls(e)}toInt(){return this.argb}get hue(){return this.internalHue}set hue(e){this.setInternalState(qs.solveToInt(e,this.internalChroma,this.internalTone))}get chroma(){return this.internalChroma}set chroma(e){this.setInternalState(qs.solveToInt(this.internalHue,e,this.internalTone))}get tone(){return this.internalTone}set tone(e){this.setInternalState(qs.solveToInt(this.internalHue,this.internalChroma,e))}constructor(e){this.argb=e;const t=Os.fromInt(e);this.internalHue=t.hue,this.internalChroma=t.chroma,this.internalTone=Ds(e),this.argb=e}setInternalState(e){const t=Os.fromInt(e);this.internalHue=t.hue,this.internalChroma=t.chroma,this.internalTone=Ds(e),this.argb=e}inViewingConditions(e){const t=Os.fromInt(this.toInt()).xyzInViewingConditions(e),i=Os.fromXyzInViewingConditions(t[0],t[1],t[2],Ss.make());return Ls.from(i.hue,i.chroma,ks(t[1]))}}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Us{static harmonize(e,t){const i=Ls.fromInt(e),r=Ls.fromInt(t),A=ps(i.hue,r.hue),s=Math.min(.5*A,15),o=gs(i.hue+s*(n=i.hue,gs(r.hue-n)<=180?1:-1));var n;return Ls.from(o,i.chroma,i.tone).toInt()}static hctHue(e,t,i){const r=Us.cam16Ucs(e,t,i),A=Os.fromInt(r),s=Os.fromInt(e);return Ls.from(A.hue,s.chroma,Ds(e)).toInt()}static cam16Ucs(e,t,i){const r=Os.fromInt(e),A=Os.fromInt(t),s=r.jstar,o=r.astar,n=r.bstar,a=s+(A.jstar-s)*i,c=o+(A.astar-o)*i,l=n+(A.bstar-n)*i;return Os.fromUcs(a,c,l).toInt()}}
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ts{static ratioOfTones(e,t){return e=us(0,100,e),t=us(0,100,t),Ts.ratioOfYs(Rs(e),Rs(t))}static ratioOfYs(e,t){const i=e>t?e:t;return(i+5)/((i===t?e:t)+5)}static lighter(e,t){if(e<0||e>100)return-1;const i=Rs(e),r=t*(i+5)-5,A=Ts.ratioOfYs(r,i),s=Math.abs(A-t);if(A<t&&s>.04)return-1;const o=ks(r)+.4;return o<0||o>100?-1:o}static darker(e,t){if(e<0||e>100)return-1;const i=Rs(e),r=(i+5)/t-5,A=Ts.ratioOfYs(i,r),s=Math.abs(A-t);if(A<t&&s>.04)return-1;const o=ks(r)-.4;return o<0||o>100?-1:o}static lighterUnsafe(e,t){const i=Ts.lighter(e,t);return i<0?100:i}static darkerUnsafe(e,t){const i=Ts.darker(e,t);return i<0?0:i}}
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Js{static isDisliked(e){const t=Math.round(e.hue)>=90&&Math.round(e.hue)<=111,i=Math.round(e.chroma)>16,r=Math.round(e.tone)<65;return t&&i&&r}static fixIfDisliked(e){return Js.isDisliked(e)?Ls.from(e.hue,e.chroma,70):e}}
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vs{static fromPalette(e){return new Vs(e.name??"",e.palette,e.tone,e.isBackground??!1,e.background,e.secondBackground,e.contrastCurve,e.toneDeltaPair)}constructor(e,t,i,r,A,s,o,n){if(this.name=e,this.palette=t,this.tone=i,this.isBackground=r,this.background=A,this.secondBackground=s,this.contrastCurve=o,this.toneDeltaPair=n,this.hctCache=new Map,!A&&s)throw new Error(`Color ${e} has secondBackgrounddefined, but background is not defined.`);if(!A&&o)throw new Error(`Color ${e} has contrastCurvedefined, but background is not defined.`);if(A&&!o)throw new Error(`Color ${e} has backgrounddefined, but contrastCurve is not defined.`)}getArgb(e){return this.getHct(e).toInt()}getHct(e){const t=this.hctCache.get(e);if(null!=t)return t;const i=this.getTone(e),r=this.palette(e).getHct(i);return this.hctCache.size>4&&this.hctCache.clear(),this.hctCache.set(e,r),r}getTone(e){const t=e.contrastLevel<0;if(this.toneDeltaPair){const i=this.toneDeltaPair(e),r=i.roleA,A=i.roleB,s=i.delta,o=i.polarity,n=i.stayTogether,a=this.background(e).getTone(e),c="nearer"===o||"lighter"===o&&!e.isDark||"darker"===o&&e.isDark,l=c?r:A,d=c?A:r,u=this.name===l.name,h=e.isDark?1:-1,g=l.contrastCurve.get(e.contrastLevel),p=d.contrastCurve.get(e.contrastLevel),v=l.tone(e);let m=Ts.ratioOfTones(a,v)>=g?v:Vs.foregroundTone(a,g);const w=d.tone(e);let f=Ts.ratioOfTones(a,w)>=p?w:Vs.foregroundTone(a,p);return t&&(m=Vs.foregroundTone(a,g),f=Vs.foregroundTone(a,p)),(f-m)*h>=s||(f=us(0,100,m+s*h),(f-m)*h>=s||(m=us(0,100,f-s*h))),50<=m&&m<60?h>0?(m=60,f=Math.max(f,m+s*h)):(m=49,f=Math.min(f,m+s*h)):50<=f&&f<60&&(n?h>0?(m=60,f=Math.max(f,m+s*h)):(m=49,f=Math.min(f,m+s*h)):f=h>0?60:49),u?m:f}{let i=this.tone(e);if(null==this.background)return i;const r=this.background(e).getTone(e),A=this.contrastCurve.get(e.contrastLevel);if(Ts.ratioOfTones(r,i)>=A||(i=Vs.foregroundTone(r,A)),t&&(i=Vs.foregroundTone(r,A)),this.isBackground&&50<=i&&i<60&&(i=Ts.ratioOfTones(49,r)>=A?49:60),this.secondBackground){const[t,r]=[this.background,this.secondBackground],[s,o]=[t(e).getTone(e),r(e).getTone(e)],[n,a]=[Math.max(s,o),Math.min(s,o)];if(Ts.ratioOfTones(n,i)>=A&&Ts.ratioOfTones(a,i)>=A)return i;const c=Ts.lighter(n,A),l=Ts.darker(a,A),d=[];-1!==c&&d.push(c),-1!==l&&d.push(l);return Vs.tonePrefersLightForeground(s)||Vs.tonePrefersLightForeground(o)?c<0?100:c:1===d.length?d[0]:l<0?0:l}return i}}static foregroundTone(e,t){const i=Ts.lighterUnsafe(e,t),r=Ts.darkerUnsafe(e,t),A=Ts.ratioOfTones(i,e),s=Ts.ratioOfTones(r,e);if(Vs.tonePrefersLightForeground(e)){const e=Math.abs(A-s)<.1&&A<t&&s<t;return A>=t||A>=s||e?i:r}return s>=t||s>=A?r:i}static tonePrefersLightForeground(e){return Math.round(e)<60}static toneAllowsLightForeground(e){return Math.round(e)<=49}static enableLightForeground(e){return Vs.tonePrefersLightForeground(e)&&!Vs.toneAllowsLightForeground(e)?49:e}}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fs{static fromInt(e){const t=Ls.fromInt(e);return Fs.fromHct(t)}static fromHct(e){return new Fs(e.hue,e.chroma,e)}static fromHueAndChroma(e,t){const i=new zs(e,t).create();return new Fs(e,t,i)}constructor(e,t,i){this.hue=e,this.chroma=t,this.keyColor=i,this.cache=new Map}tone(e){let t=this.cache.get(e);return void 0===t&&(t=Ls.from(this.hue,this.chroma,e).toInt(),this.cache.set(e,t)),t}getHct(e){return Ls.fromInt(this.tone(e))}}class zs{constructor(e,t){this.hue=e,this.requestedChroma=t,this.chromaCache=new Map,this.maxChromaValue=200}create(){let e=0,t=100;for(;e<t;){const i=Math.floor((e+t)/2),r=this.maxChroma(i)<this.maxChroma(i+1);if(this.maxChroma(i)>=this.requestedChroma-.01)if(Math.abs(e-50)<Math.abs(t-50))t=i;else{if(e===i)return Ls.from(this.hue,this.requestedChroma,e);e=i}else r?e=i+1:t=i}return Ls.from(this.hue,this.requestedChroma,e)}maxChroma(e){if(this.chromaCache.has(e))return this.chromaCache.get(e);const t=Ls.from(this.hue,this.maxChromaValue,e).chroma;return this.chromaCache.set(e,t),t}}
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ys{constructor(e,t,i,r){this.low=e,this.normal=t,this.medium=i,this.high=r}get(e){return e<=-1?this.low:e<0?ds(this.low,this.normal,(e- -1)/1):e<.5?ds(this.normal,this.medium,(e-0)/.5):e<1?ds(this.medium,this.high,(e-.5)/.5):this.high}}
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xs{constructor(e,t,i,r,A){this.roleA=e,this.roleB=t,this.delta=i,this.polarity=r,this.stayTogether=A}}
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var js;
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ks(e){return e.variant===js.FIDELITY||e.variant===js.CONTENT}function Gs(e){return e.variant===js.MONOCHROME}!function(e){e[e.MONOCHROME=0]="MONOCHROME",e[e.NEUTRAL=1]="NEUTRAL",e[e.TONAL_SPOT=2]="TONAL_SPOT",e[e.VIBRANT=3]="VIBRANT",e[e.EXPRESSIVE=4]="EXPRESSIVE",e[e.FIDELITY=5]="FIDELITY",e[e.CONTENT=6]="CONTENT",e[e.RAINBOW=7]="RAINBOW",e[e.FRUIT_SALAD=8]="FRUIT_SALAD"}(js||(js={}));class Ns{static highestSurface(e){return e.isDark?Ns.surfaceBright:Ns.surfaceDim}}Ns.contentAccentToneDelta=15,Ns.primaryPaletteKeyColor=Vs.fromPalette({name:"primary_palette_key_color",palette:e=>e.primaryPalette,tone:e=>e.primaryPalette.keyColor.tone}),Ns.secondaryPaletteKeyColor=Vs.fromPalette({name:"secondary_palette_key_color",palette:e=>e.secondaryPalette,tone:e=>e.secondaryPalette.keyColor.tone}),Ns.tertiaryPaletteKeyColor=Vs.fromPalette({name:"tertiary_palette_key_color",palette:e=>e.tertiaryPalette,tone:e=>e.tertiaryPalette.keyColor.tone}),Ns.neutralPaletteKeyColor=Vs.fromPalette({name:"neutral_palette_key_color",palette:e=>e.neutralPalette,tone:e=>e.neutralPalette.keyColor.tone}),Ns.neutralVariantPaletteKeyColor=Vs.fromPalette({name:"neutral_variant_palette_key_color",palette:e=>e.neutralVariantPalette,tone:e=>e.neutralVariantPalette.keyColor.tone}),Ns.background=Vs.fromPalette({name:"background",palette:e=>e.neutralPalette,tone:e=>e.isDark?6:98,isBackground:!0}),Ns.onBackground=Vs.fromPalette({name:"on_background",palette:e=>e.neutralPalette,tone:e=>e.isDark?90:10,background:e=>Ns.background,contrastCurve:new Ys(3,3,4.5,7)}),Ns.surface=Vs.fromPalette({name:"surface",palette:e=>e.neutralPalette,tone:e=>e.isDark?6:98,isBackground:!0}),Ns.surfaceDim=Vs.fromPalette({name:"surface_dim",palette:e=>e.neutralPalette,tone:e=>e.isDark?6:new Ys(87,87,80,75).get(e.contrastLevel),isBackground:!0}),Ns.surfaceBright=Vs.fromPalette({name:"surface_bright",palette:e=>e.neutralPalette,tone:e=>e.isDark?new Ys(24,24,29,34).get(e.contrastLevel):98,isBackground:!0}),Ns.surfaceContainerLowest=Vs.fromPalette({name:"surface_container_lowest",palette:e=>e.neutralPalette,tone:e=>e.isDark?new Ys(4,4,2,0).get(e.contrastLevel):100,isBackground:!0}),Ns.surfaceContainerLow=Vs.fromPalette({name:"surface_container_low",palette:e=>e.neutralPalette,tone:e=>e.isDark?new Ys(10,10,11,12).get(e.contrastLevel):new Ys(96,96,96,95).get(e.contrastLevel),isBackground:!0}),Ns.surfaceContainer=Vs.fromPalette({name:"surface_container",palette:e=>e.neutralPalette,tone:e=>e.isDark?new Ys(12,12,16,20).get(e.contrastLevel):new Ys(94,94,92,90).get(e.contrastLevel),isBackground:!0}),Ns.surfaceContainerHigh=Vs.fromPalette({name:"surface_container_high",palette:e=>e.neutralPalette,tone:e=>e.isDark?new Ys(17,17,21,25).get(e.contrastLevel):new Ys(92,92,88,85).get(e.contrastLevel),isBackground:!0}),Ns.surfaceContainerHighest=Vs.fromPalette({name:"surface_container_highest",palette:e=>e.neutralPalette,tone:e=>e.isDark?new Ys(22,22,26,30).get(e.contrastLevel):new Ys(90,90,84,80).get(e.contrastLevel),isBackground:!0}),Ns.onSurface=Vs.fromPalette({name:"on_surface",palette:e=>e.neutralPalette,tone:e=>e.isDark?90:10,background:e=>Ns.highestSurface(e),contrastCurve:new Ys(4.5,7,11,21)}),Ns.surfaceVariant=Vs.fromPalette({name:"surface_variant",palette:e=>e.neutralVariantPalette,tone:e=>e.isDark?30:90,isBackground:!0}),Ns.onSurfaceVariant=Vs.fromPalette({name:"on_surface_variant",palette:e=>e.neutralVariantPalette,tone:e=>e.isDark?80:30,background:e=>Ns.highestSurface(e),contrastCurve:new Ys(3,4.5,7,11)}),Ns.inverseSurface=Vs.fromPalette({name:"inverse_surface",palette:e=>e.neutralPalette,tone:e=>e.isDark?90:20}),Ns.inverseOnSurface=Vs.fromPalette({name:"inverse_on_surface",palette:e=>e.neutralPalette,tone:e=>e.isDark?20:95,background:e=>Ns.inverseSurface,contrastCurve:new Ys(4.5,7,11,21)}),Ns.outline=Vs.fromPalette({name:"outline",palette:e=>e.neutralVariantPalette,tone:e=>e.isDark?60:50,background:e=>Ns.highestSurface(e),contrastCurve:new Ys(1.5,3,4.5,7)}),Ns.outlineVariant=Vs.fromPalette({name:"outline_variant",palette:e=>e.neutralVariantPalette,tone:e=>e.isDark?30:80,background:e=>Ns.highestSurface(e),contrastCurve:new Ys(1,1,3,4.5)}),Ns.shadow=Vs.fromPalette({name:"shadow",palette:e=>e.neutralPalette,tone:e=>0}),Ns.scrim=Vs.fromPalette({name:"scrim",palette:e=>e.neutralPalette,tone:e=>0}),Ns.surfaceTint=Vs.fromPalette({name:"surface_tint",palette:e=>e.primaryPalette,tone:e=>e.isDark?80:40,isBackground:!0}),Ns.primary=Vs.fromPalette({name:"primary",palette:e=>e.primaryPalette,tone:e=>Gs(e)?e.isDark?100:0:e.isDark?80:40,isBackground:!0,background:e=>Ns.highestSurface(e),contrastCurve:new Ys(3,4.5,7,7),toneDeltaPair:e=>new Xs(Ns.primaryContainer,Ns.primary,10,"nearer",!1)}),Ns.onPrimary=Vs.fromPalette({name:"on_primary",palette:e=>e.primaryPalette,tone:e=>Gs(e)?e.isDark?10:90:e.isDark?20:100,background:e=>Ns.primary,contrastCurve:new Ys(4.5,7,11,21)}),Ns.primaryContainer=Vs.fromPalette({name:"primary_container",palette:e=>e.primaryPalette,tone:e=>Ks(e)?e.sourceColorHct.tone:Gs(e)?e.isDark?85:25:e.isDark?30:90,isBackground:!0,background:e=>Ns.highestSurface(e),contrastCurve:new Ys(1,1,3,4.5),toneDeltaPair:e=>new Xs(Ns.primaryContainer,Ns.primary,10,"nearer",!1)}),Ns.onPrimaryContainer=Vs.fromPalette({name:"on_primary_container",palette:e=>e.primaryPalette,tone:e=>Ks(e)?Vs.foregroundTone(Ns.primaryContainer.tone(e),4.5):Gs(e)?e.isDark?0:100:e.isDark?90:30,background:e=>Ns.primaryContainer,contrastCurve:new Ys(3,4.5,7,11)}),Ns.inversePrimary=Vs.fromPalette({name:"inverse_primary",palette:e=>e.primaryPalette,tone:e=>e.isDark?40:80,background:e=>Ns.inverseSurface,contrastCurve:new Ys(3,4.5,7,7)}),Ns.secondary=Vs.fromPalette({name:"secondary",palette:e=>e.secondaryPalette,tone:e=>e.isDark?80:40,isBackground:!0,background:e=>Ns.highestSurface(e),contrastCurve:new Ys(3,4.5,7,7),toneDeltaPair:e=>new Xs(Ns.secondaryContainer,Ns.secondary,10,"nearer",!1)}),Ns.onSecondary=Vs.fromPalette({name:"on_secondary",palette:e=>e.secondaryPalette,tone:e=>Gs(e)?e.isDark?10:100:e.isDark?20:100,background:e=>Ns.secondary,contrastCurve:new Ys(4.5,7,11,21)}),Ns.secondaryContainer=Vs.fromPalette({name:"secondary_container",palette:e=>e.secondaryPalette,tone:e=>{const t=e.isDark?30:90;return Gs(e)?e.isDark?30:85:Ks(e)?function(e,t,i,r){let A=i,s=Ls.from(e,t,i);if(s.chroma<t){let i=s.chroma;for(;s.chroma<t;){A+=r?-1:1;const o=Ls.from(e,t,A);if(i>o.chroma)break;if(Math.abs(o.chroma-t)<.4)break;Math.abs(o.chroma-t)<Math.abs(s.chroma-t)&&(s=o),i=Math.max(i,o.chroma)}}return A}(e.secondaryPalette.hue,e.secondaryPalette.chroma,t,!e.isDark):t},isBackground:!0,background:e=>Ns.highestSurface(e),contrastCurve:new Ys(1,1,3,4.5),toneDeltaPair:e=>new Xs(Ns.secondaryContainer,Ns.secondary,10,"nearer",!1)}),Ns.onSecondaryContainer=Vs.fromPalette({name:"on_secondary_container",palette:e=>e.secondaryPalette,tone:e=>Gs(e)?e.isDark?90:10:Ks(e)?Vs.foregroundTone(Ns.secondaryContainer.tone(e),4.5):e.isDark?90:30,background:e=>Ns.secondaryContainer,contrastCurve:new Ys(3,4.5,7,11)}),Ns.tertiary=Vs.fromPalette({name:"tertiary",palette:e=>e.tertiaryPalette,tone:e=>Gs(e)?e.isDark?90:25:e.isDark?80:40,isBackground:!0,background:e=>Ns.highestSurface(e),contrastCurve:new Ys(3,4.5,7,7),toneDeltaPair:e=>new Xs(Ns.tertiaryContainer,Ns.tertiary,10,"nearer",!1)}),Ns.onTertiary=Vs.fromPalette({name:"on_tertiary",palette:e=>e.tertiaryPalette,tone:e=>Gs(e)?e.isDark?10:90:e.isDark?20:100,background:e=>Ns.tertiary,contrastCurve:new Ys(4.5,7,11,21)}),Ns.tertiaryContainer=Vs.fromPalette({name:"tertiary_container",palette:e=>e.tertiaryPalette,tone:e=>{if(Gs(e))return e.isDark?60:49;if(!Ks(e))return e.isDark?30:90;const t=e.tertiaryPalette.getHct(e.sourceColorHct.tone);return Js.fixIfDisliked(t).tone},isBackground:!0,background:e=>Ns.highestSurface(e),contrastCurve:new Ys(1,1,3,4.5),toneDeltaPair:e=>new Xs(Ns.tertiaryContainer,Ns.tertiary,10,"nearer",!1)}),Ns.onTertiaryContainer=Vs.fromPalette({name:"on_tertiary_container",palette:e=>e.tertiaryPalette,tone:e=>Gs(e)?e.isDark?0:100:Ks(e)?Vs.foregroundTone(Ns.tertiaryContainer.tone(e),4.5):e.isDark?90:30,background:e=>Ns.tertiaryContainer,contrastCurve:new Ys(3,4.5,7,11)}),Ns.error=Vs.fromPalette({name:"error",palette:e=>e.errorPalette,tone:e=>e.isDark?80:40,isBackground:!0,background:e=>Ns.highestSurface(e),contrastCurve:new Ys(3,4.5,7,7),toneDeltaPair:e=>new Xs(Ns.errorContainer,Ns.error,10,"nearer",!1)}),Ns.onError=Vs.fromPalette({name:"on_error",palette:e=>e.errorPalette,tone:e=>e.isDark?20:100,background:e=>Ns.error,contrastCurve:new Ys(4.5,7,11,21)}),Ns.errorContainer=Vs.fromPalette({name:"error_container",palette:e=>e.errorPalette,tone:e=>e.isDark?30:90,isBackground:!0,background:e=>Ns.highestSurface(e),contrastCurve:new Ys(1,1,3,4.5),toneDeltaPair:e=>new Xs(Ns.errorContainer,Ns.error,10,"nearer",!1)}),Ns.onErrorContainer=Vs.fromPalette({name:"on_error_container",palette:e=>e.errorPalette,tone:e=>Gs(e)?e.isDark?90:10:e.isDark?90:30,background:e=>Ns.errorContainer,contrastCurve:new Ys(3,4.5,7,11)}),Ns.primaryFixed=Vs.fromPalette({name:"primary_fixed",palette:e=>e.primaryPalette,tone:e=>Gs(e)?40:90,isBackground:!0,background:e=>Ns.highestSurface(e),contrastCurve:new Ys(1,1,3,4.5),toneDeltaPair:e=>new Xs(Ns.primaryFixed,Ns.primaryFixedDim,10,"lighter",!0)}),Ns.primaryFixedDim=Vs.fromPalette({name:"primary_fixed_dim",palette:e=>e.primaryPalette,tone:e=>Gs(e)?30:80,isBackground:!0,background:e=>Ns.highestSurface(e),contrastCurve:new Ys(1,1,3,4.5),toneDeltaPair:e=>new Xs(Ns.primaryFixed,Ns.primaryFixedDim,10,"lighter",!0)}),Ns.onPrimaryFixed=Vs.fromPalette({name:"on_primary_fixed",palette:e=>e.primaryPalette,tone:e=>Gs(e)?100:10,background:e=>Ns.primaryFixedDim,secondBackground:e=>Ns.primaryFixed,contrastCurve:new Ys(4.5,7,11,21)}),Ns.onPrimaryFixedVariant=Vs.fromPalette({name:"on_primary_fixed_variant",palette:e=>e.primaryPalette,tone:e=>Gs(e)?90:30,background:e=>Ns.primaryFixedDim,secondBackground:e=>Ns.primaryFixed,contrastCurve:new Ys(3,4.5,7,11)}),Ns.secondaryFixed=Vs.fromPalette({name:"secondary_fixed",palette:e=>e.secondaryPalette,tone:e=>Gs(e)?80:90,isBackground:!0,background:e=>Ns.highestSurface(e),contrastCurve:new Ys(1,1,3,4.5),toneDeltaPair:e=>new Xs(Ns.secondaryFixed,Ns.secondaryFixedDim,10,"lighter",!0)}),Ns.secondaryFixedDim=Vs.fromPalette({name:"secondary_fixed_dim",palette:e=>e.secondaryPalette,tone:e=>Gs(e)?70:80,isBackground:!0,background:e=>Ns.highestSurface(e),contrastCurve:new Ys(1,1,3,4.5),toneDeltaPair:e=>new Xs(Ns.secondaryFixed,Ns.secondaryFixedDim,10,"lighter",!0)}),Ns.onSecondaryFixed=Vs.fromPalette({name:"on_secondary_fixed",palette:e=>e.secondaryPalette,tone:e=>10,background:e=>Ns.secondaryFixedDim,secondBackground:e=>Ns.secondaryFixed,contrastCurve:new Ys(4.5,7,11,21)}),Ns.onSecondaryFixedVariant=Vs.fromPalette({name:"on_secondary_fixed_variant",palette:e=>e.secondaryPalette,tone:e=>Gs(e)?25:30,background:e=>Ns.secondaryFixedDim,secondBackground:e=>Ns.secondaryFixed,contrastCurve:new Ys(3,4.5,7,11)}),Ns.tertiaryFixed=Vs.fromPalette({name:"tertiary_fixed",palette:e=>e.tertiaryPalette,tone:e=>Gs(e)?40:90,isBackground:!0,background:e=>Ns.highestSurface(e),contrastCurve:new Ys(1,1,3,4.5),toneDeltaPair:e=>new Xs(Ns.tertiaryFixed,Ns.tertiaryFixedDim,10,"lighter",!0)}),Ns.tertiaryFixedDim=Vs.fromPalette({name:"tertiary_fixed_dim",palette:e=>e.tertiaryPalette,tone:e=>Gs(e)?30:80,isBackground:!0,background:e=>Ns.highestSurface(e),contrastCurve:new Ys(1,1,3,4.5),toneDeltaPair:e=>new Xs(Ns.tertiaryFixed,Ns.tertiaryFixedDim,10,"lighter",!0)}),Ns.onTertiaryFixed=Vs.fromPalette({name:"on_tertiary_fixed",palette:e=>e.tertiaryPalette,tone:e=>Gs(e)?100:10,background:e=>Ns.tertiaryFixedDim,secondBackground:e=>Ns.tertiaryFixed,contrastCurve:new Ys(4.5,7,11,21)}),Ns.onTertiaryFixedVariant=Vs.fromPalette({name:"on_tertiary_fixed_variant",palette:e=>e.tertiaryPalette,tone:e=>Gs(e)?90:30,background:e=>Ns.tertiaryFixedDim,secondBackground:e=>Ns.tertiaryFixed,contrastCurve:new Ys(3,4.5,7,11)});
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ws{static of(e){return new Ws(e,!1)}static contentOf(e){return new Ws(e,!0)}static fromColors(e){return Ws.createPaletteFromColors(!1,e)}static contentFromColors(e){return Ws.createPaletteFromColors(!0,e)}static createPaletteFromColors(e,t){const i=new Ws(t.primary,e);if(t.secondary){const r=new Ws(t.secondary,e);i.a2=r.a1}if(t.tertiary){const r=new Ws(t.tertiary,e);i.a3=r.a1}if(t.error){const r=new Ws(t.error,e);i.error=r.a1}if(t.neutral){const r=new Ws(t.neutral,e);i.n1=r.n1}if(t.neutralVariant){const r=new Ws(t.neutralVariant,e);i.n2=r.n2}return i}constructor(e,t){const i=Ls.fromInt(e),r=i.hue,A=i.chroma;t?(this.a1=Fs.fromHueAndChroma(r,A),this.a2=Fs.fromHueAndChroma(r,A/3),this.a3=Fs.fromHueAndChroma(r+60,A/2),this.n1=Fs.fromHueAndChroma(r,Math.min(A/12,4)),this.n2=Fs.fromHueAndChroma(r,Math.min(A/6,8))):(this.a1=Fs.fromHueAndChroma(r,Math.max(48,A)),this.a2=Fs.fromHueAndChroma(r,16),this.a3=Fs.fromHueAndChroma(r+60,24),this.n1=Fs.fromHueAndChroma(r,4),this.n2=Fs.fromHueAndChroma(r,8)),this.error=Fs.fromHueAndChroma(25,84)}}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Zs{fromInt(e){return function(e){const t=xs(bs(e)),i=xs(Is(e)),r=xs(ys(e)),A=ms,s=A[0][0]*t+A[0][1]*i+A[0][2]*r,o=A[1][0]*t+A[1][1]*i+A[1][2]*r,n=A[2][0]*t+A[2][1]*i+A[2][2]*r,a=o/fs[1],c=n/fs[2],l=Ms(s/fs[0]),d=Ms(a);return[116*d-16,500*(l-d),200*(d-Ms(c))]}(e)}toInt(e){return function(e,t,i){const r=fs,A=(e+16)/116,s=A-i/200,o=Hs(t/500+A),n=Hs(A),a=Hs(s);return Qs(o*r[0],n*r[1],a*r[2])}(e[0],e[1],e[2])}distance(e,t){const i=e[0]-t[0],r=e[1]-t[1],A=e[2]-t[2];return i*i+r*r+A*A}}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _s{static quantize(e,t,i){const r=new Map,A=new Array,s=new Array,o=new Zs;let n=0;for(let t=0;t<e.length;t++){const i=e[t],a=r.get(i);void 0===a?(n++,A.push(o.fromInt(i)),s.push(i),r.set(i,1)):r.set(i,a+1)}const a=new Array;for(let e=0;e<n;e++){const t=s[e],i=r.get(t);void 0!==i&&(a[e]=i)}let c=Math.min(i,n);t.length>0&&(c=Math.min(c,t.length));const l=new Array;for(let e=0;e<t.length;e++)l.push(o.fromInt(t[e]));const d=c-l.length;if(0===t.length&&d>0)for(let e=0;e<d;e++){const e=100*Math.random(),t=201*Math.random()-100,i=201*Math.random()-100;l.push(new Array(e,t,i))}const u=new Array;for(let e=0;e<n;e++)u.push(Math.floor(Math.random()*c));const h=new Array;for(let e=0;e<c;e++){h.push(new Array);for(let t=0;t<c;t++)h[e].push(0)}const g=new Array;for(let e=0;e<c;e++){g.push(new Array);for(let t=0;t<c;t++)g[e].push(new $s)}const p=new Array;for(let e=0;e<c;e++)p.push(0);for(let e=0;e<10;e++){for(let e=0;e<c;e++){for(let t=e+1;t<c;t++){const i=o.distance(l[e],l[t]);g[t][e].distance=i,g[t][e].index=e,g[e][t].distance=i,g[e][t].index=t}g[e].sort();for(let t=0;t<c;t++)h[e][t]=g[e][t].index}let t=0;for(let e=0;e<n;e++){const i=A[e],r=u[e],s=l[r],n=o.distance(i,s);let a=n,d=-1;for(let e=0;e<c;e++){if(g[r][e].distance>=4*n)continue;const t=o.distance(i,l[e]);t<a&&(a=t,d=e)}if(-1!==d){Math.abs(Math.sqrt(a)-Math.sqrt(n))>3&&(t++,u[e]=d)}}if(0===t&&0!==e)break;const i=new Array(c).fill(0),r=new Array(c).fill(0),s=new Array(c).fill(0);for(let e=0;e<c;e++)p[e]=0;for(let e=0;e<n;e++){const t=u[e],o=A[e],n=a[e];p[t]+=n,i[t]+=o[0]*n,r[t]+=o[1]*n,s[t]+=o[2]*n}for(let e=0;e<c;e++){const t=p[e];if(0===t){l[e]=[0,0,0];continue}const A=i[e]/t,o=r[e]/t,n=s[e]/t;l[e]=[A,o,n]}}const v=new Map;for(let e=0;e<c;e++){const t=p[e];if(0===t)continue;const i=o.toInt(l[e]);v.has(i)||v.set(i,t)}return v}}class $s{constructor(){this.distance=-1,this.index=-1}}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class eo{static quantize(e){const t=new Map;for(let i=0;i<e.length;i++){const r=e[i];Bs(r)<255||t.set(r,(t.get(r)??0)+1)}return t}}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const to=33,io=35937,ro="red",Ao="green",so="blue";class oo{constructor(e=[],t=[],i=[],r=[],A=[],s=[]){this.weights=e,this.momentsR=t,this.momentsG=i,this.momentsB=r,this.moments=A,this.cubes=s}quantize(e,t){this.constructHistogram(e),this.computeMoments();const i=this.createBoxes(t);return this.createResult(i.resultCount)}constructHistogram(e){this.weights=Array.from({length:io}).fill(0),this.momentsR=Array.from({length:io}).fill(0),this.momentsG=Array.from({length:io}).fill(0),this.momentsB=Array.from({length:io}).fill(0),this.moments=Array.from({length:io}).fill(0);const t=eo.quantize(e);for(const[e,i]of t.entries()){const t=bs(e),r=Is(e),A=ys(e),s=3,o=1+(t>>s),n=1+(r>>s),a=1+(A>>s),c=this.getIndex(o,n,a);this.weights[c]=(this.weights[c]??0)+i,this.momentsR[c]+=i*t,this.momentsG[c]+=i*r,this.momentsB[c]+=i*A,this.moments[c]+=i*(t*t+r*r+A*A)}}computeMoments(){for(let e=1;e<to;e++){const t=Array.from({length:to}).fill(0),i=Array.from({length:to}).fill(0),r=Array.from({length:to}).fill(0),A=Array.from({length:to}).fill(0),s=Array.from({length:to}).fill(0);for(let o=1;o<to;o++){let n=0,a=0,c=0,l=0,d=0;for(let u=1;u<to;u++){const h=this.getIndex(e,o,u);n+=this.weights[h],a+=this.momentsR[h],c+=this.momentsG[h],l+=this.momentsB[h],d+=this.moments[h],t[u]+=n,i[u]+=a,r[u]+=c,A[u]+=l,s[u]+=d;const g=this.getIndex(e-1,o,u);this.weights[h]=this.weights[g]+t[u],this.momentsR[h]=this.momentsR[g]+i[u],this.momentsG[h]=this.momentsG[g]+r[u],this.momentsB[h]=this.momentsB[g]+A[u],this.moments[h]=this.moments[g]+s[u]}}}}createBoxes(e){this.cubes=Array.from({length:e}).fill(0).map(()=>new no);const t=Array.from({length:e}).fill(0);this.cubes[0].r0=0,this.cubes[0].g0=0,this.cubes[0].b0=0,this.cubes[0].r1=32,this.cubes[0].g1=32,this.cubes[0].b1=32;let i=e,r=0;for(let A=1;A<e;A++){this.cut(this.cubes[r],this.cubes[A])?(t[r]=this.cubes[r].vol>1?this.variance(this.cubes[r]):0,t[A]=this.cubes[A].vol>1?this.variance(this.cubes[A]):0):(t[r]=0,A--),r=0;let e=t[0];for(let i=1;i<=A;i++)t[i]>e&&(e=t[i],r=i);if(e<=0){i=A+1;break}}return new ao(e,i)}createResult(e){const t=[];for(let i=0;i<e;++i){const e=this.cubes[i],r=this.volume(e,this.weights);if(r>0){const i=255<<24|(255&Math.round(this.volume(e,this.momentsR)/r))<<16|(255&Math.round(this.volume(e,this.momentsG)/r))<<8|255&Math.round(this.volume(e,this.momentsB)/r);t.push(i)}}return t}variance(e){const t=this.volume(e,this.momentsR),i=this.volume(e,this.momentsG),r=this.volume(e,this.momentsB);return this.moments[this.getIndex(e.r1,e.g1,e.b1)]-this.moments[this.getIndex(e.r1,e.g1,e.b0)]-this.moments[this.getIndex(e.r1,e.g0,e.b1)]+this.moments[this.getIndex(e.r1,e.g0,e.b0)]-this.moments[this.getIndex(e.r0,e.g1,e.b1)]+this.moments[this.getIndex(e.r0,e.g1,e.b0)]+this.moments[this.getIndex(e.r0,e.g0,e.b1)]-this.moments[this.getIndex(e.r0,e.g0,e.b0)]-(t*t+i*i+r*r)/this.volume(e,this.weights)}cut(e,t){const i=this.volume(e,this.momentsR),r=this.volume(e,this.momentsG),A=this.volume(e,this.momentsB),s=this.volume(e,this.weights),o=this.maximize(e,ro,e.r0+1,e.r1,i,r,A,s),n=this.maximize(e,Ao,e.g0+1,e.g1,i,r,A,s),a=this.maximize(e,so,e.b0+1,e.b1,i,r,A,s);let c;const l=o.maximum,d=n.maximum,u=a.maximum;if(l>=d&&l>=u){if(o.cutLocation<0)return!1;c=ro}else c=d>=l&&d>=u?Ao:so;switch(t.r1=e.r1,t.g1=e.g1,t.b1=e.b1,c){case ro:e.r1=o.cutLocation,t.r0=e.r1,t.g0=e.g0,t.b0=e.b0;break;case Ao:e.g1=n.cutLocation,t.r0=e.r0,t.g0=e.g1,t.b0=e.b0;break;case so:e.b1=a.cutLocation,t.r0=e.r0,t.g0=e.g0,t.b0=e.b1;break;default:throw new Error("unexpected direction "+c)}return e.vol=(e.r1-e.r0)*(e.g1-e.g0)*(e.b1-e.b0),t.vol=(t.r1-t.r0)*(t.g1-t.g0)*(t.b1-t.b0),!0}maximize(e,t,i,r,A,s,o,n){const a=this.bottom(e,t,this.momentsR),c=this.bottom(e,t,this.momentsG),l=this.bottom(e,t,this.momentsB),d=this.bottom(e,t,this.weights);let u=0,h=-1,g=0,p=0,v=0,m=0;for(let w=i;w<r;w++){if(g=a+this.top(e,t,w,this.momentsR),p=c+this.top(e,t,w,this.momentsG),v=l+this.top(e,t,w,this.momentsB),m=d+this.top(e,t,w,this.weights),0===m)continue;let i=1*(g*g+p*p+v*v),r=1*m,f=i/r;g=A-g,p=s-p,v=o-v,m=n-m,0!==m&&(i=1*(g*g+p*p+v*v),r=1*m,f+=i/r,f>u&&(u=f,h=w))}return new co(h,u)}volume(e,t){return t[this.getIndex(e.r1,e.g1,e.b1)]-t[this.getIndex(e.r1,e.g1,e.b0)]-t[this.getIndex(e.r1,e.g0,e.b1)]+t[this.getIndex(e.r1,e.g0,e.b0)]-t[this.getIndex(e.r0,e.g1,e.b1)]+t[this.getIndex(e.r0,e.g1,e.b0)]+t[this.getIndex(e.r0,e.g0,e.b1)]-t[this.getIndex(e.r0,e.g0,e.b0)]}bottom(e,t,i){switch(t){case ro:return-i[this.getIndex(e.r0,e.g1,e.b1)]+i[this.getIndex(e.r0,e.g1,e.b0)]+i[this.getIndex(e.r0,e.g0,e.b1)]-i[this.getIndex(e.r0,e.g0,e.b0)];case Ao:return-i[this.getIndex(e.r1,e.g0,e.b1)]+i[this.getIndex(e.r1,e.g0,e.b0)]+i[this.getIndex(e.r0,e.g0,e.b1)]-i[this.getIndex(e.r0,e.g0,e.b0)];case so:return-i[this.getIndex(e.r1,e.g1,e.b0)]+i[this.getIndex(e.r1,e.g0,e.b0)]+i[this.getIndex(e.r0,e.g1,e.b0)]-i[this.getIndex(e.r0,e.g0,e.b0)];default:throw new Error("unexpected direction $direction")}}top(e,t,i,r){switch(t){case ro:return r[this.getIndex(i,e.g1,e.b1)]-r[this.getIndex(i,e.g1,e.b0)]-r[this.getIndex(i,e.g0,e.b1)]+r[this.getIndex(i,e.g0,e.b0)];case Ao:return r[this.getIndex(e.r1,i,e.b1)]-r[this.getIndex(e.r1,i,e.b0)]-r[this.getIndex(e.r0,i,e.b1)]+r[this.getIndex(e.r0,i,e.b0)];case so:return r[this.getIndex(e.r1,e.g1,i)]-r[this.getIndex(e.r1,e.g0,i)]-r[this.getIndex(e.r0,e.g1,i)]+r[this.getIndex(e.r0,e.g0,i)];default:throw new Error("unexpected direction $direction")}}getIndex(e,t,i){return(e<<10)+(e<<6)+e+(t<<5)+t+i}}class no{constructor(e=0,t=0,i=0,r=0,A=0,s=0,o=0){this.r0=e,this.r1=t,this.g0=i,this.g1=r,this.b0=A,this.b1=s,this.vol=o}}class ao{constructor(e,t){this.requestedCount=e,this.resultCount=t}}class co{constructor(e,t){this.cutLocation=e,this.maximum=t}}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class lo{static quantize(e,t){const i=(new oo).quantize(e,t);return _s.quantize(e,i,t)}}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uo{get primary(){return this.props.primary}get onPrimary(){return this.props.onPrimary}get primaryContainer(){return this.props.primaryContainer}get onPrimaryContainer(){return this.props.onPrimaryContainer}get secondary(){return this.props.secondary}get onSecondary(){return this.props.onSecondary}get secondaryContainer(){return this.props.secondaryContainer}get onSecondaryContainer(){return this.props.onSecondaryContainer}get tertiary(){return this.props.tertiary}get onTertiary(){return this.props.onTertiary}get tertiaryContainer(){return this.props.tertiaryContainer}get onTertiaryContainer(){return this.props.onTertiaryContainer}get error(){return this.props.error}get onError(){return this.props.onError}get errorContainer(){return this.props.errorContainer}get onErrorContainer(){return this.props.onErrorContainer}get background(){return this.props.background}get onBackground(){return this.props.onBackground}get surface(){return this.props.surface}get onSurface(){return this.props.onSurface}get surfaceVariant(){return this.props.surfaceVariant}get onSurfaceVariant(){return this.props.onSurfaceVariant}get outline(){return this.props.outline}get outlineVariant(){return this.props.outlineVariant}get shadow(){return this.props.shadow}get scrim(){return this.props.scrim}get inverseSurface(){return this.props.inverseSurface}get inverseOnSurface(){return this.props.inverseOnSurface}get inversePrimary(){return this.props.inversePrimary}static light(e){return uo.lightFromCorePalette(Ws.of(e))}static dark(e){return uo.darkFromCorePalette(Ws.of(e))}static lightContent(e){return uo.lightFromCorePalette(Ws.contentOf(e))}static darkContent(e){return uo.darkFromCorePalette(Ws.contentOf(e))}static lightFromCorePalette(e){return new uo({primary:e.a1.tone(40),onPrimary:e.a1.tone(100),primaryContainer:e.a1.tone(90),onPrimaryContainer:e.a1.tone(10),secondary:e.a2.tone(40),onSecondary:e.a2.tone(100),secondaryContainer:e.a2.tone(90),onSecondaryContainer:e.a2.tone(10),tertiary:e.a3.tone(40),onTertiary:e.a3.tone(100),tertiaryContainer:e.a3.tone(90),onTertiaryContainer:e.a3.tone(10),error:e.error.tone(40),onError:e.error.tone(100),errorContainer:e.error.tone(90),onErrorContainer:e.error.tone(10),background:e.n1.tone(99),onBackground:e.n1.tone(10),surface:e.n1.tone(99),onSurface:e.n1.tone(10),surfaceVariant:e.n2.tone(90),onSurfaceVariant:e.n2.tone(30),outline:e.n2.tone(50),outlineVariant:e.n2.tone(80),shadow:e.n1.tone(0),scrim:e.n1.tone(0),inverseSurface:e.n1.tone(20),inverseOnSurface:e.n1.tone(95),inversePrimary:e.a1.tone(80)})}static darkFromCorePalette(e){return new uo({primary:e.a1.tone(80),onPrimary:e.a1.tone(20),primaryContainer:e.a1.tone(30),onPrimaryContainer:e.a1.tone(90),secondary:e.a2.tone(80),onSecondary:e.a2.tone(20),secondaryContainer:e.a2.tone(30),onSecondaryContainer:e.a2.tone(90),tertiary:e.a3.tone(80),onTertiary:e.a3.tone(20),tertiaryContainer:e.a3.tone(30),onTertiaryContainer:e.a3.tone(90),error:e.error.tone(80),onError:e.error.tone(20),errorContainer:e.error.tone(30),onErrorContainer:e.error.tone(80),background:e.n1.tone(10),onBackground:e.n1.tone(90),surface:e.n1.tone(10),onSurface:e.n1.tone(90),surfaceVariant:e.n2.tone(30),onSurfaceVariant:e.n2.tone(80),outline:e.n2.tone(60),outlineVariant:e.n2.tone(30),shadow:e.n1.tone(0),scrim:e.n1.tone(0),inverseSurface:e.n1.tone(90),inverseOnSurface:e.n1.tone(20),inversePrimary:e.a1.tone(40)})}constructor(e){this.props=e}toJSON(){return{...this.props}}}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ho={desired:4,fallbackColorARGB:4282549748,filter:!0};function go(e,t){return e.score>t.score?-1:e.score<t.score?1:0}class po{constructor(){}static score(e,t){const{desired:i,fallbackColorARGB:r,filter:A}={...ho,...t},s=[],o=new Array(360).fill(0);let n=0;for(const[t,i]of e.entries()){const e=Ls.fromInt(t);s.push(e);o[Math.floor(e.hue)]+=i,n+=i}const a=new Array(360).fill(0);for(let e=0;e<360;e++){const t=o[e]/n;for(let i=e-14;i<e+16;i++){a[hs(i)]+=t}}const c=new Array;for(const e of s){const t=a[hs(Math.round(e.hue))];if(A&&(e.chroma<po.CUTOFF_CHROMA||t<=po.CUTOFF_EXCITED_PROPORTION))continue;const i=100*t*po.WEIGHT_PROPORTION,r=e.chroma<po.TARGET_CHROMA?po.WEIGHT_CHROMA_BELOW:po.WEIGHT_CHROMA_ABOVE,s=i+(e.chroma-po.TARGET_CHROMA)*r;c.push({hct:e,score:s})}c.sort(go);const l=[];for(let e=90;e>=15;e--){l.length=0;for(const{hct:t}of c){if(l.find(i=>ps(t.hue,i.hue)<e)||l.push(t),l.length>=i)break}if(l.length>=i)break}const d=[];0===l.length&&d.push(r);for(const e of l)d.push(e.toInt());return d}}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function vo(e){const t=bs(e),i=Is(e),r=ys(e),A=[t.toString(16),i.toString(16),r.toString(16)];for(const[e,t]of A.entries())1===t.length&&(A[e]="0"+t);return"#"+A.join("")}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function mo(e,t=[]){const i=Ws.of(e);return{source:e,schemes:{light:uo.light(e),dark:uo.dark(e)},palettes:{primary:i.a1,secondary:i.a2,tertiary:i.a3,neutral:i.n1,neutralVariant:i.n2,error:i.error},customColors:t.map(t=>function(e,t){let i=t.value;const r=i,A=e;t.blend&&(i=Us.harmonize(r,A));const s=Ws.of(i),o=s.a1;return{color:t,value:i,light:{color:o.tone(40),onColor:o.tone(100),colorContainer:o.tone(90),onColorContainer:o.tone(10)},dark:{color:o.tone(80),onColor:o.tone(20),colorContainer:o.tone(30),onColorContainer:o.tone(90)}}}(e,t))}}async function wo(e,t=[]){const i=await async function(e){const t=await new Promise((t,i)=>{const r=document.createElement("canvas"),A=r.getContext("2d");if(!A)return void i(new Error("Could not get canvas context"));const s=()=>{r.width=e.width,r.height=e.height,A.drawImage(e,0,0);let i=[0,0,e.width,e.height];const s=e.dataset.area;s&&/^\d+(\s*,\s*\d+){3}$/.test(s)&&(i=s.split(/\s*,\s*/).map(e=>parseInt(e,10)));const[o,n,a,c]=i;t(A.getImageData(o,n,a,c).data)},o=()=>{i(new Error("Image load failed"))};e.complete?s():(e.onload=s,e.onerror=o)}),i=[];for(let e=0;e<t.length;e+=4){const r=t[e],A=t[e+1],s=t[e+2];if(t[e+3]<255)continue;const o=Es(r,A,s);i.push(o)}const r=lo.quantize(i,128);return po.score(r)[0]}(e);return mo(i,t)}function fo(e,t){const i=t?.target||document.body;if(Eo(i,t?.dark??!1?e.schemes.dark:e.schemes.light),t?.brightnessSuffix&&(Eo(i,e.schemes.dark,"-dark"),Eo(i,e.schemes.light,"-light")),t?.paletteTones){const r=t?.paletteTones??[];for(const[t,A]of Object.entries(e.palettes)){const e=t.replace(/([a-z])([A-Z])/g,"$1-$2").toLowerCase();for(const t of r){const r=`--md-ref-palette-${e}-${e}${t}`,s=vo(A.tone(t));i.style.setProperty(r,s)}}}}function Eo(e,t,i=""){for(const[r,A]of Object.entries(t.toJSON())){const t=r.replace(/([a-z])([A-Z])/g,"$1-$2").toLowerCase(),s=vo(A);e.style.setProperty(`--md-sys-color-${t}${i}`,s)}}po.TARGET_CHROMA=48,po.WEIGHT_PROPORTION=.7,po.WEIGHT_CHROMA_ABOVE=.3,po.WEIGHT_CHROMA_BELOW=.1,po.CUTOFF_CHROMA=5,po.CUTOFF_EXCITED_PROPORTION=.01;class Co{constructor(e,t,i){this._initialExpressiveLoad=!1,this._updatingTheme=!1,this.onActiveTrackChange=e=>{const t=e.detail;if("current"!=t.type)return;const i=t.image;this.applyExpressiveThemeFromImage(i)},this._expressiveTheme=new s(i,{context:Ui}),this._useExpressive=new s(i,{context:Ti}),this._groupMembers=new s(i,{context:bi}),this._groupVolume=new s(i,{context:Ii}),this._activeEntityConfig=new s(i,{context:mi}),this._activeEntityID=new s(i,{context:wi}),this._activeMediaPlayer=new s(i,{context:Ei}),this._activePlayerName=new s(i,{context:fi}),this._volumeMediaPlayer=new s(i,{context:Ci}),this._hass=e,this.config=t,this._host=i,i.addEventListener("artwork-updated",this.onActiveTrackChange),this.setDefaultActivePlayer(),er(e,this.activeMediaPlayer,this.activeEntityConfig)&&this.expressiveTheme||this.applyExpressiveTheme()}set hass(e){this._hass=e;$i(this.activeMediaPlayer,e.states[this.activeEntityID])&&this.setActivePlayer(this.activeEntityID)}get hass(){return this._hass}set config(e){this._config=e,this.useExpressive=e.expressive}get config(){return this._config}set useExpressive(e){this._useExpressive.setValue(e)}get useExpressive(){return this._useExpressive.value}set activeEntityConfig(e){this._activeEntityConfig.setValue(e);const t=this.hass.states;this.activePlayerName=this.activeEntityConfig.name,this.volumeMediaPlayer=t[this.activeEntityConfig.volume_entity_id],this.activeMediaPlayer=t[this.activeEntityConfig.entity_id],this.activeEntityID=this.activeEntityConfig.entity_id}get activeEntityConfig(){return this._activeEntityConfig.value}set activeEntityID(e){this._activeEntityID.setValue(e)}get activeEntityID(){return this._activeEntityID.value}set activeMediaPlayer(e){if($i(this.activeMediaPlayer,e)&&(this._activeMediaPlayer.setValue(e),this.dispatchUpdatedActivePlayer(),e.attributes?.group_members&&this.setGroupAttributes(),!this._expressiveTheme)){const t=e.attributes.entity_picture_local??e.attributes.entity_picture;this.applyExpressiveThemeFromImage(t)}}get activeMediaPlayer(){return this._activeMediaPlayer.value}set activePlayerName(e){if(e.length)return void this._activePlayerName.setValue(e);const t=this.hass.states[this.activeEntityConfig.entity_id];this._activePlayerName.setValue(t.attributes.friendly_name??"")}get activePlayerName(){return this._activePlayerName.value}set groupMembers(e){!tr(this._groupMembers.value,e)&&e&&this._groupMembers.setValue(e)}get groupMembers(){return this._groupMembers.value}set groupVolume(e){this._groupVolume.value!=e&&this._groupVolume.setValue(e)}get groupVolume(){return this._groupVolume.value}set volumeMediaPlayer(e){if(!e)return;const t=this.volumeMediaPlayer?.attributes,i=e?.attributes;t?.volume_level==i?.volume_level&&t?.is_volume_muted==i?.is_volume_muted||this._volumeMediaPlayer.setValue(e)}get volumeMediaPlayer(){return this._volumeMediaPlayer.value}set expressiveTheme(e){this._expressiveTheme.setValue(e)}get expressiveTheme(){return this._expressiveTheme.value}dispatchUpdatedActivePlayer(){const e=new CustomEvent("active-player-updated",{detail:this.activeMediaPlayer});this._host.dispatchEvent(e)}setGroupAttributes(){this.groupMembers=this.getGroupedPlayers().map(e=>e.entity_id),this._getAndSetGroupedVolume()}getGroupedPlayers(){const e=this.activeMediaPlayer.attributes.active_queue;return this.config.entities.filter(t=>{const i=this.hass.states[t.entity_id]?.attributes;return i?.active_queue==e&&"group"!=i.mass_player_type})}setDefaultActivePlayer(){const e=this.hass.states,t=this._config.entities,i=t.filter(t=>{const i=e[t.entity_id];return er(this.hass,i,t)});i.length?this.activeEntityConfig=i[0]:this.activeEntityConfig=t[0]}setActivePlayer(e){const t=this.config.entities.find(t=>t.entity_id==e);t&&(this.activeEntityConfig=t)}getactivePlayerData(e){const t=this.activeMediaPlayer,i=this.volumeMediaPlayer;return{playing:"playing"==t?.state,repeat:t?.attributes?.repeat??!1,shuffle:t?.attributes?.shuffle??!1,track_album:t?.attributes?.media_album_name??"",track_artist:t?.attributes?.media_artist??"",track_artwork:t?.attributes?.entity_picture_local??t?.attributes?.entity_picture,track_title:t?.attributes?.media_title??"",muted:i?.attributes?.is_volume_muted??!0,volume:Math.floor(100*i?.attributes?.volume_level)??0,player_name:this.activePlayerName,favorite:e?.favorite??!1}}async getPlayerProgress(){if(!er(this.hass,this.activeMediaPlayer,this.activeEntityConfig))return 0;const e=await this.actionGetCurrentQueue();return e?.elapsed_time??0}async getPlayerActiveItemDuration(){if(!er(this.hass,this.activeMediaPlayer,this.activeEntityConfig))return 1;const e=await this.actionGetCurrentQueue();return e?.current_item?.duration??1}async actionGetCurrentQueue(){const e=this.activeEntityID,t={type:"call_service",domain:"music_assistant",service:"get_queue",service_data:{entity_id:e},return_response:!0};return(await this.hass.callWS(t)).response[e]}applyExpressiveThemeTo(e){this.expressiveTheme&&fo(this.expressiveTheme,{dark:this.hass.themes.darkMode,target:e})}async applyExpressiveThemeFromImage(e){if(!this.config.expressive||this._updatingTheme)return;const t=this.generateExpressiveThemeFromImage(e),i={dark:this.hass.themes.darkMode,target:this._host};this._updatingTheme=!0;const r=await t;r&&fo(r,i),this._updatingTheme=!1}async generateExpressiveThemeFromImage(e){const t=this.generateImageElementFromImage(e);if(!t)return;const i=await wo(t);return this.expressiveTheme=i,i}generateImageElementFromImage(e){const t=document.createElement("img"),i=nr(this.hass,Gt.CLEFT);return t.src=e,t.crossOrigin="Anonymous",t.onerror=()=>{t.src=i},t}async applyExpressiveTheme(){if(!this.config.expressive)return;const e=this.generateExpressiveTheme(),t={dark:this.hass.themes.darkMode,target:this._host},i=await e;i&&fo(i,t)}async generateExpressiveTheme(){return this.generateExpressiveThemeFromActiveImage()}generateImageElementFromActiveImage(){const e=this.activeMediaPlayer.attributes,t=nr(this.hass,Gt.CLEFT),i=window.location.origin,r=e.entity_picture_local,A=e.entity_picture,s=`${i}${r??A}`,o=er(this.hass,this.activeMediaPlayer,this.activeEntityConfig)?s??t:t,n=document.createElement("img");return n.height=75,n.width=75,n.src=o,n.onerror=()=>{n.src=t},n}async generateExpressiveThemeFromActiveImage(){const e=this.generateImageElementFromActiveImage();if(!e)return;const t=await wo(e);return this.expressiveTheme=t,t}async _getAndSetGroupedVolume(){const e=this.activeMediaPlayer.entity_id,t=await this.getGroupedVolume(e);this.groupVolume=t}async setGroupedVolume(e,t){await this.hass.callWS({type:"call_service",domain:"mass_queue",service:"set_group_volume",service_data:{entity:e,volume_level:t}})}async setActiveGroupVolume(e){await this.setGroupedVolume(this.activeMediaPlayer.entity_id,e),this.groupVolume=e}async getActiveGroupVolume(){return await this.getGroupedVolume(this.activeMediaPlayer.entity_id)}async getGroupedVolume(e){return(await this.hass.callWS({type:"call_service",domain:"mass_queue",service:"get_group_volume",service_data:{entity:e},return_response:!0})).response.volume_level??0}disconnected(){this._host.removeEventListener("artwork-updated",this.onActiveTrackChange)}reconnected(e){this.hass=e,this._host.addEventListener("artwork-updated",this.onActiveTrackChange),this.setActivePlayer(this.activeEntityID)}}class Bo{constructor(e,t){this.hass=e,this.player_entity=t}set hass(e){e&&(this._hass=e)}get hass(){return this._hass}set player_entity(e){this._player_entity=e}get player_entity(){return this._player_entity}async getQueue(e,t){return(await this.hass.callWS({type:"call_service",domain:"mass_queue",service:"get_queue_items",service_data:{entity:this.player_entity,limit_before:e,limit_after:t},return_response:!0})).response[this.player_entity]}async playQueueItem(e){try{await this.hass.callService("mass_queue","play_queue_item",{entity:this.player_entity,queue_item_id:e})}catch(e){console.error("Error selecting queue item",e)}}async removeQueueItem(e){try{await this.hass.callService("mass_queue","remove_queue_item",{entity:this.player_entity,queue_item_id:e})}catch(e){console.error("Error removing queue item",e)}}async MoveQueueItemNext(e){try{await this.hass.callService("mass_queue","move_queue_item_next",{entity:this.player_entity,queue_item_id:e})}catch(e){console.error("Error moving queue item next",e)}}async MoveQueueItemUp(e){try{await this.hass.callService("mass_queue","move_queue_item_up",{entity:this.player_entity,queue_item_id:e})}catch(e){console.error("Error moving queue item up",e)}}async MoveQueueItemDown(e){try{await this.hass.callService("mass_queue","move_queue_item_down",{entity:this.player_entity,queue_item_id:e})}catch(e){console.error("Error moving queue item down",e)}}async clearQueue(e=this.player_entity){await this.hass.callService("media_player","clear_playlist",{entity_id:e})}async getLocalImage(e){if("string"!=typeof e)return"";try{return await this.hass.callWS({type:"mass_queue/download_and_encode_image",url:e})}catch(e){return console.error("Error getting image",e),""}}}class bo{constructor(e,t,i){this._host=e,this._hass=t,this.setEntityConfig(i),this._setupActions()}setEntityConfig(e){this._entityConf=e;const t=e.entity_id,i=e.volume_entity_id;this._activeEntity=this._hass.states[t],this._volumeEntity=this._hass.states[i],this._activeEntityId=t,this._volumeEntityId=i}set hass(e){this._hass=e,this._updateActions()}_setupActions(){this._browserActions=new Sr(this._hass),this._playerActions=new kA(this._hass),this._playersActions=new WA(this._hass),this._queueActions=new Bo(this._hass,this._activeEntityId)}_updateActions(){this._hass&&(this._browserActions.hass=this._hass,this._playerActions.hass=this._hass,this._playersActions.hass=this._hass,this._queueActions.hass=this._hass,this._activeEntityId&&(this._activeEntity=this._hass.states[this._activeEntityId]),this._volumeEntityId&&(this._volumeEntity=this._hass.states[this._volumeEntityId])),this._queueActions.player_entity=this._activeEntityId}async actionTogglePower(){await this.PlayerActions.actionTogglePlayer(this._activeEntity)}async actionPlayPause(){await this.PlayerActions.actionPlayPause(this._activeEntity)}async actionPlayNext(){await this.PlayerActions.actionNext(this._activeEntity)}async actionPlayPrevious(){await this.PlayerActions.actionPrevious(this._activeEntity)}async actionToggleShuffle(){await this.PlayerActions.actionShuffleToggle(this._activeEntity)}async actionSetRepeat(e){await this.PlayerActions.actionRepeatSet(this._activeEntity,e)}async actionSeek(e){await this.PlayerActions.actionSeek(this._activeEntity,e)}async actionAddFavorite(){await this.PlayerActions.actionAddFavorite(this._activeEntity)}async actionRemoveFavorite(){await this.PlayerActions.actionRemoveFavorite(this._activeEntity)}async actionSetVolume(e){const t=e>1?e/100:e;await this.PlayerActions.actionSetVolume(this._volumeEntity,t)}async actionToggleMute(){await this.PlayerActions.actionMuteToggle(this._volumeEntity)}get browserActions(){return this._browserActions}get PlayerActions(){return this._playerActions}get playersActions(){return this._playersActions}get queueActions(){return this._queueActions}disconnected(){}reconnected(e){this.hass=e}}class Io{constructor(e,t,i,r){this._fails=0,this._listening=!1,this._timedListening=!1,this._updatingQueue=!1,this.getQueue=async()=>{const e=this.config.entities,t=this.activeMediaPlayer.entity_id,i=e.find(e=>e.entity_id==t);if(er(this.hass,this.activeMediaPlayer,i)){return this._getQueue()}return this.queue=[],[]},this.timedListener=()=>{try{clearInterval(this._interval)}finally{this._interval=void 0}this._interval=setInterval(this.timedListener,1e4),this.getQueue()},this.eventListener=e=>{const t=e.data,i=t.data?.queue_id;if("queue_updated"==t.type&&i==this._activeQueueID){if(this._updatingQueue)return;this.getQueue()}},this.hass=e,this.config=i,this._host=r,this._queue=new s(r,{context:Vi}),this._currentQueueItem=new s(r,{context:Fi}),this._nextQueueItem=new s(r,{context:zi}),this._previousQueueItem=new s(r,{context:Yi}),this._actions=new Bo(e,t.entity_id),this.activeMediaPlayer=t,this.getQueue(),this.subscribeUpdates()}set queue(e){tr(this._queue.value,e)||this._queue.setValue(e)}get queue(){return this._queue.value}set hass(e){this._hass=e,this.activeMediaPlayer&&(this.activeMediaPlayer=e.states[this.activeMediaPlayer.entity_id])}get hass(){return this._hass}set activeMediaPlayer(e){if(this._activeMediaPlayer){if(!$i(e,this._activeMediaPlayer))return}this._activeMediaPlayer=e,this._activeQueueID=e.attributes.active_queue,this.actions.player_entity=e.entity_id,this.getQueue()}get activeMediaPlayer(){return this._activeMediaPlayer}set config(e){this._config=e}get config(){return this._config}set actions(e){this._actions=e}get actions(){return this._actions}set currentQueueItem(e){tr(this._currentQueueItem.value,e)||this._currentQueueItem.setValue(e)}get currentQueueItem(){return this._currentQueueItem.value}set nextQueueItem(e){tr(this._nextQueueItem.value,e)||this._nextQueueItem.setValue(e)}get nextQueueItem(){return this._nextQueueItem.value}set previousQueueItem(e){tr(this._previousQueueItem.value,e)||this._previousQueueItem.setValue(e)}get previousQueueItem(){return this._previousQueueItem.value}setActiveEntityId(e){this.activeMediaPlayer=this.hass.states[e]}raiseQueueFailure(){console.error("Reached max failures getting queue, check your browser and HA logs!")}setActiveTrack(e){const t=this.activeMediaPlayer.attributes.media_content_id,i=e.findIndex(e=>e.media_content_id==t)??-1;return i>=0&&(e[i].playing=!0),e}resetQueueFailures(){this._fails=0,this.getQueue()}async _getQueue(){if(this._updatingQueue)return;this._updatingQueue=!0;const e=this.config.queue.limit_before,t=this.config.queue.limit_after;if(this._fails>=6)return this.raiseQueueFailure(),void(this._updatingQueue=!1);try{let i=await this.actions.getQueue(e,t);return i?(this._fails=0,i=this.setActiveTrack(i),this.queue=i,this.getCurNextPrQueueItems(),this._updatingQueue=!1,i):void(this._updatingQueue=!1)}catch{this._fails++}finally{this._updatingQueue=!1}return[]}get isSubscribed(){return this._listening||this._timedListening}async subscribeUpdates(){this.unsubscribeUpdates(),this.hass.user.is_admin?(this._unsubscribe=await this.hass.connection.subscribeEvents(this.eventListener,"mass_queue"),this._listening=!0):(this.timedListener(),this._timedListening=!0)}unsubscribeUpdates(){if(this._unsubscribe&&(this._unsubscribe(),this._unsubscribe=void 0),this._interval)try{clearInterval(this._interval)}finally{this._interval=void 0}}getCurNextPrQueueItems(){const e=this.queue;if(!e)return;const t=e.findIndex(e=>e.playing);this.currentQueueItem=e[t],this.previousQueueItem=t>0?e[t-1]:null,t<e.length-1?this.nextQueueItem=e[t+1]:this.nextQueueItem=null}setItemActive(e){if(!this.queue)return;const t=this.getIndex(e);if(!t)return;this.queue[t].playing=!0;const i=this.queue.findIndex(e=>e.playing);this.queue[i].playing=!1}getIndex(e){if(!this.queue)return;const t=this.queue.findIndex(t=>t.queue_item_id==e);return t}moveQueueItem(e,t){if(!this.queue)return;const i=[...this.queue];i.splice(t,0,i.splice(e,1)[0]),this.queue=i}async playQueueItem(e){this.setItemActive(e),await this.actions.playQueueItem(e)}async moveQueueItemUp(e){const t=this.getIndex(e);t&&(this.moveQueueItem(t,t-1),await this.actions.MoveQueueItemUp(e))}async moveQueueItemDown(e){const t=this.getIndex(e);t&&(this.moveQueueItem(t,t+1),await this.actions.MoveQueueItemDown(e))}async moveQueueItemNext(e){if(!this.queue)return;const t=this.getIndex(e);if(!t)return;const i=this.queue.findIndex(e=>e.playing)+1;this.moveQueueItem(t,i),await this.actions.MoveQueueItemNext(e)}async removeQueueItem(e){this.queue&&(this.queue=this.queue.filter(t=>t.queue_item_id!==e),await this.actions.removeQueueItem(e))}async clearQueue(e=this.activeMediaPlayer.entity_id){await this.actions.clearQueue(e)}disconnected(){this.unsubscribeUpdates()}reconnected(e){this.hass=e,this.subscribeUpdates(),this.resetQueueFailures(),this.getQueue()}}async function yo(e,t,i){const r=[...Array(4).keys()],A=[];r.forEach(r=>{const s=r%t.length;A.push(async function(e,t,i=Gt.DISC){const r=await Ar(e,t,i);return W` <div class="thumbnail-section" style="${r}"></div> `}(e,t[s]?.thumbnail??i,i))});const s=await Promise.all(A);let o=W``;return s.forEach(e=>{o=W` ${o} ${e} `}),W`
    <div
      class="thumbnail"
      style="display: grid; grid-template-columns: 1fr 1fr; padding-bottom: 0%; height: unset; width: unset; padding-left: unset; padding-right: unset;"
    >
      ${o}
    </div>
  `}function Qo(e){return e.map(e=>({title:e.name,thumbnail:e.image,fallback:Gt.CLEFT,data:{type:"service",media_content_id:e.media_content_id,media_content_type:e.media_content_type,service:e.service}}))}function Do(e,t){const i=ii[t];return e.map(e=>({title:e.name,thumbnail:e.image,fallback:i,data:{type:"service",media_content_id:e.uri,media_content_type:e.media_type}}))}class Ro{constructor(e,t,i,r){this.hass=e,this.config=t,this._host=r,this._items=new s(r,{context:Xi}),this.actions=new Sr(e),this.browserConfig=t.media_browser,this.activeEntityId=i,this.items||this.resetAndGenerateSections()}set items(e){if(tr(this._items.value,e))return;const t={...e};this._items.setValue(t)}get items(){return this._items.value}resetAndGenerateSections(){this.items={favorites:{main:[]},recents:{main:[]},recommendations:{main:[]},search:[]},this.generateAllSections()}generateAllSections(){const e=[this.generateAllFavorites(),this.generateAllRecents(),this.generateAllRecommendations()];Promise.all(e).then(()=>{this.generateCustomSections();const e={section:"all",cards:this.items},t=new CustomEvent("cards-updated",{detail:e});this._host.dispatchEvent(t)})}set activeEntityId(e){e!=this._activeEntityId&&(this._activeEntityId=e,this.resetAndGenerateSections())}get activeEntityId(){return this._activeEntityId}async search(e,t,i,r=!1,A=20){return Do(await this.actions.actionSearchMedia(e,t,i,r,A),i)}async generateAllFavorites(){const e=this.browserConfig.favorites,t=[this.generateFavoriteData(e.albums,Kt.ALBUM),this.generateFavoriteData(e.artists,Kt.ARTIST),this.generateFavoriteData(e.audiobooks,Kt.AUDIOBOOK),this.generateFavoriteData(e.playlists,Kt.PLAYLIST),this.generateFavoriteData(e.podcasts,Kt.PODCAST),this.generateFavoriteData(e.radios,Kt.RADIO),this.generateFavoriteData(e.tracks,Kt.TRACK)];await Promise.all(t);const i={section:"favorites",cards:this.items.favorites},r=new CustomEvent("cards-updated",{detail:i});this._host.dispatchEvent(r)}async getFavoriteSection(e,t,i=!0){const r=e.limit,A=e.items;return[...Do(await this.actions.actionGetLibrary(this.activeEntityId,t,r,i),t),...Qo(A)]}async generateFavoriteData(e,t,i=!0){if(this.items.favorites[t]||!e.enabled)return;const r=await this.getFavoriteSection(e,t,i);if(!r.length)return;const A={...this.items};A.favorites[t]=r;const s=await async function(e,t,i){const r=ii[t];return{title:ti(`browser.sections.${t}`,e),background:await yo(e,i,r),thumbnail:r,fallback:r,data:{type:"section",subtype:"favorites",section:t}}}(this.hass,t,r);A.favorites.main.push(s),this.items={...A}}async generateAllRecents(){const e=this.browserConfig.recents,t=[this.generateRecentsData(e.albums,Kt.ALBUM),this.generateRecentsData(e.artists,Kt.ARTIST),this.generateRecentsData(e.audiobooks,Kt.AUDIOBOOK),this.generateRecentsData(e.playlists,Kt.PLAYLIST),this.generateRecentsData(e.podcasts,Kt.PODCAST),this.generateRecentsData(e.radios,Kt.RADIO),this.generateRecentsData(e.tracks,Kt.TRACK)];await Promise.all(t);const i={section:"recents",cards:this.items.recents},r=new CustomEvent("cards-updated",{detail:i});this._host.dispatchEvent(r)}async getRecentSection(e,t){const i=e.limit;return[...Do(await this.actions.actionGetLibraryRecents(this.activeEntityId,t,i),t)]}async generateRecentsData(e,t){if(this.items.recents[t]||!e.enabled)return;const i=await this.getRecentSection(e,t);if(i.length){const e=await async function(e,t,i){const r=ii[t];return{title:ti(`browser.sections.${t}`,e),background:await yo(e,i,r),thumbnail:r,fallback:r,data:{type:"section",subtype:"recents",section:t}}}(this.hass,t,i),r={...this.items};r.recents.main.push(e),r.recents[t]=i,this.items={...r}}}async generateRecommendationSection(e){if(this.items.recommendations[e.name])return;const t=function(e){return e.items.map(e=>({title:e.name,thumbnail:e.image,fallback:Gt.CLEFT,data:{type:"service",media_content_id:e.uri??e.item_id,media_content_type:e.media_type}}))}(e);if(t.length){const i=await async function(e,t,i){const r=Gt.CLEFT;return{title:t.name,background:await yo(e,i,r),thumbnail:r,fallback:r,data:{type:"section",subtype:"recommendations",section:t.name}}}(this.hass,e,t),r={...this.items};r.recommendations.main.push(i),r.recommendations[e.name]=t,this.items={...r}}}async generateAllRecommendations(){const e=this.browserConfig.recommendations.providers??null;(await this.actions.actionGetRecommendations(this.activeEntityId,e)).response.response.forEach(e=>{this.generateRecommendationSection(e)});const t={section:"recommendations",cards:this.items.recommendations},i=new CustomEvent("cards-updated",{detail:t});this._host.dispatchEvent(i)}generateCustomSections(){this.browserConfig.sections.forEach(e=>{this.generateCustomSectionData(e)})}generateCustomSectionData(e){const t={title:e.name,thumbnail:e.image,fallback:Gt.CLEFT,data:{type:"section",subtype:"favorites",section:`custom-${e.name}`}},i=Qo(e.items),r={...this.items};r.favorites[`custom-${e.name}`]=i,r.favorites.main.push(t),this.items={...r}}disconnected(){}reconnected(e){this.hass=e,this.resetAndGenerateSections()}}class ko{constructor(e){this._hass=new s(document.body,{context:vi}),this._connected=!0,this._reconnected=!1,this.host=e,this.configController=new cs(e),this._activeSection=new s(this.host,{context:Pi})}set host(e){this._host=e}get host(){return this._host}setupIfReady(){this._setupActiveController(),this._setupActionsController(),this._setupQueueController(),this._setupBrowserController()}_setupActiveController(){if(this.hass&&this.config&&!this.activePlayerController){const e=new Co(this.hass,this.config,this.host);this.activePlayerController=new s(this.host,{context:Hi}),this.activePlayerController.setValue(e)}}_setupActionsController(){const e=!!(this.activePlayerController&&this.config&&this.hass);!this.actionsController&&e&&(this.actionsController=new s(this.host,{context:Si}),this.actionsController.setValue(new bo(this.host,this.hass,this.ActivePlayer.activeEntityConfig)))}_setupQueueController(){this.hass&&this.activeEntity&&this.config&&!this.queueController&&(this.queueController=new s(this.host,{context:qi}),this.queueController.setValue(new Io(this.hass,this.activeEntity,this.config,this.host)))}_setupBrowserController(){this.hass&&this.config&&this.activeEntityId&&!this.browserController&&(this.browserController=new s(this.host,{context:Li}),this.browserController.setValue(new Ro(this.hass,this.config,this.activeEntityId,this.host)))}set hass(e){this._hass.value=e,this.setupIfReady(),this.ActivePlayer.hass=e,this.Actions.hass=e,this.Queue.hass=e,this._reconnected&&(this._reconnected=!1,this.hassReconnected())}get hass(){return this._hass.value}set config(e){tr(this.configController.config,e)||(this.configController.config=e,this.setupIfReady())}get config(){return this.configController.config}get Config(){return this.configController}set activeEntityId(e){this.ActivePlayer.setActivePlayer(e),this.Actions.setEntityConfig(this.ActivePlayer.activeEntityConfig),this.Queue.setActiveEntityId(e),this.Browser.activeEntityId=e}get activeEntityId(){return this.ActivePlayer.activeEntityID}get activeEntity(){return this.ActivePlayer.activeMediaPlayer}get volumeEntity(){return this.ActivePlayer.volumeMediaPlayer}set activeSection(e){if(e!=this.activeSection){this._activeSection.setValue(e);const t=new CustomEvent("section-changed",{detail:e});this.host.dispatchEvent(t)}}get activeSection(){return this._activeSection.value}get ActivePlayer(){return this.activePlayerController.value}get Actions(){return this.actionsController.value}get Queue(){return this.queueController.value}get Browser(){return this.browserController.value}disconnected(){this.ActivePlayer.disconnected(),this.Actions.disconnected(),this.Queue.disconnected(),this.Browser.disconnected(),this._connected=!1}connected(){this._connected=!0,this._reconnected=!0}hassReconnected(){this.ActivePlayer.reconnected(this.hass),this.Actions.reconnected(this.hass),this.Queue.reconnected(this.hass),this.Browser.reconnected(this.hass)}translate(e){return ti(e,this.hass)}}const xo="mass-player-card",Po="Music Assistant Player Card";console.info(`%c ${Po} \n%c Version v2.2.0`,"color: teal; font-weight: bold; background: lightgray","color: darkblue; font-weight: bold; background: white"),window.customCards=window.customCards||[],window.customCards.push({type:`${xo}`,name:`${Po}`,preview:!1,description:"Music Assistant Player Card for Home Assistant",documentationURL:"https://github.com/droans/mass-player-card"});let Mo=class extends ve{constructor(){super(...arguments),this._controller=new ko(this),this.setActivePlayer=e=>{e.length&&(this._controller.activeEntityId=e)},this.browserItemSelected=()=>{this.config.player.enabled&&(this.active_section=Gi.MUSIC_PLAYER,this._controller.activeSection=Gi.MUSIC_PLAYER)},this.playerSelected=e=>{this.setActivePlayer(e),this.config.player.enabled&&(this.active_section=Gi.MUSIC_PLAYER,this._controller.activeSection=Gi.MUSIC_PLAYER)},this.onSectionChangedEvent=e=>{this.active_section=e.detail}}set hass(e){if(!e)return;const t=this.config.entities;let i=!1;this._controller.hass=e;const r=[];t.forEach(t=>{const A=this.hass.states[t.entity_id],s=e.states[t.entity_id];r.push(e.states[t.entity_id]),tr(A,s)||(i=!0)}),i&&(this._controller.hass=e,this.entities=r)}get hass(){return this._controller.hass}set config(e){this._config=e,this._controller.config=e}get config(){return this._controller.config}set active_section(e){this._activeSection=e}get active_section(){return this._activeSection??this._controller.activeSection}setActiveSection(e){this._controller.activeSection=e}static getConfigForm(){return{schema:[{name:"entities",required:!0,selector:{entity:{multiple:!0,integration:"music_assistant",domain:"media_player"}}},{name:"expressive",required:!1,selector:{boolean:{},default:!0}},{name:"download_local",required:!1,selector:{boolean:{},default:!1}},{name:"player",type:"expandable",iconPath:hr,schema:[{name:"enabled",selector:{boolean:{}},default:!0},vr(mA)]},{name:"queue",type:"expandable",iconPath:gr,schema:[{name:"enabled",selector:{boolean:{}},default:!0},{name:"",type:"grid",schema:[{name:"limit_before",selector:{number:{min:0,max:500,mode:"box"}}},{name:"limit_after",selector:{number:{min:0,max:500,mode:"box"}}},{name:"show_album_covers",selector:{boolean:{}}},{name:"show_artist_names",selector:{boolean:{}}}]},vr(LA)]},{name:"media_browser",type:"expandable",iconPath:cr,schema:[{name:"enabled",selector:{boolean:{}},default:!0},{name:"columns",selector:{number:{min:1,max:10,mode:"box"}}},{name:"favorites",type:"expandable",iconPath:dr,schema:[yr("album"),yr("artists"),yr("audiobooks"),yr("playlists"),yr("podcasts"),yr("radios"),yr("tracks")]},{name:"recents",type:"expandable",iconPath:ur,schema:[yr("album"),yr("artists"),yr("audiobooks"),yr("playlists"),yr("podcasts"),yr("radios"),yr("tracks")]},{name:"recommendations",type:"expandable",iconPath:lr,schema:[{name:"enabled",selector:{boolean:{}},default:!0},{name:"providers",selector:{text:{multiple:!0}}}]},vr(Ir)]},{name:"players",type:"expandable",iconPath:pr,schema:[{name:"enabled",selector:{boolean:{}},default:!0},vr(KA)]}]}}static getStubConfig(e,t){return function(e,t){return{entities:[t.filter(e=>"media_player"==e.split(".")[0]).filter(t=>e.states[t]?.attributes?.mass_player_type)[0]]}}(e,t)}setConfig(e){if(!e)throw this.createError("Invalid configuration");if(!e.entities)throw this.createError("You need to define entities.");this._controller.config=e,this.config=this._controller.config,this.active_section||this.setDefaultActiveSection(),this.requestUpdate()}setDefaultActiveSection(){this.active_section||(this._controller.activeSection=function(e){const t=Wi,i={[Gi.MUSIC_PLAYER]:e.player.enabled,[Gi.QUEUE]:e.queue.enabled,[Gi.PLAYERS]:e.players.enabled,[Gi.MEDIA_BROWSER]:e.media_browser.enabled},r=Object.entries(i).filter(e=>e[1]).map(e=>e[0]);return t.filter(e=>r.includes(e))[0]}(this.config))}shouldUpdate(e){if(e.has("activeEntityConfig")||e.has("active_section"))return!0;if(e.has("hass")){const t=e.get("hass");if(!t)return!0;const i=t.states,r=this.hass.states;let A=!1;return this.config.entities.forEach(e=>{i[e.entity_id]!==r[e.entity_id]&&(A=!0)}),A}return super.shouldUpdate(e)}renderPlayers(){return this.config.players.enabled?Ye(Be`
        <wa-tab-panel
          name="${Gi.PLAYERS}"
          class="section${this.active_section==Gi.PLAYERS?"":"-hidden"}"
        >
          <mass-player-players-card
            .selectedPlayerService=${this.playerSelected}
            .config=${this.config}
          ></mass-player-players-card>
        </wa-tab-panel>
      `):Be``}renderMusicPlayer(){return this.config.player.enabled?Ye(Be`
        <wa-tab-panel
          name="${Gi.MUSIC_PLAYER}"
          class="section${this.active_section==Gi.MUSIC_PLAYER?"":"-hidden"}"
        >
          <mass-music-player-card
            .selectedPlayerService=${this.playerSelected}
          ></mass-music-player-card>
        </wa-tab-panel>
      `):Be``}renderPlayerQueue(){return this.config.queue.enabled?Ye(Be`
        <wa-tab-panel
          name="${Gi.QUEUE}"
          class="section${this.active_section==Gi.QUEUE?"":"-hidden"}"
        >
          <mass-player-queue-card
            .config=${this.config.queue}
          ></mass-player-queue-card>
        </wa-tab-panel>
      `):Be``}renderMediaBrowser(){return this.config.media_browser.enabled?Ye(Be`
        <wa-tab-panel
          name="${Gi.MEDIA_BROWSER}"
          class="section${this.active_section==Gi.MEDIA_BROWSER?"":"-hidden"}"
        >
            <mass-media-browser
              .config=${this.config.media_browser}
              .onMediaSelectedAction=${this.browserItemSelected}
            >
          </wa-animation>
        </wa-tab-panel>
      `):Be``}renderTabs(){return Be`
      <div
        id="navbar${this.config.expressive&&this.active_section==Gi.MUSIC_PLAYER?"-expressive":""}"
      >
        ${this.config.expressive?Be`<mass-nav-bar-expressive></mass-nav-bar-expressive>`:Be`<mass-nav-bar></mass-nav-bar>`}
      </div>
    `}renderSections(){return Be`
      ${this.renderMusicPlayer()} ${this.renderPlayerQueue()}
      ${this.renderMediaBrowser()} ${this.renderPlayers()}
    `}render(){return this.error??Be`
        <ha-card id="${this.config.expressive?"expressive":""}">
          ${this.renderSections()} ${this.renderTabs()}
        </ha-card>
      `}static get styles(){return ss}connectedCallback(){super.connectedCallback(),this.shadowRoot?.querySelectorAll("wa-animation").forEach(e=>{e.play=!0}),this._controller&&(this._controller.Queue.resetQueueFailures(),this._controller.Queue.subscribeUpdates(),this.hasUpdated&&this._controller.connected())}disconnectedCallback(){super.disconnectedCallback(),this._controller.disconnected()}firstUpdated(){if(this.config.expressive){const e=os.styleSheet;document.adoptedStyleSheets.push(e)}this.addEventListener("section-changed",this.onSectionChangedEvent)}getCardSize(){return 3}createError(e){const t=new Error(e),i=document.createElement("hui-error-card");return i.setConfig({type:"error",error:t,origConfig:this.config}),this.error=Be`${i}`,t}};e([De()],Mo.prototype,"entities",void 0),e([De()],Mo.prototype,"error",void 0),e([De()],Mo.prototype,"_activeSection",void 0),e([o({context:Oi})],Mo.prototype,"_controller",void 0),e([o({context:yi})],Mo.prototype,"_config",void 0),e([n({context:Pi,subscribe:!0}),De()],Mo.prototype,"active_section",null),Mo=e([be(`${xo}`)],Mo);export{Mo as MusicAssistantPlayerCard};
